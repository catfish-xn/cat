const fs=require('node:fs'),cp=require('node:child_process'),assert=require('node:assert/strict'),ts=require(process.cwd()+'/node_modules/typescript');
const before=cp.execFileSync('git',['show','a50d6e819be8c5f227882765b64bf0c5bcb4e341:scripts/verify-m6-performance.cjs'],{encoding:'utf8'}),after=fs.readFileSync('scripts/verify-m6-performance.cjs','utf8');
const parse=s=>ts.createSourceFile('s.cjs',s,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS),a=parse(before),b=parse(after);
function nodes(root,p){const out=[];function walk(n){if(p(n))out.push(n);ts.forEachChild(n,walk)}walk(root);return out}
const checks=[];const check=(name,fn)=>{fn();checks.push(name)};
const evaluate=n=>ts.isCallExpression(n)&&n.expression.getText()==='page.evaluate';
const old=nodes(a,evaluate),now=nodes(b,evaluate);
check('Original three measurement callback functions byte-identical',()=>{
 const inner=nodes(now[0].arguments[0],n=>ts.isArrowFunction(n)&&n.parameters[0]?.name.getText()==='fixtures');
 assert.equal(inner.length,1);assert.equal(inner[0].getText(b),old[0].arguments[0].getText(a));
 assert.deepEqual(old.slice(1).map(n=>n.getText(a)),now.slice(1).map(n=>n.getText(b)));assert.equal(now.length,3);
});
check('Every measured function and budget/dependency call unchanged',()=>{const names=['measure','measured','assertBoundedImportGate','skipB6Dependency','defer'];const calls=x=>nodes(x,n=>ts.isCallExpression(n)&&names.includes(n.expression.getText())).map(n=>n.getText(x));assert.deepEqual(calls(a),calls(b))});
check('Original route generation and chosen payload unchanged',()=>{const start='  const routes=[];',end="  diagnosticPhase('browser-launch');";assert.equal(before.slice(before.indexOf(start),before.indexOf(end)),after.slice(after.indexOf(start),after.indexOf(end)))});
check('Nonasync wrapper deletes staging then returns original promise',()=>{const wrapper=now[0].arguments[0];assert(!wrapper.modifiers?.some(m=>m.kind===ts.SyntaxKind.AsyncKeyword));assert(wrapper.getText(b).includes('const fixtures=globalThis.__M6_PERF_FIXTURES;delete globalThis.__M6_PERF_FIXTURES;'));assert.equal(now[0].arguments.length,1)});
check('Browser graph signature only in separate page after all timed callbacks',()=>{const signatureCall=after.indexOf('verificationHandle.evaluate(fixtureSignature)');assert(signatureCall>after.indexOf("diagnosticPhase('bounded-import-returned')"));assert(!after.includes('fixtureHandle.evaluate(fixtureSignature)'));assert(after.includes('await stageFixtureGroups(page,fixtures,transport.groups);'))});
check('Original performance outcome preserved',()=>assert(after.includes("const failures=report.measurements.gates.filter(g=>g.status!=='skipped'&&!g.passed);assert.equal(failures.length,0,`Frozen performance budget exceeded: ${JSON.stringify(failures)}`);report.passed=true;")));
console.log(JSON.stringify({checks,scope:'AST/text only; real Chromium pending'},null,2));
