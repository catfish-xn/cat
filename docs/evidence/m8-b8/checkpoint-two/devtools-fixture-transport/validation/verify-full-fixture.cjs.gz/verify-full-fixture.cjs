const fs=require('node:fs'),v8=require('node:v8'),assert=require('node:assert/strict');
const transport=require(process.cwd()+'/scripts/m6-fixture-transport.cjs');
(async()=>{
 const input=v8.deserialize(fs.readFileSync('/tmp/b8-payload-diagnosis/fixtures-preserve-identity.v8'));
 const {groups,summaries}=transport.inspectFixtureGroups(input);assert.deepEqual(summaries.map(g=>g.encodedArgumentBytes),[75143636,32212896]);
 const original=await transport.fixtureSignature(input);assert.equal(original.uniqueObjects,518938);assert.equal(original.aliasCount,19685);assert.equal(original.valueSha256,'091351986d70ca5f08a9aec5881e35d3ddace5946fcff9eb5d2b08681ab20ec4');
 const handles=[];const page={async evaluateHandle(_f,g){const h={value:structuredClone(g),disposed:false,async dispose(){this.disposed=true}};handles.push(h);return h},async evaluate(f,args){return f({...args,first:args.first.value,second:args.second.value})}};
 await transport.stageFixtureGroups(page,input,groups);assert(handles.every(h=>h.disposed));const received=globalThis.__M6_PERF_FIXTURES;delete globalThis.__M6_PERF_FIXTURES;
 assert.deepEqual(received,input);assert.deepEqual(await transport.fixtureSignature(received),original);
 console.log(JSON.stringify({scope:'Full actual fixture + simulated native handle staging; not Chromium',summaries,original,allHandlesDisposedBeforeCallback:true,completeValueAndAliasGraphEqual:true},null,2));
})().catch(e=>{console.error(e);process.exitCode=1});
