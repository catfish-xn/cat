const fs=require('node:fs'),cp=require('node:child_process'),vm=require('node:vm'),assert=require('node:assert/strict'),{EventEmitter}=require('node:events');
const ts=require(process.cwd()+'/node_modules/typescript');
const before=cp.execFileSync('git',['show','5e8ea0e:scripts/verify-m6-performance.cjs'],{encoding:'utf8'}),after=fs.readFileSync('scripts/verify-m6-performance.cjs','utf8');
const parse=s=>ts.createSourceFile('s.cjs',s,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS),a=parse(before),b=parse(after);
function nodes(root,p){const out=[];function walk(n){if(p(n))out.push(n.getText(root));ts.forEachChild(n,walk)}walk(root);return out}
const checks=[];function check(name,fn){fn();checks.push(name)}
check('All three page.evaluate bodies byte-identical',()=>{const p=n=>ts.isCallExpression(n)&&n.expression.getText()==='page.evaluate';assert.deepEqual(nodes(a,p),nodes(b,p));assert.equal(nodes(a,p).length,3)});
check('Launch, goto, gates, skip, close, clock calls unchanged',()=>{const names=['chromium.launch','page.goto','assertBoundedImportGate','skipB6Dependency','browser?.close','server?.close','performance.now'];const p=n=>ts.isCallExpression(n)&&names.includes(n.expression.getText());assert.deepEqual(nodes(a,p),nodes(b,p))});
check('Entire route generation and payload block identical',()=>{const start='  const routes=[];',end="  diagnosticPhase('browser-launch');";assert.equal(before.slice(before.indexOf(start),before.indexOf(end)),after.slice(after.indexOf(start),after.indexOf(end)))});
check('No CI or production edit',()=>{const files=cp.execFileSync('git',['diff','--name-only'],{encoding:'utf8'}).trim().split('\n');assert.deepEqual(files,['scripts/verify-m6-performance.cjs'])});
check('Page/context/crash exact handlers simulated',()=>{
 const context=new EventEmitter(),page=new EventEmitter();page.isClosed=()=>true;page.context=()=>context;const browser={isConnected:()=>false};const records=[];
 const handlers=after.slice(after.indexOf("  page.on('close'"),after.indexOf('  report.errors=[]'));
 vm.runInNewContext(handlers,{page,browser,diagnostic:(event,details)=>records.push({event,details})});page.emit('close');context.emit('close');page.emit('crash');
 assert.deepEqual(records.map(r=>r.event),['page-close','context-close','page-crash']);assert(records.every(r=>r.details.browserConnected===false));
});
console.log(JSON.stringify({scope:'Static AST and simulated events, not Chromium validation',checks},null,2));
