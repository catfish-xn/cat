const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const root=process.cwd(),source=fs.readFileSync('scripts/verify-m6-performance.cjs','utf8');
const prefix=source.slice(0,source.indexOf("const {skipB6Dependency}"));
for(const prior of [undefined,'pw:api','-pw:*','custom:* -pw:api']){
 const environment={};if(prior!==undefined)environment.DEBUG=prior;
 vm.runInNewContext(prefix,{process:{env:environment}});
 assert.equal(environment.DEBUG,[prior??'','pw:browser'].filter(Boolean).join(','));
 console.log(JSON.stringify({test:'DEBUG-preservation',prior:prior??null,effective:environment.DEBUG}));
}
vm.runInThisContext(prefix);
const {chromium}=require(path.join(root,'node_modules/playwright'));
(async()=>{
 for(const action of ['page.close','browser.close','cleanup']){
  const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
  const page=await browser.newPage();let diagnosticCleanupStarted=false;const events=[];
  const diagnostic=(event,details={})=>{const record={event,cleanupStarted:diagnosticCleanupStarted,details};events.push(record);console.log(JSON.stringify({action,...record}));};
  const listeners=source.slice(source.indexOf("  page.on('close'"),source.indexOf('  report.errors=[]'));
  vm.runInNewContext(listeners,{page,browser,diagnostic});
  browser.on('disconnected',()=>diagnostic('browser-disconnected',{connected:browser.isConnected()}));
  if(action==='page.close'){
   diagnostic('active-call',{location:'diagnostic-harness:page.close'});await page.close();
   assert(events.some(e=>e.event==='page-close'));assert(browser.isConnected());
  }else{
   if(action==='cleanup')diagnosticCleanupStarted=true;
   diagnostic('active-call',{location:'diagnostic-harness:browser.close'});await browser.close();
   assert(events.some(e=>e.event==='page-close'));assert(events.some(e=>e.event==='context-close'));assert(events.some(e=>e.event==='browser-disconnected'));
  }
  diagnostic('catch-state-control',{pageClosed:page.isClosed(),browserConnected:browser.isConnected()});
  diagnosticCleanupStarted=true;await browser.close();
 }
})().catch(error=>{console.error(error);process.exitCode=1});
