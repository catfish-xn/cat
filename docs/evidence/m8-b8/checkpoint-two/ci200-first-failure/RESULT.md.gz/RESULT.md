# CI200 fixed c854 first-attempt result

https://github.com/catfish-xn/cat/actions/runs/38031091668

Fixed HEAD c8543e192589cdc52b2a2119a45d5bfd613d8bf7. Attempt1 completed failure at2026-10-10T07:08:57Z. All12 executed jobs' original checkout logs match this SHA. No retries, cancellations, repository edits or gate changes were made by the monitor.

## Outcomes

- 10 workloads succeeded: six dev/preview cannon/sniper/mage browser jobs, input-preview, U3 dynamic, M7 presentation, retention.
- 2 workloads failed: test-and-build114152012079 and input-dev114152012025.
- compare-evidence skipped because prerequisites failed; optional heap-diagnostics and warmup-experiment skipped as configured. No final cross-mode comparison executed.
- All six browser jobs actually ran normal-time browser routes, with durations676.840–774.885s. They did not fail at golden preflight. Their coverage still explicitly excludes B9 rounds6-5/6-6/6-7 and complete application archive; fullApplicationRoutePassed=false.
- Both native-input31case segments passed with5 pre-existing B8 component/Rageblade deferrals. Both touch-cannon routes passed their executed coverage (dev679.136s, preview802.843s). Preview's full job passed. Dev later failed during M6 performance; it is not an input/golden preflight failure.

## Original tests

131files:128passed,3failed.1857tests:1840passed,7failed,10skipped. Duration836.93s. Existing10skips remain explicit.

- M5 sniper replay, tests/m5-replay.test.ts:7:64, timed out at180000ms.
- B5 all43 eligible child definitions, tests/m8-b5-temporary.test.ts:187:3, timed out at5000ms.
- Five B7 Herald equipment variants, tests/m8-b7-match-wiring.test.ts:121:75 and130:42, timed out at5000ms: three aura-maintenance cases and quicksilver/edge-of-night immunity cases.

These original CI failures remain preserved independently of later test-fixture repairs and future candidate CI. The M5 replay180s timeout is additional to the six local5s failures previously reported. Test failure prevented this job's subsequent build/headless/performance commands; artifact name headless is not proof those ran.

## Independent dev-input performance failure

verify-m6-performance.cjs:54:34 failed with page.evaluate: Target page, context or browser has been closed. Original manifest m6-performance-failure.json records five domain-route preparations completed in85520.7ms, Chromium153.0.8010.12 opened, then evaluate failed. errors=[]; no completed measurements. Total102850.2ms; peakProcessRssBytes2397937664; runner memory16766414848. The available evidence does not establish OOM, flakiness or an exact page-close root cause. Native-input and touch-route passes do not excuse this failure. Later retry/application-failure commands in that shell step were not established as executed.

The manifest simultaneously retains the old full-load15-equipment B8-deferral wording and reports fullLoadCoverage with15equipped units. Preserve this discrepancy; do not infer the complete deferred performance/import gate passed from a coverage row.

## Budget

M7 budget succeeded: productiongzip9=502900B, M7baseline424763B, ratio1.1839543463060578<=1.30; interactive medians623/600ms, ratio1.0383333333333333<=1.20. This is separate from the B8 stage cumulative/all-export budget and is not independent proof of that different limit.

## Evidence saved

All12 complete executed job logs, initial/final run metadata, final job metadata, all12 originalartifact ZIPs totaling251988973B, GitHub artifact metadata and SHA256 integrity manifest. All12 local ZIP digests exactly match GitHub. selected/ contains manifest/budget/timingJSON extracts. artifact-integrity.json maps files and hashes. Exact job URLs follow https://github.com/catfish-xn/cat/actions/runs/38031091668/job/<job-id>.

CI200 is a failed historical candidate record, not acceptance of checkpoint two, B8/B9, or any subsequently repaired SHA.
