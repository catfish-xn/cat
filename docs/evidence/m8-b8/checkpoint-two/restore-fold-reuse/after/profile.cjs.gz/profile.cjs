var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key3 of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key3) && key3 !== except)
        __defProp(to, key3, { get: () => from[key3], enumerable: !(desc = __getOwnPropDesc(from, key3)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// tests/fixtures/m5/oracle.cjs
var require_oracle = __commonJS({
  "tests/fixtures/m5/oracle.cjs"(exports2, module2) {
    "use strict";
    var assert2 = require("node:assert/strict");
    var CATALOG = [[], ["darius", "irelia", "lux", "maddie", "zyra"], ["leona", "rell", "tristana", "urgot", "vander"], ["ezreal", "kogmaw", "loris", "nami", "scar"], ["corki", "garen", "zoe"], ["caitlyn"]];
    var COST = Object.fromEntries(CATALOG.flatMap((ids2, cost) => ids2.map((id2) => [id2, cost])));
    var ODDS = { 1: [100, 0, 0, 0, 0], 2: [100, 0, 0, 0, 0], 3: [75, 25, 0, 0, 0], 4: [55, 30, 15, 0, 0], 5: [45, 33, 20, 2, 0], 6: [30, 40, 25, 5, 0], 7: [19, 30, 40, 10, 1], 8: [18, 25, 32, 22, 3], 9: [15, 20, 25, 30, 10] };
    var XP = { 1: 2, 2: 2, 3: 6, 4: 10, 5: 20, 6: 36, 7: 48, 8: 76 };
    var AUGMENTS = ["bulky-buddies-i", "glass-cannon-i", "investment-strategy-i", "manaflow-i", "placebo", "pumping-up-i"];
    var ANOMALIES = ["kill-streak", "mage-armor", "titanic-strikes"];
    var COMPONENTS = ["sword", "vest", "belt", "rod", "cloak", "bow", "gloves", "tear"];
    var SELL = { 1: [1, 3, 9], 2: [2, 5, 17], 3: [3, 8, 26], 4: [4, 11, 35], 5: [5, 14, 44] };
    function word(value) {
      return Number((BigInt(value) * 1664525n + 1013904223n) % 4294967296n);
    }
    function shop(rng, generation, level, locked = false) {
      const slots = [];
      for (let i = 0; i < 5; i++) {
        rng = word(rng);
        const roll = Number(BigInt(rng) * 100n / 4294967296n);
        let total = 0, cost = 0;
        for (let j = 0; j < 5; j++) {
          total += ODDS[level][j];
          if (roll < total) {
            cost = j + 1;
            break;
          }
        }
        rng = word(rng);
        const bucket = CATALOG[cost];
        slots.push({ status: "available", definitionId: bucket[Number(BigInt(rng) * BigInt(bucket.length) / 4294967296n)] });
      }
      return { rngState: rng, shop: { generation, slots, locked } };
    }
    function xp(level, value, amount3) {
      let applied = 0;
      while (amount3 > 0 && level < 9) {
        const take = Math.min(amount3, XP[level] - value);
        amount3 -= take;
        applied += take;
        value += take;
        if (value === XP[level]) {
          value = 0;
          level++;
        }
      }
      return { level, xp: value, xpApplied: applied };
    }
    var ROUND_IDS = [
      "1-2",
      "1-3",
      "1-4",
      "2-1",
      "2-2",
      "2-3",
      "2-4",
      "2-5",
      "2-6",
      "2-7",
      "3-1",
      "3-2",
      "3-3",
      "3-4",
      "3-5",
      "3-6",
      "3-7",
      "4-1",
      "4-2",
      "4-3",
      "4-4",
      "4-5",
      "4-6",
      "4-7",
      "5-1",
      "5-2",
      "5-3",
      "5-4",
      "5-5",
      "5-6",
      "5-7",
      "6-1",
      "6-2",
      "6-3",
      "6-4",
      "6-5",
      "6-6",
      "6-7"
    ];
    var ROUNDS = ROUND_IDS.map((roundId, index) => {
      const [stage, sub] = roundId.split("-").map(Number);
      return { roundId, ordinal: index + 1, stage, sub, kind: stage === 1 ? "pve" : sub === 4 ? "supply" : sub === 7 ? "pve" : "pvp" };
    });
    function roundOrdinal(id2) {
      const round2 = ROUNDS.find((r) => r.roundId === id2);
      assert2(round2, `Unknown independent round ${id2}`);
      return round2.ordinal;
    }
    function ungrantedLootGold(before, combat2) {
      if (before.seed === void 0 || !combat2) return 0;
      const drops = lootPlan(before.seed, before.round).rounds.find((r) => r.encounterPlan.roundId === ROUNDS[before.round - 1].roundId)?.encounterPlan.drops ?? [];
      return drops.filter((d) => d.payload.kind === "gold" && !before.m8?.loot.receipts.some((r) => r.dropId === d.dropId) && combat2.neutralReceipts?.deaths.some((e) => e.unitId === d.sourceUnitId) && combat2.units.some((u) => u.id === d.sourceUnitId && u.team === "enemy" && !u.alive)).reduce((sum, d) => sum + d.payload.quantity, 0);
    }
    function settlement(before, combat2, goldBefore = before.gold + ungrantedLootGold(before, combat2)) {
      const round2 = before.round, definition = ROUNDS[round2 - 1];
      assert2(definition, "Round outside approved campaign");
      const { roundId, stage, sub, kind: roundKind } = definition, result = combat2?.result ?? "supply";
      const survivingEnemyCount = combat2?.units.filter((u) => u.team === "enemy" && u.alive).length ?? 0;
      let streakAfter = before.streak;
      if (roundKind === "pvp") {
        const kind = result === "playerWin" ? "win" : "loss";
        streakAfter = { kind, count: before.streak.kind === kind ? before.streak.count + 1 : 1 };
      }
      const base = stage === 1 ? { 2: 2, 3: 3, 4: 5 }[sub] : 5, naturalXp = stage === 1 && sub === 4 ? 0 : 2;
      const win = roundKind === "pvp" && result === "playerWin" ? 1 : 0, interestBasis = goldBefore + win;
      const interest = stage === 1 ? 0 : Math.min(5, Math.floor(interestBasis / 10));
      const streak = roundKind !== "pvp" ? 0 : streakAfter.count >= 6 ? 3 : streakAfter.count >= 4 ? 2 : streakAfter.count >= 2 ? 1 : 0;
      const baseDamage = roundKind === "pvp" ? [2, 5, 8, 10, 12][stage - 2] : roundKind === "pve" ? 3 : 0;
      const playerDamage = result === "playerWin" || roundKind === "supply" ? 0 : roundKind === "pve" ? 3 : baseDamage + survivingEnemyCount;
      const progression = xp(before.level, before.xp, naturalXp), income = base + win + interest + streak, hpLost = Math.min(before.playerHp, playerDamage);
      return {
        round: round2,
        roundId,
        result,
        combatTicks: combat2?.tick ?? 0,
        combatEventCount: combat2?.nextEventSeq ?? 0,
        settlementId: `round-${round2}-settled`,
        roundKind,
        incomeBreakdown: { base, win, interest, streak },
        interestBasis,
        streakBefore: before.streak,
        streakAfter,
        xpRequested: naturalXp,
        income,
        goldBefore,
        goldAfter: goldBefore + income,
        xpAwarded: progression.xpApplied,
        levelBefore: before.level,
        levelAfter: progression.level,
        xpBefore: before.xp,
        xpAfter: progression.xp,
        hpBefore: before.playerHp,
        hpAfter: before.playerHp - hpLost,
        baseDamage,
        survivingEnemyCount,
        playerDamage,
        hpLost
      };
    }
    var LOOT_HEROES = [[], ["darius", "irelia", "lux", "maddie", "zyra"], ["leona", "vander", "rell", "tristana", "urgot"], ["loris", "ezreal", "scar", "kogmaw", "nami"], ["corki", "garen", "zoe"]];
    var LOOT_TABLE = [
      ["1-2", "minions-a-v1", [["m01", 0, "unit", "maddie"]]],
      ["1-3", "minions-b-v1", [["m01", 0, "unit", "lux"], ["r01", 0, "choice"]]],
      ["1-4", "minions-c-v1", [["r01", 0, "choice"]]],
      ["2-7", "krugs-v1", [["k01", 0, "component"], ["k01", 1, "extra", 1], ["k02", 0, "choice"]]],
      ["3-7", "wolves-v1", [["w00", 0, "component"], ["w00", 1, "extra", 2], ["w01", 0, "choice"]]],
      ["4-7", "razorbeaks-v1", [["r00", 0, "component"], ["r00", 1, "extra", 3], ["r01", 0, "choice"]]],
      ["5-7", "elder-dragon-v1", [["d01", 0, "component"], ["d01", 1, "choice"], ["d01", 2, "extra", 4]]],
      ["6-7", "rift-herald-v1", [["h01", 0, "gold", 5]]]
    ];
    var counterKey2 = (id2) => JSON.stringify(["m8b-loot-project-v1", id2, "components-granted"]);
    var receiptId = (id2) => JSON.stringify([id2, "grant"]);
    var choiceId = (id2) => JSON.stringify(["m8b-loot-choice", id2]);
    function lootIndex(rng, n) {
      const limit = 4294967296n / BigInt(n) * BigInt(n);
      let state = rng.state, draws = rng.draws;
      do {
        state = word(state);
        draws++;
      } while (BigInt(state) >= limit);
      return { index: state % n, rng: { state, draws } };
    }
    var lootPlans = /* @__PURE__ */ new Map();
    function lootPlan(seed, ordinal) {
      const key3 = JSON.stringify([seed, ordinal]);
      if (lootPlans.has(key3)) return lootPlans.get(key3);
      assert2(Number.isInteger(seed) && seed >= 0 && seed <= 4294967295);
      assert2(Number.isInteger(ordinal) && ordinal >= 0 && ordinal <= 38);
      let rng = { state: (seed ^ 3735928559) >>> 0, draws: 0 };
      const rounds = [];
      const draw = (n) => {
        const next = lootIndex(rng, n);
        rng = next.rng;
        return next.index;
      };
      for (const [roundId, encounterId, slots] of LOOT_TABLE) {
        if (roundOrdinal(roundId) > ordinal) break;
        const drops = [], choices = [];
        for (const [local, slotOrdinal, kind, value] of slots) {
          const sourceUnitId = JSON.stringify(["pve", roundId, encounterId, local]);
          const identity = { roundId, encounterId, sourceUnitId, slotOrdinal, dropId: JSON.stringify([roundId, encounterId, sourceUnitId, slotOrdinal]) };
          if (kind === "choice") {
            choices.push({ ...identity, kind: "component-choice", quantity: 1, poolVersion: "m8b-components-v1", terminalFallbackDefinitionId: COMPONENTS[draw(8)], revealCondition: "source-killed" });
            continue;
          }
          let payload;
          if (kind === "unit") payload = { kind: "unit", definitionId: value, quantity: 1 };
          if (kind === "gold") payload = { kind: "gold", quantity: value };
          if (kind === "component") payload = { kind: "item", definitionId: COMPONENTS[draw(8)], quantity: 1 };
          if (kind === "extra") {
            const roll = draw(100), gold = roll < (value === 4 ? 70 : 75) ? value : value === 4 && roll < 80 ? 5 : 0;
            payload = gold ? { kind: "gold", quantity: gold } : { kind: "unit", definitionId: LOOT_HEROES[value][draw(LOOT_HEROES[value].length)], quantity: 1 };
          }
          drops.push({ ...identity, payload, status: "planned", revealCondition: "source-killed", receiptId: null });
        }
        rounds.push({ encounterPlan: { roundId, encounterId, policyVersion: "m8b-pve-project-v1", drops }, choices });
      }
      const freeze = (value) => {
        if (value && typeof value === "object") {
          Object.values(value).forEach(freeze);
          Object.freeze(value);
        }
        return value;
      };
      const result = freeze({ rng, rounds });
      lootPlans.set(key3, result);
      return result;
    }
    function appended(before, after, key3, label) {
      assert2.deepEqual(after.slice(0, before.length), before, `${label} append-only`);
      assert2.equal(new Set(after.map((x) => x[key3])).size, after.length, `${label} unique identity`);
      return after.slice(before.length);
    }
    function bare(event) {
      const { domain, eventSeq, ...value } = event;
      return value;
    }
    function validateLoot(state) {
      const loot = state.m8.loot, expected = lootPlan(state.seed, state.round), frozen = loot.frozen;
      assert2.equal(frozen.version, "m8-b8-loot-freeze-v1");
      assert2.equal(frozen.seed, state.seed);
      assert2.equal(frozen.throughRoundOrdinal, state.round);
      assert2.deepEqual(frozen.rounds, expected.rounds, "independent frozen loot source/payload/fallback");
      assert2.deepEqual(frozen.rng, expected.rng, "independent loot RNG conservation");
      const direct = expected.rounds.flatMap((r) => r.encounterPlan.drops), choices = expected.rounds.flatMap((r) => r.choices);
      const entries = new Map([...direct, ...choices].map((d) => [d.dropId, d]));
      assert2.deepEqual(loot.direct.map((d) => d.dropId), direct.map((d) => d.dropId), "direct loot identity");
      assert2.deepEqual(loot.choiceEligibility.map((d) => d.dropId), choices.map((d) => d.dropId), "choice loot identity");
      for (const [records, key3, label] of [[loot.receipts, "receiptId", "loot receipt"], [loot.receipts, "dropId", "loot drop receipt"], [loot.earnedEvidence, "dropId", "earned loot"], [loot.choiceResolutions, "dropId", "choice resolution"]]) assert2.equal(new Set(records.map((r) => r[key3])).size, records.length, `${label} unique identity`);
      const earned = new Map(loot.earnedEvidence.map((e) => [e.dropId, e]));
      for (const evidence of earned.values()) {
        const entry = entries.get(evidence.dropId);
        assert2(entry, "earned loot must have approved source");
        assert2.equal(evidence.death.combatId, `round-${roundOrdinal(entry.roundId)}`, "earned combat identity");
        assert2(Number.isSafeInteger(evidence.death.tick) && evidence.death.tick >= 0);
        assert2(Number.isSafeInteger(evidence.death.eventSeq) && evidence.death.eventSeq >= 0);
        if (entry.roundId === state.roundDefinitionId) {
          const combat2 = state.combat;
          assert2(combat2, "earned loot requires combat");
          assert2(combat2.units.some((u) => u.id === entry.sourceUnitId && u.team === "enemy" && u.unitKind === "neutral" && !u.alive), "earned source must be dead");
          const deaths = combat2.neutralReceipts.deaths.filter((d) => d.unitId === entry.sourceUnitId);
          assert2.equal(deaths.length, 1, "unique source death");
          assert2.deepEqual(evidence.death, { combatId: combat2.combatId, tick: deaths[0].tick, eventSeq: deaths[0].eventSeq }, "earned source death identity");
          assert2(evidence.death.tick <= combat2.tick && evidence.death.eventSeq < combat2.nextEventSeq, "earned death boundary");
        }
      }
      const receipts = new Map(loot.receipts.map((r) => [r.dropId, r]));
      const resolutions = new Map(loot.choiceResolutions.map((r) => [r.dropId, r]));
      for (const drop of loot.direct) {
        assert2(["planned", "revealed", "pending-capacity", "retained-terminal", "forfeited", "granted"].includes(drop.status));
        assert2.equal(earned.has(drop.dropId), !["planned", "forfeited"].includes(drop.status), "direct earned-only status");
        assert2.equal(receipts.has(drop.dropId), drop.status === "granted", "direct actual receipt");
        assert2.equal(drop.receiptId, drop.status === "granted" ? receiptId(drop.dropId) : null);
        if (["pending-capacity", "retained-terminal"].includes(drop.status)) assert2.equal(entries.get(drop.dropId).payload.kind, "unit", "only heroes wait for capacity");
      }
      for (const choice of loot.choiceEligibility) {
        assert2(["planned", "revealed", "forfeited"].includes(choice.status));
        assert2.equal(earned.has(choice.dropId), choice.status === "revealed", "choice earned-only status");
        assert2.equal(receipts.has(choice.dropId), resolutions.has(choice.dropId), "choice receipt and resolution atomic");
        if (resolutions.has(choice.dropId)) assert2.equal(choice.status, "revealed", "resolved choice is earned");
      }
      const itemIds = [], unitIds = [], counters = Object.fromEntries(LOOT_TABLE.map(([id2]) => [counterKey2(id2), 0]));
      for (const receipt of loot.receipts) {
        const entry = entries.get(receipt.dropId);
        assert2(entry, "receipt must have approved source");
        assert2(earned.has(receipt.dropId), "receipt must be earned");
        assert2.equal(receipt.receiptId, receiptId(receipt.dropId), "canonical loot receipt");
        if (entry.payload) assert2.deepEqual(receipt.payload, entry.payload, "independent loot receipt payload");
        else {
          const resolution = resolutions.get(receipt.dropId);
          assert2(resolution, "choice resolution required");
          assert2.equal(resolution.receiptId, receipt.receiptId);
          assert2(["player-choice", "terminal-fallback"].includes(resolution.method));
          assert2.deepEqual(receipt.payload, { kind: "item", definitionId: receipt.payload.definitionId, quantity: 1 });
          assert2(COMPONENTS.includes(receipt.payload.definitionId), "all eight component candidates only");
          if (resolution.method === "terminal-fallback") {
            assert2.equal(receipt.payload.definitionId, entry.terminalFallbackDefinitionId, "pre-frozen terminal fallback");
            assert2.equal(state.phase, "gameOver", "terminal fallback remains terminal");
          }
        }
        const { payload, grantedItemIds, grantedUnitIds } = receipt;
        assert2.equal(grantedItemIds.length, payload.kind === "item" ? 1 : 0, "actual loot item count");
        assert2.equal(grantedUnitIds.length, payload.kind === "unit" ? 1 : 0, "actual loot unit count");
        itemIds.push(...grantedItemIds);
        unitIds.push(...grantedUnitIds);
        if (payload.kind === "item") counters[counterKey2(entry.roundId)]++;
      }
      for (const resolution of resolutions.values()) assert2(choices.some((c) => c.dropId === resolution.dropId) && receipts.has(resolution.dropId), "resolution requires actual choice receipt");
      assert2.equal(new Set(itemIds).size, itemIds.length, "unique loot item identities");
      assert2.equal(new Set(unitIds).size, unitIds.length, "unique loot unit births");
      assert2.deepEqual(loot.guaranteeCounters, counters, "actual-only component counters");
      const pending = state.pendingChoice;
      if (pending?.kind === "component") {
        const descriptor = choices.find((c) => choiceId(c.dropId) === pending.choiceId);
        if (descriptor) {
          assert2(earned.has(descriptor.dropId) && !resolutions.has(descriptor.dropId), "pending earned choice");
          assert2.deepEqual(pending, { kind: "component", step: "offer", choiceId: choiceId(descriptor.dropId), eventId: choiceId(descriptor.dropId), generation: 0, returnPhase: "settlement", offers: COMPONENTS, targetId: null, rerollCount: 0 }, "complete loot choice");
        } else assert2.equal(pending.eventId, `round:${state.roundDefinitionId}:supply`, "schedule component source");
      }
      for (const receipt of state.scheduleReceipts) {
        const round2 = ROUNDS[receipt.round - 1];
        assert2(round2, "schedule round");
        const kind = round2.kind === "supply" ? "component" : ["2-1", "3-2", "4-2"].includes(round2.roundId) ? "augment" : round2.roundId === "4-6" ? "anomaly" : null;
        assert2(kind, "approved schedule receipt source");
        assert2.equal(receipt.kind, kind);
        assert2.equal(receipt.eventId, `round:${round2.roundId}:${kind === "component" ? "supply" : kind}`, "schedule namespace");
      }
      return entries;
    }
    function validateLootTransition(before, after, command, events) {
      const prior = before.m8.loot, next = after.m8.loot, entries = validateLoot(after);
      const receipts = appended(prior.receipts, next.receipts, "receiptId", "loot receipts");
      const earned = appended(prior.earnedEvidence, next.earnedEvidence, "dropId", "loot evidence");
      const resolved = appended(prior.choiceResolutions, next.choiceResolutions, "dropId", "loot resolutions");
      assert2.deepEqual(events.filter((e) => e.type === "lootGranted").map((e) => e.receipt), receipts, "exactly one event per actual loot receipt");
      assert2.deepEqual(events.filter((e) => e.type === "lootRevealed").map((e) => bare(e)), earned.map((e) => ({ type: "lootRevealed", ...e })), "exactly one event per earned loot");
      assert2.deepEqual(events.filter((e) => e.type === "lootChoiceResolved").map((e) => bare(e)), resolved.map((e) => ({ type: "lootChoiceResolved", ...e })), "exactly one event per choice resolution");
      const newlyForfeited = [...next.direct, ...next.choiceEligibility].filter((d) => d.status === "forfeited" && ![...prior.direct, ...prior.choiceEligibility].some((p) => p.dropId === d.dropId && p.status === "forfeited"));
      assert2.deepEqual(events.filter((e) => e.type === "lootForfeited").map((e) => e.dropId), newlyForfeited.map((d) => d.dropId), "exactly one event per loot forfeit");
      for (const drop of newlyForfeited) {
        assert2.equal(after.combat?.status, "finished", "forfeit only after combat");
        assert2.equal(entries.get(drop.dropId).roundId, after.roundDefinitionId, "forfeit only current round");
      }
      for (const evidence of earned) {
        const entry = entries.get(evidence.dropId);
        assert2(events.some((e) => e.domain === "combat" && e.type === "death" && e.unitId === entry.sourceUnitId && e.tick === evidence.death.tick && e.eventSeq === evidence.death.eventSeq), "reveal requires this transition actual source death");
      }
      for (const receipt of receipts) {
        assert2.equal(after.combat?.status, "finished", "loot only after combat");
        const entry = entries.get(receipt.dropId);
        assert2.equal(entry.roundId, after.roundDefinitionId, "grant only current round");
        for (const id2 of receipt.grantedItemIds) assert2.equal(after.items.find((i) => i.id === id2)?.definitionId, receipt.payload.definitionId, "actual granted component definition");
      }
      for (const resolution of resolved) {
        if (resolution.method === "terminal-fallback") assert2.equal(after.phase, "gameOver", "fallback only terminal");
        else {
          assert2.equal(command?.type, "select", "player choice needs command");
          assert2.equal(command.choiceId, choiceId(resolution.dropId));
          assert2.equal(command.generation, 0);
          assert2.equal(command.definitionId, receipts.find((r) => r.dropId === resolution.dropId).payload.definitionId);
        }
      }
      return receipts;
    }
    function investment(before, record4) {
      return { pumpingRounds: before.augmentProgress.pumpingRounds + (before.augments.some((a) => a.definitionId === "pumping-up-i") ? 1 : 0), investmentHp: before.augmentProgress.investmentHp + (before.augments.some((a) => a.definitionId === "investment-strategy-i") ? 8 * record4.incomeBreakdown.interest : 0) };
    }
    var Ledger = class {
      constructor(initial) {
        this.gold = 0;
        this.cards = 1;
        this.combinations = 0;
        this.costs = { purchases: 0, sales: 0, saleLoss: 0, rerolls: 0, xp: 0, anomaly: 0, income: 0, rewards: 0 };
        this.rows = [];
        this.receipts = /* @__PURE__ */ new Set();
        this.check(initial);
      }
      apply(before, after, command, events = []) {
        const lootReceipts = validateLootTransition(before, after, command, events);
        let choice = before.choiceRngState, reward = before.rewardRngState, battle = before.battleSeedRngState;
        if (command?.type === "start") battle = word(battle);
        if (command?.type === "target" || command?.type === "anomalyReroll") {
          choice = word(choice);
          const pool = ANOMALIES.filter((id2) => command.type !== "anomalyReroll" || !before.pendingChoice.offers.includes(id2));
          assert2.deepEqual(after.pendingChoice.offers, [pool[Number(BigInt(choice) * BigInt(pool.length) / 4294967296n)]], "independent anomaly offer");
        }
        for (const event of events) {
          if (event.type === "choiceOpened" && event.choice.kind === "augment") {
            const pool = AUGMENTS.filter((id2) => !after.augments.some((a) => a.definitionId === id2));
            for (let i = 0; i < 3; i++) {
              choice = word(choice);
              const j = i + choice % (pool.length - i);
              [pool[i], pool[j]] = [pool[j], pool[i]];
            }
            assert2.deepEqual(event.choice.offers, pool.slice(0, 3), "independent augment offers");
          }
          if (event.type === "rewardGranted") {
            reward = word(reward);
            assert2.equal(event.receipt.itemIds.length, 1);
            assert2.equal(after.items.find((i) => i.id === event.receipt.itemIds[0]).definitionId, COMPONENTS[reward % 8], "independent random component");
          }
        }
        assert2.equal(after.choiceRngState, choice, "choice RNG conservation");
        assert2.equal(after.rewardRngState, reward, "reward RNG conservation");
        assert2.equal(after.battleSeedRngState, battle, "battle seed RNG conservation");
        const domain = events.filter((e) => e.domain === "match");
        assert2.deepEqual(domain.map((e) => e.eventSeq), domain.map((_, i) => before.nextMatchEventSeq + i), "match event sequence");
        assert2.equal(after.nextMatchEventSeq, before.nextMatchEventSeq + domain.length);
        const costs = this.costs, units = new Map(before.preparation.units.filter((u) => u.team === "player").map((u) => [u.id, { definitionId: u.definitionId, starLevel: u.starLevel }]));
        let serial = before.nextUnitSerial;
        if (command?.type === "buy") {
          const definitionId2 = before.shop.slots[command.slot].definitionId, cost = COST[definitionId2];
          this.gold -= cost;
          costs.purchases += cost;
          this.cards++;
          units.set(`unit-${serial++}`, { definitionId: definitionId2, starLevel: 1 });
        }
        if (command?.type === "sell") {
          const unit = before.preparation.units.find((u) => u.id === command.id), cost = COST[unit.definitionId], copies = 3 ** (unit.starLevel - 1), value = SELL[cost][unit.starLevel - 1];
          this.gold += value;
          costs.sales += value;
          costs.saleLoss += cost * copies - value;
          this.cards -= copies;
          units.delete(unit.id);
        }
        for (const [type, cost, key3] of [["reroll", 2, "rerolls"], ["buyXp", 4, "xp"], ["anomalyReroll", 1, "anomaly"]]) if (command?.type === type) {
          this.gold -= cost;
          costs[key3] += cost;
        }
        for (const receipt of lootReceipts) {
          if (receipt.payload.kind === "gold") {
            this.gold += receipt.payload.quantity;
            costs.rewards += receipt.payload.quantity;
          }
          if (receipt.payload.kind === "unit") {
            assert2.deepEqual(receipt.grantedUnitIds, [`unit-${serial}`], "true loot candidate serial");
            units.set(`unit-${serial++}`, { definitionId: receipt.payload.definitionId, starLevel: 1 });
            this.cards++;
          }
        }
        assert2.equal(after.nextUnitSerial, serial, "unit serial accounting");
        for (const event of events.filter((e) => e.type === "unitUpgraded")) {
          assert2.equal(event.consumedIds.length, 2);
          assert2.equal((/* @__PURE__ */ new Set([event.survivorId, ...event.consumedIds])).size, 3);
          for (const id2 of [event.survivorId, ...event.consumedIds]) assert2.deepEqual(units.get(id2), { definitionId: event.definitionId, starLevel: event.fromStar }, "upgrade consumes actual candidate lineage");
          assert2.equal(event.toStar, event.fromStar + 1);
          for (const id2 of event.consumedIds) units.delete(id2);
          units.set(event.survivorId, { definitionId: event.definitionId, starLevel: event.toStar });
        }
        assert2.deepEqual(new Map(after.preparation.units.filter((u) => u.team === "player").map((u) => [u.id, { definitionId: u.definitionId, starLevel: u.starLevel }])), units, "actual player unit lineage");
        const schedule = appended(before.scheduleReceipts, after.scheduleReceipts, "eventId", "schedule receipts");
        for (const receipt of schedule) {
          assert2(!this.receipts.has(receipt.eventId), "schedule receipt only once");
          this.receipts.add(receipt.eventId);
          this.gold += receipt.gold;
          costs.rewards += receipt.gold;
        }
        let itemSerial = before.nextItemSerial;
        for (const receipt of lootReceipts) for (const id2 of receipt.grantedItemIds) assert2.equal(id2, `item-${itemSerial++}`, "loot item serial");
        for (const receipt of schedule) for (const id2 of receipt.itemIds) assert2.equal(id2, `item-${itemSerial++}`, "schedule item serial");
        const records = appended(before.roundResults, after.roundResults, "settlementId", "settlements");
        assert2(records.length <= 1, "one settlement per command");
        let growth = before.augmentProgress;
        for (const record4 of records) {
          const expected = settlement(before, after.combat, this.gold);
          assert2.deepEqual(record4, expected, `independent settlement R${before.round}`);
          this.gold += expected.income;
          costs.income += expected.income;
          this.rows.push(expected);
          growth = investment(before, expected);
        }
        assert2.deepEqual(after.augmentProgress, growth, "once-only independent augment growth");
        this.combinations += events.filter((e) => e.type === "itemCombined").length;
        this.check(after, true);
      }
      check(state, lootChecked = false) {
        if (!lootChecked) validateLoot(state);
        assert2.equal(state.gold, this.gold, "independent gold ledger");
        assert2.equal(state.preparation.units.filter((u) => u.team === "player").reduce((n, u) => n + 3 ** (u.starLevel - 1), 0), this.cards, "card-equivalent conservation");
        assert2.equal(new Set(state.items.map((i) => i.id)).size, state.items.length, "unique item IDs");
        const grants = state.scheduleReceipts.reduce((n, r) => n + r.itemIds.length, 0) + state.m8.loot.receipts.reduce((n, r) => n + r.grantedItemIds.length, 0);
        assert2.equal(state.items.length, grants - this.combinations, "component/completed-item conservation");
        assert2.equal(new Set(state.scheduleReceipts.map((r) => r.eventId)).size, state.scheduleReceipts.length, "receipt identity");
        assert2.equal(state.nextItemSerial, 1 + grants + this.combinations, "item serial accounting");
      }
    };
    module2.exports = { ROUNDS, roundOrdinal, CATALOG, COST, ODDS, XP, SELL, COMPONENTS, word, shop, xp, settlement, investment, lootIndex, lootPlan, validateLoot, validateLootTransition, Ledger };
  }
});

// scripts/m4-evidence.cjs
var require_m4_evidence = __commonJS({
  "scripts/m4-evidence.cjs"(exports2, module2) {
    "use strict";
    var crypto2 = require("node:crypto");
    function canonical(value) {
      if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
      if (value !== null && typeof value === "object") return `{${Object.keys(value).filter((key3) => value[key3] !== void 0).sort().map((key3) => `${JSON.stringify(key3)}:${canonical(value[key3])}`).join(",")}}`;
      return JSON.stringify(value);
    }
    module2.exports = { canonical, hash: (value) => crypto2.createHash("sha256").update(canonical(value)).digest("hex") };
  }
});

// scripts/generate-m5-route.cjs
var require_generate_m5_route = __commonJS({
  "scripts/generate-m5-route.cjs"(exports2, module2) {
    "use strict";
    var assert2 = require("node:assert/strict");
    var path2 = require("node:path");
    var { Ledger, COST, shop, ROUNDS, roundOrdinal } = require_oracle();
    var { hash } = require_m4_evidence();
    var BUILDS = {
      cannon: { core: "corki", tank: "loris", units: ["irelia", "rell", "leona", "loris", "tristana", "urgot", "ezreal", "corki"], carry: ["deathblade", "shojin", "gunblade"], early: "maddie" },
      sniper: { core: "kogmaw", tank: "garen", units: ["darius", "vander", "scar", "garen", "irelia", "loris", "maddie", "kogmaw"], carry: ["rageblade", "archangel", "gunblade"], early: "lux" },
      mage: { core: "zoe", tank: "loris", units: ["irelia", "rell", "leona", "loris", "lux", "zyra", "nami", "zoe"], carry: ["shojin", "deathcap", "gunblade"], early: "maddie" }
    };
    var RECIPES = { deathblade: ["sword", "sword"], shojin: ["sword", "tear"], gunblade: ["sword", "rod"], rageblade: ["bow", "rod"], archangel: ["rod", "tear"], deathcap: ["rod", "rod"], warmog: ["belt", "belt"], "dragons-claw": ["cloak", "cloak"], gargoyle: ["vest", "cloak"] };
    var FRONT = /* @__PURE__ */ new Set(["irelia", "rell", "leona", "loris", "darius", "vander", "scar", "garen"]);
    function dispatch2(api, state, c) {
      switch (c.type) {
        case "buy":
          return api.buyUnit(state, c.slot, c.generation);
        case "sell":
          return api.sellUnit(state, c.id);
        case "deploy":
          return api.deployMatchUnit(state, c.id, c.target);
        case "reroll":
          return api.rerollShop(state);
        case "buyXp":
          return api.buyXp(state);
        case "combine":
          return api.combineItems(state, ...c.ids);
        case "equip":
          return api.equipItem(state, c.itemId, c.unitId, c.slot);
        case "select":
          return api.selectChoice(state, c.choiceId, c.generation, c.definitionId);
        case "target":
          return api.selectAnomalyTarget(state, c.choiceId, c.generation, c.unitId);
        case "anomalyReroll":
          return api.rerollAnomaly(state, c.choiceId, c.generation);
        case "lock":
          return api.setShopLock(state, c.locked, c.generation);
        case "start":
          return api.startMatchCombat(state);
        case "continue":
          return api.nextRound(state, c.round);
        default:
          throw Error(`unknown ${c.type}`);
      }
    }
    async function generateRoute(options = {}) {
      const { createServer } = await import("vite");
      const server = await createServer({ root: path2.resolve(__dirname, ".."), server: { middlewareMode: true, ws: false }, optimizeDeps: { noDiscovery: true, include: [] }, appType: "custom" });
      try {
        return await run2(await server.ssrLoadModule("/src/simulation/match.ts"), options);
      } finally {
        await server.close();
      }
    }
    async function run2(api, { build = "cannon", seed = 42, retainStates = false, onStep } = {}) {
      const lateCaitlyn = build === "sniper-caitlyn", config = BUILDS[lateCaitlyn ? "sniper" : build];
      assert2(config);
      let state = api.createMatch(seed);
      const initial = structuredClone(state), ledger = new Ledger(state), actions = [], rounds = [], checkpoints = [];
      let caitlynBattles = 0, caitlynCasts = 0, ticks = 0, formedAt = null, formedBattles = 0, boundBattles = 0, transitioned = false;
      const started = Date.now(), tickDurations = [];
      const players = () => state.preparation.units.filter((u) => u.team === "player");
      const best = (id2) => players().filter((u) => u.definitionId === id2).sort((a, b) => b.starLevel - a.starLevel || a.id.localeCompare(b.id))[0];
      const inventory = () => state.items.filter((i) => i.location.kind === "inventory");
      function observe(before, result, command2) {
        assert2(result.ok !== false, `R${state.round} ${JSON.stringify(command2)} ${result.reason}`);
        state = result.state;
        ledger.apply(before, state, command2, result.events);
        if (command2?.type === "reroll" || command2?.type === "continue" && !before.shop.locked) {
          const expected = shop(before.rngState, before.shop.generation + 1, before.level, Boolean(before.shop.locked));
          assert2.deepEqual(state.shop, expected.shop, "independent shop slots/generation");
          assert2.equal(state.rngState, expected.rngState, "independent shop RNG");
        }
        if (command2?.type === "continue" && before.shop.locked) {
          assert2.deepEqual(state.shop, before.shop);
          assert2.equal(state.rngState, before.rngState);
        }
        const entry = { index: actions.length, round: before.round, command: command2, events: result.events, ...command2 ? { beforeHash: hash(before), afterHash: hash(state) } : {} };
        if (retainStates) {
          entry.before = before;
          entry.after = state;
        }
        if (command2) actions.push(entry);
        onStep?.(before, result, command2);
        return entry;
      }
      const command = (c) => observe(state, dispatch2(api, state, c), c);
      const select = (id2) => command({ type: "select", choiceId: state.pendingChoice.choiceId, generation: state.pendingChoice.generation, definitionId: id2 });
      function components() {
        const desired = [config.carry[0], config.carry[1], "warmog", config.carry[2], "dragons-claw", "gargoyle"];
        const counts = {};
        for (const item of state.items) {
          for (const id2 of RECIPES[item.definitionId] ?? [item.definitionId]) counts[id2] = (counts[id2] ?? 0) + 1;
        }
        for (const item of desired) for (const id2 of RECIPES[item]) {
          if ((counts[id2] ?? 0) > 0) counts[id2]--;
          else return id2;
        }
        return "belt";
      }
      function choices() {
        while (state.phase === "choice") {
          const c = state.pendingChoice;
          if (c.kind === "component") select(components());
          else if (c.kind === "augment") {
            const order = ["investment-strategy-i", "pumping-up-i", "placebo", "manaflow-i", "bulky-buddies-i", "glass-cannon-i"];
            select(order.find((id2) => c.offers.includes(id2)) ?? c.offers[0]);
          } else if (c.step === "target") {
            const target = best(config.core) ?? best(build === "cannon" ? "tristana" : build === "mage" ? "nami" : "maddie") ?? players()[0];
            command({ type: "target", choiceId: c.choiceId, generation: c.generation, unitId: target.id });
          } else if (c.rerollCount === 0 && state.gold >= 1) command({ type: "anomalyReroll", choiceId: c.choiceId, generation: c.generation });
          else select(c.offers[0]);
        }
      }
      function buyShop() {
        for (let slot3 = 0; slot3 < 5; slot3++) {
          const offer = state.shop.slots[slot3];
          if (offer.status !== "available" || !(config.units.includes(offer.definitionId) || lateCaitlyn && state.round >= roundOrdinal("5-1") && offer.definitionId === "caitlyn")) continue;
          const copies = players().filter((u) => u.definitionId === offer.definitionId).reduce((n, u) => n + 3 ** (u.starLevel - 1), 0);
          if (copies >= (offer.definitionId === "caitlyn" ? 1 : 3) || state.gold < COST[offer.definitionId]) continue;
          const result = dispatch2(api, state, { type: "buy", slot: slot3, generation: state.shop.generation });
          if (result.ok) observe(state, result, { type: "buy", slot: slot3, generation: state.shop.generation });
        }
      }
      function items() {
        const desired = [...config.carry, "warmog", "dragons-claw", "gargoyle"];
        for (const recipe of desired) {
          if (state.items.some((i) => i.definitionId === recipe)) continue;
          const chosen = [];
          for (const definitionId2 of RECIPES[recipe]) {
            const item = inventory().find((i) => i.definitionId === definitionId2 && !chosen.includes(i.id));
            if (item) chosen.push(item.id);
          }
          if (chosen.length === 2) command({ type: "combine", ids: chosen });
        }
        const carry = best(config.core) ?? best(config.early) ?? best(build === "mage" ? "nami" : build === "cannon" ? "tristana" : "maddie");
        const tank = best(config.tank) ?? best("irelia") ?? players().find((u) => FRONT.has(u.definitionId));
        for (const item of inventory()) {
          const target = config.carry.includes(item.definitionId) ? carry : ["warmog", "dragons-claw", "gargoyle"].includes(item.definitionId) ? tank : null;
          if (!target) continue;
          const slots = new Set(state.items.filter((i) => i.location.kind === "unit" && i.location.unitId === target.id).map((i) => i.location.slot)), slot3 = [0, 1, 2].find((s) => !slots.has(s));
          if (slot3 !== void 0) command({ type: "equip", itemId: item.id, unitId: target.id, slot: slot3 });
        }
      }
      function formation() {
        const ranked = players().filter((u) => best(u.definitionId)?.id === u.id && !(lateCaitlyn && best("caitlyn") && u.definitionId === "maddie")).sort((a, b) => {
          const score = (u) => (u.definitionId === config.core || lateCaitlyn && u.definitionId === "caitlyn" ? 100 : 0) + (config.units.includes(u.definitionId) ? 20 : 0) + u.starLevel * 15 + (FRONT.has(u.definitionId) ? 4 : 0);
          return score(b) - score(a) || a.id.localeCompare(b.id);
        });
        const chosen = ranked.slice(0, state.level);
        const chosenIds = new Set(chosen.map((u) => u.id));
        for (const u of players().filter((u2) => u2.location.kind === "board" && !chosenIds.has(u2.id))) {
          const taken = new Set(players().filter((u2) => u2.location.kind === "bench").map((u2) => u2.location.slot));
          const slot3 = Array.from({ length: 9 }, (_, i) => i).find((i) => !taken.has(i));
          if (slot3 !== void 0) command({ type: "deploy", id: u.id, target: { kind: "bench", slot: slot3 } });
        }
        for (const u of chosen) {
          const current = players().find((p) => p.id === u.id);
          if (current.location.kind === "board") continue;
          const cells = FRONT.has(u.definitionId) ? [[1, 4], [3, 4], [5, 4], [0, 4], [6, 4], [2, 5], [4, 5]] : [[1, 7], [3, 7], [5, 7], [0, 7], [6, 7], [2, 6], [4, 6]];
          const cell = cells.find(([col, row]) => !players().some((p) => p.location.kind === "board" && p.location.cell.col === col && p.location.cell.row === row));
          if (cell) command({ type: "deploy", id: u.id, target: { kind: "board", cell: { col: cell[0], row: cell[1] } } });
        }
      }
      function prepare() {
        if (state.shop.locked) command({ type: "lock", locked: false, generation: state.shop.generation });
        buyShop();
        const target = state.round < roundOrdinal("2-3") ? 3 : state.round < roundOrdinal("2-6") ? 4 : state.round < roundOrdinal("3-3") ? 5 : state.round < roundOrdinal("3-7") ? 6 : state.round < roundOrdinal("4-4") ? 7 : 8;
        const reserve = state.round < roundOrdinal("3-1") ? 10 : state.round < roundOrdinal("4-4") ? 30 : state.round < roundOrdinal("5-3") ? 15 : 0;
        while (state.level < target && state.gold >= reserve + 4) command({ type: "buyXp" });
        if (state.level >= 7 || state.round >= roundOrdinal("3-3")) {
          for (let i = 0; i < 30 && state.gold >= reserve + 5; i++) {
            if (config.units.every((id2) => best(id2)?.starLevel >= 2) && (!lateCaitlyn || state.round < roundOrdinal("5-1") || best("caitlyn"))) break;
            command({ type: "reroll" });
            buyShop();
          }
        }
        if (best(config.core) && !transitioned) {
          const old = best(config.early);
          if (old && old.id !== state.anomalyBinding?.unitId) {
            command({ type: "sell", id: old.id });
            transitioned = true;
          }
        }
        for (const u of [...players()]) if (!config.units.includes(u.definitionId) && !(lateCaitlyn && u.definitionId === "caitlyn") && u.definitionId !== config.early && players().length > state.level && u.id !== state.anomalyBinding?.unitId) command({ type: "sell", id: u.id });
        items();
        formation();
        if (state.round === roundOrdinal("2-2")) command({ type: "lock", locked: true, generation: state.shop.generation });
      }
      while (state.phase !== "gameOver" && state.round <= ROUNDS.length) {
        choices();
        if (state.phase === "settlement") {
          command({ type: "continue", round: state.round });
          continue;
        }
        assert2.equal(state.phase, "preparation");
        prepare();
        const before = state, board = players().filter((u) => u.location.kind === "board"), core = best(config.core), tank = best(config.tank), equipped = (u) => state.items.filter((i) => i.location.kind === "unit" && i.location.unitId === u?.id && RECIPES[i.definitionId]).length;
        const formed = config.units.every((id2) => board.some((u) => u.definitionId === id2)) && core?.starLevel >= 2 && equipped(core) >= 2 && equipped(tank) >= 1;
        if (formed && formedAt === null) formedAt = state.round;
        if (formed) formedBattles++;
        if (state.anomalyBinding && board.some((u) => u.id === state.anomalyBinding.unitId)) boundBattles++;
        const combatEvents = [];
        combatEvents.push(...command({ type: "start" }).events);
        const startedState = state;
        while (state.phase === "combat") {
          const measuredAt = performance.now();
          const result = api.stepMatch(state);
          tickDurations.push(performance.now() - measuredAt);
          combatEvents.push(...result.events);
          observe(state, result);
          ticks++;
          assert2(ticks <= ROUNDS.filter((r) => r.kind !== "supply").length * 1200, "catalog battles bounded by 1200 ticks");
        }
        const ended = state;
        if (board.some((u) => u.definitionId === "caitlyn")) caitlynBattles++;
        caitlynCasts += combatEvents.filter((e) => e.type === "cast" && e.abilityId === "caitlyn-ability").length;
        const battleEvents = combatEvents.filter((e) => e.domain === "combat");
        assert2.deepEqual(battleEvents.map((e) => e.eventSeq), battleEvents.map((_, i) => i), "complete per-combat event sequence");
        assert2.equal(battleEvents.filter((e) => e.type === "combatFinished").length, 1, "one terminal combat event");
        rounds.push({ snapshot: startedState.combat?.strategy, binding: before.anomalyBinding, round: before.round, roundDefinitionId: before.roundDefinitionId, formed, board: board.map((u) => ({ id: u.id, definitionId: u.definitionId, starLevel: u.starLevel })), result: state.roundResults.at(-1), stateHash: hash(ended), eventsHash: hash(combatEvents), events: combatEvents, ...retainStates ? { before, after: ended } : {} });
        checkpoints.push({ round: before.round, hp: state.playerHp, gold: state.gold, level: state.level, formed, core: core?.starLevel ?? 0 });
        await new Promise((resolve) => setImmediate(resolve));
      }
      tickDurations.sort((a, b) => a - b);
      const tickTimingMs = { p50: tickDurations[Math.floor(tickDurations.length * 0.5)], p95: tickDurations[Math.floor(tickDurations.length * 0.95)], p99: tickDurations[Math.floor(tickDurations.length * 0.99)], max: tickDurations.at(-1) };
      const summary = { caitlynBattles, caitlynCasts, tickTimingMs, build, seed, outcome: state.outcome, round: state.round, hp: state.playerHp, gold: state.gold, formedAt, formedBattles, boundBattles, transitioned, ticks, commands: actions.length, durationSeconds: (Date.now() - started) / 1e3 };
      return { summary, initial, final: state, actions, rounds, checkpoints, ledger: { costs: ledger.costs, rounds: ledger.rows } };
    }
    module2.exports = generateRoute;
    module2.exports.run = run2;
    module2.exports.dispatch = dispatch2;
    module2.exports.BUILDS = BUILDS;
    if (require.main === module2) {
      generateRoute({ build: process.argv[2] ?? "cannon", seed: Number(process.argv[3] ?? 42) }).then((route) => {
        console.log(JSON.stringify({ summary: route.summary, ledger: route.ledger.costs }, null, 2));
        if (process.env.M5_ROUTE_OUTPUT) require("node:fs").writeFileSync(process.env.M5_ROUTE_OUTPUT, JSON.stringify(route));
      }).catch((error) => {
        console.error(error);
        process.exitCode = 1;
      });
    }
  }
});

// src/simulation/match.ts
var match_exports = {};
__export(match_exports, {
  DEFAULT_MATCH_SEED: () => DEFAULT_MATCH_SEED,
  MATCH_RULES: () => MATCH_RULES,
  buyUnit: () => buyUnit,
  buyXp: () => buyXp,
  combineItems: () => combineItems,
  createMatch: () => createMatch,
  deployMatchUnit: () => deployMatchUnit,
  equipItem: () => equipItem,
  getDeploymentCap: () => getDeploymentCap,
  getShopOdds: () => getShopOdds,
  getUnitSellPrice: () => getUnitSellPrice,
  getUnitStats: () => getUnitStats,
  getXpToNextLevel: () => getXpToNextLevel,
  matchStartFailure: () => matchStartFailure,
  needsAnomalyRecruitment: () => needsAnomalyRecruitment,
  nextRound: () => nextRound,
  readEncounterPreview: () => readEncounterPreview,
  rerollAnomaly: () => rerollAnomaly,
  rerollShop: () => rerollShop,
  selectAnomalyTarget: () => selectAnomalyTarget,
  selectChoice: () => selectChoice,
  sellUnit: () => sellUnit,
  setShopLock: () => setShopLock,
  startMatchCombat: () => startMatchCombat,
  stepMatch: () => stepMatch,
  validateMatchDeployment: () => validateMatchDeployment
});

// src/simulation/content/freeze.ts
function freezeContent(value) {
  if (value !== null && typeof value === "object") {
    for (const child of Object.values(value)) freezeContent(child);
    Object.freeze(value);
  }
  return value;
}

// src/simulation/content/loot.ts
var LOOT_POLICY_VERSION = "m8b-loot-project-v1";
var LOOT_HERO_POOL_VERSION = "m8b-heroes-1to4-v1";
var LOOT_HERO_POOLS = freezeContent({
  1: [["TFT13_Darius", "darius"], ["TFT13_Irelia", "irelia"], ["TFT13_Lux", "lux"], ["TFT13_Shooter", "maddie"], ["TFT13_Zyra", "zyra"]],
  2: [["TFT13_Leona", "leona"], ["TFT13_Prime", "vander"], ["TFT13_Rell", "rell"], ["TFT13_Tristana", "tristana"], ["TFT13_Urgot", "urgot"]],
  3: [["TFT13_Beardy", "loris"], ["TFT13_Ezreal", "ezreal"], ["TFT13_FlyGuy", "scar"], ["TFT13_KogMaw", "kogmaw"], ["TFT13_Nami", "nami"]],
  4: [["TFT13_Corki", "corki"], ["TFT13_Garen", "garen"], ["TFT13_Zoe", "zoe"]]
});
var slot = (sourceSlotId, slotOrdinal, content) => ({ sourceSlotId, slotOrdinal, content });
var LOOT_SLOTS = freezeContent({
  "1-2": [slot("m01", 0, { kind: "fixed", payload: { kind: "unit", definitionId: "maddie", quantity: 1 } })],
  "1-3": [slot("m01", 0, { kind: "fixed", payload: { kind: "unit", definitionId: "lux", quantity: 1 } }), slot("r01", 0, { kind: "component-choice" })],
  "1-4": [slot("r01", 0, { kind: "component-choice" })],
  "2-7": [slot("k01", 0, { kind: "random-component" }), slot("k01", 1, { kind: "extra", cost: 1 }), slot("k02", 0, { kind: "component-choice" })],
  "3-7": [slot("w00", 0, { kind: "random-component" }), slot("w00", 1, { kind: "extra", cost: 2 }), slot("w01", 0, { kind: "component-choice" })],
  "4-7": [slot("r00", 0, { kind: "random-component" }), slot("r00", 1, { kind: "extra", cost: 3 }), slot("r01", 0, { kind: "component-choice" })],
  "5-7": [slot("d01", 0, { kind: "random-component" }), slot("d01", 1, { kind: "component-choice" }), slot("d01", 2, { kind: "extra", cost: 4 })],
  "6-7": [slot("h01", 0, { kind: "fixed", payload: { kind: "gold", quantity: 5 } })]
});
var LOOT_CATEGORIES = freezeContent({
  1: [{ id: "gold_1", weight: 75, payload: { kind: "gold", quantity: 1 } }, { id: "unit_1", weight: 25, payload: { kind: "hero-pool", cost: 1 } }],
  2: [{ id: "gold_2", weight: 75, payload: { kind: "gold", quantity: 2 } }, { id: "unit_2", weight: 25, payload: { kind: "hero-pool", cost: 2 } }],
  3: [{ id: "gold_3", weight: 75, payload: { kind: "gold", quantity: 3 } }, { id: "unit_3", weight: 25, payload: { kind: "hero-pool", cost: 3 } }],
  4: [{ id: "gold_4", weight: 70, payload: { kind: "gold", quantity: 4 } }, { id: "gold_5_substitute", weight: 10, payload: { kind: "gold", quantity: 5 } }, { id: "unit_4", weight: 20, payload: { kind: "hero-pool", cost: 4 } }]
});
var LOOT_FREEZE_ALGORITHM = freezeContent({
  revision: "m8b-loot-freeze-v1",
  rng: "lcg32-v1",
  multiplier: 1664525,
  increment: 1013904223,
  seedXor: 3735928559,
  sampling: "uint32-rejection-modulo",
  order: "sourceUnitId-codepoint/slotOrdinal-numeric",
  choiceOrder: "dropId-codepoint",
  choices: "full-pool/one-fallback-word"
});
var LOOT_RUNTIME_REVISION = "m8-b8-live-loot-basis-provenance-v1";

// src/simulation/neutral-receipts.ts
var NEUTRAL_RUNTIME_VERSION = "m8-b7-neutral-receipts-v1";
function recordNeutralReceipts(step) {
  const previous = step.state.neutralReceipts;
  if (!previous) return step;
  let changed = false;
  const deaths = [...previous.deaths], controls = [...previous.controls];
  for (const e of step.events) {
    if (e.type === "death" && step.state.units.some((u) => u.id === e.unitId && u.unitKind === "neutral")) {
      changed = true;
      deaths.push({ unitId: e.unitId, tick: e.tick, eventSeq: e.eventSeq });
    }
    if (e.type !== "statusChanged" || e.status.kind !== "stun" || !step.state.units.some((u) => u.id === e.status.source.ownerId && u.unitKind === "neutral")) continue;
    changed = true;
    if (e.reason === "applied") controls.push({ key: e.status.key, targetId: e.unitId, appliedEventSeq: e.eventSeq, removedAtTick: null, removedEventSeq: null, removedReason: null });
    else {
      const index = controls.findIndex((c) => c.key === e.status.key);
      if (index >= 0) controls[index] = { ...controls[index], removedAtTick: e.tick, removedEventSeq: e.eventSeq, removedReason: e.reason };
    }
  }
  return changed ? { ...step, state: { ...step.state, neutralReceipts: { deaths, controls } } } : step;
}

// src/simulation/content/neutrals.ts
function neutral(id2, name, monsterFamily, health, attack, baseAttackSpeedBps, armor, magicResist, attackRange, mechanism = { kind: "none" }) {
  return {
    id: id2,
    name,
    unitKind: "neutral",
    monsterFamily,
    starLevel: 1,
    health,
    attack,
    baseAttackSpeedBps,
    armor,
    magicResist,
    attackRange,
    abilityPower: 100,
    initialMana: 0,
    maxMana: 0,
    baseCritChanceBps: 2500,
    baseCritMultiplierBps: 14e3,
    traits: [],
    equipment: [],
    mechanism
  };
}
function neutralAbilityId(definition) {
  return definition.mechanism.kind === "none" ? "neutral-attack" : definition.mechanism.id;
}
var NEUTRAL_DEFINITIONS = freezeContent({
  "pve-minion-melee-a": neutral("pve-minion-melee-a", "\u8FD1\u6218\u5C0F\u5175 A", "minion", 110, 8, 5e3, 0, 0, 1),
  "pve-minion-melee-b": neutral("pve-minion-melee-b", "\u8FD1\u6218\u5C0F\u5175 B", "minion", 160, 10, 6e3, 0, 0, 1),
  "pve-minion-ranged-b": neutral("pve-minion-ranged-b", "\u8FDC\u7A0B\u5C0F\u5175 B", "minion", 120, 9, 6e3, 0, 0, 3),
  "pve-minion-melee-c": neutral("pve-minion-melee-c", "\u8FD1\u6218\u5C0F\u5175 C", "minion", 220, 12, 6e3, 0, 0, 1),
  "pve-minion-ranged-c": neutral("pve-minion-ranged-c", "\u8FDC\u7A0B\u5C0F\u5175 C", "minion", 160, 10, 6e3, 0, 0, 3),
  "pve-krug": neutral(
    "pve-krug",
    "\u77F3\u7532\u866B",
    "krug",
    400,
    30,
    8e3,
    20,
    20,
    1,
    { kind: "companion-heal", id: "stone-salvage-project-v1", missingHpBps: 1e4, maxReactions: 2 }
  ),
  "pve-wolf-large": neutral(
    "pve-wolf-large",
    "\u5927\u72FC",
    "wolf",
    900,
    50,
    8e3,
    15,
    15,
    1,
    { kind: "backline-jump", id: "pack-leap-project-v1" }
  ),
  "pve-wolf-small": neutral(
    "pve-wolf-small",
    "\u5C0F\u72FC",
    "wolf",
    450,
    22,
    8e3,
    15,
    15,
    1,
    { kind: "backline-jump", id: "pack-leap-project-v1" }
  ),
  "pve-razorbeak-large": neutral(
    "pve-razorbeak-large",
    "\u5927\u9E1F",
    "razorbeak",
    1400,
    65,
    8e3,
    25,
    25,
    1,
    { kind: "companion-speed", id: "furious-flock-project-v1", attackSpeedBps: 1500, maxReactions: 5 }
  ),
  "pve-razorbeak-small": neutral(
    "pve-razorbeak-small",
    "\u5C0F\u9E1F",
    "razorbeak",
    680,
    32,
    8e3,
    25,
    25,
    1,
    { kind: "companion-speed", id: "furious-flock-project-v1", attackSpeedBps: 1500, maxReactions: 5 }
  ),
  "pve-elder-dragon": neutral(
    "pve-elder-dragon",
    "\u8FDC\u53E4\u9F99",
    "elder-dragon",
    6e3,
    85,
    1e4,
    50,
    50,
    2,
    { kind: "attack-cone", id: "primordial-breath-project-v1", secondaryDamageBps: 3500 }
  ),
  "pve-rift-herald": neutral(
    "pve-rift-herald",
    "\u5CE1\u8C37\u5148\u950B",
    "rift-herald",
    9e3,
    120,
    1e4,
    60,
    60,
    2,
    { kind: "path-charge", id: "void-charge-project-v1", targetMaxHpBps: 1500, damageCap: 300, stunTicks: 10 }
  )
});

// src/simulation/content/neutral-encounters.ts
var NEUTRAL_ENCOUNTER_CATALOG_VERSION = "m8b-encounters-project-v1";
var NEUTRAL_ENCOUNTER_POLICY_VERSION = "m8b-pve-project-v1";
var slot2 = (slotId, definitionId2, col, row) => ({ slotId, definitionId: definitionId2, cell: { col, row } });
var NEUTRAL_ENCOUNTERS = freezeContent([
  { roundId: "1-2", encounterId: "minions-a-v1", slots: [
    slot2("m01", "pve-minion-melee-a", 2, 3),
    slot2("m02", "pve-minion-melee-a", 4, 3)
  ] },
  { roundId: "1-3", encounterId: "minions-b-v1", slots: [
    slot2("m01", "pve-minion-melee-b", 2, 3),
    slot2("m02", "pve-minion-melee-b", 4, 3),
    slot2("r01", "pve-minion-ranged-b", 3, 1)
  ] },
  { roundId: "1-4", encounterId: "minions-c-v1", slots: [
    slot2("m01", "pve-minion-melee-c", 2, 3),
    slot2("m02", "pve-minion-melee-c", 4, 3),
    slot2("r01", "pve-minion-ranged-c", 2, 1),
    slot2("r02", "pve-minion-ranged-c", 4, 1)
  ] },
  { roundId: "2-7", encounterId: "krugs-v1", slots: [
    slot2("k01", "pve-krug", 1, 3),
    slot2("k02", "pve-krug", 3, 3),
    slot2("k03", "pve-krug", 5, 3)
  ] },
  { roundId: "3-7", encounterId: "wolves-v1", slots: [
    slot2("w00", "pve-wolf-large", 3, 2),
    slot2("w01", "pve-wolf-small", 1, 3),
    slot2("w02", "pve-wolf-small", 2, 3),
    slot2("w03", "pve-wolf-small", 4, 3),
    slot2("w04", "pve-wolf-small", 5, 3)
  ] },
  { roundId: "4-7", encounterId: "razorbeaks-v1", slots: [
    slot2("r00", "pve-razorbeak-large", 3, 2),
    slot2("r01", "pve-razorbeak-small", 0, 3),
    slot2("r02", "pve-razorbeak-small", 1, 3),
    slot2("r03", "pve-razorbeak-small", 2, 3),
    slot2("r04", "pve-razorbeak-small", 4, 3),
    slot2("r05", "pve-razorbeak-small", 5, 3)
  ] },
  { roundId: "5-7", encounterId: "elder-dragon-v1", slots: [slot2("d01", "pve-elder-dragon", 3, 2)] },
  { roundId: "6-7", encounterId: "rift-herald-v1", slots: [slot2("h01", "pve-rift-herald", 3, 1)] }
]);

// src/simulation/content/item-programs.ts
var always = { kind: "always" };
var refresh = { kind: "refresh-same-instance", magnitude: "replace", phase: "preserve" };
var combat = { kind: "combat" };
var duration = (ticks) => ({ kind: "ticks", ticks });
var hp = (op, thresholdBps) => ({ kind: "hp-ratio", subject: "holder", op, thresholdBps });
var rows = (rows2) => ({ kind: "starting-rows", rows: rows2 });
var filter = (deliveries = "all") => ({ deliveries, damageTypes: ["physical", "magic"], redirected: "exclude" });
var amount = (patch = {}) => ({ flat: 0, attackDamageBps: 0, abilityPowerBps: 0, maxHpBps: 0, missingHpBps: 0, actualManaSpentBps: 0, actualDamageBps: 0, shieldAbsorbedBps: 0, hpBasis: "holder", sample: "application", cap: null, ...patch });
var modifier = (stat2, n, unit = "flat", condition = always, damageFilter = null) => ({ stat: stat2, unit, value: { kind: "constant", amount: n }, condition, damageFilter });
var selector = (patch = {}) => ({ primary: "normal", candidates: "board", relation: "self", anchor: "holder", radius: null, maxTargets: 1, excludeSelf: false, excludePrimary: false, distinct: true, order: "distance-id", sample: "action-completion", ...patch });
var enemies = (patch = {}) => selector({ relation: "enemy", excludeSelf: true, ...patch });
var stat = (m, ticks = null, activation = "immediate") => ({ kind: "modify-stat", modifier: m, activation, duration: ticks === null ? combat : duration(ticks), stackPolicy: refresh });
var status = (kind, n, ticks, patch) => ({ kind: "apply-status", status: { kind, magnitudeBps: n, duration: duration(ticks), stackPolicy: ["burn", "wound", "sunder", "shred", "damage-reduction"].includes(kind) ? { kind: "strongest-category", category: kind, retainSuppressed: true } : refresh, polarity: ["burn", "wound", "sunder", "shred", "stun"].includes(kind) ? "harmful" : "beneficial", removable: ["burn", "wound", "sunder", "shred", "stun"].includes(kind), damageFilter: kind === "damage-reduction" ? filter() : null, onEnd: null, ...patch } });
var burn = (ticks) => [status("burn", 100, ticks, { activation: "immediate" }), status("wound", 3300, ticks, { activation: "immediate" })];
var shield = (bps, ticks, endEffects = []) => ({ kind: "grant-shield", amount: amount({ maxHpBps: bps }), durationTicks: ticks, decay: { kind: "none" }, onEnd: endEffects.length ? ["depleted", "expired"] : [], endTiming: "post-damage", endTargeting: { kind: "select", selector: selector() }, endEffects });
var trigger = (patch) => ({ id: "trigger", event: "attack-completed", listener: { subject: "actor", relationToHolder: "self", withinHexes: null }, aggregation: "event", counters: [], gate: { kind: "always" }, condition: always, selector: selector(), internalCooldownTicks: 0, maxPerAction: 1, maxPerCombat: null, stackPolicy: refresh, effects: [], ...patch });
var survival = (thresholdBps, effects2, initial = false) => trigger({ id: "survival", event: "post-damage-survival", ...initial ? { initialAlso: true } : {}, listener: { subject: "target", relationToHolder: "self", withinHexes: null }, condition: hp("lte", thresholdBps), maxPerCombat: 1, effects: effects2 });
var damage = (damageType, patch) => ({ kind: "damage", damageType, delivery: "equipment-proc", critEligibility: "never", amount: amount(patch) });
var mana = (n, reason) => ({ kind: "grant-mana", amount: n, reason, bypassLock: reason === "cast-refund" ? "this-cast-refund" : "none" });
var periodic = (periodTicks, effects2, s = selector({ sample: "each-pulse" }), patch = {}) => ({ periodTicks, program: { selector: s, targetSnapshot: "once-per-pulse", effects: effects2 }, ...patch });
var vamp = (bps, condition = always) => ({ modifier: modifier("omnivamp", bps, "bps", condition), allyBps: 0, allyCondition: always });

// src/simulation/content/items-components.ts
var COMPONENTS_ITEMS = [
  {
    "id": "sword",
    "name": "\u66B4\u98CE\u5927\u5251",
    "kind": "component",
    "apiName": "TFT_Item_BFSword",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "effectDescriptions": [
      "AD: 1000 Bps"
    ],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 1e3
      }
    ]
  },
  {
    "id": "vest",
    "name": "\u9501\u5B50\u7532",
    "kind": "component",
    "apiName": "TFT_Item_ChainVest",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "effectDescriptions": [
      "Armor: 20 resistance-points"
    ],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "armor",
        "amount": 20
      }
    ]
  },
  {
    "id": "belt",
    "name": "\u5DE8\u4EBA\u8170\u5E26",
    "kind": "component",
    "apiName": "TFT_Item_GiantsBelt",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "effectDescriptions": [
      "Health: 150 health-points"
    ],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      }
    ]
  },
  {
    "id": "rod",
    "name": "\u65E0\u7528\u5927\u68D2",
    "kind": "component",
    "apiName": "TFT_Item_NeedlesslyLargeRod",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "effectDescriptions": [
      "AP: 10 ability-power-points"
    ],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 10
      }
    ]
  },
  {
    "id": "cloak",
    "name": "\u8D1F\u6781\u6597\u7BF7",
    "kind": "component",
    "apiName": "TFT_Item_NegatronCloak",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "effectDescriptions": [
      "MagicResist: 20 magic-resist-points"
    ],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "magicResist",
        "amount": 20
      }
    ]
  },
  {
    "id": "bow",
    "name": "\u53CD\u66F2\u4E4B\u5F13",
    "kind": "component",
    "apiName": "TFT_Item_RecurveBow",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "effectDescriptions": [
      "AS: 1000 Bps"
    ],
    "effects": [
      {
        "kind": "attackSpeedBps",
        "bps": 1e3
      }
    ]
  },
  {
    "id": "gloves",
    "name": "\u62F3\u5957",
    "kind": "component",
    "apiName": "TFT_Item_SparringGloves",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387 +20%\u3002"],
    "effects": [],
    combatProgram: { modifiers: [modifier("critChance", 2e3, "bps")] }
  },
  {
    "id": "tear",
    "name": "\u5973\u795E\u4E4B\u6CEA",
    "kind": "component",
    "apiName": "TFT_Item_TearOfTheGoddess",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "effectDescriptions": [
      "Mana: 15 mana-points"
    ],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "initialMana",
        "amount": 15
      }
    ]
  }
];

// src/simulation/content/items-sword.ts
var SWORD_ITEMS = [
  {
    "id": "bloodthirster",
    "name": "\u996E\u8840\u5251",
    "kind": "completed",
    "apiName": "TFT_Item_Bloodthirster",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-04",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "sword",
      "cloak"
    ],
    "effectDescriptions": ["20%\u5168\u80FD\u5438\u8840\uFF1B\u53D7\u4F24\u540E\u5B58\u6D3B\u4E14\u751F\u547D\u226440%\u65F6\u6BCF\u6218\u4E00\u6B21\u83B7\u5F9725%\u6700\u5927\u751F\u547D\u62A4\u76FE\uFF0C\u6301\u7EED5\u79D2\u3002"],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 1500
      },
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 15
      },
      {
        "kind": "statFlat",
        "stat": "magicResist",
        "amount": 20
      }
    ],
    combatProgram: { vamp: [vamp(2e3)], survival: [survival(4e3, [shield(2500, 100)])] }
  },
  {
    "id": "edge-of-night",
    "name": "\u591C\u4E4B\u950B\u5203",
    "kind": "completed",
    "apiName": "TFT_Item_GuardianAngel",
    "unique": true,
    "slotCost": 1,
    "conventionIds": [
      "A-14",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "sword",
      "vest"
    ],
    "effectDescriptions": ["\u53D7\u4F24\u540E\u5B58\u6D3B\u4E14\u751F\u547D\u226460%\u65F6\u6BCF\u6218\u4E00\u6B21\u6E05\u9664\u53EF\u79FB\u9664\u7684\u654C\u65B9\u63A7\u5236\u3001\u6301\u7EED\u4F24\u5BB3\u548C\u51CF\u76CA\uFF1B1\u79D2\u65E0\u6CD5\u9009\u4E2D\u5E76\u9632\u6B62\u4F24\u5BB3\uFF0C\u7ED3\u675F\u540E\u83B7\u5F9715%\u653B\u901F\u3002"],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 1e3
      },
      {
        "kind": "statFlat",
        "stat": "armor",
        "amount": 20
      }
    ],
    combatProgram: { survival: [survival(6e3, [{ kind: "cleanse", remove: "removable-hostile-control-dot-debuff", retarget: true }, status("untargetable", 1e4, 20, { activation: "immediate", onEnd: { reasons: ["expired"], timing: "expiry-before-actions", effects: [stat(modifier("attackSpeed", 1500, "bps"))] } }), status("damage-prevention", 1e4, 20, { activation: "immediate" })])] }
  },
  {
    "id": "infinity-edge",
    "name": "\u65E0\u5C3D\u4E4B\u5203",
    "kind": "completed",
    "apiName": "TFT_Item_InfinityEdge",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-17",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "sword",
      "gloves"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387+35%\uFF1B\u6280\u80FD\u4F24\u5BB3\u53EF\u66B4\u51FB\uFF0C\u91CD\u590D\u6280\u80FD\u66B4\u51FB\u6388\u6743\u6BCF\u6B21\u52A010%\u66B4\u4F24\u3002"],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 3500
      }
    ],
    combatProgram: { modifiers: [modifier("critChance", 3500, "bps")], effects: [{ kind: "authorize-spell-crit", duplicateBonusBps: 1e3 }] }
  },
  {
    "id": "giant-slayer",
    "name": "\u5DE8\u4EBA\u6740\u624B",
    "kind": "completed",
    "apiName": "TFT_Item_MadredsBloodrazor",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01",
      "GS-01"
    ],
    "recipe": [
      "sword",
      "bow"
    ],
    "effectDescriptions": ["\u57FA\u7840\u589E\u4F245%\uFF1B\u6BCF\u5305\u76EE\u6807\u5F53\u524D\u6700\u5927\u751F\u547D\u4E25\u683C\u8D85\u8FC71750\u65F6\u53E6\u52A020%\u3002"],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 2500
      },
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 25
      },
      {
        "kind": "attackSpeedBps",
        "bps": 1e3
      }
    ],
    combatProgram: { modifiers: [modifier("damageAmp", 500, "bps"), modifier("damageAmp", 2e3, "bps", { kind: "target-max-hp", op: "gt", hp: 1750 })] }
  },
  {
    "id": "steraks-gage",
    "name": "\u65AF\u7279\u62C9\u514B\u7684\u6311\u6218\u62A4\u624B",
    "kind": "completed",
    "apiName": "TFT_Item_SteraksGage",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "sword",
      "belt"
    ],
    "effectDescriptions": ["\u5F00\u573A\u6216\u53D7\u4F24\u540E\u5B58\u6D3B\u4E14\u751F\u547D\u226460%\u65F6\u6BCF\u6218\u4E00\u6B21\u589E\u52A025%\u6700\u5927\u751F\u547D\u53CA\u7B49\u91CF\u5F53\u524D\u751F\u547D\u300135%\u653B\u51FB\u529B\uFF0C\u6301\u7EED\u672C\u6218\u3002"],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 1500
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      }
    ],
    combatProgram: { survival: [survival(6e3, [{ kind: "change-max-hp", bonusBps: 2500, currentHp: "add-max-delta", countsAsHeal: false }, stat(modifier("attackDamage", 3500, "bps"))], true)] }
  }
];

// src/simulation/content/items-bow.ts
var BOW_ITEMS = [
  {
    "id": "last-whisper",
    "name": "\u6700\u540E\u7684\u8F7B\u8BED",
    "kind": "completed",
    "apiName": "TFT_Item_LastWhisper",
    "unique": true,
    "slotCost": 1,
    "conventionIds": [
      "A-20",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "bow",
      "gloves"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387+20%\uFF1B\u6B63\u7269\u7406\u4F24\u5BB3\uFF08\u542B\u62A4\u76FE\u4F24\u5BB3\uFF09\u4E4B\u540E\u65BD\u52A030%\u524A\u75323\u79D2\uFF0C\u540C\u7C7B\u53D6\u6700\u5F3A\uFF0C\u5237\u65B0\u4E0D\u53E0\u4E58\u3002"],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 1500
      },
      {
        "kind": "attackSpeedBps",
        "bps": 2e3
      }
    ],
    combatProgram: { modifiers: [modifier("critChance", 2e3, "bps")], triggers: [trigger({ event: "damage-dealt", selector: enemies({ candidates: "event-target" }), effects: [status("sunder", 3e3, 60, { activation: "immediate" })] })] }
  },
  {
    "id": "nashors-tooth",
    "name": "\u7EB3\u4EC0\u4E4B\u7259",
    "kind": "completed",
    "apiName": "TFT_Item_Leviathan",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-21",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "belt",
      "bow"
    ],
    "effectDescriptions": ["\u5B8C\u6210\u65BD\u6CD5\u540E\u4E0B\u4E00tick\u83B7\u5F9760%\u653B\u901F5\u79D2\uFF0C\u540C\u4EF6\u5237\u65B0\u4E0D\u53E0\u52A0\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 10
      },
      {
        "kind": "attackSpeedBps",
        "bps": 1e3
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      }
    ],
    combatProgram: { triggers: [trigger({ event: "cast-completed", effects: [stat(modifier("attackSpeed", 6e3, "bps"), 100, "next-tick")] })] }
  },
  {
    "id": "red-buff",
    "evidenceStatus": "approved-provisional",
    "name": "\u7EA2\u9738\u7B26",
    "kind": "completed",
    "apiName": "TFT_Item_RapidFireCannon",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "B-07",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "bow",
      "bow"
    ],
    "effectDescriptions": ["\u57FA\u7840\u589E\u4F243%\uFF1B\u6B63\u666E\u653B\u548C\u6280\u80FD\u4F24\u5BB3\u65BD\u52A05\u79D2\u707C\u70E7\u4E0E33%\u91CD\u4F24\uFF0C\u6BCF\u79D2\u707C\u70E71%\u5F53\u524D\u6700\u5927\u751F\u547D\u3002"],
    "effects": [
      {
        "kind": "attackSpeedBps",
        "bps": 3500
      }
    ],
    combatProgram: { modifiers: [modifier("damageAmp", 300, "bps")], triggers: [trigger({ event: "damage-dealt", selector: enemies({ candidates: "event-target" }), effects: burn(100) })] }
  },
  {
    "id": "runaans-hurricane",
    "evidenceStatus": "approved-provisional",
    "name": "\u5362\u5B89\u5A1C\u7684\u98D3\u98CE",
    "kind": "completed",
    "apiName": "TFT_Item_RunaansHurricane",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "B-10",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "cloak",
      "bow"
    ],
    "effectDescriptions": ["\u6BCF\u6B21\u5B8C\u6210\u666E\u653B\u5411\u6700\u8FD1\u7684\u53E6\u4E00\u654C\u4EBA\u53D1\u5C0455%\u5F53\u524D\u653B\u51FB\u529B\u7684\u7269\u7406\u88C5\u5907\u7BAD\u77E2\uFF1B\u4E0D\u66B4\u51FB\u3001\u4E0D\u9644\u5E26\u653B\u51FB\u7279\u6548\u3002"],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 2500
      },
      {
        "kind": "attackSpeedBps",
        "bps": 1e3
      },
      {
        "kind": "statFlat",
        "stat": "magicResist",
        "amount": 20
      }
    ],
    combatProgram: { triggers: [trigger({ selector: enemies({ excludePrimary: true, maxTargets: 1 }), effects: [damage("physical", { attackDamageBps: 5500 })] })] }
  },
  {
    "id": "statikk-shiv",
    "name": "\u65AF\u5854\u7F07\u514B\u7535\u5203",
    "kind": "completed",
    "apiName": "TFT_Item_StatikkShiv",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "B-13",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "bow",
      "tear"
    ],
    "effectDescriptions": ["\u6BCF\u7B2C3\u6B21\u5B8C\u6210\u666E\u653B\uFF0C\u5BF9\u4E3B\u76EE\u6807\u53CA\u6700\u8FD1\u6700\u591A3\u4E2A\u4E0D\u540C\u654C\u4EBA\u5148\u65BD\u52A030%\u51CF\u9B54\u62975\u79D2\uFF0C\u518D\u9020\u621035\u9B54\u6CD5\u88C5\u5907\u4F24\u5BB3\uFF0C\u4E0D\u66B4\u51FB\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 15
      },
      {
        "kind": "attackSpeedBps",
        "bps": 1500
      },
      {
        "kind": "statFlat",
        "stat": "initialMana",
        "amount": 15
      }
    ],
    combatProgram: { triggers: [trigger({ counters: [{ id: "attacks", events: [{ event: "attack-completed", listener: { subject: "actor", relationToHolder: "self", withinHexes: null }, qualifies: "completed-event" }], scope: "source-instance", reset: "combat-start", cap: null }], gate: { kind: "every-n", counterId: "attacks", everyN: 3, firstAt: 3 }, selector: enemies({ primary: "first-required", anchor: "primary-target", maxTargets: 4 }), effects: [status("shred", 3e3, 100, { activation: "immediate" }), damage("magic", { flat: 35 })] })] }
  },
  {
    "id": "titans-resolve",
    "name": "\u6CF0\u5766\u7684\u575A\u51B3",
    "kind": "completed",
    "apiName": "TFT_Item_TitansResolve",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "vest",
      "bow"
    ],
    "effectDescriptions": ["\u6BCF\u6B21\u5B8C\u6210\u666E\u653B\u53CA\u6BCF\u4E2A\u6B63\u5B9E\u9645\u627F\u4F24\u5305\uFF08\u542B\u62A4\u76FE\u627F\u4F24\uFF09\u5404\u53E01\u5C42\uFF1B\u6BCF\u5C422%\u653B\u51FB\u529B\u30012\u6CD5\u5F3A\uFF0C\u4E0B\u4E00tick\u751F\u6548\uFF0C\u6301\u7EED\u672C\u573A\uFF0C\u6700\u591A25\u5C42\u3002\u6EE1\u5C42\u989D\u591620\u53CC\u6297\u6BCF\u4EF6\u53EA\u6388\u4E88\u4E00\u6B21\uFF1B\u96F6\u4F24\u5BB3\u4E0D\u53E0\u5C42\u3002"],
    "effects": [
      {
        "kind": "attackSpeedBps",
        "bps": 1e3
      },
      {
        "kind": "statFlat",
        "stat": "armor",
        "amount": 20
      }
    ],
    combatProgram: { triggers: [trigger({ id: "growth", event: "counter-updated", counters: [{ id: "stacks", events: [{ event: "attack-completed", listener: { subject: "actor", relationToHolder: "self", withinHexes: null }, qualifies: "completed-event" }, { event: "damage-taken", listener: { subject: "target", relationToHolder: "self", withinHexes: null }, qualifies: "positive-actual-damage" }], scope: "source-instance", reset: "combat-start", cap: 25 }], effects: ["attackDamage", "abilityPower"].map((s, i) => stat({ ...modifier(s, 0, i === 0 ? "bps" : "flat"), value: { kind: "counter", counterId: "stacks", perCount: i === 0 ? 200 : 2 } }, null, "next-tick")) }), trigger({ id: "cap", event: "counter-updated", counters: [{ id: "stacks", events: [{ event: "attack-completed", listener: { subject: "actor", relationToHolder: "self", withinHexes: null }, qualifies: "completed-event" }, { event: "damage-taken", listener: { subject: "target", relationToHolder: "self", withinHexes: null }, qualifies: "positive-actual-damage" }], scope: "source-instance", reset: "combat-start", cap: 25 }], gate: { kind: "stack-threshold-once", counterId: "stacks", at: 25, rewardId: "resists" }, effects: [stat(modifier("armor", 20), null, "next-tick"), stat(modifier("magicResist", 20), null, "next-tick")] })] }
  }
];

// src/simulation/content/items-rod.ts
var ROD_ITEMS = [
  {
    "id": "crownguard",
    "name": "\u5195\u536B",
    "kind": "completed",
    "apiName": "TFT_Item_Crownguard",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-08",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "vest",
      "rod"
    ],
    "effectDescriptions": ["\u5F00\u6218\u83B7\u5F9725%\u6700\u5927\u751F\u547D\u62A4\u76FE8\u79D2\uFF1B\u62A4\u76FE\u8017\u5C3D\u6216\u81EA\u7136\u5230\u671F\u540E\u83B7\u5F9725\u6CD5\u5F3A\u81F3\u6218\u6597\u7ED3\u675F\uFF0C\u6B7B\u4EA1\u6E05\u9664\u4E0D\u5956\u52B1\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 20
      },
      {
        "kind": "statFlat",
        "stat": "armor",
        "amount": 20
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 100
      }
    ],
    combatProgram: { effects: [shield(2500, 160, [stat(modifier("abilityPower", 25))])] }
  },
  {
    "id": "ionic-spark",
    "name": "\u79BB\u5B50\u706B\u82B1",
    "kind": "completed",
    "apiName": "TFT_Item_IonicSpark",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-18",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "rod",
      "cloak"
    ],
    "effectDescriptions": ["2\u683C\u5185\u5B58\u6D3B\u654C\u4EBA\u9B54\u6297\u964D\u4F4E30%\uFF1B\u8303\u56F4\u5185\u654C\u4EBA\u5B8C\u6210\u65BD\u6CD5\u65F6\u53D7\u5B9E\u9645\u6D88\u8017\u6CD5\u529B\xD7160%\u7684\u9B54\u6CD5\u88C5\u5907\u4F24\u5BB3\uFF0C\u4E0D\u66B4\u51FB\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 15
      },
      {
        "kind": "statFlat",
        "stat": "magicResist",
        "amount": 25
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 100
      }
    ],
    combatProgram: { periodic: [periodic(1, [status("shred", 3e3, 1, { activation: "immediate" })], enemies({ radius: 2, maxTargets: 100, sample: "each-tick" }))], triggers: [trigger({ event: "cast-completed", listener: { subject: "actor", relationToHolder: "enemy", withinHexes: 2 }, selector: enemies({ candidates: "event-actor" }), effects: [damage("magic", { actualManaSpentBps: 16e3 })] })] }
  },
  {
    "id": "jeweled-gauntlet",
    "name": "\u73E0\u5149\u62A4\u624B",
    "kind": "completed",
    "apiName": "TFT_Item_JeweledGauntlet",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-19",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "rod",
      "gloves"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387+35%\uFF1B\u6280\u80FD\u4F24\u5BB3\u53EF\u66B4\u51FB\uFF0C\u91CD\u590D\u6280\u80FD\u66B4\u51FB\u6388\u6743\u6BCF\u6B21\u52A010%\u66B4\u4F24\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 35
      }
    ],
    combatProgram: { modifiers: [modifier("critChance", 3500, "bps")], effects: [{ kind: "authorize-spell-crit", duplicateBonusBps: 1e3 }] }
  },
  {
    "id": "morellonomicon",
    "name": "\u83AB\u96F7\u6D1B\u79D8\u5178",
    "kind": "completed",
    "apiName": "TFT_Item_Morellonomicon",
    "unique": true,
    "slotCost": 1,
    "conventionIds": [
      "B-01",
      "B-02",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "belt",
      "rod"
    ],
    "effectDescriptions": ["\u6B63\u666E\u653B\u548C\u6280\u80FD\u4F24\u5BB3\u65BD\u52A010\u79D2\u707C\u70E7\u4E0E33%\u91CD\u4F24\uFF0C\u6BCF\u79D2\u707C\u70E71%\u5F53\u524D\u6700\u5927\u751F\u547D\uFF1B\u4E2D\u7ACB\u6BCF\u8DF3\u4E0A\u9650100\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 25
      },
      {
        "kind": "attackSpeedBps",
        "bps": 1e3
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      }
    ],
    combatProgram: { triggers: [trigger({ event: "damage-dealt", selector: enemies({ candidates: "event-target" }), effects: burn(200) })] }
  }
];

// src/simulation/content/items-tear.ts
var TEAR_ITEMS = [
  {
    "id": "adaptive-helm",
    "name": "\u81EA\u9002\u5E94\u5934\u76D4",
    "kind": "completed",
    "apiName": "TFT_Item_AdaptiveHelm",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-01",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "cloak",
      "tear"
    ],
    "effectDescriptions": ["\u5F00\u6218\u9501\u5B9A\u5DF1\u65B9\u524D\u4E24\u6392\uFF1A40\u53CC\u6297\u3001\u6BCF\u6B21\u666E\u901A\u653B\u51FB\u547D\u4E2D\u989D\u5916\u56DE1\u84DD\uFF1B\u540E\u4E24\u6392\uFF1A15\u6CD5\u5F3A\u3001\u6BCF3\u79D2\u56DE10\u84DD\u3002\u79FB\u52A8\u4E0D\u5207\u6362\u5206\u652F\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 10
      },
      {
        "kind": "statFlat",
        "stat": "magicResist",
        "amount": 20
      },
      {
        "kind": "statFlat",
        "stat": "initialMana",
        "amount": 15
      }
    ],
    combatProgram: { modifiers: [modifier("armor", 40, "flat", rows("front-two")), modifier("magicResist", 40, "flat", rows("front-two")), modifier("abilityPower", 15, "flat", rows("back-two"))], triggers: [trigger({ event: "incoming-basic-hit", listener: { subject: "target", relationToHolder: "self", withinHexes: null }, condition: rows("front-two"), effects: [mana(1, "incoming-basic-hit")] })], periodic: [periodic(60, [mana(10, "periodic")], selector({ sample: "each-pulse" }), { condition: rows("back-two") })] }
  },
  {
    "id": "blue-buff",
    "name": "\u84DD\u9738\u7B26",
    "kind": "completed",
    "apiName": "TFT_Item_BlueBuff",
    "unique": true,
    "slotCost": 1,
    "conventionIds": [
      "A-05",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "tear",
      "tear"
    ],
    "effectDescriptions": ["\u5B8C\u6210\u65BD\u6CD5\u56DE\u590D10\u6CD5\u529B\uFF0C\u53EF\u7ED5\u8FC7\u8BE5\u6B21\u65BD\u6CD5\u9501\u84DD\uFF1B\u53C2\u4E0E\u51FB\u6740\u540E\u589E\u4F245%\u6301\u7EED8\u79D2\uFF0C\u540C\u4EF6\u5237\u65B0\u4E0D\u53E0\u52A0\u3002"],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 1500
      },
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 15
      },
      {
        "kind": "statFlat",
        "stat": "initialMana",
        "amount": 30
      }
    ],
    combatProgram: { triggers: [trigger({ id: "refund", event: "cast-completed", effects: [mana(10, "cast-refund")] }), trigger({ id: "takedown", event: "kill-or-assist", effects: [stat(modifier("damageAmp", 500, "bps"), 160)] })] }
  },
  {
    "id": "protectors-vow",
    "name": "\u5723\u76FE\u4F7F\u7684\u8A93\u7EA6",
    "kind": "completed",
    "apiName": "TFT_Item_FrozenHeart",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-11",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "vest",
      "tear"
    ],
    "effectDescriptions": ["\u53D7\u4F24\u540E\u5B58\u6D3B\u4E14\u751F\u547D\u226440%\u65F6\u6BCF\u6218\u4E00\u6B21\u83B7\u5F9725%\u6700\u5927\u751F\u547D\u62A4\u76FE5\u79D2\u53CA20\u53CC\u6297\u81F3\u6218\u6597\u7ED3\u675F\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "armor",
        "amount": 20
      },
      {
        "kind": "statFlat",
        "stat": "initialMana",
        "amount": 30
      }
    ],
    combatProgram: { survival: [survival(4e3, [shield(2500, 100), stat(modifier("armor", 20)), stat(modifier("magicResist", 20))])] }
  },
  {
    "id": "redemption",
    "name": "\u6551\u8D4E",
    "kind": "completed",
    "apiName": "TFT_Item_Redemption",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "B-09",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "belt",
      "tear"
    ],
    "effectDescriptions": ["\u6BCF5\u79D2\u6CBB\u75971\u683C\u5185\u5B58\u6D3B\u53CB\u519B\uFF08\u5305\u62EC\u81EA\u8EAB\uFF0915%\u5DF2\u635F\u751F\u547D\uFF0C\u6BCF\u6B21\u6BCF\u76EE\u6807\u4E0A\u96501000\uFF1B\u540C\u65F6\u65BD\u52A0\u4E0B\u4E00tick\u751F\u6548\u768410%\u5E38\u89C4\u51CF\u4F245\u79D2\uFF0C\u540C\u7C7B\u4E0D\u53E0\u52A0\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "initialMana",
        "amount": 15
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      }
    ],
    combatProgram: { periodic: [periodic(100, [{ kind: "heal", amount: amount({ missingHpBps: 1500, hpBasis: "target", sample: "each-pulse", cap: 1e3 }) }, status("damage-reduction", 1e3, 100, { activation: "next-tick" })], selector({ relation: "ally", radius: 1, maxTargets: 100, sample: "each-pulse" }))] }
  },
  {
    "id": "hand-of-justice",
    "name": "\u6B63\u4E49\u4E4B\u624B",
    "kind": "completed",
    "apiName": "TFT_Item_UnstableConcoction",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "gloves",
      "tear"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387+20%\uFF1B\u57FA\u784015%\u653B\u51FB\u529B\u300115\u6CD5\u5F3A\u300112%\u5168\u80FD\u5438\u8840\uFF1B\u751F\u547D\u4E25\u683C\u9AD8\u4E8E50%\u653B\u51FB/\u6CD5\u5F3A\u7FFB\u500D\uFF0C\u4E25\u683C\u4F4E\u4E8E50%\u5438\u8840\u7FFB\u500D\uFF0C\u607050%\u4E0D\u7FFB\u500D\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "initialMana",
        "amount": 15
      }
    ],
    combatProgram: { modifiers: [modifier("critChance", 2e3, "bps"), modifier("attackDamage", 1500, "bps"), modifier("abilityPower", 15), modifier("attackDamage", 1500, "bps", hp("gt", 5e3)), modifier("abilityPower", 15, "flat", hp("gt", 5e3))], vamp: [vamp(1200), vamp(1200, hp("lt", 5e3))] }
  }
];

// src/simulation/content/items-vest.ts
var VEST_ITEMS = [
  {
    "id": "bramble-vest",
    "name": "\u68D8\u523A\u80CC\u5FC3",
    "kind": "completed",
    "apiName": "TFT_Item_BrambleVest",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-06",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "vest",
      "vest"
    ],
    "effectDescriptions": ["\u666E\u653B\u5305\u51CF\u4F248%\uFF1B\u6BCF\u6B21\u666E\u901A\u653B\u51FB\u547D\u4E2D\uFF08\u542B\u62A4\u76FE\uFF09\u54111\u683C\u5185\u654C\u4EBA\u53CD\u51FB100\u9B54\u6CD5\u88C5\u5907\u4F24\u5BB3\uFF0C\u6BCF\u4EF6\u51B7\u53742\u79D2\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "armor",
        "amount": 65
      },
      {
        "kind": "statPercentBps",
        "stat": "maxHp",
        "bps": 700
      }
    ],
    combatProgram: { modifiers: [modifier("damageReduction", 800, "bps", always, filter(["basic-attack"]))], triggers: [trigger({ event: "incoming-basic-hit", listener: { subject: "target", relationToHolder: "self", withinHexes: null }, internalCooldownTicks: 40, selector: enemies({ radius: 1, maxTargets: 100 }), effects: [damage("magic", { flat: 100 })] })] }
  },
  {
    "id": "steadfast-heart",
    "name": "\u575A\u5B9A\u4E4B\u5FC3",
    "kind": "completed",
    "apiName": "TFT_Item_NightHarvester",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "vest",
      "gloves"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387+20%\uFF1B\u6BCF\u53D7\u4F24\u5305\u4E4B\u524D\u68C0\u67E5\u5F53\u524D\u751F\u547D\uFF1A\u4E25\u683C\u9AD8\u4E8E50%\u51CF\u4F2415%\uFF0C\u5176\u4F598%\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "armor",
        "amount": 20
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 200
      }
    ],
    combatProgram: { modifiers: [modifier("critChance", 2e3, "bps"), modifier("damageReduction", 800, "bps", always, filter()), modifier("damageReduction", 1500, "bps", hp("gt", 5e3), filter())] }
  },
  {
    "id": "sunfire-cape",
    "name": "\u65E5\u708E\u6597\u7BF7",
    "kind": "completed",
    "apiName": "TFT_Item_RedBuff",
    "unique": true,
    "slotCost": 1,
    "conventionIds": [
      "B-02",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "vest",
      "belt"
    ],
    "effectDescriptions": ["\u6BCF2\u79D2\u9009\u62E92\u683C\u5185\u4F18\u5148\u672A\u53D7\u672C\u4EF6\u707C\u70E7\u7684\u654C\u4EBA\uFF0C\u65BD\u52A010\u79D21%\u6BCF\u79D2\u707C\u70E7\u4E0E33%\u91CD\u4F24\uFF1B\u540C\u7C7B\u53D6\u5F3A\uFF0C\u4E2D\u7ACB\u6BCF\u8DF3\u4E0A\u9650100\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "armor",
        "amount": 20
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      },
      {
        "kind": "statPercentBps",
        "stat": "maxHp",
        "bps": 800
      }
    ],
    combatProgram: { periodic: [periodic(40, burn(200), enemies({ radius: 2, order: "not-burned-by-this-instance-distance-id", sample: "each-pulse" }))] }
  }
];

// src/simulation/content/items-cloak.ts
var CLOAK_ITEMS = [
  {
    "id": "quicksilver",
    "name": "\u6C34\u94F6",
    "kind": "completed",
    "apiName": "TFT_Item_Quicksilver",
    "unique": true,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "cloak",
      "gloves"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387+20%\uFF1B\u5F00\u6218\u514D\u63A718\u79D2\uFF0C\u6BCF2\u79D2\u83B7\u5F973%\u653B\u901F\uFF0C\u51719\u6B21\uFF1B\u653B\u901F\u6301\u7EED\u672C\u6218\uFF0C18\u79D2\u672B\u6B21\u52A0\u901F\u540E\u514D\u63A7\u5230\u671F\u3002"],
    "effects": [
      {
        "kind": "attackSpeedBps",
        "bps": 3e3
      },
      {
        "kind": "statFlat",
        "stat": "magicResist",
        "amount": 20
      }
    ],
    combatProgram: { modifiers: [modifier("critChance", 2e3, "bps")], effects: [status("control-immunity", 1e4, 360, { activation: "immediate" })], periodic: [periodic(40, [{ kind: "modify-stat", modifier: modifier("attackSpeed", 300, "bps"), activation: "immediate", duration: combat, stackPolicy: { kind: "add-stacks", cap: null } }], selector({ sample: "each-pulse" }), { endsAtTick: 360, finalPulse: "before-expiry" })] }
  },
  {
    "id": "evenshroud",
    "name": "\u8584\u66AE\u6CD5\u888D",
    "kind": "completed",
    "apiName": "TFT_Item_SpectralGauntlet",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "belt",
      "cloak"
    ],
    "effectDescriptions": ["\u5F00\u6218\u83B7\u5F9725\u53CC\u629710\u79D2\uFF1B2\u683C\u5185\u654C\u4EBA\u62A4\u7532\u964D\u4F4E30%\uFF0C\u79FB\u52A8\u3001\u79BB\u5F00\u6216\u6301\u6709\u8005\u6B7B\u4EA1\u5373\u65F6\u79FB\u9664\u5149\u73AF\uFF0C\u540C\u7C7B\u53D6\u6700\u5F3A\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "magicResist",
        "amount": 20
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      }
    ],
    combatProgram: { effects: [stat(modifier("armor", 25), 200), stat(modifier("magicResist", 25), 200)], periodic: [periodic(1, [status("sunder", 3e3, 1, { activation: "immediate" })], enemies({ radius: 2, maxTargets: 100, sample: "each-tick" }))] }
  }
];

// src/simulation/content/items-belt.ts
var BELT_ITEMS = [
  {
    "id": "guardbreaker",
    "name": "\u7834\u9632\u8005",
    "kind": "completed",
    "apiName": "TFT_Item_PowerGauntlet",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "B-04",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "belt",
      "gloves"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387+20%\u3001\u57FA\u7840\u589E\u4F2410%\uFF1B\u5BF9\u62A4\u76FE\u9020\u6210\u6B63\u4F24\u5BB3\u540E\u53E6\u589E\u4F2415%\u6301\u7EED3\u79D2\uFF0C\u540C\u4EF6\u5237\u65B0\u4E0D\u53E0\u52A0\uFF0C\u89E6\u53D1\u5305\u4E0D\u4EAB\u53D7\u65B0\u589E\u76CA\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 10
      },
      {
        "kind": "attackSpeedBps",
        "bps": 2e3
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      }
    ],
    combatProgram: { modifiers: [modifier("critChance", 2e3, "bps"), modifier("damageAmp", 1e3, "bps")], triggers: [trigger({ event: "shield-hit", effects: [stat(modifier("damageAmp", 1500, "bps"), 60)] })] }
  }
];

// src/simulation/content/items-gloves.ts
var GLOVES_ITEMS = [
  {
    "id": "thiefs-gloves",
    "name": "\u7A83\u8D3C\u624B\u5957",
    "kind": "completed",
    "apiName": "TFT_Item_ThiefsGloves",
    "unique": false,
    "slotCost": 3,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "gloves",
      "gloves"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387+20%\uFF1B\u672C\u4F53\u4E0E\u4E34\u65F6\u4EF6\u5360\u75283\u69FD\u3002\u6BCF\u8F6E\u9996\u6B21\u7A7F\u6234\u751F\u6210\u4E34\u65F6\u88C5\u5907\uFF1A7\u7EA7\u53CA\u4EE5\u4E0A\u4E24\u4EF6\u6210\u88C5\uFF0C\u4EE5\u4E0B\u6210\u88C5\uFF0B\u7EC4\u4EF6\uFF1B\u540C\u8F6E\u4FDD\u6301\u7EC4\u5408\uFF0C\u65B0\u8F6E\u5237\u65B0\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      }
    ],
    combatProgram: { modifiers: [modifier("critChance", 2e3, "bps")], effects: [{ kind: "temporary-equipment", policyId: "TG-01", lifetime: "round" }] }
  }
];

// src/simulation/content/items.ts
var ITEM_DEFINITIONS = freezeContent({
  ...Object.fromEntries([COMPONENTS_ITEMS, SWORD_ITEMS, BOW_ITEMS, ROD_ITEMS, TEAR_ITEMS, VEST_ITEMS, CLOAK_ITEMS, BELT_ITEMS, GLOVES_ITEMS].flat().map((item) => [item.id, item])),
  ...{
    "rageblade": {
      "id": "rageblade",
      "effectDescriptions": ["\u6BCF\u6B21\u5B8C\u6210\u666E\u653B\u53E0\u52A05%\u653B\u901F\uFF0C\u6301\u7EED\u672C\u573A\uFF0C\u65E0\u4E0A\u9650\u3002"],
      "name": "\u9B3C\u7D22\u7684\u72C2\u66B4\u4E4B\u5203",
      "kind": "completed",
      "apiName": "TFT_Item_GuinsoosRageblade",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "A-15",
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "bow",
        "rod"
      ],
      "effects": [
        {
          "kind": "statFlat",
          "stat": "abilityPower",
          "amount": 10
        },
        {
          "kind": "attackSpeedBps",
          "bps": 1e3
        },
        {
          "kind": "mechanic",
          "mechanic": "rageblade",
          "values": {
            "attackSpeedBps": 500
          }
        }
      ]
    },
    "deathblade": {
      "id": "deathblade",
      "effectDescriptions": ["\u5E38\u9A7B\u589E\u4F248%\uFF0C\u4E0E\u653B\u51FB\u529B\u5C5E\u6027\u5206\u522B\u8BA1\u7B97\u3002"],
      "name": "\u6B7B\u4EA1\u4E4B\u5203",
      "kind": "completed",
      "apiName": "TFT_Item_Deathblade",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "A-09",
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "sword",
        "sword"
      ],
      "effects": [
        {
          "kind": "statPercentBps",
          "stat": "attackDamage",
          "bps": 5500
        },
        {
          "kind": "mechanic",
          "mechanic": "damageAmp",
          "values": {
            "bps": 800
          }
        }
      ]
    },
    "shojin": {
      "id": "shojin",
      "effectDescriptions": ["\u6BCF\u6B21\u5B8C\u6210\u666E\u653B\u989D\u5916\u56DE5\u6CD5\u529B\uFF0C\u4ECD\u53D7\u9501\u84DD\u4E0E\u4E0A\u9650\u9650\u5236\u3002"],
      "name": "\u6714\u6781\u4E4B\u77DB",
      "kind": "completed",
      "apiName": "TFT_Item_SpearOfShojin",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "sword",
        "tear"
      ],
      "effects": [
        {
          "kind": "statPercentBps",
          "stat": "attackDamage",
          "bps": 1500
        },
        {
          "kind": "statFlat",
          "stat": "abilityPower",
          "amount": 15
        },
        {
          "kind": "statFlat",
          "stat": "initialMana",
          "amount": 15
        },
        {
          "kind": "mechanic",
          "mechanic": "extraAttackMana",
          "values": {
            "amount": 5
          }
        }
      ]
    },
    "archangel": {
      "id": "archangel",
      "effectDescriptions": ["\u6BCF5\u79D2\u589E\u52A030\u6CD5\u5F3A\uFF0C\u6301\u7EED\u672C\u573A\uFF0C\u9996\u6B21\u4E0D\u662F\u5F00\u6218\u3002"],
      "name": "\u5927\u5929\u4F7F\u4E4B\u6756",
      "kind": "completed",
      "apiName": "TFT_Item_ArchangelsStaff",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "A-02",
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "rod",
        "tear"
      ],
      "effects": [
        {
          "kind": "statFlat",
          "stat": "abilityPower",
          "amount": 20
        },
        {
          "kind": "statFlat",
          "stat": "initialMana",
          "amount": 15
        },
        {
          "kind": "mechanic",
          "mechanic": "archangel",
          "values": {
            "periodTicks": 100,
            "abilityPower": 30
          }
        }
      ]
    },
    "deathcap": {
      "id": "deathcap",
      "effectDescriptions": ["\u5E38\u9A7B\u589E\u4F2415%\u3002"],
      "name": "\u706D\u4E16\u8005\u7684\u6B7B\u4EA1\u4E4B\u5E3D",
      "kind": "completed",
      "apiName": "TFT_Item_RabadonsDeathcap",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "B-06",
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "rod",
        "rod"
      ],
      "effects": [
        {
          "kind": "statFlat",
          "stat": "abilityPower",
          "amount": 50
        },
        {
          "kind": "mechanic",
          "mechanic": "damageAmp",
          "values": {
            "bps": 1500
          }
        }
      ]
    },
    "warmog": {
      "id": "warmog",
      "effectDescriptions": ["\u751F\u547D\u6309\uFF08\u57FA\u7840\u4E0E\u56FA\u5B9A\u751F\u547D\u4E4B\u548C\uFF09\xD7\uFF081+\u5408\u8BA1\u751F\u547D\u767E\u5206\u6BD4\uFF09\u8BA1\u7B97\u3002"],
      "name": "\u72C2\u5F92\u94E0\u7532",
      "kind": "completed",
      "apiName": "TFT_Item_WarmogsArmor",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "belt",
        "belt"
      ],
      "effects": [
        {
          "kind": "statFlat",
          "stat": "maxHp",
          "amount": 600
        },
        {
          "kind": "statPercentBps",
          "stat": "maxHp",
          "bps": 1200
        }
      ]
    },
    "dragons-claw": {
      "id": "dragons-claw",
      "effectDescriptions": ["\u6BCF2\u79D2\u6CBB\u7597\u5F53\u65F6\u6700\u5927\u751F\u547D\u76842.5%\uFF0C\u4E0D\u590D\u6D3B\u3001\u4E0D\u8F6C\u76FE\u3002"],
      "name": "\u5DE8\u9F99\u4E4B\u722A",
      "kind": "completed",
      "apiName": "TFT_Item_DragonsClaw",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "A-10",
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "cloak",
        "cloak"
      ],
      "effects": [
        {
          "kind": "statFlat",
          "stat": "magicResist",
          "amount": 75
        },
        {
          "kind": "statPercentBps",
          "stat": "maxHp",
          "bps": 900
        },
        {
          "kind": "mechanic",
          "mechanic": "dragonClaw",
          "values": {
            "periodTicks": 40,
            "healMaxHpBps": 250
          }
        }
      ]
    },
    "gargoyle": {
      "id": "gargoyle",
      "effectDescriptions": ["\u6BCF\u4E2A\u5F53\u524D\u4E3B\u76EE\u6807\u4E3A\u6301\u6709\u8005\u7684\u5B58\u6D3B\u654C\u4EBA\u589E\u52A010\u53CC\u6297\uFF0C\u76EE\u6807\u6539\u53D8\u6216\u6B7B\u4EA1\u5373\u65F6\u91CD\u7B97\u3002"],
      "name": "\u77F3\u50CF\u9B3C\u77F3\u677F\u7532",
      "kind": "completed",
      "apiName": "TFT_Item_GargoyleStoneplate",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "A-12",
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "vest",
        "cloak"
      ],
      "effects": [
        {
          "kind": "statFlat",
          "stat": "maxHp",
          "amount": 100
        },
        {
          "kind": "statFlat",
          "stat": "armor",
          "amount": 25
        },
        {
          "kind": "statFlat",
          "stat": "magicResist",
          "amount": 25
        },
        {
          "kind": "mechanic",
          "mechanic": "gargoyle",
          "values": {
            "resistPerEnemy": 10
          }
        }
      ]
    },
    "gunblade": {
      "id": "gunblade",
      "effectDescriptions": ["15%\u5168\u80FD\u5438\u8840\uFF1B\u5408\u8D44\u683C\u5B9E\u9645\u76FE\u4F24+\u751F\u547D\u4F24\u5BB3\u768425%\u6CBB\u7597\u53E6\u4E00\u540D\u751F\u547D\u6BD4\u4F8B\u6700\u4F4E\u5B58\u6D3B\u53CB\u519B\uFF0C\u540C\u503C\u6309\u7A33\u5B9AID\uFF0C\u4E0D\u6CBB\u7597\u81EA\u8EAB\u3002"],
      "name": "\u6D77\u514B\u65AF\u79D1\u6280\u67AA\u5203",
      "kind": "completed",
      "apiName": "TFT_Item_HextechGunblade",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "A-16",
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "sword",
        "rod"
      ],
      "effects": [
        {
          "kind": "statPercentBps",
          "stat": "attackDamage",
          "bps": 2e3
        },
        {
          "kind": "statFlat",
          "stat": "abilityPower",
          "amount": 20
        },
        {
          "kind": "mechanic",
          "mechanic": "gunblade",
          "values": {
            "selfHealBps": 1500,
            "allyHealBps": 2500
          }
        }
      ]
    }
  }
});
var COMPONENT_IDS = Object.freeze(Object.values(ITEM_DEFINITIONS).filter((item) => item.kind === "component").sort((a, b) => a.apiName < b.apiName ? -1 : 1).map((item) => item.id));

// src/simulation/component-pool.ts
var COMPONENT_POOL_VERSION = "m8b-components-v1";
var COMPONENT_POOL = Object.freeze([
  ["TFT_Item_BFSword", "sword"],
  ["TFT_Item_ChainVest", "vest"],
  ["TFT_Item_GiantsBelt", "belt"],
  ["TFT_Item_NeedlesslyLargeRod", "rod"],
  ["TFT_Item_NegatronCloak", "cloak"],
  ["TFT_Item_RecurveBow", "bow"],
  ["TFT_Item_SparringGloves", "gloves"],
  ["TFT_Item_TearOfTheGoddess", "tear"]
].map(([apiName, definitionId2]) => Object.freeze({ apiName, definitionId: definitionId2 })));
function validateComponentPool(catalog = ITEM_DEFINITIONS) {
  const components = Object.values(catalog).filter((i) => i.kind === "component");
  if (components.length !== 8 || new Set(components.map((i) => i.apiName)).size !== 8 || COMPONENT_POOL.some((p) => catalog[p.definitionId]?.kind !== "component" || catalog[p.definitionId].apiName !== p.apiName)) throw new RangeError("Invalid m8b-components-v1 mapping");
}
function validateComponentCandidates(ids2, version = COMPONENT_POOL_VERSION) {
  validateComponentPool();
  if (version !== COMPONENT_POOL_VERSION || ids2.length !== 8 || ids2.some((id2, i) => id2 !== COMPONENT_POOL[i].definitionId) || new Set(ids2).size !== 8) throw new RangeError("Invalid component candidates");
}
validateComponentCandidates(COMPONENT_IDS);

// src/simulation/rng.ts
function validateSeed(seed) {
  if (!Number.isInteger(seed) || seed < 0 || seed > 4294967295) throw new RangeError("Seed must be a uint32 integer");
}
function nextRandom(state) {
  const word = Math.imul(state, 1664525) + 1013904223 >>> 0;
  return { word, state: word };
}

// src/simulation/m8/stats.ts
function integer(value, minimum = 0) {
  if (!Number.isSafeInteger(value) || value < minimum) throw new RangeError("Expected safe integer");
  return BigInt(value);
}
function safeNumber(value) {
  const result = Number(value);
  if (!Number.isSafeInteger(result)) throw new RangeError("Unsafe numeric result");
  return result;
}
function conditionHolds(condition, sample) {
  switch (condition.kind) {
    case "always":
      return true;
    case "positive-hp-damage":
      if (sample.positiveHpDamage === void 0) throw new RangeError("Missing HP damage sample");
      return sample.positiveHpDamage;
    case "hp-ratio": {
      const unit = condition.subject === "holder" ? sample.holder : sample.target;
      if (!unit) throw new RangeError("Missing HP ratio subject");
      const left = integer(unit.hp) * 10000n, right = integer(unit.maxHp, 1) * integer(condition.thresholdBps);
      return condition.op === "gt" ? left > right : condition.op === "lt" ? left < right : left <= right;
    }
    case "target-max-hp":
      if (!sample.target) throw new RangeError("Missing target HP");
      return integer(sample.target.maxHp, 1) > integer(condition.hp);
    case "starting-rows":
      if (!sample.startingRows) throw new RangeError("Missing frozen starting rows");
      return sample.startingRows === condition.rows;
    case "enemy-targeting-holder":
      if (!sample.enemiesTargetingHolder) throw new RangeError("Missing current primary targets");
      return sample.enemiesTargetingHolder.length > 0;
  }
}
function modifierValues(stat2, modifiers, sample) {
  let flat = 0n, bps = 0n, resistanceReduction = 0n;
  for (const entry of modifiers) {
    const modifier2 = "modifier" in entry ? entry.modifier : entry;
    const counters = "modifier" in entry ? entry.counters : sample.counters;
    if (modifier2.stat !== stat2) continue;
    if (modifier2.unit === "hexes" && stat2 !== "range" || stat2 === "range" && modifier2.unit !== "hexes" || ["attackSpeed", "critChance", "critMultiplier", "damageAmp", "damageReduction", "omnivamp"].includes(stat2) && modifier2.unit !== "bps") throw new RangeError("Invalid modifier unit");
    if (stat2 === "damageReduction") {
      if (!modifier2.damageFilter || !sample.packet) throw new RangeError("Reduction requires explicit filter and packet");
      const f = modifier2.damageFilter, c = sample.packet;
      if (f.deliveries !== "all" && !f.deliveries.includes(c.delivery) || f.damageTypes !== "all" && !f.damageTypes.includes(c.damageType) || f.redirected === "exclude" && c.redirected || f.redirected === "only" && !c.redirected) continue;
    } else if (modifier2.damageFilter !== null) throw new RangeError("Only reduction accepts a damage filter");
    if (!conditionHolds(modifier2.condition, sample)) continue;
    let value;
    switch (modifier2.value.kind) {
      case "constant":
        value = integer(modifier2.value.amount, Number.MIN_SAFE_INTEGER);
        break;
      case "counter":
        if (!counters || !Object.hasOwn(counters, modifier2.value.counterId)) throw new RangeError("Missing modifier counter");
        value = integer(counters[modifier2.value.counterId]) * integer(modifier2.value.perCount, Number.MIN_SAFE_INTEGER);
        break;
      case "unit-count":
        if (!sample.enemiesTargetingHolder) throw new RangeError("Missing current unit count");
        value = BigInt(new Set(sample.enemiesTargetingHolder).size) * integer(modifier2.value.perUnit, Number.MIN_SAFE_INTEGER);
        break;
    }
    if (stat2 === "damageReduction") {
      if (modifier2.unit !== "bps" || value < 0n || value > 10000n) throw new RangeError("Invalid reduction");
      bps = value > bps ? value : bps;
    } else if ((stat2 === "armor" || stat2 === "magicResist") && modifier2.unit === "bps" && value < 0n)
      resistanceReduction = value < resistanceReduction ? value : resistanceReduction;
    else if (modifier2.unit === "bps") bps += value;
    else flat += value;
  }
  return { flat: safeNumber(flat), bps: safeNumber(bps + resistanceReduction) };
}
function resolveStat(stat2, base, modifiers, sample) {
  const { flat, bps } = modifierValues(stat2, modifiers, sample);
  if (stat2 === "damageReduction") return Math.max(base, bps);
  if (["attackSpeed", "critChance", "critMultiplier", "damageAmp", "omnivamp"].includes(stat2)) {
    const total = integer(base, Number.MIN_SAFE_INTEGER) + integer(flat, Number.MIN_SAFE_INTEGER) + integer(bps, Number.MIN_SAFE_INTEGER);
    if (stat2 === "critChance") return total < 0n ? 0 : total > 10000n ? 1e4 : safeNumber(total);
    return safeNumber(total > 0n ? total : 0n);
  }
  const numerator = (integer(base, Number.MIN_SAFE_INTEGER) + integer(flat, Number.MIN_SAFE_INTEGER)) * (10000n + integer(bps, Number.MIN_SAFE_INTEGER));
  return Math.max(stat2 === "maxHp" ? 1 : 0, safeNumber(numerator / 10000n));
}
function attackInterval(baseSpeedBps, bonusBps) {
  const denominator = integer(baseSpeedBps, 1) * (10000n + integer(bonusBps, -9999));
  return Math.max(1, safeNumber((2000000000n + denominator - 1n) / denominator));
}
function changeMaxHp(beforeMax, beforeHp, afterMax) {
  integer(beforeMax, 1);
  integer(beforeHp);
  integer(afterMax, 1);
  if (beforeHp > beforeMax) throw new RangeError("Invalid current HP");
  return {
    beforeMax,
    afterMax,
    beforeHp,
    afterHp: beforeHp === 0 ? 0 : Math.max(0, Math.min(afterMax, safeNumber(BigInt(beforeHp) + BigInt(afterMax) - BigInt(beforeMax)))),
    countsAsHeal: false
  };
}
function amountNumerator(amount3, sample) {
  const hp2 = amount3.hpBasis === "holder" ? sample.holder : sample.target;
  if (!hp2) throw new RangeError("Missing amount HP basis");
  integer(hp2.hp);
  integer(hp2.maxHp, 1);
  if (hp2.hp > hp2.maxHp) throw new RangeError("Invalid HP sample");
  let numerator = integer(amount3.flat) * 10000n + integer(sample.attackDamage) * integer(amount3.attackDamageBps) + integer(sample.abilityPower) * integer(amount3.abilityPowerBps) + integer(hp2.maxHp) * integer(amount3.maxHpBps) + integer(hp2.maxHp - hp2.hp) * integer(amount3.missingHpBps);
  if (amount3.actualManaSpentBps !== 0) {
    if (!sample.cast?.completed) throw new RangeError("Missing completed cast receipt");
    numerator += integer(sample.cast.actualManaSpent) * integer(amount3.actualManaSpentBps);
  }
  if (amount3.actualDamageBps !== 0) {
    const outcomes = sample.damageOutcomes ?? (sample.damage ? [sample.damage] : []);
    const actual = outcomes.filter((d) => d.hit).reduce((sum, d) => sum + integer(d.absorbed) + integer(d.hpDamage), 0n);
    if (actual <= 0n) throw new RangeError("Missing positive damage outcome");
    numerator += actual * integer(amount3.actualDamageBps);
  }
  if (amount3.shieldAbsorbedBps !== 0) {
    if (sample.shieldAbsorbed === void 0) throw new RangeError("Missing shield absorption sample");
    numerator += integer(sample.shieldAbsorbed) * integer(amount3.shieldAbsorbedBps);
  }
  return numerator;
}
function evaluateAmount(amount3, sample) {
  const value = amountNumerator(amount3, sample) / 10000n;
  return safeNumber(amount3.cap === null ? value : value < integer(amount3.cap) ? value : integer(amount3.cap));
}

// src/simulation/m8/identity.ts
var compareCodePoints = (a, b) => a < b ? -1 : a > b ? 1 : 0;
var sourceTuple = (s) => [s.ownerId, s.sourceKind, s.definitionId, s.instanceId, s.effectIndex, s.parentItemInstanceId];
var canonicalSource = (s) => JSON.stringify(sourceTuple(s));
function effectIdentity(combatId, source, targetId, applicationId = "source") {
  const tuple = [combatId, source.ownerId, source.sourceKind, source.definitionId, source.instanceId, source.effectIndex, source.parentItemInstanceId, targetId, applicationId];
  return { key: JSON.stringify(tuple), source, targetId };
}
function validateIdentity(value, combatId) {
  const tuple = JSON.parse(value.key);
  if (!Array.isArray(tuple) || tuple.length !== 9 || typeof tuple[0] !== "string" || typeof tuple[8] !== "string" || !tuple[8] || combatId !== void 0 && tuple[0] !== combatId || JSON.stringify(tuple) !== value.key || effectIdentity(tuple[0], value.source, value.targetId, tuple[8]).key !== value.key) throw new RangeError("Invalid effect identity");
  integer(value.source.effectIndex);
  for (const text of [value.targetId, value.source.ownerId, value.source.definitionId, value.source.instanceId]) if (typeof text !== "string" || !text) throw new RangeError("Invalid effect source");
  if (!["attack", "ability", "trait", "item", "augment", "anomaly", "enemyGrowth"].includes(value.source.sourceKind) || value.source.parentItemInstanceId !== null && (typeof value.source.parentItemInstanceId !== "string" || !value.source.parentItemInstanceId)) throw new RangeError("Invalid source kind/parent");
}
function gcd(a, b) {
  while (b !== 0n) {
    const next = a % b;
    a = b;
    b = next;
  }
  return a;
}
function fraction(numerator, denominator) {
  return { numerator: integer(numerator), denominator: integer(denominator, 1) };
}
function addFractions(a, b) {
  const common = gcd(a.denominator, b.denominator), denominator = a.denominator / common * b.denominator;
  return { numerator: a.numerator * (denominator / a.denominator) + b.numerator * (denominator / b.denominator), denominator };
}
function savedFraction(f) {
  const divisor = gcd(f.numerator, f.denominator);
  return { numerator: safeNumber(f.numerator / divisor), denominator: safeNumber(f.denominator / divisor) };
}

// src/simulation/m8/equipment.ts
var key = (parent, round2) => JSON.stringify([parent, round2]);
function initializeStreams(seed) {
  integer(seed);
  if (seed > 4294967295) throw new RangeError("Invalid seed");
  return { equipment: { state: (seed ^ 608135816) >>> 0, draws: 0 }, encounter: { state: (seed ^ 3084996962) >>> 0, draws: 0 }, loot: { state: (seed ^ 3735928559) >>> 0, draws: 0 } };
}
function uniformIndex(size, draw) {
  integer(size, 1);
  if (size > 4294967296) throw new RangeError("Uniform pool too large");
  const limit = Math.floor(4294967296 / size) * size;
  for (; ; ) {
    const word = draw();
    integer(word);
    if (word > 4294967295) throw new RangeError("Invalid random word");
    if (word < limit) return word % size;
  }
}
function validatePool(pool) {
  const all = [...pool.completed, ...pool.components];
  if (pool.version !== "tg-01-v1" || pool.completed.length !== 35 || pool.components.length !== 8 || all.some((e) => !e.apiName || !e.definitionId) || new Set(all.map((e) => e.apiName)).size !== 43 || new Set(all.map((e) => e.definitionId)).size !== 43) throw new RangeError("Invalid approved TG pool");
}
function selectTemporaryPair(playerLevel, pool, draw) {
  integer(playerLevel, 1);
  validatePool(pool);
  const completed = [...pool.completed].sort((a, b) => compareCodePoints(a.apiName, b.apiName)), components = [...pool.components].sort((a, b) => compareCodePoints(a.apiName, b.apiName));
  const first = completed[uniformIndex(completed.length, draw)], secondPool = playerLevel <= 6 ? components : completed.filter((e) => e.definitionId !== first.definitionId);
  return [first.definitionId, secondPool[uniformIndex(secondPool.length, draw)].definitionId];
}
function generateRoundRolls(state, requests, pool) {
  validatePool(pool);
  validateEquipmentState(state, pool);
  const seen = /* @__PURE__ */ new Set();
  for (const r of requests) {
    integer(r.playerLevel, 1);
    if (!r.parentItemInstanceId || !r.roundId || seen.has(key(r.parentItemInstanceId, r.roundId))) throw new RangeError("Invalid round roll request");
    seen.add(key(r.parentItemInstanceId, r.roundId));
  }
  const pending = requests.filter((r) => !state.rolls.some((old) => key(old.parentItemInstanceId, old.roundId) === key(r.parentItemInstanceId, r.roundId))).sort((a, b) => compareCodePoints(a.parentItemInstanceId, b.parentItemInstanceId) || compareCodePoints(a.roundId, b.roundId));
  if (!pending.length) return state;
  if (new Set(pending.map((r) => r.roundId)).size > 1) throw new RangeError("One round per equipment generation transaction");
  let rng = { ...state.equipment };
  const draw = () => {
    const next = nextRandom(rng.state);
    rng = { state: next.state, draws: rng.draws + 1 };
    integer(rng.draws);
    return next.word;
  };
  const additions = pending.map((r) => {
    const rngDrawStart = rng.draws, children = selectTemporaryPair(r.playerLevel, pool, draw);
    return { parentItemInstanceId: r.parentItemInstanceId, roundId: r.roundId, playerLevelSnapshot: r.playerLevel, poolVersion: pool.version, children, rngDrawStart, rngDrawEnd: rng.draws };
  });
  return { equipment: rng, rolls: [...state.rolls, ...additions] };
}
function projectTemporaryEquipment(roll, holderId) {
  if (!holderId) throw new RangeError("Missing temporary holder");
  return roll.children.map((definitionId2, index) => ({ temporaryId: JSON.stringify([roll.parentItemInstanceId, roll.roundId, index + 1]), parentItemInstanceId: roll.parentItemInstanceId, roundId: roll.roundId, holderId, definitionId: definitionId2, slot: index + 1, expiresAfterRoundId: roll.roundId }));
}
function reconcileTemporaryEquipment(previous, desired) {
  const same4 = (a, b) => a.temporaryId === b.temporaryId && a.parentItemInstanceId === b.parentItemInstanceId && a.roundId === b.roundId && a.holderId === b.holderId && a.definitionId === b.definitionId && a.slot === b.slot && a.expiresAfterRoundId === b.expiresAfterRoundId;
  const sort = (a, b) => compareCodePoints(a.temporaryId, b.temporaryId);
  return { remove: previous.filter((a) => !desired.some((b) => same4(a, b))).sort(sort), apply: desired.filter((b) => !previous.some((a) => same4(a, b))).sort(sort) };
}
function validateEquipmentState(state, pool, initialStream) {
  validatePool(pool);
  integer(state.equipment.state);
  integer(state.equipment.draws);
  if (state.equipment.state > 4294967295) throw new RangeError("Invalid equipment stream");
  const seen = /* @__PURE__ */ new Set();
  let end = 0;
  for (const r of state.rolls) {
    const id2 = key(r.parentItemInstanceId, r.roundId);
    integer(r.playerLevelSnapshot, 1);
    integer(r.rngDrawStart);
    integer(r.rngDrawEnd);
    const second = r.playerLevelSnapshot <= 6 ? pool.components : pool.completed;
    if (seen.has(id2) || !r.parentItemInstanceId || !r.roundId || r.poolVersion !== pool.version || r.children.length !== 2 || !pool.completed.some((e) => e.definitionId === r.children[0]) || !second.some((e) => e.definitionId === r.children[1]) || r.children[0] === r.children[1] || r.rngDrawStart !== end || r.rngDrawEnd < r.rngDrawStart + 2 || r.rngDrawEnd > state.equipment.draws) throw new RangeError("Invalid equipment roll ledger");
    seen.add(id2);
    end = r.rngDrawEnd;
  }
  if (end !== state.equipment.draws) throw new RangeError("Unreceipted equipment draws");
  if (initialStream) {
    integer(initialStream.state);
    if (initialStream.state > 4294967295 || initialStream.draws !== 0) throw new RangeError("Invalid initial equipment stream");
    let cursor = { ...initialStream };
    const draw = () => {
      const next = nextRandom(cursor.state);
      cursor = { state: next.state, draws: cursor.draws + 1 };
      return next.word;
    };
    const completed = [...pool.completed].sort((a, b) => compareCodePoints(a.apiName, b.apiName)), components = [...pool.components].sort((a, b) => compareCodePoints(a.apiName, b.apiName));
    for (const r of state.rolls) {
      const first = completed[uniformIndex(35, draw)], secondPool = r.playerLevelSnapshot <= 6 ? components : completed.filter((e) => e.definitionId !== first.definitionId);
      const second = secondPool[uniformIndex(secondPool.length, draw)];
      if (r.children[0] !== first.definitionId || r.children[1] !== second.definitionId || r.rngDrawEnd !== cursor.draws) throw new RangeError("Equipment roll does not match trusted initial stream");
    }
    if (cursor.state !== state.equipment.state || cursor.draws !== state.equipment.draws) throw new RangeError("Equipment stream mismatch");
  }
}
function createEquipmentPool(entries) {
  const eligible = entries.filter((e) => !e.effects.some((effect) => effect.kind === "temporary-equipment"));
  const project = (e) => ({ apiName: e.apiName, definitionId: e.definitionId });
  const pool = { version: "tg-01-v1", completed: eligible.filter((e) => e.kind === "completed").map(project), components: eligible.filter((e) => e.kind === "component").map(project) };
  validatePool(pool);
  return pool;
}
function validateTemporaryEquipment(children, rolls) {
  const ids2 = /* @__PURE__ */ new Set(), holders = /* @__PURE__ */ new Map();
  for (const c of children) {
    const roll = rolls.find((r) => r.parentItemInstanceId === c.parentItemInstanceId && r.roundId === c.roundId);
    const pair = key(c.parentItemInstanceId, c.roundId), old = holders.get(c.holderId);
    if (!roll || !c.holderId || c.slot !== 1 && c.slot !== 2 || c.expiresAfterRoundId !== c.roundId || c.definitionId !== roll.children[c.slot - 1] || c.temporaryId !== JSON.stringify([c.parentItemInstanceId, c.roundId, c.slot]) || ids2.has(c.temporaryId) || old !== void 0 && old !== pair) throw new RangeError("Invalid temporary equipment binding/slots");
    ids2.add(c.temporaryId);
    holders.set(c.holderId, pair);
  }
  for (const [holder, pair] of holders) if (children.filter((c) => c.holderId === holder && key(c.parentItemInstanceId, c.roundId) === pair).length !== 2) throw new RangeError("Missing temporary sibling");
}

// src/simulation/content/round-catalog.ts
var ROUND_CATALOG = freezeContent([
  { roundId: "1-2", ordinal: 1, stage: 1, subround: 2, kind: "pve", isFinal: false, encounterId: "minions-a-v1", displayName: "1-2" },
  { roundId: "1-3", ordinal: 2, stage: 1, subround: 3, kind: "pve", isFinal: false, encounterId: "minions-b-v1", displayName: "1-3" },
  { roundId: "1-4", ordinal: 3, stage: 1, subround: 4, kind: "pve", isFinal: false, encounterId: "minions-c-v1", displayName: "1-4" },
  { roundId: "2-1", ordinal: 4, stage: 2, subround: 1, kind: "pvp", isFinal: false, encounterId: null, displayName: "2-1" },
  { roundId: "2-2", ordinal: 5, stage: 2, subround: 2, kind: "pvp", isFinal: false, encounterId: null, displayName: "2-2" },
  { roundId: "2-3", ordinal: 6, stage: 2, subround: 3, kind: "pvp", isFinal: false, encounterId: null, displayName: "2-3" },
  { roundId: "2-4", ordinal: 7, stage: 2, subround: 4, kind: "supply", isFinal: false, encounterId: null, displayName: "2-4" },
  { roundId: "2-5", ordinal: 8, stage: 2, subround: 5, kind: "pvp", isFinal: false, encounterId: null, displayName: "2-5" },
  { roundId: "2-6", ordinal: 9, stage: 2, subround: 6, kind: "pvp", isFinal: false, encounterId: null, displayName: "2-6" },
  { roundId: "2-7", ordinal: 10, stage: 2, subround: 7, kind: "pve", isFinal: false, encounterId: "krugs-v1", displayName: "2-7" },
  { roundId: "3-1", ordinal: 11, stage: 3, subround: 1, kind: "pvp", isFinal: false, encounterId: null, displayName: "3-1" },
  { roundId: "3-2", ordinal: 12, stage: 3, subround: 2, kind: "pvp", isFinal: false, encounterId: null, displayName: "3-2" },
  { roundId: "3-3", ordinal: 13, stage: 3, subround: 3, kind: "pvp", isFinal: false, encounterId: null, displayName: "3-3" },
  { roundId: "3-4", ordinal: 14, stage: 3, subround: 4, kind: "supply", isFinal: false, encounterId: null, displayName: "3-4" },
  { roundId: "3-5", ordinal: 15, stage: 3, subround: 5, kind: "pvp", isFinal: false, encounterId: null, displayName: "3-5" },
  { roundId: "3-6", ordinal: 16, stage: 3, subround: 6, kind: "pvp", isFinal: false, encounterId: null, displayName: "3-6" },
  { roundId: "3-7", ordinal: 17, stage: 3, subround: 7, kind: "pve", isFinal: false, encounterId: "wolves-v1", displayName: "3-7" },
  { roundId: "4-1", ordinal: 18, stage: 4, subround: 1, kind: "pvp", isFinal: false, encounterId: null, displayName: "4-1" },
  { roundId: "4-2", ordinal: 19, stage: 4, subround: 2, kind: "pvp", isFinal: false, encounterId: null, displayName: "4-2" },
  { roundId: "4-3", ordinal: 20, stage: 4, subround: 3, kind: "pvp", isFinal: false, encounterId: null, displayName: "4-3" },
  { roundId: "4-4", ordinal: 21, stage: 4, subround: 4, kind: "supply", isFinal: false, encounterId: null, displayName: "4-4" },
  { roundId: "4-5", ordinal: 22, stage: 4, subround: 5, kind: "pvp", isFinal: false, encounterId: null, displayName: "4-5" },
  { roundId: "4-6", ordinal: 23, stage: 4, subround: 6, kind: "pvp", isFinal: false, encounterId: null, displayName: "4-6" },
  { roundId: "4-7", ordinal: 24, stage: 4, subround: 7, kind: "pve", isFinal: false, encounterId: "razorbeaks-v1", displayName: "4-7" },
  { roundId: "5-1", ordinal: 25, stage: 5, subround: 1, kind: "pvp", isFinal: false, encounterId: null, displayName: "5-1" },
  { roundId: "5-2", ordinal: 26, stage: 5, subround: 2, kind: "pvp", isFinal: false, encounterId: null, displayName: "5-2" },
  { roundId: "5-3", ordinal: 27, stage: 5, subround: 3, kind: "pvp", isFinal: false, encounterId: null, displayName: "5-3" },
  { roundId: "5-4", ordinal: 28, stage: 5, subround: 4, kind: "supply", isFinal: false, encounterId: null, displayName: "5-4" },
  { roundId: "5-5", ordinal: 29, stage: 5, subround: 5, kind: "pvp", isFinal: false, encounterId: null, displayName: "5-5" },
  { roundId: "5-6", ordinal: 30, stage: 5, subround: 6, kind: "pvp", isFinal: false, encounterId: null, displayName: "5-6" },
  { roundId: "5-7", ordinal: 31, stage: 5, subround: 7, kind: "pve", isFinal: false, encounterId: "elder-dragon-v1", displayName: "5-7" },
  { roundId: "6-1", ordinal: 32, stage: 6, subround: 1, kind: "pvp", isFinal: false, encounterId: null, displayName: "6-1" },
  { roundId: "6-2", ordinal: 33, stage: 6, subround: 2, kind: "pvp", isFinal: false, encounterId: null, displayName: "6-2" },
  { roundId: "6-3", ordinal: 34, stage: 6, subround: 3, kind: "pvp", isFinal: false, encounterId: null, displayName: "6-3" },
  { roundId: "6-4", ordinal: 35, stage: 6, subround: 4, kind: "supply", isFinal: false, encounterId: null, displayName: "6-4" },
  { roundId: "6-5", ordinal: 36, stage: 6, subround: 5, kind: "pvp", isFinal: false, encounterId: null, displayName: "6-5" },
  { roundId: "6-6", ordinal: 37, stage: 6, subround: 6, kind: "pvp", isFinal: false, encounterId: null, displayName: "6-6" },
  { roundId: "6-7", ordinal: 38, stage: 6, subround: 7, kind: "pve", isFinal: true, encounterId: "rift-herald-v1", displayName: "6-7" }
]);
var ROUND_SEMANTIC_NODES = freezeContent({
  "2-1": ["augment"],
  "2-4": ["supply"],
  "3-2": ["augment"],
  "3-4": ["supply"],
  "4-2": ["augment"],
  "4-4": ["supply"],
  "4-6": ["anomaly"],
  "5-4": ["supply"],
  "6-4": ["supply"]
});

// src/simulation/round-selectors.ts
function getCatalogRoundByOrdinal(ordinal) {
  if (!Number.isSafeInteger(ordinal)) throw new RangeError("Invalid catalog round ordinal");
  const round2 = ROUND_CATALOG.find((r) => r.ordinal === ordinal);
  if (!round2) throw new RangeError("Unknown catalog round ordinal");
  return round2;
}
function getCatalogRoundById(roundId) {
  const round2 = ROUND_CATALOG.find((r) => r.roundId === roundId);
  if (!round2) throw new RangeError("Unknown catalog round ID");
  return round2;
}
function getNextCatalogRound(roundId) {
  const round2 = getCatalogRoundById(roundId);
  return round2.isFinal ? null : getCatalogRoundByOrdinal(round2.ordinal + 1);
}

// src/simulation/round-schedule.ts
var ROUND_RULES_VERSION = "m8-b6-round-opening-v1";
var FINAL_ROUND = ROUND_CATALOG.at(-1).ordinal;
var ROUND_PREPARATION_RULES = freezeContent({ version: "m8-b8-preparation-v1", pveContent: "ready-b8-loot" });
var fixed = ROUND_CATALOG.flatMap((round2) => (ROUND_SEMANTIC_NODES[round2.roundId] ?? []).map((node) => ({ round: round2.ordinal, event: {
  id: `round:${round2.roundId}:${node}`,
  kind: node === "supply" ? "component" : node,
  priority: node === "augment" ? 20 : node === "anomaly" ? 30 : 10,
  timing: "before"
} })));
var ROUND_SCHEDULE = freezeContent({
  fixed,
  fallbackDefinitionId: "irelia",
  finalRound: FINAL_ROUND,
  recurring: { fromRound: FINAL_ROUND + 1, everyRounds: 7, randomComponents: 0 }
});
function getStageRound(round2) {
  const definition = getCatalogRoundByOrdinal(round2);
  return { stage: definition.stage, round: definition.subround };
}
function getRoundKind(round2) {
  return getCatalogRoundByOrdinal(round2).kind;
}
function getRoundSchedule(round2) {
  getCatalogRoundByOrdinal(round2);
  return ROUND_SCHEDULE.fixed.filter((entry) => entry.round === round2).map(({ event }) => event.kind === "reward" ? { ...event, components: [...event.components] } : { ...event });
}

// src/simulation/match-rules.ts
var OPENING_INITIAL_STATE = freezeContent({
  gold: 0,
  level: 1,
  xp: 0,
  hp: 100,
  unit: { definitionId: "irelia", id: "unit-1", starLevel: 1, cell: { col: 1, row: 4 } },
  nextUnitSeq: 2
});
var MATCH_RULES = Object.freeze({
  initialGold: OPENING_INITIAL_STATE.gold,
  rerollCost: 2,
  roundIncome: 5,
  shopSize: 5,
  initialLevel: OPENING_INITIAL_STATE.level,
  maxLevel: 9,
  initialHp: OPENING_INITIAL_STATE.hp,
  xpPurchaseCost: 4,
  xpPurchaseAmount: 4,
  roundXp: 2
});
var DEFAULT_MATCH_SEED = 42;
var XP_TO_NEXT_LEVEL = Object.freeze({ 1: 2, 2: 2, 3: 6, 4: 10, 5: 20, 6: 36, 7: 48, 8: 76 });
var SHOP_ODDS = Object.freeze({
  1: [100, 0, 0, 0, 0],
  2: [100, 0, 0, 0, 0],
  3: [75, 25, 0, 0, 0],
  4: [55, 30, 15, 0, 0],
  5: [45, 33, 20, 2, 0],
  6: [30, 40, 25, 5, 0],
  7: [19, 30, 40, 10, 1],
  8: [18, 25, 32, 22, 3],
  9: [15, 20, 25, 30, 10]
});
for (const row of Object.values(SHOP_ODDS)) Object.freeze(row);
var SHOP_CATALOG_BY_COST = Object.freeze({
  1: Object.freeze(["darius", "irelia", "lux", "maddie", "zyra"]),
  2: Object.freeze(["leona", "rell", "tristana", "urgot", "vander"]),
  3: Object.freeze(["ezreal", "kogmaw", "loris", "nami", "scar"]),
  4: Object.freeze(["corki", "garen", "zoe"]),
  5: Object.freeze(["caitlyn"])
});
var SHOP_CATALOG = Object.freeze(Object.values(SHOP_CATALOG_BY_COST).flat());
var STAGE_PLAYER_DAMAGE = Object.freeze({ 2: 2, 3: 5, 4: 8, 5: 10, 6: 12 });
var ECONOMY_RULES = Object.freeze({
  interestDivisor: 10,
  interestCap: 5,
  victoryGold: 1,
  pveFailureDamage: 3,
  streakThresholds: Object.freeze([Object.freeze({ count: 2, gold: 1 }), Object.freeze({ count: 4, gold: 2 }), Object.freeze({ count: 6, gold: 3 })])
});
var OPENING_ECONOMY_RULES = freezeContent({
  version: "m8b-opening-project-v1",
  rounds: { "1-2": { baseGold: 2, naturalXp: 2 }, "1-3": { baseGold: 3, naturalXp: 2 }, "1-4": { baseGold: 5, naturalXp: 0 } },
  interest: 0,
  victoryGold: 0,
  streakGold: 0,
  updateStreak: false,
  pveFailureDamage: ECONOMY_RULES.pveFailureDamage
});

// src/simulation/temporary-equipment.ts
var grantsTemporaryEquipment = (definition) => definition.combatProgram?.effects?.some((effect) => effect.kind === "temporary-equipment") ?? false;
var TEMPORARY_EQUIPMENT_POOL = freezeContent(createEquipmentPool(Object.values(ITEM_DEFINITIONS).map((item) => ({
  apiName: item.apiName,
  definitionId: item.id,
  kind: item.kind,
  effects: item.combatProgram?.effects ?? []
}))));
function projectCurrent(state) {
  return state.items.filter((item) => item.location.kind === "unit" && grantsTemporaryEquipment(ITEM_DEFINITIONS[item.definitionId])).sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0).flatMap((parent) => {
    if (parent.location.kind !== "unit") throw new Error("Expected equipped parent");
    const roll = state.equipmentState.rolls.find((roll2) => roll2.parentItemInstanceId === parent.id && roll2.roundId === state.roundDefinitionId);
    if (!roll) throw new Error("Missing equipped parent round roll");
    return projectTemporaryEquipment(roll, parent.location.unitId);
  });
}
function planTemporaryEquipment(state) {
  const requests = state.items.filter((item) => item.location.kind === "unit" && grantsTemporaryEquipment(ITEM_DEFINITIONS[item.definitionId])).map((item) => ({ parentItemInstanceId: item.id, roundId: state.roundDefinitionId, playerLevel: state.level }));
  const equipmentState = generateRoundRolls(state.equipmentState, requests, TEMPORARY_EQUIPMENT_POOL);
  const desired = projectCurrent({ ...state, equipmentState });
  const changes = reconcileTemporaryEquipment(state.temporaryEquipment, desired);
  const events = equipmentState.rolls.slice(state.equipmentState.rolls.length).map((roll) => ({ type: "equipmentRolled", roll: structuredClone(roll) }));
  if (changes.remove.length || changes.apply.length) events.push({
    type: "temporaryEquipmentChanged",
    removed: structuredClone(changes.remove),
    applied: structuredClone(changes.apply)
  });
  return { state: equipmentState === state.equipmentState && !events.length ? state : { ...state, equipmentState, temporaryEquipment: desired }, events };
}
function isTemporaryItemId(state, id2) {
  return state.equipmentState.rolls.some((roll) => [1, 2].some((slot3) => JSON.stringify([roll.parentItemInstanceId, roll.roundId, slot3]) === id2));
}
function validateMatchEquipment(state) {
  const __b8Timer = globalThis.__b8Start("validateMatchEquipment");
  try {
    validateEquipmentState(state.equipmentState, TEMPORARY_EQUIPMENT_POOL, initializeStreams(state.seed).equipment);
    if (!Number.isInteger(state.round) || state.round < 1 || state.round > FINAL_ROUND) throw new Error("Invalid equipment round");
    const roundIds = ROUND_CATALOG.slice(0, state.round).map((round2) => round2.roundId);
    let previousRound = -1;
    for (const roll of state.equipmentState.rolls) {
      const parent = state.items.find((item) => item.id === roll.parentItemInstanceId), round2 = roundIds.indexOf(roll.roundId);
      if (!parent || !grantsTemporaryEquipment(ITEM_DEFINITIONS[parent.definitionId]) || ITEM_DEFINITIONS[parent.definitionId].slotCost !== 3 || round2 < 0 || round2 < previousRound || roll.playerLevelSnapshot < MATCH_RULES.initialLevel || roll.playerLevelSnapshot > state.level) {
        throw new Error("Invalid equipment parent/round/level");
      }
      const startingLevel = round2 === 0 ? MATCH_RULES.initialLevel : state.roundResults[round2 - 1].levelAfter;
      const lastRollLevel = state.roundResults[round2]?.levelBefore ?? state.level;
      if (roll.playerLevelSnapshot < startingLevel || roll.playerLevelSnapshot > lastRollLevel) {
        throw new Error("Invalid equipment round level");
      }
      previousRound = round2;
    }
    validateTemporaryEquipment(state.temporaryEquipment, state.equipmentState.rolls);
    const expected = projectCurrent(state), actual = state.temporaryEquipment;
    if (actual.length !== expected.length || expected.some((child) => !actual.some((other) => child.temporaryId === other.temporaryId && child.parentItemInstanceId === other.parentItemInstanceId && child.roundId === other.roundId && child.holderId === other.holderId && child.definitionId === other.definitionId && child.slot === other.slot && child.expiresAfterRoundId === other.expiresAfterRoundId))) {
      throw new Error("Invalid current temporary equipment projection");
    }
  } finally {
    globalThis.__b8End(__b8Timer);
  }
}

// src/simulation/equipment-policy.ts
var EQUIPMENT_RULES_VERSION = "m8-b5-instances-v2";
function checkEquipmentPlacement(items, item, unitId, slot3) {
  if (!Number.isInteger(slot3) || slot3 < 0 || slot3 > 2) {
    return { allowed: false, reason: "invalid-slot", conflictingItemIds: [] };
  }
  const definition = ITEM_DEFINITIONS[item.definitionId];
  if (!definition) throw new RangeError("Unknown item definition");
  const held = items.filter((other) => other.id !== item.id && other.location.kind === "unit" && other.location.unitId === unitId);
  const duplicates = held.filter((other) => {
    const otherDefinition = ITEM_DEFINITIONS[other.definitionId];
    return (definition.unique || otherDefinition.unique) && (definition.apiName ?? definition.id) === (otherDefinition.apiName ?? otherDefinition.id);
  });
  if (duplicates.length) return { allowed: false, reason: "unique-conflict", conflictingItemIds: duplicates.map((i) => i.id).sort() };
  const exclusive = held.filter((other) => definition.slotCost === 3 || ITEM_DEFINITIONS[other.definitionId].slotCost === 3);
  if (exclusive.length) return { allowed: false, reason: "exclusive-slots", conflictingItemIds: exclusive.map((i) => i.id).sort() };
  const occupied = held.filter((other) => other.location.kind === "unit" && other.location.slot === slot3);
  if (occupied.length) return { allowed: false, reason: "item-slot-occupied", conflictingItemIds: occupied.map((i) => i.id).sort() };
  return { allowed: true, reason: null, occupiedSlots: definition.slotCost === 3 ? [0, 1, 2] : [slot3], conflictingItemIds: [] };
}

// src/simulation/s13-rules.ts
var S13_COMBAT_RULES = Object.freeze({
  tickMs: 50,
  maxTicks: 1200,
  moveIntervalTicks: 5,
  abilityPowerBase: 100,
  attackCritBps: 2500,
  critMultiplierBps: 14e3,
  attackMana: 10,
  damageManaBps: 300,
  damageManaCap: 20,
  attackSpeedIntervalNumerator: 2e9,
  starStatPercent: Object.freeze([100, 180, 324]),
  arithmeticRevision: "m8-b4-catalog-1",
  modifierPipeline: "m8-global-numeric-01-bigint-intermediates-safe-integer-results",
  damagePipeline: "m8-g02-delivery-permissions-true-bypass-inherited-single-mitigation",
  spellCriticalStrikes: "m8-g03-authorized-per-packet-actor-action-target-ordinal-word-threshold",
  neutralAttackTiming: "legacy-authored-ticks-explicit-new-neutral-base-bps-final-ceil",
  attackSpeedStacking: "original-base-times-sum-static-runtime-status-final-ceil",
  packetOrder: "owner-action-target-ordinal",
  statusTiming: "new-action-status-next-tick-full-duration",
  openingControlTiming: "m8-b3-v1-bound-packet-then-surviving-target-next-tick-stun",
  periodicTiming: "final-before-expiry-ordinary-before-actions-per-task-effect-target-rational-remainders",
  statusStacking: "same-instance-refresh-independent-instances-strongest-retains-suppressed-burn-clock-only",
  healingPipeline: "exact-merge-once-wound-cap-three-stage-largest-remainder-source-shares",
  shieldPipeline: "initial-linear-decay-distinct-from-absorption-end-consumed-once",
  survivalPipeline: "whole-batch-positive-damage-surviving-hp-and-maxhp-frozen-before-effects",
  anomalySampling: "one-word-full-range-scale-exclude-last",
  emptyAnomaly: "defer-until-purchase-preserve-affordable-offer",
  damageSharing: "all-hit-packets-including-mitigated-ricochet-one-transfer-no-recursion",
  ricochet: "primary-lethal-only-once-per-action-no-redirect-no-recursion"
});

// src/simulation/board.ts
var DEFAULT_BOARD = {
  columns: 7,
  rows: 8,
  deploymentZones: {
    enemy: { firstRow: 0, lastRow: 3 },
    player: { firstRow: 4, lastRow: 7 }
  }
};
function contains(board, cell) {
  return Number.isInteger(cell.col) && Number.isInteger(cell.row) && cell.col >= 0 && cell.col < board.columns && cell.row >= 0 && cell.row < board.rows;
}
function sameCell(a, b) {
  return a.col === b.col && a.row === b.row;
}
function isDeploymentCell(board, team, cell) {
  const zone = board.deploymentZones[team];
  return contains(board, cell) && cell.row >= zone.firstRow && cell.row <= zone.lastRow;
}
function getNeighbors(board, cell) {
  if (!contains(board, cell)) return [];
  const offset2 = cell.row % 2;
  const deltas = [[1, 0], [offset2, 1], [offset2 - 1, 1], [-1, 0], [offset2 - 1, -1], [offset2, -1]];
  return deltas.map(([col, row]) => ({ col: cell.col + col, row: cell.row + row })).filter((neighbor) => contains(board, neighbor));
}
function hexDistance(a, b) {
  const aq = a.col - Math.floor(a.row / 2);
  const bq = b.col - Math.floor(b.row / 2);
  const dq = aq - bq, dr = a.row - b.row;
  return Math.max(Math.abs(dq), Math.abs(dr), Math.abs(dq + dr));
}

// src/simulation/combat-types.ts
var MAX_COMBAT_TICKS = 1200;
var MOVE_INTERVAL_TICKS = 5;
function compareIds(a, b) {
  return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}
function eliminationResult(units) {
  const player = units.some((unit) => unit.alive && unit.team === "player");
  const enemy = units.some((unit) => unit.alive && unit.team === "enemy");
  return player && enemy ? null : player ? "playerWin" : enemy ? "enemyWin" : "draw";
}

// src/simulation/content/abilities.ts
var S13_ABILITY_DATA = freezeContent({
  "irelia-ability": {
    "id": "irelia-ability",
    "championId": "irelia",
    "variables": {
      "ShieldDuration": [
        3,
        3,
        3
      ],
      "ShieldHealth": [
        400,
        475,
        575
      ],
      "StrikeBaseDamage": [
        70,
        100,
        150
      ],
      "PercentShieldDamage": [
        0.3,
        0.3,
        0.3
      ]
    },
    "description": "Enter a defensive stance and gain <TFTBonus>@ModifiedShield@&nbsp;(%i:scaleAP%)</TFTBonus> Shield that rapidly decays over @ShieldDuration@ seconds. When it expires, deal <magicDamage>@ModifiedBaseStrikeDamage@&nbsp;(%i:scaleAP%)</magicDamage> magic damage + <magicDamage>@PercentShieldDamage*100@%</magicDamage> of the damage absorbed to enemies around and in front of&nbsp;Irelia."
  },
  "maddie-ability": {
    "id": "maddie-ability",
    "championId": "maddie",
    "variables": {
      "PercentAttackDamage": [
        1.25,
        1.25,
        1.4
      ],
      "APDamage": [
        10,
        15,
        25
      ],
      "NumOfShots": [
        6,
        6,
        6
      ],
      "TotalSpellTime": [
        1.15,
        1.15,
        1.15
      ],
      "ShotsPerSimulatedLaunchAttack": [
        3,
        3,
        3
      ]
    },
    "description": "Fire @NumOfShots@ shots towards the farthest enemy that deal <physicalDamage>@TotalDamage@&nbsp;(%i:scaleAD%)</physicalDamage> physical damage to the first enemy they&nbsp;hit."
  },
  "darius-ability": {
    "id": "darius-ability",
    "championId": "darius",
    "variables": {
      "BleedDuration": [
        4,
        4,
        4
      ],
      "PercentAttackDamage": [
        2.4,
        2.4,
        2.4
      ],
      "Heal": [
        150,
        175,
        200
      ],
      "BleedPercentAttackDamage": [
        2,
        2,
        2
      ]
    },
    "description": "Spin, dealing <physicalDamage>@ModifiedDamage@&nbsp;(%i:scaleAD%)</physicalDamage> physical damage to adjacent enemies and healing <scaleHealth>@ModifiedHeal@&nbsp;(%i:scaleAP%)</scaleHealth>. Apply a <physicalDamage>@ModifiedBleedDamage@&nbsp;(%i:scaleAD%)</physicalDamage> physical damage bleed to target over @BleedDuration@&nbsp;seconds."
  },
  "lux-ability": {
    "id": "lux-ability",
    "championId": "lux",
    "variables": {
      "Damage": [
        360,
        540,
        900
      ],
      "Shield": [
        160,
        180,
        240
      ],
      "ShieldDuration": [
        4,
        4,
        4
      ],
      "DamageReduction": [
        0.35,
        0.35,
        0.35
      ]
    },
    "description": "Grant <TFTBonus>@ModifiedShield@&nbsp;(%i:scaleAP%)</TFTBonus> Shield to the lowest current Health ally. Lux's next attack deals <magicDamage>@ModifiedDamage@&nbsp;(%i:scaleAP%)</magicDamage> bonus magic&nbsp;damage."
  },
  "zyra-ability": {
    "id": "zyra-ability",
    "championId": "zyra",
    "variables": {
      "TargetDamage": [
        260,
        390,
        585
      ],
      "StunDuration": [
        1,
        1,
        1
      ],
      "AOEDamage": [
        95,
        140,
        215
      ],
      "NumSmallerVines": [
        2,
        2,
        2
      ]
    },
    "description": "Send vines towards the current target, Stunning them for @StunDuration@ second and dealing <magicDamage>@ModifiedTargetDamage@&nbsp;(%i:scaleAP%)</magicDamage> magic&nbsp;damage. Then smaller vines seek out the @NumSmallerVines@ nearest enemies and deal <magicDamage>@ModifiedAOEDamage@&nbsp;(%i:scaleAP%)</magicDamage> magic damage to them.<br><br><spellActive enabled=TFT13_ExperimentActive alternate=rules>Experiment Bonus:<TFTBonus><ShowIfNot.TFT13_ExperimentActive></ShowIfNot.TFT13_ExperimentActive><ShowIf.TFT13_ExperimentActive></ShowIf.TFT13_ExperimentActive></TFTBonus> Ability damage bleeds enemies for <trueDamage enabled=TFT13_ExperimentActive alternate=rules>@TFTUnitProperty.:TFT13_ZyraCurrentExperimentBonus@%</trueDamage> bonus true damage over @ExperimentDuration@&nbsp;seconds.</spellActive>"
  },
  "tristana-ability": {
    "id": "tristana-ability",
    "championId": "tristana",
    "variables": {
      "PercentAttackDamage": [
        5.25,
        5.25,
        5.25
      ],
      "APDamage": [
        50,
        75,
        115
      ],
      "ASKillGain": [
        1.25,
        1.25,
        1.25
      ]
    },
    "description": "Fire a cannonball at target, dealing <physicalDamage>@TotalDamage@&nbsp;(%i:scaleAD%)</physicalDamage> physical damage. If they die, the cannonball ricochets to the nearest enemy, dealing the overkill damage. When it does, permanently gain <TFTBonus>@TFTUnitProperty.:TFT13_TristanaASPerStack@%</TFTBonus>&nbsp;Attack Damage.<br><br><TFTTrackerLabel>(Current Bonus:&nbsp;@TFTUnitProperty.:TFT13_TristanaASGain@% %i:scaleAD%) </TFTTrackerLabel> "
  },
  "urgot-ability": {
    "id": "urgot-ability",
    "championId": "urgot",
    "variables": {
      "PrimaryDamage": [
        3,
        3,
        3.3
      ],
      "SecondaryDamage": [
        1.5,
        1.5,
        1.65
      ],
      "Duration": [
        6,
        6,
        6
      ],
      "APDamage": [
        35,
        50,
        75
      ]
    },
    "description": "Fire an explosive charge, dealing <physicalDamage>@ModifiedPrimaryDamage@&nbsp;(%i:scaleAD%)</physicalDamage> physical damage to target and <physicalDamage>@ModifiedSecondaryDamage@&nbsp;(%i:scaleAD%)</physicalDamage> physical damage to adjacent enemies. 20% <TFTKeyword>Sunder</TFTKeyword> all enemies hit for @Duration@&nbsp;seconds.<br><br><rules><tftbold>Sunder:</tftbold> Reduce Armor</rules><br><br><spellActive enabled=TFT13_ExperimentActive alternate=rules>Experiment Bonus:<TFTBonus><ShowIfNot.TFT13_ExperimentActive></ShowIfNot.TFT13_ExperimentActive><ShowIf.TFT13_ExperimentActive></ShowIf.TFT13_ExperimentActive></TFTBonus> Dash to targets. On cast, gain <TFTBonus enabled=TFT13_ExperimentActive alternate=rules>@TFTUnitProperty.:TFT13_UrgotCurrentExperimentBonusShield@%</TFTBonus> max Health Shield and <TFTBonus enabled=TFT13_ExperimentActive alternate=rules>@TFTUnitProperty.:TFT13_UrgotCurrentExperimentBonusAS@%</TFTBonus>&nbsp;Attack Speed for @ExperimentDuration@&nbsp;seconds.</spellActive>"
  },
  "rell-ability": {
    "id": "rell-ability",
    "championId": "rell",
    "variables": {
      "StabDamage": [
        120,
        180,
        270
      ],
      "DefenseStealDuration": [
        60,
        60,
        60
      ],
      "DefensesSteal": [
        10,
        12,
        15
      ],
      "ShieldDuration": [
        4,
        4,
        4
      ],
      "Shield": [
        300,
        350,
        400
      ]
    },
    "description": "Gain <TFTBonus>@ModifiedShield@&nbsp;(%i:scaleAP%)</TFTBonus> Shield for @ShieldDuration@ seconds. Lance enemies in a line for <magicDamage>@ModifiedDamage@&nbsp;(%i:scaleAP%)</magicDamage> magic damage and steal <TFTBonus>@DefensesSteal@</TFTBonus> Armor and Magic Resist from enemies&nbsp;hit."
  },
  "leona-ability": {
    "id": "leona-ability",
    "championId": "leona",
    "variables": {
      "Duration": [
        3,
        3,
        3
      ],
      "Damage": [
        115,
        175,
        270
      ],
      "DR": [
        0.5,
        0.5,
        0.5
      ]
    },
    "description": "Fortify for @Duration@ seconds, gaining <TFTBonus>@ModifiedDurability@&nbsp;(%i:scaleAP%)</TFTBonus> Durability. Afterwards, deal <magicDamage>@ModifiedDamage@&nbsp;(%i:scaleAP%)</magicDamage> magic damage to adjacent enemies."
  },
  "vander-ability": {
    "id": "vander-ability",
    "championId": "vander",
    "variables": {
      "TauntDuration": [
        2.5,
        2.5,
        2.5
      ],
      "Resists": [
        100,
        125,
        150
      ],
      "PercentAttackDamage": [
        4,
        4,
        4
      ],
      "BonusDamageADRatio": [
        1,
        1,
        1
      ]
    },
    "description": "Stop attacking and brace for @TauntDuration@ seconds, gaining <TFTBonus>@ModifiedDefenses@&nbsp;(%i:scaleAP%)</TFTBonus> Armor and Magic Resist. Vander's next attack is replaced with a strike that deals <physicalDamage>@ModifiedDamage@&nbsp;(%i:scaleAD%)</physicalDamage> physical damage, increased by <physicalDamage>@ModifiedBonusDamage@&nbsp;(%i:scaleAD%)</physicalDamage> physical damage for each 1 or 2 cost champion on your&nbsp;team. "
  },
  "kogmaw-ability": {
    "id": "kogmaw-ability",
    "championId": "kogmaw",
    "variables": {
      "MaxAS": [
        20,
        20,
        20
      ],
      "AttackSpeed": [
        0.25,
        0.25,
        0.25
      ],
      "Duration": [
        60,
        60,
        60
      ],
      "DamageOnAttack": [
        48,
        72,
        120
      ],
      "RangeIncreaseNumAttacks": [
        3,
        3,
        3
      ]
    },
    "description": "<spellPassive>Passive:</spellPassive> Attacks deal <magicDamage>@ModifiedDamage@&nbsp;(%i:scaleAP%)</magicDamage> bonus magic&nbsp;damage.<br><br><spellActive>Active:</spellActive> Gain <TFTBonus>@AttackSpeed*100@%</TFTBonus> stacking Attack Speed for the rest of combat. After every @RangeIncreaseNumAttacks@ casts, gain&nbsp;+1&nbsp;Range."
  },
  "scar-ability": {
    "id": "scar-ability",
    "championId": "scar",
    "variables": {
      "Heal": [
        220,
        240,
        270
      ],
      "NumEnemies": [
        3,
        3,
        3
      ],
      "StunDuration": [
        1.5,
        1.5,
        1.75
      ],
      "Damage": [
        80,
        120,
        180
      ]
    },
    "description": "Lob bombs at the nearest @NumEnemies@ enemies, Stunning them for <scaleLevel>@StunDuration@</scaleLevel> seconds and dealing <magicDamage>@ModifiedDamage@&nbsp;(%i:scaleAP%)</magicDamage> magic damage to each. Heal <scaleHealth>@ModifiedHeal@&nbsp;(%i:scaleAP%)</scaleHealth>."
  },
  "ezreal-ability": {
    "id": "ezreal-ability",
    "championId": "ezreal",
    "variables": {
      "PercentAttackDamage": [
        1.35,
        1.35,
        1.35
      ],
      "APDamage": [
        20,
        30,
        50
      ],
      "PercentCenterDamage": [
        2.7,
        2.7,
        2.7
      ]
    },
    "description": "Fire a shot towards current target that deals <physicalDamage>@TotalDamage@&nbsp;(%i:scaleAD%)</physicalDamage> physical damage to all enemies within 1 hex. Then, deal <physicalDamage>@ModifiedDamage@&nbsp;(%i:scaleAD%)</physicalDamage> physical damage to the unit in the center of the&nbsp;blast.<br><br><br>"
  },
  "loris-ability": {
    "id": "loris-ability",
    "championId": "loris",
    "variables": {
      "Shield": [
        525,
        600,
        700
      ],
      "Damage": [
        150,
        225,
        360
      ],
      "PercentDamageRedirect": [
        0.5,
        0.5,
        0.5
      ],
      "Duration": [
        4,
        4,
        4
      ]
    },
    "description": "Gain <TFTBonus>@ModifiedShield@&nbsp;(%i:scaleAP%)</TFTBonus> Shield for @Duration@ seconds. It redirects <TFTBonus>@PercentDamageRedirect*100@%</TFTBonus> of damage taken by adjacent allies. When it expires, deal <magicDamage>@ModifiedDamage@&nbsp;(%i:scaleAP%)</magicDamage> magic damage in a&nbsp;cone."
  },
  "nami-ability": {
    "id": "nami-ability",
    "championId": "nami",
    "variables": {
      "NumBounces": [
        3,
        3,
        3
      ],
      "Damage": [
        120,
        180,
        290
      ],
      "SearchRange": [
        3,
        3,
        3
      ],
      "TimesHitTarget": [
        1,
        1,
        1
      ]
    },
    "description": "Launch a wave at target that bounces @NumBounces@ times to enemies within @SearchRange@ hexes and deals <magicDamage>@ModifiedDamage@&nbsp;(%i:scaleAP%)</magicDamage> magic&nbsp;damage."
  },
  "corki-ability": {
    "id": "corki-ability",
    "championId": "corki",
    "variables": {
      "BaseMissiles": [
        21,
        21,
        35
      ],
      "PercentAD": [
        0.35,
        0.35,
        0.6
      ],
      "FlatArmorShred": [
        1,
        1,
        1
      ],
      "SpecialMissileNum": [
        7,
        7,
        7
      ],
      "SpecialMissileMult": [
        7,
        7,
        7
      ],
      "MissilesPerLaunchAttack": [
        5,
        5,
        5
      ],
      "FlatDamagePerMissile": [
        6,
        9,
        36
      ]
    },
    "description": "Lock onto target and strafe to a nearby position, unleashing <scaleLevel>@BaseMissiles@</scaleLevel> missiles split between the target and all enemies within two hexes. Each missile deals <physicalDamage>@ModifiedDamage@&nbsp;(%i:scaleAD%)</physicalDamage> physical damage and reduces Armor by&nbsp;@FlatArmorShred@.<br><br>Every @SpecialMissileNum@th missile deals <physicalDamage>@ModifiedSpecialDamage@&nbsp;(%i:scaleAD%)</physicalDamage> physical damage and reduces Armor by&nbsp;@SpecialMissileArmorReduction@."
  },
  "garen-ability": {
    "id": "garen-ability",
    "championId": "garen",
    "variables": {
      "APShield": [
        200,
        220,
        1500
      ],
      "PercentHealthShield": [
        0.15,
        0.15,
        0.15
      ],
      "ShieldDuration": [
        4,
        4,
        4
      ],
      "ADRatio": [
        2.5,
        2.5,
        15
      ],
      "SecondaryADRatio": [
        1.25,
        1.25,
        7.5
      ],
      "HealPercentHealth": [
        0.015,
        0.015,
        0.05
      ]
    },
    "description": "<spellPassive>Passive:</spellPassive> After dealing damage, heal <scaleHealth>@ModifiedHeal@&nbsp;(%i:scaleHealth%).</scaleHealth><br><br><spellActive>Active:</spellActive> Gain <TFTBonus>@ModifiedShield@&nbsp;(%i:scaleHealth%%i:scaleAP%)</TFTBonus> Shield for @ShieldDuration@ seconds. Slam a massive sword on target, dealing <physicalDamage>@ModifiedDamage@&nbsp;(%i:scaleAD%)</physicalDamage> physical damage to them and <physicalDamage>@ModifiedSecondaryDamage@&nbsp;(%i:scaleAD%)</physicalDamage> physical damage to enemies within 2&nbsp;hexes. "
  },
  "zoe-ability": {
    "id": "zoe-ability",
    "championId": "zoe",
    "variables": {
      "Damage": [
        140,
        210,
        450
      ],
      "NumRepeats": [
        2,
        2,
        4
      ],
      "HexLimiter": [
        4,
        4,
        4
      ]
    },
    "description": "Launch a star at target that deals <magicDamage>@ModifiedDamage@&nbsp;(%i:scaleAP%)</magicDamage> magic damage. It bounces to the farthest enemy within @HexLimiter@ hexes, then bounces back to the target. This effect repeats @NumRepeats@ times, hitting a different enemy each&nbsp;time."
  },
  "caitlyn-ability": {
    "id": "caitlyn-ability",
    "championId": "caitlyn",
    "variables": {
      "RaidDuration": [
        5,
        5,
        5
      ],
      "TotalShots": [
        4,
        4,
        20
      ],
      "PercentAttackDamage": [
        1.8,
        1.8,
        7.5
      ],
      "APDamage": [
        20,
        30,
        100
      ],
      "HeadshotPercentAD": [
        2.8,
        2.8,
        13.5
      ],
      "BonusSearchRange": [
        630,
        630,
        630
      ],
      "PercentShotsFocusedOnFrontline": [
        0.5,
        0.5,
        0.5
      ],
      "ResistReduction": [
        20,
        20,
        20
      ]
    },
    "description": "Enter a sniper's stance and call in an airship that circles the battlefield for @RaidDuration@ seconds, dropping @TotalShots@ bombs at a random cluster of enemies over the duration. Bombs deal <physicalDamage>@TotalDamage@&nbsp;(%i:scaleAD%&nbsp;%i:scaleAP%)</physicalDamage> physical damage in a one-hex&nbsp;circle.<br><br>Whenever an enemy is caught in the epicenter of an Air Raid blast, reduce their Armor and Magic Resist by @ResistReduction@ and fire a shot towards them, dealing <physicalDamage>@HeadshotDamage@&nbsp;(%i:scaleAD%)</physicalDamage> physical&nbsp;damage."
  }
});

// src/simulation/combat-abilities.ts
var definitions = {
  "sentinel-guard": { id: "sentinel-guard", kind: "selfShield", amountByStar: [220, 400, 720], durationTicks: 60 },
  "ranger-shot": { id: "ranger-shot", kind: "damage", damageType: "physical", radius: 0, amountByStar: [150, 270, 486] },
  "mystic-bolt": { id: "mystic-bolt", kind: "damage", damageType: "magic", radius: 0, amountByStar: [180, 324, 583] },
  "bulwark-guard": { id: "bulwark-guard", kind: "selfShield", amountByStar: [300, 540, 972], durationTicks: 60 },
  "archer-shot": { id: "archer-shot", kind: "damage", damageType: "physical", radius: 0, amountByStar: [220, 396, 713] },
  "arcanist-burst": { id: "arcanist-burst", kind: "damage", damageType: "magic", radius: 1, amountByStar: [210, 378, 680] },
  "duelist-strike": { id: "duelist-strike", kind: "damage", damageType: "physical", radius: 0, amountByStar: [300, 540, 972] },
  "warden-guard": { id: "warden-guard", kind: "selfShield", amountByStar: [500, 900, 1620], durationTicks: 60 },
  "tempest-burst": { id: "tempest-burst", kind: "damage", damageType: "magic", radius: 1, amountByStar: [300, 540, 972] },
  "colossus-guard": { id: "colossus-guard", kind: "selfShield", amountByStar: [750, 1350, 2430], durationTicks: 60 },
  "oracle-burst": { id: "oracle-burst", kind: "damage", damageType: "magic", radius: 1, amountByStar: [420, 756, 1361] }
};
var ABILITY_DEFINITIONS = Object.freeze(
  Object.fromEntries(Object.entries(definitions).map(([id2, ability]) => [
    id2,
    Object.freeze({ ...ability, amountByStar: Object.freeze([...ability.amountByStar]) })
  ]))
);
function validateAbilityDefinitions(catalog = ABILITY_DEFINITIONS) {
  const seen = /* @__PURE__ */ new Set();
  for (const [key3, ability] of Object.entries(catalog)) {
    if (!ability.id || key3 !== ability.id || seen.has(ability.id)) throw new Error(`Invalid ability ID: ${key3}`);
    seen.add(ability.id);
    if (ability.amountByStar.length !== 3 || [...ability.amountByStar].some((amount3) => !Number.isSafeInteger(amount3) || amount3 < 0)) {
      throw new RangeError(`Invalid star values for ability: ${key3}`);
    }
    if (ability.kind === "selfShield") {
      if (!Number.isSafeInteger(ability.durationTicks) || ability.durationTicks < 1) throw new RangeError(`Invalid shield duration: ${key3}`);
    } else if (ability.kind !== "damage" || !["physical", "magic"].includes(ability.damageType) || ![0, 1].includes(ability.radius)) {
      throw new Error(`Invalid damage ability: ${key3}`);
    }
  }
}
validateAbilityDefinitions();
function resolveAbility(abilityId, starLevel) {
  if (![1, 2, 3].includes(starLevel)) throw new RangeError("Invalid star level");
  if (Object.hasOwn(S13_ABILITY_DATA, abilityId)) {
    const definition2 = S13_ABILITY_DATA[abilityId];
    return {
      id: abilityId,
      amount: 0,
      kind: "s13",
      championId: definition2.championId,
      variables: Object.fromEntries(Object.entries(definition2.variables).map(([key3, values]) => [key3, Math.round(values[starLevel - 1] * 1e4)]))
    };
  }
  if (abilityId === "neutral-attack" || Object.values(NEUTRAL_DEFINITIONS).some((d) => neutralAbilityId(d) === abilityId)) return { id: abilityId, amount: 0, kind: "s13", championId: "neutral", variables: {} };
  const definition = ABILITY_DEFINITIONS[abilityId];
  if (!definition) throw new Error(`Unknown ability: ${abilityId}`);
  if (![1, 2, 3].includes(starLevel)) throw new RangeError("Invalid star level");
  const amount3 = definition.amountByStar[starLevel - 1];
  return definition.kind === "damage" ? { id: definition.id, kind: "damage", amount: amount3, damageType: definition.damageType, radius: definition.radius } : { id: definition.id, kind: "selfShield", amount: amount3, durationTicks: definition.durationTicks };
}
function planAbility(unit, target, units) {
  if (!unit.alive || !target || unit.mana < unit.maxMana) return void 0;
  const ability = unit.ability;
  if (ability.kind === "s13") return void 0;
  if (ability.kind === "selfShield") {
    return { targetIds: [unit.id], packets: [], shield: { unitId: unit.id, amount: ability.amount, durationTicks: ability.durationTicks } };
  }
  if (hexDistance(unit.cell, target.cell) > unit.attackRange) return void 0;
  const targets = ability.radius === 0 ? [target] : units.filter((other) => other.alive && other.team !== unit.team && hexDistance(other.cell, target.cell) <= ability.radius).sort(compareIds);
  return {
    targetIds: targets.map((other) => other.id),
    packets: targets.map((other, effectIndex) => ({
      sourceId: unit.id,
      targetId: other.id,
      damageType: ability.damageType,
      rawAmount: ability.amount,
      sourceKind: "ability",
      abilityId: ability.id,
      effectIndex
    }))
  };
}

// src/simulation/m8/crit.ts
var sourceTuple2 = (source) => JSON.stringify([
  source.ownerId,
  source.sourceKind,
  source.definitionId,
  source.instanceId,
  source.effectIndex,
  source.parentItemInstanceId
]);
function ordered(sources) {
  for (const source of sources) {
    integer(source.effectIndex);
    if (![source.ownerId, source.definitionId, source.instanceId].every((id2) => typeof id2 === "string" && id2.length > 0) || !["attack", "ability", "trait", "item", "augment", "anomaly", "enemyGrowth"].includes(source.sourceKind) || source.parentItemInstanceId !== null && (typeof source.parentItemInstanceId !== "string" || source.parentItemInstanceId.length === 0)) throw new RangeError("Invalid authorization provenance");
  }
  const sorted3 = sources.map((source) => ({ ...source })).sort((a, b) => sourceTuple2(a) < sourceTuple2(b) ? -1 : sourceTuple2(a) > sourceTuple2(b) ? 1 : 0);
  if (new Set(sorted3.map(sourceTuple2)).size !== sorted3.length) throw new RangeError("Duplicate authorization source");
  return sorted3;
}
function authorizeSpellCrit(nonItemSources, itemSources, chanceBps, baseMultiplierBps) {
  integer(chanceBps, Number.MIN_SAFE_INTEGER);
  integer(baseMultiplierBps, 1e4);
  if (nonItemSources.some((s) => s.sourceKind === "item") || itemSources.some((s) => s.sourceKind !== "item")) throw new RangeError("Invalid authorization source kind");
  const nonItems = ordered(nonItemSources), items = ordered(itemSources);
  const bonus = 1e3 * (nonItems.length > 0 ? items.length : Math.max(0, items.length - 1));
  return {
    nonItemSources: nonItems,
    itemSources: items,
    enabled: nonItems.length > 0 || items.length > 0,
    redundantItemBonusBps: bonus,
    chanceBps: Math.max(0, Math.min(1e4, chanceBps)),
    multiplierBps: safeNumber(BigInt(baseMultiplierBps) + BigInt(bonus))
  };
}
function validateSpellCrit(authorization) {
  const expected = authorizeSpellCrit(
    authorization.nonItemSources,
    authorization.itemSources,
    authorization.chanceBps,
    authorization.multiplierBps - authorization.redundantItemBonusBps
  );
  if (expected.enabled !== authorization.enabled || expected.chanceBps !== authorization.chanceBps || expected.multiplierBps !== authorization.multiplierBps || expected.redundantItemBonusBps !== authorization.redundantItemBonusBps || expected.itemSources.some((s, i) => sourceTuple2(s) !== sourceTuple2(authorization.itemSources[i])) || expected.nonItemSources.some((s, i) => sourceTuple2(s) !== sourceTuple2(authorization.nonItemSources[i]))) throw new RangeError("Invalid spell critical projection");
  return expected;
}
function rollCrit(eligibility, authorization, draw) {
  if (!["basic", "requires-spell-authorization", "never"].includes(eligibility)) throw new RangeError("Invalid critical eligibility");
  validateSpellCrit(authorization);
  if (eligibility === "never" || eligibility === "requires-spell-authorization" && !authorization.enabled) return false;
  const word = draw();
  integer(word);
  integer(authorization.chanceBps);
  if (word >= 4294967296 || authorization.chanceBps > 1e4) throw new RangeError("Invalid critical random word/chance");
  return word * 1e4 < authorization.chanceBps * 4294967296;
}

// src/simulation/m8/mana.ts
var natural = (n) => {
  integer(n);
  if (n < 0) throw new RangeError("Negative mana value");
  return n;
};
function validateManaDefinition(value) {
  natural(value.initialMana);
  natural(value.maxMana);
  if (value.initialMana > value.maxMana || value.maxMana === 0 && value.unitKind !== "neutral") throw new RangeError("Invalid mana definition");
}
function validateManaState(state) {
  natural(state.current);
  natural(state.maximum);
  natural(state.lockedUntilTick);
  if (!state.unitId || state.current > state.maximum) throw new RangeError("Invalid mana state");
}
function resolveMana(state, request, tick, cast) {
  validateManaState(state);
  natural(tick);
  natural(request.amount);
  if (request.targetId !== state.unitId) throw new RangeError("Mana target mismatch");
  const bypass = request.bypassLock === "this-cast-refund";
  if (request.reason === "cast-refund" || bypass) {
    if (!cast?.completed || request.reason !== "cast-refund" || request.castActionSeq !== cast.actionSeq || cast.source.ownerId !== state.unitId || cast.targetsSampledAtTick !== tick) throw new RangeError("Unbound cast refund");
  } else if (request.castActionSeq !== null) throw new RangeError("Unexpected cast binding");
  const blocked = tick < state.lockedUntilTick && !bypass ? request.amount : 0;
  const applied = Math.min(request.amount - blocked, state.maximum - state.current);
  return { ...request, before: state.current, blocked, applied, overflow: request.amount - blocked - applied, after: state.current + applied };
}
function damageMana(actualHpLoss) {
  return Math.min(20, safeNumber(BigInt(natural(actualHpLoss)) * 3n / 100n));
}
function planManaCost(state, requested) {
  validateManaState(state);
  natural(requested);
  return state.maximum === 0 || state.current < requested ? null : { actualManaSpent: requested, after: { ...state, current: state.current - requested } };
}
function completeCast(plan, actualManaSpent) {
  natural(actualManaSpent);
  natural(plan.actionSeq);
  natural(plan.targetsSampledAtTick);
  if (!plan.completed || plan.refundedMana !== 0) throw new RangeError("Invalid new completed cast");
  return { ...plan, actualManaSpent, targetIds: [...plan.targetIds], completionCell: { ...plan.completionCell } };
}
function refundCast(state, request, receipt, tick) {
  const outcome = resolveMana(state, request, tick, receipt);
  return { outcome, receipt: { ...receipt, refundedMana: safeNumber(integer(receipt.refundedMana) + integer(outcome.applied)) } };
}

// src/simulation/m8/unit-inputs.ts
function validateNeutralInputs(value) {
  validateManaDefinition(value);
  if (value.unitKind !== "neutral") return;
  if (!value.monsterFamily || value.baseAttackSpeedBps === void 0 || value.baseCritChanceBps === void 0 || value.baseCritMultiplierBps === void 0) throw new RangeError("Missing authored neutral inputs");
  integer(value.baseAttackSpeedBps, 1);
  integer(value.baseCritChanceBps);
  integer(value.baseCritMultiplierBps, 1);
  if (value.baseCritChanceBps > 1e4 || value.attackIntervalTicks !== attackInterval(value.baseAttackSpeedBps, 0)) throw new RangeError("Invalid authored neutral inputs");
}
function compileUnitInputs(stats) {
  if (stats.unitKind !== "neutral") return {};
  validateNeutralInputs({ ...stats, attackIntervalTicks: attackInterval(stats.baseAttackSpeedBps, 0) });
  return {
    unitKind: stats.unitKind,
    monsterFamily: stats.monsterFamily,
    baseAttackSpeedBps: stats.baseAttackSpeedBps,
    baseCritChanceBps: stats.baseCritChanceBps,
    baseCritMultiplierBps: stats.baseCritMultiplierBps,
    spellCrit: authorizeSpellCrit([], [], stats.baseCritChanceBps, stats.baseCritMultiplierBps)
  };
}

// src/simulation/units.ts
function define(definition) {
  return freezeContent(definition);
}
var LEGACY_UNIT_DEFINITIONS = Object.freeze({
  sentinel: define({
    id: "sentinel",
    name: "\u5B88\u536B",
    symbol: "\u76FE",
    color: 6872528,
    cost: 1,
    baseStats: { health: 800, attack: 45, armor: 40, magicResist: 30 },
    attackRange: 1,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 80,
    abilityId: "sentinel-guard",
    traits: ["bulwark", "conduit"]
  }),
  ranger: define({
    id: "ranger",
    name: "\u6E38\u4FA0",
    symbol: "\u5F13",
    color: 15121526,
    cost: 1,
    baseStats: { health: 500, attack: 70, armor: 15, magicResist: 15 },
    attackRange: 3,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 60,
    abilityId: "ranger-shot",
    traits: ["marksman", "forge"]
  }),
  mystic: define({
    id: "mystic",
    name: "\u79D8\u672F\u5E08",
    symbol: "\u661F",
    color: 11837941,
    cost: 1,
    baseStats: { health: 450, attack: 80, armor: 10, magicResist: 20 },
    attackRange: 1,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 60,
    abilityId: "mystic-bolt",
    traits: ["scholar", "conduit"]
  }),
  bulwark: define({
    id: "bulwark",
    name: "\u58C1\u5792",
    symbol: "\u58C1",
    color: 7391642,
    cost: 2,
    baseStats: { health: 1e3, attack: 55, armor: 45, magicResist: 35 },
    attackRange: 1,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 80,
    abilityId: "bulwark-guard",
    traits: ["bulwark", "forge"]
  }),
  archer: define({
    id: "archer",
    name: "\u795E\u5C04\u624B",
    symbol: "\u7BAD",
    color: 10406256,
    cost: 2,
    baseStats: { health: 650, attack: 85, armor: 20, magicResist: 20 },
    attackRange: 3,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 60,
    abilityId: "archer-shot",
    traits: ["marksman", "conduit"]
  }),
  arcanist: define({
    id: "arcanist",
    name: "\u5965\u672F\u5E08",
    symbol: "\u672F",
    color: 7446242,
    cost: 3,
    baseStats: { health: 750, attack: 85, armor: 25, magicResist: 30 },
    attackRange: 3,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 80,
    abilityId: "arcanist-burst",
    traits: ["scholar", "forge"]
  }),
  duelist: define({
    id: "duelist",
    name: "\u51B3\u6597\u8005",
    symbol: "\u5203",
    color: 7708112,
    cost: 3,
    baseStats: { health: 1100, attack: 100, armor: 35, magicResist: 30 },
    attackRange: 1,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 60,
    abilityId: "duelist-strike",
    traits: ["duelist", "forge"]
  }),
  warden: define({
    id: "warden",
    name: "\u5B88\u671B\u8005",
    symbol: "\u536B",
    color: 12354264,
    cost: 4,
    baseStats: { health: 1500, attack: 90, armor: 55, magicResist: 50 },
    attackRange: 1,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 80,
    abilityId: "warden-guard",
    traits: ["bulwark", "scholar"]
  }),
  tempest: define({
    id: "tempest",
    name: "\u98CE\u66B4\u4F7F",
    symbol: "\u5C9A",
    color: 10915301,
    cost: 4,
    baseStats: { health: 950, attack: 110, armor: 30, magicResist: 35 },
    attackRange: 3,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 80,
    abilityId: "tempest-burst",
    traits: ["scholar", "marksman"]
  }),
  colossus: define({
    id: "colossus",
    name: "\u5DE8\u50CF",
    symbol: "\u5DE8",
    color: 14793825,
    cost: 5,
    baseStats: { health: 1800, attack: 125, armor: 65, magicResist: 60 },
    attackRange: 1,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 90,
    abilityId: "colossus-guard",
    traits: ["bulwark", "forge"]
  }),
  oracle: define({
    id: "oracle",
    name: "\u5148\u77E5",
    symbol: "\u8C15",
    color: 15780995,
    cost: 5,
    baseStats: { health: 1150, attack: 125, armor: 35, magicResist: 45 },
    attackRange: 3,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 80,
    abilityId: "oracle-burst",
    traits: ["scholar", "conduit"]
  }),
  squire: define({
    id: "squire",
    name: "\u4F8D\u536B",
    symbol: "\u4F8D",
    color: 9033661,
    cost: 1,
    baseStats: { health: 800, attack: 45, armor: 40, magicResist: 30 },
    attackRange: 1,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 80,
    abilityId: "sentinel-guard",
    traits: ["bulwark", "duelist"]
  }),
  spark: define({
    id: "spark",
    name: "\u706B\u82B1",
    symbol: "\u706B",
    color: 15706744,
    cost: 1,
    baseStats: { health: 450, attack: 80, armor: 10, magicResist: 20 },
    attackRange: 1,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 60,
    abilityId: "mystic-bolt",
    traits: ["scholar", "forge"]
  }),
  scout: define({
    id: "scout",
    name: "\u65A5\u5019",
    symbol: "\u65A5",
    color: 8369549,
    cost: 2,
    baseStats: { health: 650, attack: 85, armor: 20, magicResist: 20 },
    attackRange: 3,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 60,
    abilityId: "archer-shot",
    traits: ["marksman", "duelist"]
  }),
  binder: define({
    id: "binder",
    name: "\u7EC7\u6D41\u8005",
    symbol: "\u7EC7",
    color: 8635602,
    cost: 2,
    baseStats: { health: 1e3, attack: 55, armor: 45, magicResist: 35 },
    attackRange: 1,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 80,
    abilityId: "bulwark-guard",
    traits: ["conduit", "duelist"]
  }),
  striker: define({
    id: "striker",
    name: "\u7A81\u51FB\u624B",
    symbol: "\u7A81",
    color: 12160135,
    cost: 3,
    baseStats: { health: 1100, attack: 100, armor: 35, magicResist: 30 },
    attackRange: 1,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 60,
    abilityId: "duelist-strike",
    traits: ["marksman", "duelist"]
  }),
  beacon: define({
    id: "beacon",
    name: "\u706F\u5854",
    symbol: "\u706F",
    color: 15655074,
    cost: 3,
    baseStats: { health: 750, attack: 85, armor: 25, magicResist: 30 },
    attackRange: 3,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 80,
    abilityId: "arcanist-burst",
    traits: ["bulwark", "conduit"]
  }),
  prism: define({
    id: "prism",
    name: "\u68F1\u955C",
    symbol: "\u68F1",
    color: 14196953,
    cost: 4,
    baseStats: { health: 950, attack: 110, armor: 30, magicResist: 35 },
    attackRange: 3,
    attackIntervalTicks: 20,
    initialMana: 0,
    maxMana: 80,
    abilityId: "tempest-burst",
    traits: ["marksman", "forge"]
  })
});
var M5_UNIT_DEFINITIONS = freezeContent({
  "irelia": {
    "id": "irelia",
    "name": "Irelia",
    "symbol": "I",
    "color": 10466749,
    "cost": 1,
    "baseStats": {
      "health": 700,
      "attack": 45,
      "armor": 40,
      "magicResist": 40
    },
    "attackRange": 1,
    "attackIntervalTicks": 34,
    "baseAttackSpeedBps": 6e3,
    "initialMana": 30,
    "maxMana": 70,
    "abilityId": "irelia-ability",
    "traits": [
      "sentinel"
    ]
  },
  "maddie": {
    "id": "maddie",
    "name": "Maddie",
    "symbol": "M",
    "color": 10466749,
    "cost": 1,
    "baseStats": {
      "health": 500,
      "attack": 50,
      "armor": 15,
      "magicResist": 15
    },
    "attackRange": 6,
    "attackIntervalTicks": 29,
    "baseAttackSpeedBps": 7e3,
    "initialMana": 20,
    "maxMana": 120,
    "abilityId": "maddie-ability",
    "traits": [
      "sniper"
    ]
  },
  "darius": {
    "id": "darius",
    "name": "Darius",
    "symbol": "D",
    "color": 10466749,
    "cost": 1,
    "baseStats": {
      "health": 600,
      "attack": 55,
      "armor": 40,
      "magicResist": 40
    },
    "attackRange": 1,
    "attackIntervalTicks": 29,
    "baseAttackSpeedBps": 7e3,
    "initialMana": 30,
    "maxMana": 70,
    "abilityId": "darius-ability",
    "traits": [
      "watcher"
    ]
  },
  "lux": {
    "id": "lux",
    "name": "Lux",
    "symbol": "L",
    "color": 10466749,
    "cost": 1,
    "baseStats": {
      "health": 500,
      "attack": 30,
      "armor": 20,
      "magicResist": 20
    },
    "attackRange": 4,
    "attackIntervalTicks": 29,
    "baseAttackSpeedBps": 7e3,
    "initialMana": 0,
    "maxMana": 50,
    "abilityId": "lux-ability",
    "traits": [
      "sorcerer"
    ]
  },
  "zyra": {
    "id": "zyra",
    "name": "Zyra",
    "symbol": "Z",
    "color": 10466749,
    "cost": 1,
    "baseStats": {
      "health": 500,
      "attack": 30,
      "armor": 20,
      "magicResist": 20
    },
    "attackRange": 4,
    "attackIntervalTicks": 29,
    "baseAttackSpeedBps": 7e3,
    "initialMana": 10,
    "maxMana": 60,
    "abilityId": "zyra-ability",
    "traits": [
      "sorcerer"
    ]
  },
  "tristana": {
    "id": "tristana",
    "name": "Tristana",
    "symbol": "T",
    "color": 7523468,
    "cost": 2,
    "baseStats": {
      "health": 550,
      "attack": 42,
      "armor": 20,
      "magicResist": 20
    },
    "attackRange": 4,
    "attackIntervalTicks": 27,
    "baseAttackSpeedBps": 7500,
    "initialMana": 20,
    "maxMana": 60,
    "abilityId": "tristana-ability",
    "traits": [
      "artillerist"
    ]
  },
  "urgot": {
    "id": "urgot",
    "name": "Urgot",
    "symbol": "U",
    "color": 7523468,
    "cost": 2,
    "baseStats": {
      "health": 700,
      "attack": 50,
      "armor": 45,
      "magicResist": 45
    },
    "attackRange": 2,
    "attackIntervalTicks": 29,
    "baseAttackSpeedBps": 7e3,
    "initialMana": 20,
    "maxMana": 70,
    "abilityId": "urgot-ability",
    "traits": [
      "artillerist"
    ]
  },
  "rell": {
    "id": "rell",
    "name": "Rell",
    "symbol": "R",
    "color": 7523468,
    "cost": 2,
    "baseStats": {
      "health": 800,
      "attack": 60,
      "armor": 45,
      "magicResist": 45
    },
    "attackRange": 1,
    "attackIntervalTicks": 34,
    "baseAttackSpeedBps": 6e3,
    "initialMana": 40,
    "maxMana": 90,
    "abilityId": "rell-ability",
    "traits": [
      "sentinel"
    ]
  },
  "leona": {
    "id": "leona",
    "name": "Leona",
    "symbol": "L",
    "color": 7523468,
    "cost": 2,
    "baseStats": {
      "health": 800,
      "attack": 55,
      "armor": 50,
      "magicResist": 50
    },
    "attackRange": 1,
    "attackIntervalTicks": 34,
    "baseAttackSpeedBps": 6e3,
    "initialMana": 50,
    "maxMana": 90,
    "abilityId": "leona-ability",
    "traits": [
      "sentinel"
    ]
  },
  "vander": {
    "id": "vander",
    "name": "Vander",
    "symbol": "V",
    "color": 7523468,
    "cost": 2,
    "baseStats": {
      "health": 800,
      "attack": 50,
      "armor": 45,
      "magicResist": 45
    },
    "attackRange": 1,
    "attackIntervalTicks": 29,
    "baseAttackSpeedBps": 7e3,
    "initialMana": 0,
    "maxMana": 50,
    "abilityId": "vander-ability",
    "traits": [
      "watcher"
    ]
  },
  "kogmaw": {
    "id": "kogmaw",
    "name": "Kog'Maw",
    "symbol": "K",
    "color": 7839464,
    "cost": 3,
    "baseStats": {
      "health": 650,
      "attack": 15,
      "armor": 25,
      "magicResist": 25
    },
    "attackRange": 4,
    "attackIntervalTicks": 29,
    "baseAttackSpeedBps": 7e3,
    "initialMana": 0,
    "maxMana": 40,
    "abilityId": "kogmaw-ability",
    "traits": [
      "sniper"
    ]
  },
  "scar": {
    "id": "scar",
    "name": "Scar",
    "symbol": "S",
    "color": 7839464,
    "cost": 3,
    "baseStats": {
      "health": 800,
      "attack": 50,
      "armor": 50,
      "magicResist": 50
    },
    "attackRange": 1,
    "attackIntervalTicks": 31,
    "baseAttackSpeedBps": 6500,
    "initialMana": 80,
    "maxMana": 170,
    "abilityId": "scar-ability",
    "traits": [
      "watcher"
    ]
  },
  "ezreal": {
    "id": "ezreal",
    "name": "Ezreal",
    "symbol": "E",
    "color": 7839464,
    "cost": 3,
    "baseStats": {
      "health": 700,
      "attack": 60,
      "armor": 25,
      "magicResist": 25
    },
    "attackRange": 4,
    "attackIntervalTicks": 27,
    "baseAttackSpeedBps": 7500,
    "initialMana": 0,
    "maxMana": 60,
    "abilityId": "ezreal-ability",
    "traits": [
      "artillerist"
    ]
  },
  "loris": {
    "id": "loris",
    "name": "Loris",
    "symbol": "L",
    "color": 7839464,
    "cost": 3,
    "baseStats": {
      "health": 850,
      "attack": 50,
      "armor": 50,
      "magicResist": 50
    },
    "attackRange": 1,
    "attackIntervalTicks": 31,
    "baseAttackSpeedBps": 6500,
    "initialMana": 40,
    "maxMana": 80,
    "abilityId": "loris-ability",
    "traits": [
      "sentinel"
    ]
  },
  "nami": {
    "id": "nami",
    "name": "Nami",
    "symbol": "N",
    "color": 7839464,
    "cost": 3,
    "baseStats": {
      "health": 700,
      "attack": 40,
      "armor": 25,
      "magicResist": 25
    },
    "attackRange": 4,
    "attackIntervalTicks": 29,
    "baseAttackSpeedBps": 7e3,
    "initialMana": 0,
    "maxMana": 60,
    "abilityId": "nami-ability",
    "traits": [
      "sorcerer"
    ]
  },
  "corki": {
    "id": "corki",
    "name": "Corki",
    "symbol": "C",
    "color": 12025069,
    "cost": 4,
    "baseStats": {
      "health": 850,
      "attack": 65,
      "armor": 30,
      "magicResist": 30
    },
    "attackRange": 4,
    "attackIntervalTicks": 27,
    "baseAttackSpeedBps": 7500,
    "initialMana": 0,
    "maxMana": 60,
    "abilityId": "corki-ability",
    "traits": [
      "artillerist"
    ]
  },
  "garen": {
    "id": "garen",
    "name": "Garen",
    "symbol": "G",
    "color": 12025069,
    "cost": 4,
    "baseStats": {
      "health": 1e3,
      "attack": 65,
      "armor": 60,
      "magicResist": 60
    },
    "attackRange": 1,
    "attackIntervalTicks": 34,
    "baseAttackSpeedBps": 6e3,
    "initialMana": 60,
    "maxMana": 125,
    "abilityId": "garen-ability",
    "traits": [
      "watcher"
    ]
  },
  "zoe": {
    "id": "zoe",
    "name": "Zoe",
    "symbol": "Z",
    "color": 12025069,
    "cost": 4,
    "baseStats": {
      "health": 800,
      "attack": 40,
      "armor": 30,
      "magicResist": 30
    },
    "attackRange": 4,
    "attackIntervalTicks": 27,
    "baseAttackSpeedBps": 7500,
    "initialMana": 20,
    "maxMana": 80,
    "abilityId": "zoe-ability",
    "traits": [
      "sorcerer"
    ]
  },
  "caitlyn": {
    "id": "caitlyn",
    "name": "Caitlyn",
    "symbol": "C",
    "color": 14859608,
    "cost": 5,
    "baseStats": {
      "health": 900,
      "attack": 82,
      "armor": 40,
      "magicResist": 40
    },
    "attackRange": 13,
    "attackIntervalTicks": 37,
    "baseAttackSpeedBps": 5500,
    "initialMana": 0,
    "maxMana": 50,
    "abilityId": "caitlyn-ability",
    "traits": [
      "sniper"
    ]
  }
});
var NEUTRAL_UNIT_DEFINITIONS = freezeContent({
  "neutral-stage-2": {
    "id": "neutral-stage-2",
    "name": "\u4E2D\u7ACB\u5B88\u536B 2",
    "symbol": "\u517D",
    "color": 9993582,
    "cost": 1,
    "baseStats": {
      "health": 500,
      "attack": 35,
      "armor": 20,
      "magicResist": 20
    },
    "attackRange": 1,
    "attackIntervalTicks": 25,
    "initialMana": 0,
    "maxMana": 1,
    "abilityId": "neutral-attack",
    "traits": []
  },
  "neutral-stage-3": {
    "id": "neutral-stage-3",
    "name": "\u4E2D\u7ACB\u5B88\u536B 3",
    "symbol": "\u517D",
    "color": 9993582,
    "cost": 1,
    "baseStats": {
      "health": 900,
      "attack": 50,
      "armor": 30,
      "magicResist": 30
    },
    "attackRange": 1,
    "attackIntervalTicks": 23,
    "initialMana": 0,
    "maxMana": 1,
    "abilityId": "neutral-attack",
    "traits": []
  },
  "neutral-stage-4": {
    "id": "neutral-stage-4",
    "name": "\u4E2D\u7ACB\u5B88\u536B 4",
    "symbol": "\u517D",
    "color": 9993582,
    "cost": 1,
    "baseStats": {
      "health": 1200,
      "attack": 65,
      "armor": 40,
      "magicResist": 40
    },
    "attackRange": 1,
    "attackIntervalTicks": 22,
    "initialMana": 0,
    "maxMana": 1,
    "abilityId": "neutral-attack",
    "traits": []
  },
  "neutral-stage-5": {
    "id": "neutral-stage-5",
    "name": "\u4E2D\u7ACB\u5B88\u536B 5",
    "symbol": "\u517D",
    "color": 9993582,
    "cost": 1,
    "baseStats": {
      "health": 6e3,
      "attack": 100,
      "armor": 50,
      "magicResist": 50
    },
    "attackRange": 2,
    "attackIntervalTicks": 20,
    "initialMana": 0,
    "maxMana": 1,
    "abilityId": "neutral-attack",
    "traits": []
  },
  "neutral-stage-6": {
    "id": "neutral-stage-6",
    "name": "\u4E2D\u7ACB\u5B88\u536B 6",
    "symbol": "\u517D",
    "color": 9993582,
    "cost": 1,
    "baseStats": {
      "health": 9e3,
      "attack": 130,
      "armor": 60,
      "magicResist": 60
    },
    "attackRange": 2,
    "attackIntervalTicks": 18,
    "initialMana": 0,
    "maxMana": 1,
    "abilityId": "neutral-attack",
    "traits": []
  }
});
var M8_NEUTRAL_UNIT_DEFINITIONS = freezeContent(Object.fromEntries(
  Object.values(NEUTRAL_DEFINITIONS).map((d) => [d.id, {
    id: d.id,
    name: d.name,
    symbol: "\u517D",
    color: 9993582,
    cost: 1,
    traits: [],
    unitKind: d.unitKind,
    monsterFamily: d.monsterFamily,
    baseStats: { health: d.health, attack: d.attack, armor: d.armor, magicResist: d.magicResist },
    attackRange: d.attackRange,
    attackIntervalTicks: attackInterval(d.baseAttackSpeedBps, 0),
    baseAttackSpeedBps: d.baseAttackSpeedBps,
    initialMana: d.initialMana,
    maxMana: d.maxMana,
    abilityId: neutralAbilityId(d),
    baseCritChanceBps: d.baseCritChanceBps,
    baseCritMultiplierBps: d.baseCritMultiplierBps
  }])
));
var M5_UNIT_IDS = Object.freeze(Object.keys(M5_UNIT_DEFINITIONS).sort());
var UNIT_DEFINITIONS = Object.freeze({ ...LEGACY_UNIT_DEFINITIONS, ...M5_UNIT_DEFINITIONS, ...NEUTRAL_UNIT_DEFINITIONS, ...M8_NEUTRAL_UNIT_DEFINITIONS });
function validateUnitDefinitions(definitions2 = UNIT_DEFINITIONS, catalogByCost = SHOP_CATALOG_BY_COST) {
  const integerAtLeast = (value, minimum) => Number.isSafeInteger(value) && value >= minimum;
  for (const [id2, definition] of Object.entries(definitions2)) {
    validateManaDefinition(definition);
    validateNeutralInputs(definition);
    const s = definition.baseStats;
    if (definition.id !== id2 || !/^[a-z][a-z0-9-]*$/.test(id2) || !definition.name || !definition.symbol || !definition.abilityId || !integerAtLeast(definition.color, 0) || definition.color > 16777215 || !integerAtLeast(definition.cost, 1) || definition.cost > 5 || !integerAtLeast(s.health, 1) || !integerAtLeast(s.attack, 0) || !integerAtLeast(s.armor, 0) || !integerAtLeast(s.magicResist, 0) || !integerAtLeast(definition.attackRange, 1) || !integerAtLeast(definition.attackIntervalTicks, 1) || !integerAtLeast(definition.maxMana, 0) || !integerAtLeast(definition.initialMana, 0) || definition.initialMana > definition.maxMana || !Array.isArray(definition.traits) || new Set(definition.traits).size !== definition.traits.length || definition.traits.some((trait) => typeof trait !== "string" || !trait)) throw new RangeError(`Invalid unit definition: ${id2}`);
  }
  const seen = /* @__PURE__ */ new Set();
  for (const cost of [1, 2, 3, 4, 5]) {
    const catalog = catalogByCost[cost];
    if (!catalog.length) throw new RangeError(`Empty shop tier: ${cost}`);
    for (const id2 of catalog) {
      if (seen.has(id2) || definitions2[id2]?.cost !== cost) throw new RangeError(`Invalid shop definition: ${id2}`);
      seen.add(id2);
    }
  }
  if (definitions2 === UNIT_DEFINITIONS && [...seen].some((id2) => !Object.hasOwn(M5_UNIT_DEFINITIONS, id2))) throw new RangeError("Legacy or neutral unit in M5 shop");
}
validateUnitDefinitions();

// src/simulation/m8/status.ts
function isEffective(c, tick, includeFinalPulse = false) {
  return c.appliedAtTick <= tick && (c.expiresAtTick === null || (includeFinalPulse ? c.expiresAtTick >= tick : c.expiresAtTick > tick));
}
function summarizeGroup(group, tick, includeFinalPulse = false) {
  let best;
  for (const contribution of group.contributions) if (isEffective(contribution, tick, includeFinalPulse) && (!best || contribution.application.magnitudeBps > best.application.magnitudeBps || contribution.application.magnitudeBps === best.application.magnitudeBps && compareCodePoints(contribution.key, best.key) < 0)) best = contribution;
  return { ...group, effectiveSourceKey: best?.key ?? null, effectiveMagnitudeBps: best?.application.magnitudeBps ?? 0 };
}
function effectiveStatuses(groups, tick, includeFinalPulse = false) {
  return groups.map((g) => summarizeGroup(g, tick, includeFinalPulse)).filter((g) => g.effectiveSourceKey !== null);
}
function statusMagnitude(groups, kind, tick) {
  return Math.max(0, ...effectiveStatuses(groups, tick).filter((g) => g.kind === kind).map((g) => g.effectiveMagnitudeBps));
}
function validateStatusApplication(app) {
  if (!["stun", "burn", "wound", "sunder", "shred", "damage-reduction", "control-immunity", "untargetable", "damage-prevention", "stat-buff", "stat-debuff"].includes(app.kind) || !["immediate", "next-tick"].includes(app.activation) || !["beneficial", "harmful"].includes(app.polarity) || typeof app.removable !== "boolean" || !["ticks", "combat"].includes(app.duration.kind) || !["refresh-same-instance", "independent-instances", "strongest-category", "add-stacks"].includes(app.stackPolicy.kind)) throw new RangeError("Invalid status declaration");
  if (app.stackPolicy.kind === "add-stacks" && app.stackPolicy.cap !== null) integer(app.stackPolicy.cap, 1);
  if (app.stackPolicy.kind === "refresh-same-instance" && (!["replace", "max"].includes(app.stackPolicy.magnitude) || app.stackPolicy.phase !== "preserve")) throw new RangeError("Invalid status refresh policy");
  if (app.stackPolicy.kind === "strongest-category" && app.stackPolicy.retainSuppressed !== true) throw new RangeError("Suppressed contributions must be retained");
  integer(app.magnitudeBps);
  if (app.magnitudeBps > 1e4) throw new RangeError("Invalid status magnitude");
  if (app.duration.kind === "ticks") integer(app.duration.ticks, 1);
  const stat2 = app.kind === "stat-buff" || app.kind === "stat-debuff";
  if (stat2 !== (app.modifier !== void 0) || app.kind === "damage-reduction" !== (app.damageFilter !== null)) throw new RangeError("Status modifier/filter mismatch");
  if (app.stackPolicy.kind === "strongest-category" && app.stackPolicy.category !== app.kind) throw new RangeError("Wrong strongest status category");
}
function applyStatusContribution(groups, identity, app, tick) {
  validateIdentity(identity);
  validateStatusApplication(app);
  integer(tick);
  if (app.kind === "stun" && effectiveStatuses(groups, tick).some((g) => g.targetId === identity.targetId && g.kind === "control-immunity")) return { groups: [...groups], accepted: false, refreshed: false };
  const group = groups.find((g) => g.targetId === identity.targetId && g.kind === app.kind);
  const old = group?.contributions.find((c) => c.key === identity.key);
  const requestedStart = tick + (app.activation === "next-tick" ? 1 : 0);
  const requestedEnd = app.duration.kind === "combat" ? null : requestedStart + app.duration.ticks;
  let application = app;
  const policy = app.stackPolicy;
  if (old && policy.kind === "independent-instances") throw new RangeError("Duplicate independent status identity");
  if (old && policy.kind === "refresh-same-instance" && policy.magnitude === "max" && old.application.magnitudeBps > app.magnitudeBps) application = { ...app, magnitudeBps: old.application.magnitudeBps, ...old.application.modifier ? { modifier: old.application.modifier } : {} };
  if (old && policy.kind === "refresh-same-instance" && policy.magnitude === "max" && app.modifier?.value.kind === "constant" && old.application.modifier?.value.kind === "constant" && Math.abs(old.application.modifier.value.amount) > Math.abs(app.modifier.value.amount)) application = { ...application, modifier: old.application.modifier };
  if (old && policy.kind === "add-stacks") {
    const previous = old.application.modifier, next2 = app.modifier;
    if (previous && next2) {
      if (previous.stat !== next2.stat || previous.unit !== next2.unit || previous.value.kind !== "constant" || next2.value.kind !== "constant") throw new RangeError("Incompatible status stack modifier");
      const perStack = next2.value.amount;
      if (perStack === 0 || previous.value.amount % perStack !== 0) throw new RangeError("Invalid saved status stack amount");
      const stacks = Math.min(policy.cap ?? Number.MAX_SAFE_INTEGER, previous.value.amount / perStack + 1);
      application = { ...app, modifier: { ...next2, value: { kind: "constant", amount: safeNumber(integer(stacks) * integer(perStack, Number.MIN_SAFE_INTEGER)) } } };
    } else {
      if (app.magnitudeBps === 0 || old.application.magnitudeBps % app.magnitudeBps !== 0) throw new RangeError("Invalid saved status stack magnitude");
      application = { ...app, magnitudeBps: Math.min(1e4, Math.min(policy.cap ?? Number.MAX_SAFE_INTEGER, old.application.magnitudeBps / app.magnitudeBps + 1) * app.magnitudeBps) };
    }
  }
  const start = old && isEffective(old, tick) ? old.appliedAtTick : requestedStart;
  const expiresAtTick = old?.expiresAtTick === null || requestedEnd === null ? null : Math.max(old?.expiresAtTick ?? 0, requestedEnd);
  const contribution = { ...identity, application, appliedAtTick: start, expiresAtTick, endRewardConsumed: false };
  const next = summarizeGroup({
    targetId: identity.targetId,
    kind: app.kind,
    contributions: [...group?.contributions.filter((c) => c.key !== identity.key) ?? [], contribution].sort((a, b) => compareCodePoints(a.key, b.key)),
    effectiveSourceKey: null,
    effectiveMagnitudeBps: 0,
    nextPulseAtTick: app.kind === "burn" ? group?.nextPulseAtTick ?? requestedStart + 20 : null
  }, tick);
  return { groups: [...groups.filter((g) => g !== group), next].sort((a, b) => compareCodePoints(JSON.stringify([a.targetId, a.kind]), JSON.stringify([b.targetId, b.kind]))), accepted: true, refreshed: old !== void 0 };
}
function removeStatusContributions(groups, remove, reason, tick) {
  const ended = [], remaining = [];
  for (const group of groups) {
    const contributions = group.contributions.filter((c) => {
      if (!remove(c)) return true;
      const effects2 = !c.endRewardConsumed && c.application.onEnd?.reasons.includes(reason) ? c.application.onEnd.effects : [];
      ended.push({ contribution: { ...c, endRewardConsumed: true }, reason, effects: effects2 });
      return false;
    });
    if (contributions.length) remaining.push(summarizeGroup({ ...group, contributions }, tick));
  }
  return { groups: remaining, ended };
}
function endStatuses(groups, tick) {
  return removeStatusContributions(groups, (c) => c.expiresAtTick !== null && c.expiresAtTick <= tick, "expired", tick);
}
function cleanseStatuses(groups, targetId, hostileOwners, tick) {
  return removeStatusContributions(groups, (c) => c.targetId === targetId && hostileOwners.has(c.source.ownerId) && c.application.removable && c.application.polarity === "harmful" && ["stun", "burn", "wound", "sunder", "shred", "stat-debuff"].includes(c.application.kind), "cleansed", tick);
}
function advanceBurnClock(groups, targetId, tick) {
  return groups.map((g) => g.targetId === targetId && g.kind === "burn" && g.nextPulseAtTick !== null && g.nextPulseAtTick <= tick ? { ...g, nextPulseAtTick: g.nextPulseAtTick + 20 } : g);
}
function validateStatusGroups(groups, tick, combatId) {
  const keys3 = /* @__PURE__ */ new Set(), categories = /* @__PURE__ */ new Set();
  for (const group of groups) {
    const category = JSON.stringify([group.targetId, group.kind]);
    if (categories.has(category) || !group.contributions.length) throw new RangeError("Duplicate/empty status group");
    categories.add(category);
    for (const c of group.contributions) {
      validateIdentity(c, combatId);
      validateStatusApplication(c.application);
      integer(c.appliedAtTick);
      if (c.expiresAtTick !== null) {
        integer(c.expiresAtTick, 1);
        if (c.expiresAtTick <= tick || c.expiresAtTick <= c.appliedAtTick) throw new RangeError("Expired status contribution");
      }
      if (keys3.has(c.key) || c.targetId !== group.targetId || c.application.kind !== group.kind || c.appliedAtTick > tick + 1 || c.endRewardConsumed) throw new RangeError("Invalid status contribution");
      keys3.add(c.key);
    }
    const expected = summarizeGroup(group, tick);
    if (group.effectiveSourceKey !== expected.effectiveSourceKey || group.effectiveMagnitudeBps !== expected.effectiveMagnitudeBps) throw new RangeError("Invalid effective status");
    if (group.kind === "burn") {
      integer(group.nextPulseAtTick, 1);
      if (group.nextPulseAtTick <= tick) throw new RangeError("Invalid burn clock");
    } else if (group.nextPulseAtTick !== null) throw new RangeError("Non-burn clock");
  }
}

// src/simulation/m8/item-program.ts
function itemPrograms(unit) {
  return unit.itemPrograms ?? [];
}
function programEntries(unit) {
  return itemPrograms(unit).flatMap(({ source, program }) => {
    let ordinal = 0;
    const bind = (kind, declaration) => ({ kind, source: { ...source, effectIndex: source.effectIndex + 32 * ordinal++ }, declaration });
    return [
      ...(program.modifiers ?? []).map((d) => bind("modifier", d)),
      ...(program.effects ?? []).map((d) => bind("effect", d)),
      ...(program.triggers ?? []).map((d) => bind("trigger", d)),
      ...(program.survival ?? []).map((d) => bind("survival", d)),
      ...(program.periodic ?? []).map((d) => bind("periodic", d)),
      ...(program.vamp ?? []).map((d) => bind("vamp", d))
    ];
  });
}
function compileItemCrit(unit) {
  const programs = itemPrograms(unit), modifiers = programs.flatMap((p) => p.program.modifiers ?? []);
  const sources = programEntries(unit).flatMap((e) => e.kind === "effect" && "kind" in e.declaration && e.declaration.kind === "authorize-spell-crit" ? [e.source] : []);
  const chance = resolveStat("critChance", unit.baseCritChanceBps ?? (unit.ability.kind === "s13" && unit.ability.championId === "neutral" ? 0 : 2500), modifiers, { holder: unit });
  return authorizeSpellCrit(sources.filter((s) => s.sourceKind !== "item"), sources.filter((s) => s.sourceKind === "item"), chance, unit.baseCritMultiplierBps ?? 14e3);
}
function validateItemProgram(program) {
  const check4 = (v) => {
    if (!v) throw new RangeError("Invalid combat program");
  };
  check4(program && Object.keys(program).every((k) => ["modifiers", "effects", "triggers", "survival", "periodic", "vamp"].includes(k)));
  const effect = (e) => {
    check4(["modify-stat", "damage", "apply-status", "heal", "grant-shield", "grant-mana", "change-max-hp", "authorize-spell-crit", "cleanse", "temporary-equipment"].includes(e.kind));
    if (e.kind === "apply-status") validateStatusApplication(e.status);
    if (e.kind === "modify-stat") {
      modifier2(e.modifier);
      if (e.duration.kind === "ticks") integer(e.duration.ticks, 1);
    }
    if ("amount" in e) {
      if (typeof e.amount === "number") integer(e.amount);
      else {
        for (const [k, v] of Object.entries(e.amount)) if (typeof v === "number") integer(v, k === "flat" ? Number.MIN_SAFE_INTEGER : 0);
      }
    }
    if (e.kind === "damage") check4(["physical", "magic", "true"].includes(e.damageType) && ["basic-attack", "ability-direct", "ability-periodic", "attack-extra", "equipment-proc", "item-burn"].includes(e.delivery) && ["basic", "requires-spell-authorization", "never"].includes(e.critEligibility));
    if (e.kind === "grant-shield") {
      integer(e.durationTicks, 1);
      e.endEffects.forEach(effect);
    }
  };
  const modifier2 = (m) => {
    check4(["maxHp", "attackDamage", "abilityPower", "armor", "magicResist", "attackSpeed", "range", "critChance", "critMultiplier", "damageAmp", "damageReduction", "omnivamp"].includes(m.stat));
    check4(["flat", "bps", "hexes"].includes(m.unit));
    for (const v of Object.values(m.value)) if (typeof v === "number") integer(v, Number.MIN_SAFE_INTEGER);
  };
  (program.modifiers ?? []).forEach(modifier2);
  (program.effects ?? []).forEach(effect);
  for (const d of [...program.triggers ?? [], ...program.survival ?? []]) {
    check4(d.id && !("source" in d) && d.effects.length < 32);
    integer(d.internalCooldownTicks);
    integer(d.maxPerAction, 1);
    if (d.maxPerCombat !== null) integer(d.maxPerCombat, 1);
    d.effects.forEach(effect);
  }
  for (const p of program.periodic ?? []) {
    integer(p.periodTicks, 1);
    if (p.endsAtTick !== void 0) integer(p.endsAtTick, 1);
    check4(p.program.effects.length < 32);
    p.program.effects.forEach(effect);
  }
  for (const v of program.vamp ?? []) {
    modifier2(v.modifier);
    integer(v.allyBps);
  }
}

// src/simulation/m8/targeting.ts
function startingRows(team, row) {
  return team === "player" ? row === 4 || row === 5 ? "front-two" : row === 6 || row === 7 ? "back-two" : null : row === 2 || row === 3 ? "front-two" : row === 0 || row === 1 ? "back-two" : null;
}
function isSelectable(unit, holder, env) {
  return unit.alive && unit.hp > 0 && contains(env.board, unit.cell) && (unit.team === holder.team || env.eligibility === "bound-packet" || env.eligibility === "area-hit" || !unit.untargetable);
}
var get = (env, id2) => env.units.find((u) => u.id === id2);
var distanceOrder = (anchor, a, b, farthest = false) => (farthest ? -1 : 1) * (hexDistance(anchor, a.cell) - hexDistance(anchor, b.cell)) || compareCodePoints(a.id, b.id);
function enemies2(env) {
  const holder = get(env, env.holderId);
  if (!holder) return [];
  return env.units.filter((u) => u.team !== holder.team && isSelectable(u, holder, env)).sort((a, b) => compareCodePoints(a.id, b.id));
}
function selectTargets(selector2, env) {
  integer(selector2.maxTargets);
  if (selector2.radius !== null) integer(selector2.radius);
  const holder = get(env, env.holderId);
  if (!holder) return [];
  const primary = get(env, env.primaryId), previous = get(env, env.previousId), actor = get(env, env.eventActorId);
  const anchor = selector2.anchor === "holder" ? holder.cell : selector2.anchor === "primary-target" ? primary?.cell : selector2.anchor === "previous-target" ? previous?.cell : env.eventActorCell ?? actor?.cell;
  if (!anchor) return [];
  const candidateIds = selector2.candidates === "event-actor" ? [env.eventActorId] : selector2.candidates === "event-target" ? [env.eventTargetId] : selector2.candidates === "bound-target" ? env.boundTargetIds ?? [] : null;
  const qualified = (u) => isSelectable(u, holder, env) && (selector2.relation === "self" ? u.id === holder.id : selector2.relation === "ally" ? u.team === holder.team : u.team !== holder.team) && (!selector2.excludeSelf || u.id !== holder.id) && (!selector2.excludePrimary || u.id !== primary?.id) && (selector2.radius === null || hexDistance(anchor, u.cell) <= selector2.radius);
  let candidates = env.units.filter((u) => (candidateIds === null || candidateIds.includes(u.id)) && qualified(u));
  const burnt = (u) => env.source && u.burnSources?.some((s) => s.ownerId === env.source.ownerId && s.sourceKind === env.source.sourceKind && s.definitionId === env.source.definitionId && s.instanceId === env.source.instanceId && s.parentItemInstanceId === env.source.parentItemInstanceId) ? 1 : 0;
  candidates.sort((a, b) => {
    const d = hexDistance(anchor, a.cell) - hexDistance(anchor, b.cell), id2 = compareCodePoints(a.id, b.id);
    switch (selector2.order) {
      case "id":
        return id2;
      case "farthest-id":
        return -d || id2;
      case "hp-ratio-id": {
        const left = integer(a.hp) * integer(b.maxHp, 1), right = integer(b.hp) * integer(a.maxHp, 1);
        return (left < right ? -1 : left > right ? 1 : 0) || id2;
      }
      case "hp-absolute-distance-id":
        return a.hp - b.hp || d || id2;
      case "not-burned-by-this-instance-distance-id":
        return burnt(a) - burnt(b) || d || id2;
      default:
        return d || id2;
    }
  });
  if (selector2.primary === "first-required") {
    if (!primary || !isSelectable(primary, holder, env) || selector2.maxTargets === 0 || candidateIds !== null && !candidateIds.includes(primary.id) || (selector2.relation === "self" ? primary.id !== holder.id : selector2.relation === "ally" ? primary.team !== holder.team : primary.team === holder.team) || selector2.radius !== null && hexDistance(anchor, primary.cell) > selector2.radius) return [];
    candidates = [primary, ...candidates.filter((u) => u.id !== primary.id)];
  }
  return candidates.slice(0, selector2.maxTargets).map((u) => u.id);
}
function shortestPath(board, from, to) {
  if (!contains(board, from) || !contains(board, to)) return [];
  const cells = [];
  let at = from;
  while (!sameCell(at, to)) {
    const next = getNeighbors(board, at).find((c) => hexDistance(c, to) < hexDistance(at, to));
    if (!next) break;
    cells.push(next);
    at = next;
  }
  return cells;
}
function chooseRandomCenter(env, draw) {
  const candidates = enemies2(env);
  if (!candidates.length) return null;
  const word = draw();
  integer(word);
  if (word > 4294967295) throw new RangeError("Invalid combat random word");
  return candidates[word % candidates.length].id;
}
function selectAbilityTargets(targeting, env) {
  const holder = get(env, env.holderId);
  if (!holder) return { targetIds: [] };
  const opponents = enemies2(env);
  const bound = (ids2) => ids2.filter((id2) => {
    const u = get(env, id2);
    return u && isSelectable(u, holder, { ...env, eligibility: "bound-packet" });
  });
  switch (targeting.kind) {
    case "bound-selection":
      return { targetIds: bound(env.boundTargetIds ?? []), centerId: env.boundCenterId == null ? null : bound([env.boundCenterId])[0] ?? null };
    case "fixed":
      return { targetIds: bound(targeting.targetIds) };
    case "select":
      return { targetIds: selectTargets(targeting.selector, env) };
    case "area-around-selected": {
      const center = get(env, selectTargets(targeting.center, env)[0]);
      if (!center) return { targetIds: [] };
      return { centerId: center.id, targetIds: env.units.filter((u) => isSelectable(u, holder, { ...env, eligibility: "area-hit" }) && (targeting.relation === "ally" ? u.team === holder.team : u.team !== holder.team) && hexDistance(u.cell, center.cell) <= targeting.radius).sort((a, b) => compareCodePoints(a.id, b.id)).map((u) => u.id) };
    }
    case "random-enemy-center": {
      if (env.randomCenterId === void 0) throw new RangeError("Random center must be sampled before plan execution");
      const center = get(env, env.randomCenterId);
      if (!center) return { targetIds: [], centerId: null };
      return { centerId: center.id, targetIds: enemies2({ ...env, eligibility: "area-hit" }).filter((u) => hexDistance(u.cell, center.cell) <= targeting.radius).map((u) => u.id) };
    }
    case "path": {
      const aim = opponents.find((u) => u.id === targeting.aimId) ?? (targeting.fallback === "farthest-enemy" ? [...opponents].sort((a, b) => distanceOrder(holder.cell, a, b, true))[0] : void 0);
      if (!aim) return { targetIds: [] };
      const cells = shortestPath(env.board, holder.cell, aim.cell);
      const members = targeting.intercept === "all-enemies" ? enemies2({ ...env, eligibility: "area-hit" }) : opponents;
      let hits = cells.flatMap((c) => members.filter((u) => sameCell(u.cell, c)));
      if (targeting.intercept === "first-enemy") hits = hits.slice(0, 1);
      if (targeting.hitOrder === "id") hits.sort((a, b) => compareCodePoints(a.id, b.id));
      return { targetIds: hits.map((u) => u.id) };
    }
    case "round-robin": {
      const aim = opponents.find((u) => u.id === targeting.primaryId) ?? [...opponents].sort((a, b) => distanceOrder(holder.cell, a, b))[0];
      if (!aim) return { targetIds: [] };
      const choices = [aim, ...opponents.filter((u) => u.id !== aim.id && hexDistance(u.cell, aim.cell) <= targeting.radius)];
      integer(targeting.ordinal);
      return { targetIds: [choices[targeting.ordinal % choices.length].id] };
    }
    case "chain": {
      const primary = opponents.find((u) => u.id === targeting.primaryId);
      if (!primary) return { targetIds: [] };
      const ids2 = [primary.id], seen = new Set(ids2);
      let previous = primary;
      for (let n = 0; n < targeting.additionalTargets; n++) {
        const from = targeting.order === "nearest-previous" ? previous : primary;
        const next = opponents.filter((u) => !seen.has(u.id) && hexDistance(from.cell, u.cell) <= targeting.radius).sort((a, b) => distanceOrder(from.cell, a, b, targeting.order === "farthest-from-primary-return-primary"))[0];
        if (!next) break;
        ids2.push(next.id);
        seen.add(next.id);
        previous = next;
        if (targeting.order === "farthest-from-primary-return-primary") ids2.push(primary.id);
      }
      return { targetIds: ids2 };
    }
  }
}
var AXIAL_DIRECTIONS = [[1, 0], [0, 1], [-1, 1], [-1, 0], [0, -1], [1, -1]];
var axial = (c) => [c.col - Math.floor(c.row / 2), c.row];
var offset = (q, r) => ({ col: q + Math.floor(r / 2), row: r });
function coneCells(board, origin2, primary) {
  if (!contains(board, origin2) || !contains(board, primary)) return [];
  const [q, r] = axial(origin2), dIndex = AXIAL_DIRECTIONS.findIndex(([dq, dr]) => {
    const c = offset(q + dq, r + dr);
    return contains(board, c) && hexDistance(c, primary) < hexDistance(origin2, primary);
  });
  if (dIndex < 0) return [];
  const d = AXIAL_DIRECTIONS[dIndex], left = AXIAL_DIRECTIONS[(dIndex + 5) % 6], right = AXIAL_DIRECTIONS[(dIndex + 1) % 6], [pq, pr] = axial(primary);
  return [[d[0], d[1]], [2 * d[0], 2 * d[1]], [d[0] + left[0], d[1] + left[1]], [d[0] + right[0], d[1] + right[1]]].map(([dq, dr]) => offset(pq + dq, pr + dr)).filter((c) => contains(board, c) && !sameCell(c, primary));
}
function selectConeTargets(env) {
  const holder = get(env, env.holderId), primary = get(env, env.primaryId);
  if (!holder || !primary) return [];
  const cells = coneCells(env.board, holder.cell, primary.cell);
  return enemies2(env).filter((u) => u.id !== primary.id && cells.some((c) => sameCell(c, u.cell))).sort((a, b) => distanceOrder(primary.cell, a, b)).slice(0, 2).map((u) => u.id);
}

// src/simulation/m8/s13-definitions.ts
var asSource = (source) => ({ ...source, parentItemInstanceId: "parentItemInstanceId" in source ? source.parentItemInstanceId : null });
var flatAmount = (flat = 0, patch = {}) => ({
  flat,
  attackDamageBps: 0,
  abilityPowerBps: 0,
  maxHpBps: 0,
  missingHpBps: 0,
  actualManaSpentBps: 0,
  actualDamageBps: 0,
  shieldAbsorbedBps: 0,
  hpBasis: "holder",
  sample: "application",
  cap: null,
  ...patch
});
var selfSelector = (patch = {}) => ({
  primary: "normal",
  candidates: "board",
  relation: "self",
  anchor: "holder",
  radius: null,
  maxTargets: 1,
  excludeSelf: false,
  excludePrimary: false,
  distinct: true,
  order: "distance-id",
  sample: "each-pulse",
  ...patch
});
function compileMechanismDefinitions(unit, combatId) {
  const eventTriggers = [];
  const survivalTriggers = [];
  const periodicTasks = [], vamp2 = [];
  for (const m of unit.mechanics ?? []) {
    const source = asSource(m.source), v = m.values;
    let effects2;
    if (m.mechanic === "rageblade") eventTriggers.push({ id: "attack-growth", source, listener: { subject: "actor", relationToHolder: "self", withinHexes: null }, aggregation: "event", counters: [], gate: { kind: "always" }, event: "attack-completed", condition: { kind: "always" }, selector: selfSelector({ sample: "action-completion" }), internalCooldownTicks: 0, maxPerAction: 1, maxPerCombat: null, stackPolicy: { kind: "add-stacks", cap: null }, effects: [{ kind: "modify-stat", modifier: { stat: "attackSpeed", unit: "bps", value: { kind: "constant", amount: v.attackSpeedBps }, condition: { kind: "always" }, damageFilter: null }, activation: "immediate", duration: { kind: "combat" }, stackPolicy: { kind: "add-stacks", cap: null } }] });
    if (m.mechanic === "dragonClaw") effects2 = [{ kind: "heal", amount: flatAmount(0, { maxHpBps: v.healMaxHpBps, sample: "each-pulse" }) }];
    if (m.mechanic === "archangel") effects2 = [{
      kind: "modify-stat",
      activation: "immediate",
      stackPolicy: { kind: "add-stacks", cap: null },
      duration: { kind: "combat" },
      modifier: { stat: "abilityPower", unit: "flat", value: { kind: "constant", amount: v.abilityPower }, condition: { kind: "always" }, damageFilter: null }
    }];
    if (effects2) periodicTasks.push({
      ...effectIdentity(combatId, source, unit.id),
      nextPulseAtTick: v.periodTicks,
      periodTicks: v.periodTicks,
      endsAtTick: null,
      pulseOrdinal: 0,
      pulseLimit: null,
      remainders: [],
      finalPulse: "none",
      onSourceDeath: "cancel",
      onTargetDeath: "cancel",
      program: { definitionId: JSON.stringify([source.definitionId, source.effectIndex, "periodic"]), selector: selfSelector(), targetSnapshot: "once-per-pulse", effects: effects2 }
    });
    if (m.mechanic === "gunblade") vamp2.push({
      source,
      modifier: { stat: "omnivamp", unit: "bps", value: { kind: "constant", amount: v.selfHealBps }, condition: { kind: "always" }, damageFilter: null },
      allyBps: v.allyHealBps,
      allyCondition: { kind: "always" }
    });
  }
  for (const entry of programEntries(unit)) {
    const { source } = entry;
    if (entry.kind === "trigger") eventTriggers.push({ ...entry.declaration, source });
    if (entry.kind === "survival") {
      const { initialAlso, ...d } = entry.declaration;
      survivalTriggers.push({ ...d, source });
      if (initialAlso) survivalTriggers.push({ ...d, source, event: "combat-start", listener: { ...d.listener, subject: "actor" } });
    }
    if (entry.kind === "vamp") vamp2.push({ ...entry.declaration, source });
    if (entry.kind === "periodic") {
      const p = entry.declaration;
      if (p.condition && !conditionHolds(p.condition, { holder: unit, startingRows: startingRows(unit.team, unit.startingCell?.row ?? unit.cell.row) ?? void 0 })) continue;
      periodicTasks.push({
        ...effectIdentity(combatId, source, unit.id),
        nextPulseAtTick: p.startsAtTick ?? p.periodTicks,
        periodTicks: p.periodTicks,
        endsAtTick: p.endsAtTick ?? null,
        pulseOrdinal: 0,
        pulseLimit: null,
        remainders: [],
        finalPulse: p.finalPulse ?? "none",
        onSourceDeath: "cancel",
        onTargetDeath: "cancel",
        program: { ...p.program, definitionId: JSON.stringify([source.definitionId, source.effectIndex, "periodic"]) }
      });
    }
    const startEffect = entry.kind === "modifier" && !["critChance", "critMultiplier"].includes(entry.declaration.stat) ? { kind: "modify-stat", modifier: entry.declaration, activation: "immediate", duration: { kind: "combat" }, stackPolicy: { kind: "independent-instances" } } : entry.kind === "effect" && !["authorize-spell-crit", "temporary-equipment"].includes(entry.declaration.kind) ? entry.declaration : void 0;
    if (startEffect) survivalTriggers.push({ id: "initial", source, event: "combat-start", listener: { subject: "actor", relationToHolder: "self", withinHexes: null }, aggregation: "event", counters: [], gate: { kind: "always" }, condition: { kind: "always" }, selector: selfSelector({ sample: "combat-start" }), internalCooldownTicks: 0, maxPerAction: 1, maxPerCombat: 1, stackPolicy: { kind: "independent-instances" }, effects: [startEffect] });
  }
  return { ...eventTriggers.length ? { eventTriggers } : {}, periodicTasks, survivalTriggers, vamp: vamp2, ...unit.ability.kind === "s13" && unit.ability.variables.HealPercentHealth > 0 ? { positiveDamageHeals: [{ source: asSource({ ownerId: unit.id, sourceKind: "ability", definitionId: unit.ability.id, instanceId: unit.id, effectIndex: 0 }), amount: flatAmount(0, { maxHpBps: unit.ability.variables.HealPercentHealth, sample: "packet" }) }] } : {} };
}

// src/simulation/neutral-encounter-compiler.ts
function compileNeutralEncounter(roundId) {
  const encounter = NEUTRAL_ENCOUNTERS.find((entry) => entry.roundId === roundId);
  if (!encounter) throw new RangeError(`Unknown neutral round: ${roundId}`);
  const deployment = [], units = [], openingDefinitions = [];
  const seenSlots = /* @__PURE__ */ new Set(), seenCells = /* @__PURE__ */ new Set();
  for (const slot3 of encounter.slots) {
    const cellKey3 = JSON.stringify([slot3.cell.col, slot3.cell.row]);
    if (!slot3.slotId || seenSlots.has(slot3.slotId) || seenCells.has(cellKey3) || !isDeploymentCell(DEFAULT_BOARD, "enemy", slot3.cell)) {
      throw new RangeError(`Invalid neutral deployment: ${encounter.encounterId}/${slot3.slotId}`);
    }
    seenSlots.add(slot3.slotId);
    seenCells.add(cellKey3);
    if (!Object.hasOwn(NEUTRAL_DEFINITIONS, slot3.definitionId)) throw new RangeError(`Unknown neutral definition: ${slot3.definitionId}`);
    const definition = NEUTRAL_DEFINITIONS[slot3.definitionId], mechanism = definition.mechanism;
    const id2 = JSON.stringify(["pve", roundId, encounter.encounterId, slot3.slotId]);
    const abilityId = neutralAbilityId(definition);
    const stats = {
      unitKind: definition.unitKind,
      monsterFamily: definition.monsterFamily,
      health: definition.health,
      attack: definition.attack,
      armor: definition.armor,
      magicResist: definition.magicResist,
      attackRange: definition.attackRange,
      attackIntervalTicks: attackInterval(definition.baseAttackSpeedBps, 0),
      baseAttackSpeedBps: definition.baseAttackSpeedBps,
      initialMana: definition.initialMana,
      maxMana: definition.maxMana,
      baseCritChanceBps: definition.baseCritChanceBps,
      baseCritMultiplierBps: definition.baseCritMultiplierBps,
      abilityId
    };
    validateNeutralInputs(stats);
    const source = { ownerId: id2, sourceKind: "ability", definitionId: abilityId, instanceId: id2, effectIndex: 0, parentItemInstanceId: null };
    const passive = mechanism.kind === "companion-heal" ? { companionDefinitions: [{
      source,
      maxReactions: mechanism.maxReactions,
      effects: [{ kind: "heal", amount: flatAmount(0, { missingHpBps: mechanism.missingHpBps }) }]
    }] } : mechanism.kind === "companion-speed" ? { companionDefinitions: [{ source, maxReactions: mechanism.maxReactions, effects: [{
      kind: "modify-stat",
      modifier: { stat: "attackSpeed", unit: "bps", value: { kind: "constant", amount: mechanism.attackSpeedBps }, condition: { kind: "always" }, damageFilter: null },
      activation: "next-tick",
      duration: { kind: "combat" },
      stackPolicy: { kind: "independent-instances" }
    }] }] } : mechanism.kind === "attack-cone" ? { attackCone: { secondaryDamageBps: mechanism.secondaryDamageBps } } : {};
    if (mechanism.kind === "backline-jump") openingDefinitions.push({ kind: "backline-jump", source });
    if (mechanism.kind === "path-charge") openingDefinitions.push({ kind: "path-charge", source, effects: [
      {
        kind: "damage",
        damageType: "magic",
        delivery: "ability-direct",
        critEligibility: "never",
        amount: flatAmount(0, { maxHpBps: mechanism.targetMaxHpBps, hpBasis: "target", cap: mechanism.damageCap, sample: "packet" })
      },
      { kind: "apply-status", status: {
        kind: "stun",
        magnitudeBps: 0,
        activation: "next-tick",
        duration: { kind: "ticks", ticks: mechanism.stunTicks },
        stackPolicy: { kind: "independent-instances" },
        removable: true,
        polarity: "harmful",
        damageFilter: null,
        onEnd: null
      } }
    ] });
    deployment.push({
      id: id2,
      definitionId: definition.id,
      encounterId: encounter.encounterId,
      team: "enemy",
      starLevel: definition.starLevel,
      location: { kind: "board", cell: { ...slot3.cell } }
    });
    units.push({
      ...compileUnitInputs(stats),
      ...passive,
      id: id2,
      definitionId: definition.id,
      encounterId: encounter.encounterId,
      team: "enemy",
      starLevel: definition.starLevel,
      cell: { ...slot3.cell },
      startingCell: { ...slot3.cell },
      hp: stats.health,
      maxHp: stats.health,
      maxHpBasis: { base: stats.health, flat: 0, bps: 0, bonusBps: 0 },
      attackDamage: stats.attack,
      attackDamageBase: stats.attack,
      attackDamagePercentBps: 0,
      abilityPower: definition.abilityPower,
      attackRange: stats.attackRange,
      attackIntervalTicks: stats.attackIntervalTicks,
      attackSpeedBonusBps: 0,
      cooldownTicks: 0,
      moveCooldownTicks: 0,
      armor: stats.armor,
      magicResist: stats.magicResist,
      mana: stats.initialMana,
      maxMana: stats.maxMana,
      shield: 0,
      shieldExpiresAtTick: null,
      ability: { id: abilityId, amount: 0, kind: "s13", championId: "neutral", variables: {} },
      sources: [],
      triggers: [],
      effectRuntime: [],
      mechanics: [],
      itemPrograms: [],
      shieldLayers: [],
      statuses: [],
      tasks: [],
      alive: true,
      targetId: null
    });
  }
  return freezeContent({
    roundId,
    encounterId: encounter.encounterId,
    catalogVersion: NEUTRAL_ENCOUNTER_CATALOG_VERSION,
    policyVersion: NEUTRAL_ENCOUNTER_POLICY_VERSION,
    encounterRngDraws: 0,
    deployment: deployment.sort(compareIds),
    units: units.sort(compareIds),
    openingDefinitions
  });
}
var COMPILED_NEUTRAL_ENCOUNTERS = freezeContent(NEUTRAL_ENCOUNTERS.map((e) => compileNeutralEncounter(e.roundId)));
var NEUTRAL_COMBAT_UNITS = new Map(COMPILED_NEUTRAL_ENCOUNTERS.flatMap((e) => e.units.map((u) => [u.id, u])));
function readNeutralCombatUnit(id2) {
  return NEUTRAL_COMBAT_UNITS.get(id2);
}

// src/simulation/round-enemies.ts
var ENEMY_TEMPLATES = freezeContent([
  ["irelia", "rell", "leona", "loris", "tristana", "urgot", "ezreal", "corki"],
  ["darius", "vander", "scar", "garen", "irelia", "loris", "maddie", "kogmaw"],
  ["irelia", "rell", "leona", "loris", "lux", "zyra", "nami", "zoe"]
]);
var ENEMY_POSITIONS = freezeContent([[1, 3], [3, 3], [5, 3], [0, 2], [6, 2], [1, 0], [3, 0], [5, 0]]);
var ENEMY_GROWTH = freezeContent({ fromRound: FINAL_ROUND + 1, bpsPerRound: 0, maxBps: 0 });
function templateIndex(round2) {
  let count = 0;
  for (let n = 1; n < round2; n++) if (getRoundKind(n) === "pvp") count++;
  return count % ENEMY_TEMPLATES.length;
}
function idsForRound(round2) {
  const { stage, round: sub } = getStageRound(round2), kind = getRoundKind(round2);
  if (kind === "supply") return [];
  if (kind === "pve") return [];
  const count = stage === 2 ? sub >= 5 ? 4 : 3 : stage + 2;
  let pool = ENEMY_TEMPLATES[templateIndex(round2)];
  if (stage === 2) pool = pool.filter((id2) => M5_UNIT_DEFINITIONS[id2].cost <= 2);
  return Array.from({ length: count }, (_, index) => pool[index % pool.length]);
}
function createRoundEnemies(round2) {
  const { stage } = getStageRound(round2), kind = getRoundKind(round2);
  if (kind === "pve") {
    const encounter = COMPILED_NEUTRAL_ENCOUNTERS.find((e) => e.roundId === ROUND_CATALOG[round2 - 1].roundId);
    if (!encounter) throw new RangeError("Missing approved neutral encounter");
    return encounter.deployment;
  }
  return idsForRound(round2).map((definitionId2, index) => ({
    id: round2 === 1 ? `enemy-${index + 1}` : `enemy-r${round2}-${index + 1}`,
    definitionId: definitionId2,
    team: "enemy",
    starLevel: stage >= 5 ? 2 : stage === 4 && index < 3 ? 2 : stage === 3 && index === 0 ? 2 : 1,
    location: { kind: "board", cell: { col: ENEMY_POSITIONS[index][0], row: ENEMY_POSITIONS[index][1] } }
  }));
}
function getRoundEnemyItems(round2) {
  const { stage } = getStageRound(round2);
  if (getRoundKind(round2) !== "pvp" || stage < 4) return [];
  const units = createRoundEnemies(round2), line = templateIndex(round2);
  const carryPreference = line === 0 ? ["corki", "ezreal", "tristana", "urgot"] : line === 1 ? ["kogmaw", "maddie", "garen"] : ["zoe", "nami", "zyra", "lux"];
  const carry = carryPreference.map((id2) => units.find((u) => u.definitionId === id2)).find(Boolean) ?? units[units.length - 1];
  const tank = units.find((unit) => unit.id !== carry.id) ?? units[0];
  const carryItems = line === 0 ? ["deathblade", "shojin", "gunblade"] : line === 1 ? ["rageblade", "archangel", "gunblade"] : ["shojin", "deathcap", "gunblade"];
  const result = carryItems.slice(0, stage - 3).map((definitionId2, slot3) => ({ unitId: carry.id, definitionId: definitionId2, slot: slot3 }));
  if (stage >= 5) result.push(...["warmog", "dragons-claw"].slice(0, stage - 4).map((definitionId2, slot3) => ({ unitId: tank.id, definitionId: definitionId2, slot: slot3 })));
  return result;
}
var ROUND_ENEMY_PROJECTIONS = freezeContent(ROUND_CATALOG.map((round2) => ({
  round: round2.ordinal,
  roundId: round2.roundId,
  units: createRoundEnemies(round2.ordinal),
  items: getRoundEnemyItems(round2.ordinal)
})));
function readRoundEnemyProjection(round2) {
  getStageRound(round2);
  return ROUND_ENEMY_PROJECTIONS[round2 - 1];
}

// src/simulation/progression.ts
function validateLevel(level) {
  if (!Number.isInteger(level) || level < 1 || level > MATCH_RULES.maxLevel) throw new RangeError(`Invalid player level: ${level}`);
}
function getXpToNextLevel(level) {
  validateLevel(level);
  return level === MATCH_RULES.maxLevel ? null : XP_TO_NEXT_LEVEL[level];
}
function getShopOdds(level) {
  validateLevel(level);
  return SHOP_ODDS[level];
}
function grantXp(level, xp, amount3) {
  const threshold = getXpToNextLevel(level);
  if (!Number.isSafeInteger(xp) || xp < 0 || (threshold === null ? xp !== 0 : xp >= threshold) || !Number.isSafeInteger(amount3) || amount3 < 0 || !Number.isSafeInteger(xp + amount3)) {
    throw new RangeError("Experience must be a normalized nonnegative integer");
  }
  const initialLevel = level;
  let remaining = amount3;
  while (level < MATCH_RULES.maxLevel) {
    const required = XP_TO_NEXT_LEVEL[level] - xp;
    if (remaining < required) {
      xp += remaining;
      remaining = 0;
      break;
    }
    remaining -= required;
    level++;
    xp = 0;
  }
  return { level, xp, xpRequested: amount3, xpApplied: amount3 - remaining, levelsGained: level - initialLevel };
}

// src/simulation/economy.ts
function nonnegativeInteger(value, label) {
  if (!Number.isSafeInteger(value) || value < 0) throw new RangeError(`Invalid ${label}`);
}
function planRoundEconomy(input) {
  const { stage, roundKind, result, gold, streak, level, xp, hp: hp2, enemySurvivors } = input;
  if (!Number.isInteger(stage) || STAGE_PLAYER_DAMAGE[stage] === void 0) throw new RangeError("Invalid stage");
  if (!["pvp", "pve", "supply"].includes(roundKind)) throw new RangeError("Invalid round kind");
  if (roundKind === "supply" ? result !== null : !["playerWin", "enemyWin", "draw"].includes(result ?? "")) {
    throw new RangeError("Result does not match round kind");
  }
  nonnegativeInteger(gold, "gold");
  nonnegativeInteger(hp2, "HP");
  nonnegativeInteger(enemySurvivors, "enemy survivor count");
  nonnegativeInteger(streak.count, "streak count");
  if (!["win", "loss", null].includes(streak.kind) || streak.kind === null !== (streak.count === 0)) {
    throw new RangeError("Invalid streak");
  }
  if (hp2 > MATCH_RULES.initialHp || roundKind === "supply" && enemySurvivors !== 0) throw new RangeError("Invalid round resources");
  const isPvp = roundKind === "pvp";
  const won = result === "playerWin";
  let streakAfter = { ...streak };
  if (isPvp) {
    const kind = won ? "win" : "loss";
    streakAfter = { kind, count: streak.kind === kind ? streak.count + 1 : 1 };
    nonnegativeInteger(streakAfter.count, "streak count");
  }
  const win = isPvp && won ? ECONOMY_RULES.victoryGold : 0;
  const interestBasis = gold + win;
  nonnegativeInteger(interestBasis, "interest basis");
  const interest = Math.min(ECONOMY_RULES.interestCap, Math.floor(interestBasis / ECONOMY_RULES.interestDivisor));
  let streakGold = 0;
  if (isPvp) for (const threshold of ECONOMY_RULES.streakThresholds) {
    if (streakAfter.count >= threshold.count) streakGold = threshold.gold;
  }
  const incomeBreakdown = { base: MATCH_RULES.roundIncome, win, interest, streak: streakGold };
  const income = incomeBreakdown.base + win + interest + streakGold;
  const goldAfter = gold + income;
  nonnegativeInteger(goldAfter, "settled gold");
  const baseDamage = isPvp ? STAGE_PLAYER_DAMAGE[stage] : roundKind === "pve" ? ECONOMY_RULES.pveFailureDamage : 0;
  const playerDamage = roundKind === "supply" || won ? 0 : baseDamage + (isPvp ? enemySurvivors : 0);
  nonnegativeInteger(playerDamage, "player damage");
  const hpAfter = Math.max(0, hp2 - playerDamage);
  return {
    goldAfter,
    hpAfter,
    income,
    incomeBreakdown,
    interestBasis,
    streakAfter,
    baseDamage,
    playerDamage,
    hpLost: hp2 - hpAfter,
    progression: grantXp(level, xp, MATCH_RULES.roundXp)
  };
}

// src/simulation/opening-economy.ts
function planOpeningEconomy(input) {
  const round2 = getCatalogRoundById(input.roundId);
  if (round2.kind === "supply" ? input.result !== null : !["playerWin", "enemyWin", "draw"].includes(input.result ?? "")) {
    throw new RangeError("Result does not match catalog round kind");
  }
  if (round2.stage >= 2) return { kind: "existing-rules", roundId: round2.roundId };
  if (!Number.isSafeInteger(input.gold) || input.gold < 0) throw new RangeError("Invalid opening gold");
  const { kind, count } = input.streak;
  if (!Number.isSafeInteger(count) || count < 0 || !["win", "loss", null].includes(kind) || kind === null !== (count === 0)) throw new RangeError("Invalid opening streak");
  const parameters = OPENING_ECONOMY_RULES.rounds[round2.roundId];
  if (!parameters) throw new RangeError("Missing opening economy parameters");
  const { baseGold: base, naturalXp } = parameters;
  const goldAfter = input.gold + base;
  if (!Number.isSafeInteger(goldAfter)) throw new RangeError("Invalid settled opening gold");
  return {
    kind: "opening",
    roundId: round2.roundId,
    income: base,
    incomeBreakdown: { base, win: OPENING_ECONOMY_RULES.victoryGold, interest: OPENING_ECONOMY_RULES.interest, streak: OPENING_ECONOMY_RULES.streakGold },
    goldAfter,
    naturalXp,
    playerDamage: input.result === "playerWin" ? 0 : OPENING_ECONOMY_RULES.pveFailureDamage,
    streakAfter: { ...input.streak },
    progression: grantXp(input.level, input.xp, naturalXp)
  };
}
function planCatalogRoundEconomy(input) {
  const round2 = getCatalogRoundById(input.roundId);
  const opening = planOpeningEconomy(input);
  if (opening.kind === "existing-rules") return planRoundEconomy({ ...input, stage: round2.stage, roundKind: round2.kind });
  if (!Number.isSafeInteger(input.hp) || input.hp < 0 || input.hp > MATCH_RULES.initialHp || !Number.isSafeInteger(input.enemySurvivors) || input.enemySurvivors < 0) throw new RangeError("Invalid opening resources");
  const hpAfter = Math.max(0, input.hp - opening.playerDamage);
  return {
    goldAfter: opening.goldAfter,
    hpAfter,
    income: opening.income,
    incomeBreakdown: opening.incomeBreakdown,
    interestBasis: input.gold,
    streakAfter: opening.streakAfter,
    baseDamage: OPENING_ECONOMY_RULES.pveFailureDamage,
    playerDamage: opening.playerDamage,
    hpLost: input.hp - hpAfter,
    progression: opening.progression
  };
}

// src/simulation/content/source-manifest.ts
var SOURCE_MANIFEST = freezeContent({
  "referencePatch": "S13-14.24b",
  "contentVersion": "s13-14.24b-slice-v1",
  "equipmentCatalogVersion": "s13-14.24b-m8-b5-v1",
  "equipmentArchive": "src/simulation/content/source/s13-14.24b/normalized/items.json",
  "rawUrl": "https://raw.communitydragon.org/14.24/cdragon/tft/en_us.json",
  "rawSha256": "c1237ba2441f932a1b9761ce12887ad21089dffbd3a8004671cc9cb82dfd5bd3",
  "selector": 'setData[mutator === "TFTSet13"]',
  "localArchive": "src/simulation/content/source/s13-14.24.json",
  "overrides": [
    {
      "path": "champions.loris.stats.initialMana",
      "from": 50,
      "to": 40
    },
    {
      "path": "champions.loris.stats.mana",
      "from": 90,
      "to": 80
    }
  ],
  "overrideSource": "https://teamfighttactics.leagueoflegends.com/en-us/news/game-updates/teamfight-tactics-patch-14-24-notes/",
  "anomalySource": "https://wiki.leagueoflegends.com/en-us/TFT:Anomaly?oldid=3848901",
  "championApiNames": {
    "irelia": "TFT13_Irelia",
    "maddie": "TFT13_Shooter",
    "darius": "TFT13_Darius",
    "lux": "TFT13_Lux",
    "zyra": "TFT13_Zyra",
    "tristana": "TFT13_Tristana",
    "urgot": "TFT13_Urgot",
    "rell": "TFT13_Rell",
    "leona": "TFT13_Leona",
    "vander": "TFT13_Prime",
    "kogmaw": "TFT13_KogMaw",
    "scar": "TFT13_FlyGuy",
    "ezreal": "TFT13_Ezreal",
    "loris": "TFT13_Beardy",
    "nami": "TFT13_Nami",
    "corki": "TFT13_Corki",
    "garen": "TFT13_Garen",
    "zoe": "TFT13_Zoe",
    "caitlyn": "TFT13_Caitlyn"
  },
  "itemApiNames": {
    "adaptive-helm": "TFT_Item_AdaptiveHelm",
    "archangel": "TFT_Item_ArchangelsStaff",
    "sword": "TFT_Item_BFSword",
    "bloodthirster": "TFT_Item_Bloodthirster",
    "blue-buff": "TFT_Item_BlueBuff",
    "bramble-vest": "TFT_Item_BrambleVest",
    "vest": "TFT_Item_ChainVest",
    "crownguard": "TFT_Item_Crownguard",
    "deathblade": "TFT_Item_Deathblade",
    "dragons-claw": "TFT_Item_DragonsClaw",
    "protectors-vow": "TFT_Item_FrozenHeart",
    "gargoyle": "TFT_Item_GargoyleStoneplate",
    "belt": "TFT_Item_GiantsBelt",
    "edge-of-night": "TFT_Item_GuardianAngel",
    "rageblade": "TFT_Item_GuinsoosRageblade",
    "gunblade": "TFT_Item_HextechGunblade",
    "infinity-edge": "TFT_Item_InfinityEdge",
    "ionic-spark": "TFT_Item_IonicSpark",
    "jeweled-gauntlet": "TFT_Item_JeweledGauntlet",
    "last-whisper": "TFT_Item_LastWhisper",
    "nashors-tooth": "TFT_Item_Leviathan",
    "giant-slayer": "TFT_Item_MadredsBloodrazor",
    "morellonomicon": "TFT_Item_Morellonomicon",
    "rod": "TFT_Item_NeedlesslyLargeRod",
    "cloak": "TFT_Item_NegatronCloak",
    "steadfast-heart": "TFT_Item_NightHarvester",
    "guardbreaker": "TFT_Item_PowerGauntlet",
    "quicksilver": "TFT_Item_Quicksilver",
    "deathcap": "TFT_Item_RabadonsDeathcap",
    "red-buff": "TFT_Item_RapidFireCannon",
    "bow": "TFT_Item_RecurveBow",
    "sunfire-cape": "TFT_Item_RedBuff",
    "redemption": "TFT_Item_Redemption",
    "runaans-hurricane": "TFT_Item_RunaansHurricane",
    "gloves": "TFT_Item_SparringGloves",
    "shojin": "TFT_Item_SpearOfShojin",
    "evenshroud": "TFT_Item_SpectralGauntlet",
    "statikk-shiv": "TFT_Item_StatikkShiv",
    "steraks-gage": "TFT_Item_SteraksGage",
    "tear": "TFT_Item_TearOfTheGoddess",
    "thiefs-gloves": "TFT_Item_ThiefsGloves",
    "titans-resolve": "TFT_Item_TitansResolve",
    "hand-of-justice": "TFT_Item_UnstableConcoction",
    "warmog": "TFT_Item_WarmogsArmor"
  },
  "augmentApiNames": {
    "placebo": "TFT_Augment_Placebo",
    "manaflow-i": "TFT_Augment_Manaflow1",
    "glass-cannon-i": "TFT_Augment_GlassCannonI",
    "pumping-up-i": "TFT9_Augment_PumpingUp",
    "investment-strategy-i": "TFT_Augment_InvestmentStrategy1",
    "bulky-buddies-i": "TFT_Augment_BulkyBuddies1"
  },
  "variableConvention": {
    "starSlots": [
      1,
      2,
      3
    ],
    "decimalPlaces": 4,
    "ratio": "fraction: multiply by 10000 to derive integer basis points",
    "duration": "seconds: multiply by 20 to derive ticks",
    "apAmount": "multiply by AP/100",
    "excludedPrefixes": [
      "HERO",
      "Experiment"
    ],
    "excludedModes": [
      "Hyperroll"
    ]
  },
  "disabledOriginTraits": {
    "irelia": [
      "Rebel"
    ],
    "maddie": [
      "Enforcer"
    ],
    "darius": [
      "Conqueror"
    ],
    "lux": [
      "Academy"
    ],
    "zyra": [
      "Experiment"
    ],
    "tristana": [
      "Emissary"
    ],
    "urgot": [
      "Experiment",
      "Pit Fighter"
    ],
    "rell": [
      "Conqueror",
      "Visionary"
    ],
    "leona": [
      "Academy"
    ],
    "vander": [
      "Family"
    ],
    "kogmaw": [
      "Automata"
    ],
    "scar": [
      "Firelight"
    ],
    "ezreal": [
      "Academy",
      "Rebel"
    ],
    "loris": [
      "Enforcer"
    ],
    "nami": [
      "Emissary"
    ],
    "corki": [
      "Scrap"
    ],
    "garen": [
      "Emissary"
    ],
    "zoe": [
      "Rebel"
    ],
    "caitlyn": [
      "Enforcer"
    ]
  },
  "approvedSimplifications": [
    "No origin-trait effects",
    "M5 hex line/cone geometry",
    "Fixed tick multi-shot cadence",
    "No Corki gameplay dash",
    "Template enemies, supply replaces carousel",
    "HP/AD star multipliers 1/1.8/3.24"
  ]
});

// src/simulation/content/traits.ts
var TRAIT_DEFINITIONS = freezeContent({
  "sentinel": {
    "id": "sentinel",
    "name": "\u54E8\u5175",
    "target": "team",
    "tiers": [
      {
        "threshold": 2,
        "effects": [
          {
            "kind": "statFlat",
            "stat": "armor",
            "amount": 12
          },
          {
            "kind": "statFlat",
            "stat": "magicResist",
            "amount": 12
          }
        ],
        "memberEffects": [
          {
            "kind": "statFlat",
            "stat": "armor",
            "amount": 24
          },
          {
            "kind": "statFlat",
            "stat": "magicResist",
            "amount": 24
          }
        ]
      },
      {
        "threshold": 4,
        "effects": [
          {
            "kind": "statFlat",
            "stat": "armor",
            "amount": 25
          },
          {
            "kind": "statFlat",
            "stat": "magicResist",
            "amount": 25
          }
        ],
        "memberEffects": [
          {
            "kind": "statFlat",
            "stat": "armor",
            "amount": 50
          },
          {
            "kind": "statFlat",
            "stat": "magicResist",
            "amount": 50
          }
        ]
      }
    ]
  },
  "artillerist": {
    "id": "artillerist",
    "name": "\u70AE\u624B",
    "target": "members",
    "tiers": [
      {
        "threshold": 2,
        "effects": [
          {
            "kind": "statPercentBps",
            "stat": "attackDamage",
            "bps": 1e3
          },
          {
            "kind": "mechanic",
            "mechanic": "artillery",
            "values": {
              "everyN": 5,
              "adBps": 12500,
              "radius": 1
            }
          }
        ]
      },
      {
        "threshold": 4,
        "effects": [
          {
            "kind": "statPercentBps",
            "stat": "attackDamage",
            "bps": 4500
          },
          {
            "kind": "mechanic",
            "mechanic": "artillery",
            "values": {
              "everyN": 5,
              "adBps": 12500,
              "radius": 1
            }
          }
        ]
      }
    ]
  },
  "sniper": {
    "id": "sniper",
    "name": "\u72D9\u795E",
    "target": "members",
    "tiers": [
      {
        "threshold": 2,
        "effects": [
          {
            "kind": "mechanic",
            "mechanic": "sniper",
            "values": {
              "damageBpsPerHex": 700
            }
          }
        ]
      }
    ]
  },
  "watcher": {
    "id": "watcher",
    "name": "\u76D1\u5BDF",
    "target": "members",
    "tiers": [
      {
        "threshold": 2,
        "effects": [
          {
            "kind": "mechanic",
            "mechanic": "watcher",
            "values": {
              "reductionBps": 1500,
              "healthyReductionBps": 3e3,
              "thresholdBps": 5e3
            }
          }
        ]
      },
      {
        "threshold": 4,
        "effects": [
          {
            "kind": "mechanic",
            "mechanic": "watcher",
            "values": {
              "reductionBps": 2500,
              "healthyReductionBps": 4500,
              "thresholdBps": 5e3
            }
          }
        ]
      }
    ]
  },
  "sorcerer": {
    "id": "sorcerer",
    "name": "\u6CD5\u5E08",
    "target": "team",
    "tiers": [
      {
        "threshold": 2,
        "effects": [
          {
            "kind": "statFlat",
            "stat": "abilityPower",
            "amount": 10
          }
        ],
        "memberEffects": [
          {
            "kind": "statFlat",
            "stat": "abilityPower",
            "amount": 10
          }
        ]
      },
      {
        "threshold": 4,
        "effects": [
          {
            "kind": "statFlat",
            "stat": "abilityPower",
            "amount": 10
          }
        ],
        "memberEffects": [
          {
            "kind": "statFlat",
            "stat": "abilityPower",
            "amount": 40
          }
        ]
      }
    ]
  }
});

// src/simulation/content/augments.ts
var AUGMENT_DEFINITIONS = freezeContent({
  "placebo": {
    "id": "placebo",
    "name": "\u5B89\u6170\u5242",
    "description": "\u7ACB\u5373\u83B7\u5F978\u91D1\u5E01\uFF0C\u5168\u961F\u83B7\u5F971%\u653B\u901F\u3002",
    "effects": [
      {
        "kind": "attackSpeedBps",
        "bps": 100
      },
      {
        "kind": "mechanic",
        "mechanic": "acquisitionGold",
        "values": {
          "amount": 8
        }
      }
    ]
  },
  "manaflow-i": {
    "id": "manaflow-i",
    "name": "\u6CD5\u529B\u6D41 I",
    "description": "\u5F00\u6218\u65F6\u6700\u540E\u4E00\u6392\u5355\u4F4D\u6BCF\u6B21\u666E\u653B\u989D\u5916\u83B7\u5F972\u6CD5\u529B\u3002",
    "effects": [
      {
        "kind": "mechanic",
        "mechanic": "extraAttackMana",
        "values": {
          "amount": 2,
          "backRowOnly": 1
        }
      }
    ]
  },
  "glass-cannon-i": {
    "id": "glass-cannon-i",
    "name": "\u73BB\u7483\u5927\u70AE I",
    "description": "\u5F00\u6218\u65F6\u6700\u540E\u4E00\u6392\u5355\u4F4D\u4EE580%\u6700\u5927\u751F\u547D\u5F00\u59CB\uFF0C\u83B7\u5F9712%\u4F24\u5BB3\u589E\u5E45\u3002",
    "effects": [
      {
        "kind": "mechanic",
        "mechanic": "glassCannon",
        "values": {
          "startingHealthBps": 8e3,
          "damageAmpBps": 1200,
          "backRowOnly": 1
        }
      }
    ]
  },
  "pumping-up-i": {
    "id": "pumping-up-i",
    "name": "\u52A0\u5FEB\u8282\u594F I",
    "description": "\u5168\u961F\u83B7\u5F976%\u653B\u901F\uFF0C\u6B64\u540E\u6BCF\u5B8C\u6210\u4E00\u8F6E\u589E\u52A00.5\u4E2A\u767E\u5206\u70B9\u3002",
    "effects": [
      {
        "kind": "attackSpeedBps",
        "bps": 600
      },
      {
        "kind": "mechanic",
        "mechanic": "pumpingUp",
        "values": {
          "attackSpeedBpsPerRound": 50
        }
      }
    ]
  },
  "investment-strategy-i": {
    "id": "investment-strategy-i",
    "name": "\u6295\u8D44\u7B56\u7565 I",
    "description": "\u83B7\u5F97\u540E\uFF0C\u6BCF\u8D5A\u53D61\u5229\u606F\uFF0C\u5168\u961F\u6C38\u4E45\u589E\u52A08\u6700\u5927\u751F\u547D\u3002",
    "effects": [
      {
        "kind": "mechanic",
        "mechanic": "investment",
        "values": {
          "healthPerInterest": 8
        }
      }
    ]
  },
  "bulky-buddies-i": {
    "id": "bulky-buddies-i",
    "name": "\u5927\u5757\u5934\u4F19\u4F34 I",
    "description": "\u5F00\u6218\u65F6\u6070\u4E0E\u4E00\u4E2A\u53CB\u519B\u76F8\u90BB\u7684\u5355\u4F4D\u83B7\u5F97100\u751F\u547D\uFF1B\u8BE5\u90BB\u5C45\u6B7B\u4EA1\u65F6\uFF0C\u83B7\u5F9710%\u6700\u5927\u751F\u547D\u768410\u79D2\u76FE\u3002",
    "effects": [
      {
        "kind": "mechanic",
        "mechanic": "bulkyBuddies",
        "values": {
          "health": 100,
          "shieldMaxHpBps": 1e3,
          "durationTicks": 200
        }
      }
    ]
  }
});

// src/simulation/content/anomalies.ts
var ANOMALY_DEFINITIONS = freezeContent({
  "titanic-strikes": {
    "id": "titanic-strikes",
    "name": "\u6CF0\u5766\u6253\u51FB",
    "description": "\u666E\u653B\u5BF9\u76EE\u6807\u53CA\u5176\u4E00\u683C\u90BB\u57DF\u9644\u52A040%\u653B\u51FB\u529B\u7269\u7406\u4F24\u5BB3\u3002",
    "effects": [
      {
        "kind": "mechanic",
        "mechanic": "titanic",
        "values": {
          "adBps": 4e3,
          "radius": 1
        }
      }
    ]
  },
  "mage-armor": {
    "id": "mage-armor",
    "name": "\u6CD5\u5E08\u62A4\u7532",
    "description": "\u83B7\u5F97\u76F8\u5F53\u4E8E\u8F6C\u6362\u524D\u6700\u7EC8\u6CD5\u5F3A50%\u7684\u62A4\u7532\u548C\u9B54\u6297\u3002",
    "effects": [
      {
        "kind": "mechanic",
        "mechanic": "mageArmor",
        "values": {
          "apBps": 5e3
        }
      }
    ]
  },
  "kill-streak": {
    "id": "kill-streak",
    "name": "\u8FDE\u6740",
    "description": "\u6BCF\u6B21\u51FB\u6740\u540E\uFF0C\u82E5\u672Ctick\u4ECD\u5B58\u6D3B\uFF0C\u83B7\u5F9720\u6CD5\u529B\u3002",
    "effects": [
      {
        "kind": "mechanic",
        "mechanic": "killStreak",
        "values": {
          "mana": 20
        }
      }
    ]
  }
});

// src/simulation/content/index.ts
function canonicalContent(value) {
  if (value === null || typeof value === "string" || typeof value === "boolean") return JSON.stringify(value);
  if (typeof value === "number" && Number.isFinite(value)) return JSON.stringify(value);
  if (Array.isArray(value)) {
    for (let i = 0; i < value.length; i++) if (!Object.hasOwn(value, i)) throw new TypeError("Content cannot contain sparse arrays");
    return `[${value.map(canonicalContent).join(",")}]`;
  }
  if (typeof value === "object" && value !== null && Object.getPrototypeOf(value) === Object.prototype) {
    return `{${Object.keys(value).sort().map((key3) => `${JSON.stringify(key3)}:${canonicalContent(value[key3])}`).join(",")}}`;
  }
  throw new TypeError("Content must be finite plain JSON data");
}
function digestContent(value) {
  let hash = 2166136261;
  const text = canonicalContent(value);
  for (let i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619) >>> 0;
  return `fnv1a32-utf16:${hash.toString(16).padStart(8, "0")}`;
}
var CONTENT_DIGEST = digestContent({
  loot: { runtime: LOOT_RUNTIME_REVISION, freeze: LOOT_FREEZE_ALGORITHM, policy: LOOT_POLICY_VERSION, heroPoolVersion: LOOT_HERO_POOL_VERSION, heroPools: LOOT_HERO_POOLS, slots: LOOT_SLOTS, categories: LOOT_CATEGORIES },
  neutralEncounters: { runtime: NEUTRAL_RUNTIME_VERSION, version: NEUTRAL_ENCOUNTER_CATALOG_VERSION, policy: NEUTRAL_ENCOUNTER_POLICY_VERSION, definitions: NEUTRAL_DEFINITIONS, encounters: NEUTRAL_ENCOUNTERS },
  roundRulesVersion: ROUND_RULES_VERSION,
  roundCatalog: ROUND_CATALOG,
  roundSemanticNodes: ROUND_SEMANTIC_NODES,
  roundPreparation: ROUND_PREPARATION_RULES,
  opening: { initial: OPENING_INITIAL_STATE, economy: OPENING_ECONOMY_RULES },
  finalRound: FINAL_ROUND,
  equipmentRulesVersion: EQUIPMENT_RULES_VERSION,
  temporaryEquipmentPool: TEMPORARY_EQUIPMENT_POOL,
  units: M5_UNIT_DEFINITIONS,
  neutralUnits: NEUTRAL_UNIT_DEFINITIONS,
  abilities: ABILITY_DEFINITIONS,
  s13Abilities: S13_ABILITY_DATA,
  traits: TRAIT_DEFINITIONS,
  items: ITEM_DEFINITIONS,
  augments: AUGMENT_DEFINITIONS,
  anomalies: ANOMALY_DEFINITIONS,
  schedule: ROUND_SCHEDULE,
  shopCatalog: SHOP_CATALOG_BY_COST,
  shopOdds: SHOP_ODDS,
  enemyTemplates: ENEMY_TEMPLATES,
  enemyPositions: ENEMY_POSITIONS,
  enemyGrowth: ENEMY_GROWTH,
  opponents: ROUND_ENEMY_PROJECTIONS,
  economy: { rules: MATCH_RULES, stages: STAGE_PLAYER_DAMAGE, income: ECONOMY_RULES, experience: XP_TO_NEXT_LEVEL },
  componentPool: { version: COMPONENT_POOL_VERSION, entries: COMPONENT_POOL },
  reference: SOURCE_MANIFEST,
  combatRules: S13_COMBAT_RULES
});

// src/simulation/input-assets.ts
function createInputValidation(requireValue3) {
  function integer8(value, min = 0) {
    requireValue3(Number.isSafeInteger(value) && value >= min, "integer");
  }
  function id2(value) {
    requireValue3(typeof value === "string" && value.length > 0, "ID");
  }
  function definitionId2(value, catalog, label) {
    id2(value);
    requireValue3(Object.hasOwn(catalog, value), label);
  }
  function list2(value) {
    requireValue3(Array.isArray(value), "array");
  }
  function record4(value) {
    requireValue3(value !== null && typeof value === "object" && Object.getPrototypeOf(value) === Object.prototype, "object");
  }
  function checkSerial2(instanceId, prefix, next) {
    id2(instanceId);
    requireValue3(new RegExp(`^${prefix}-[1-9][0-9]*$`).test(instanceId), `${prefix} ID`);
    requireValue3(Number(instanceId.slice(prefix.length + 1)) < next, `${prefix} serial`);
  }
  return { requireValue: requireValue3, integer: integer8, id: id2, definitionId: definitionId2, list: list2, record: record4, checkSerial: checkSerial2 };
}
function validateInputAssets(input, boundary, enemies4, validation) {
  const __b8Timer = globalThis.__b8Start("validateInputAssets");
  try {
    const requireValue3 = validation.requireValue;
    const integer8 = validation.integer;
    const id2 = validation.id;
    const definitionId2 = validation.definitionId;
    const list2 = validation.list;
    const record4 = validation.record;
    const checkSerial2 = validation.checkSerial;
    integer8(boundary.playerLevel, 1);
    integer8(boundary.nextUnitSerial, 1);
    integer8(boundary.nextItemSerial, 1);
    requireValue3(boundary.playerLevel <= 9, "level/HP bounds");
    record4(input.preparation);
    record4(input.preparation.board);
    record4(input.preparation.board.deploymentZones);
    const { board, benchSize } = input.preparation;
    integer8(board.columns, 1);
    integer8(board.rows, 1);
    for (const team of ["player", "enemy"]) {
      record4(board.deploymentZones[team]);
      integer8(board.deploymentZones[team].firstRow);
      integer8(board.deploymentZones[team].lastRow);
    }
    integer8(benchSize, 1);
    list2(input.preparation.units);
    requireValue3(canonicalContent(board) === canonicalContent(DEFAULT_BOARD) && benchSize === 9, "board rules");
    const units = /* @__PURE__ */ new Map(), locations = /* @__PURE__ */ new Set();
    for (const unit of input.preparation.units) {
      record4(unit);
      id2(unit.id);
      requireValue3(!units.has(unit.id), "duplicate unit");
      units.set(unit.id, unit);
      definitionId2(unit.definitionId, unit.team === "player" ? M5_UNIT_DEFINITIONS : UNIT_DEFINITIONS, "unit definition");
      requireValue3(unit.team === "player" || unit.team === "enemy", "team");
      requireValue3([1, 2, 3].includes(unit.starLevel), "star");
      record4(unit.location);
      if (unit.team === "player") checkSerial2(unit.id, "unit", boundary.nextUnitSerial);
      if (unit.location.kind === "bench") {
        integer8(unit.location.slot);
        requireValue3(unit.team === "player" && unit.location.slot < benchSize, "bench location");
      } else {
        requireValue3(unit.location.kind === "board", "location kind");
        record4(unit.location.cell);
        integer8(unit.location.cell.col);
        integer8(unit.location.cell.row);
        requireValue3(contains(board, unit.location.cell) && isDeploymentCell(board, unit.team, unit.location.cell), "board location");
      }
      const key3 = unit.location.kind === "bench" ? `bench:${unit.location.slot}` : `board:${unit.location.cell.col}:${unit.location.cell.row}`;
      requireValue3(!locations.has(key3), "occupied location");
      locations.add(key3);
    }
    const byId = (a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
    requireValue3(canonicalContent(input.preparation.units.filter((unit) => unit.team === "enemy").sort(byId)) === canonicalContent([...enemies4].sort(byId)), "enemy roster identity");
    requireValue3([...units.values()].filter((unit) => unit.team === "player" && unit.location.kind === "board").length <= boundary.playerLevel, "population cap");
    list2(input.items);
    const itemIds = /* @__PURE__ */ new Set(), equipment = /* @__PURE__ */ new Set();
    for (const item of input.items) {
      record4(item);
      id2(item.id);
      checkSerial2(item.id, "item", boundary.nextItemSerial);
      requireValue3(!itemIds.has(item.id), "duplicate item");
      itemIds.add(item.id);
      definitionId2(item.definitionId, ITEM_DEFINITIONS, "item definition");
      record4(item.location);
      if (item.location.kind === "unit") {
        requireValue3(units.get(item.location.unitId)?.team === "player", "item owner");
        integer8(item.location.slot);
        requireValue3(item.location.slot <= 2, "equipment slot");
        const key3 = `${item.location.unitId}:${item.location.slot}`;
        requireValue3(!equipment.has(key3), "occupied equipment slot");
        equipment.add(key3);
      } else requireValue3(item.location.kind === "inventory", "item location");
    }
    for (const item of input.items) if (item.location.kind === "unit") {
      requireValue3(ITEM_DEFINITIONS[item.definitionId].slotCost !== 3 || item.location.slot === 0, "exclusive parent slot");
      requireValue3(checkEquipmentPlacement(input.items, item, item.location.unitId, item.location.slot).allowed, "equipment constraints");
    }
    return units;
  } finally {
    globalThis.__b8End(__b8Timer);
  }
}

// src/simulation/combat-input.ts
var COMBAT_INPUT_VERSION = "m8-b8-combat-input-v1";
function readCombatStrategyInputs(state) {
  const { round: round2, preparation, items, temporaryEquipment, augments, anomalyBinding, persistentGrowth, augmentProgress } = state;
  return { round: round2, preparation, items, temporaryEquipment, augments, anomalyBinding, persistentGrowth, augmentProgress };
}
function freezeCombatInput(state, battleSeed, provenancePrefixLength) {
  return freezeContent(structuredClone({
    version: COMBAT_INPUT_VERSION,
    combatId: `round-${state.round}`,
    roundId: state.roundDefinitionId,
    contentDigest: state.contentDigest,
    battleSeed,
    playerLevel: state.level,
    nextUnitSerial: state.nextUnitSerial,
    nextItemSerial: state.nextItemSerial,
    equipmentRollPrefixLength: state.equipmentState.rolls.length,
    provenancePrefixLength,
    inputs: readCombatStrategyInputs(state)
  }));
}
var equal = (a, b) => canonicalContent(a) === canonicalContent(b);
function requireBasis(condition) {
  if (!condition) throw new RangeError("Invalid combat input basis");
}
var inputValidation = createInputValidation(requireBasis);
var integer2 = inputValidation.integer;
var record = inputValidation.record;
var sorted = (values) => [...values].sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
function restoreCombatInput(value, authority) {
  const __b8Timer = globalThis.__b8Start("restoreCombatInput");
  try {
    canonicalContent(value);
    record(value);
    const basis = value, input = basis.inputs;
    record(input);
    const round2 = ROUND_CATALOG.find((entry) => entry.ordinal === authority.round);
    requireBasis(round2 && round2.kind !== "supply" && basis.version === COMBAT_INPUT_VERSION && basis.combatId === `round-${authority.round}` && basis.roundId === round2.roundId && basis.contentDigest === authority.contentDigest && input.round === authority.round);
    validateSeed(authority.seed);
    validateSeed(basis.battleSeed);
    let battleSeed = (authority.seed ^ 2654435769) >>> 0;
    for (const entry of ROUND_CATALOG) {
      if (entry.ordinal > authority.round) break;
      if (entry.kind !== "supply") battleSeed = nextRandom(battleSeed).word;
    }
    requireBasis(basis.battleSeed === battleSeed);
    integer2(basis.provenancePrefixLength);
    integer2(basis.equipmentRollPrefixLength);
    requireBasis(basis.playerLevel === authority.playerLevel && basis.provenancePrefixLength === authority.provenancePrefixLength && basis.equipmentRollPrefixLength === authority.equipmentRollPrefixLength && basis.equipmentRollPrefixLength <= authority.equipmentRolls.length && basis.nextUnitSerial === authority.resources.nextUnitSerial && basis.nextItemSerial === authority.resources.nextItemSerial);
    const units = validateInputAssets(input, basis, readRoundEnemyProjection(authority.round).units, inputValidation);
    const players = input.preparation.units.filter((unit) => unit.team === "player");
    requireBasis(equal(sorted(players.map(({ id: id2, definitionId: definitionId2, starLevel }) => ({ id: id2, definitionId: definitionId2, starLevel }))), sorted(authority.resources.units.map(({ id: id2, definitionId: definitionId2, starLevel }) => ({ id: id2, definitionId: definitionId2, starLevel })))));
    requireBasis(equal(sorted(input.items.map(({ id: id2, definitionId: definitionId2 }) => ({ id: id2, definitionId: definitionId2 }))), sorted(authority.resources.items.map(({ id: id2, definitionId: definitionId2 }) => ({ id: id2, definitionId: definitionId2 })))));
    requireBasis(Array.isArray(input.augments) && input.augments.length <= 3);
    const receipts = authority.scheduleReceipts.filter((receipt) => receipt.round <= authority.round);
    const expectedAugments = receipts.filter((receipt) => receipt.kind === "augment").map((receipt) => ({ definitionId: receipt.definitionId, choiceId: receipt.eventId, acquiredRound: receipt.round }));
    requireBasis(equal(input.augments, expectedAugments) && new Set(input.augments.map((augment) => augment.definitionId)).size === input.augments.length);
    for (const augment of input.augments) requireBasis(Object.hasOwn(AUGMENT_DEFINITIONS, augment.definitionId));
    if (input.anomalyBinding !== null) {
      record(input.anomalyBinding);
      const binding = input.anomalyBinding;
      requireBasis(Object.hasOwn(ANOMALY_DEFINITIONS, binding.definitionId) && units.get(binding.unitId)?.team === "player" && receipts.some((receipt) => receipt.kind === "anomaly" && receipt.eventId === binding.choiceId && receipt.definitionId === binding.definitionId && receipt.round === binding.boundRound));
    }
    requireBasis(Array.isArray(input.persistentGrowth) && equal(input.persistentGrowth, authority.resources.persistentGrowth));
    const growthIds = /* @__PURE__ */ new Set();
    for (const growth of input.persistentGrowth) {
      record(growth);
      integer2(growth.attackDamageBps, 1);
      requireBasis(units.get(growth.unitId)?.definitionId === "tristana" && growth.attackDamageBps % 125 === 0 && !growthIds.has(growth.unitId));
      growthIds.add(growth.unitId);
    }
    const history = authority.roundResults.filter((result) => result.round < authority.round);
    const pump = input.augments.find((augment) => augment.definitionId === "pumping-up-i");
    const investment = input.augments.find((augment) => augment.definitionId === "investment-strategy-i");
    requireBasis(equal(input.augmentProgress, {
      pumpingRounds: pump ? history.filter((result) => result.round >= pump.acquiredRound).length : 0,
      investmentHp: investment ? history.filter((result) => result.round >= investment.acquiredRound).reduce((sum, result) => sum + result.incomeBreakdown.interest * 8, 0) : 0
    }));
    const rolls = authority.equipmentRolls.slice(0, basis.equipmentRollPrefixLength);
    const expectedChildren = sorted(input.items).filter((item) => item.location.kind === "unit" && grantsTemporaryEquipment(ITEM_DEFINITIONS[item.definitionId])).flatMap((item) => {
      requireBasis(item.location.kind === "unit");
      const roll = rolls.find((entry) => entry.parentItemInstanceId === item.id && entry.roundId === basis.roundId);
      requireBasis(roll && roll.playerLevelSnapshot <= basis.playerLevel);
      return projectTemporaryEquipment(roll, item.location.unitId);
    });
    requireBasis(equal(input.temporaryEquipment, expectedChildren));
    return freezeContent(structuredClone(basis));
  } finally {
    globalThis.__b8End(__b8Timer);
  }
}

// src/simulation/loot-identity.ts
function lootDropId(roundId, encounterId, sourceUnitId, slotOrdinal) {
  if (![roundId, encounterId, sourceUnitId].every((v) => typeof v === "string" && v.length > 0) || !Number.isSafeInteger(slotOrdinal) || slotOrdinal < 0) throw new RangeError("Invalid loot identity");
  return JSON.stringify([roundId, encounterId, sourceUnitId, slotOrdinal]);
}
var lootReceiptId = (dropId) => JSON.stringify([dropId, "grant"]);
var lootChoiceId = (dropId) => JSON.stringify(["m8b-loot-choice", dropId]);
function compareLootFreezeSlots(a, b) {
  return compareCodePoints(a.sourceUnitId, b.sourceUnitId) || a.slotOrdinal - b.slotOrdinal;
}
function compareLootChoices(a, b) {
  return compareCodePoints(a.dropId, b.dropId);
}

// src/simulation/unit-stats.ts
var STAR_PERCENT = Object.freeze({ 1: 100, 2: 180, 3: 324 });
function getUnitStats(definitionId2, starLevel) {
  const definition = UNIT_DEFINITIONS[definitionId2];
  if (!Object.hasOwn(UNIT_DEFINITIONS, definitionId2)) throw new RangeError(`Unknown unit definition: ${definitionId2}`);
  if (definition.unitKind === "neutral" && starLevel !== 1) throw new RangeError("Neutral units have fixed one star");
  return resolveUnitStats(definition, starLevel);
}
function resolveUnitStats(definition, starLevel) {
  validateNeutralInputs(definition);
  if (!Object.hasOwn(STAR_PERCENT, starLevel)) throw new RangeError(`Invalid star level: ${starLevel}`);
  return {
    ...definition.unitKind ? { unitKind: definition.unitKind, ...definition.monsterFamily ? { monsterFamily: definition.monsterFamily } : {} } : {},
    ...definition.baseCritChanceBps === void 0 ? {} : { baseCritChanceBps: definition.baseCritChanceBps, baseCritMultiplierBps: definition.baseCritMultiplierBps },
    health: Math.floor(definition.baseStats.health * STAR_PERCENT[starLevel] / 100),
    attack: Math.floor(definition.baseStats.attack * STAR_PERCENT[starLevel] / 100),
    armor: definition.baseStats.armor,
    magicResist: definition.baseStats.magicResist,
    attackRange: definition.attackRange,
    attackIntervalTicks: definition.attackIntervalTicks,
    ...definition.baseAttackSpeedBps === void 0 ? {} : { baseAttackSpeedBps: definition.baseAttackSpeedBps },
    initialMana: definition.initialMana,
    maxMana: definition.maxMana,
    abilityId: definition.abilityId
  };
}
function getUnitSellPrice(unit) {
  if (!Object.hasOwn(UNIT_DEFINITIONS, unit.definitionId)) throw new RangeError(`Unknown unit definition: ${unit.definitionId}`);
  if (!Object.hasOwn(STAR_PERCENT, unit.starLevel)) throw new RangeError(`Invalid star level: ${unit.starLevel}`);
  if (UNIT_DEFINITIONS[unit.definitionId].unitKind === "neutral") return 0;
  const cost = UNIT_DEFINITIONS[unit.definitionId].cost;
  return unit.starLevel === 1 ? cost : cost * 3 ** (unit.starLevel - 1) - (cost > 1 ? 1 : 0);
}

// src/simulation/resource-provenance.ts
var RESOURCE_PROVENANCE_VERSION = "m8-b8-resource-provenance-v1";
function requireValue(condition, message) {
  if (!condition) throw new RangeError(`Invalid resource provenance: ${message}`);
}
function integer3(value, minimum = 0) {
  requireValue(Number.isSafeInteger(value) && value >= minimum, "integer");
}
function nonempty(value) {
  requireValue(typeof value === "string" && value.length > 0, "identity");
}
function record2(value) {
  requireValue(value !== null && typeof value === "object" && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype, "plain object");
}
function keys(value, names) {
  record2(value);
  const actual = Object.keys(value);
  requireValue(actual.length === names.length && actual.every((key3) => names.includes(key3)), "fields");
}
function plainJson(value, ancestors = /* @__PURE__ */ new Set()) {
  if (value === null || typeof value === "string" || typeof value === "boolean") return;
  if (typeof value === "number") {
    requireValue(Number.isSafeInteger(value), "JSON integer");
    return;
  }
  requireValue(typeof value === "object" && value !== null && !ancestors.has(value), "plain JSON");
  ancestors.add(value);
  if (Array.isArray(value)) {
    requireValue(Object.keys(value).length === value.length, "dense JSON array");
    for (let i = 0; i < value.length; i++) {
      requireValue(Object.hasOwn(value, i), "dense JSON array");
      plainJson(value[i], ancestors);
    }
  } else {
    record2(value);
    requireValue(Reflect.ownKeys(value).length === Object.keys(value).length, "JSON keys");
    for (const descriptor of Object.values(Object.getOwnPropertyDescriptors(value))) {
      requireValue("value" in descriptor, "JSON data property");
      plainJson(descriptor.value, ancestors);
    }
  }
  ancestors.delete(value);
}
var compareIds2 = (a, b) => compareCodePoints(a.id, b.id);
var compareGrowth = (a, b) => compareCodePoints(a.unitId, b.unitId);
function appendResourceProvenance(provenance, roundId, facts) {
  requireValue(provenance.version === RESOURCE_PROVENANCE_VERSION, "version");
  const round2 = getCatalogRoundById(roundId);
  requireValue(!provenance.entries.length || getCatalogRoundById(provenance.entries.at(-1).roundId).ordinal <= round2.ordinal, "round order");
  const added = Array.isArray(facts) ? facts : [facts];
  plainJson(added);
  return freezeContent({
    version: RESOURCE_PROVENANCE_VERSION,
    entries: [...structuredClone(provenance.entries), ...added.map((fact, index) => ({
      ...structuredClone(fact),
      sequence: provenance.entries.length + index,
      roundId
    }))]
  });
}
function mergeGrowthLedger(ledger, events) {
  const values = /* @__PURE__ */ new Map();
  for (const entry of ledger) {
    nonempty(entry.unitId);
    requireValue(Number.isSafeInteger(entry.attackDamageBps) && entry.attackDamageBps >= 0 && !values.has(entry.unitId), "growth ledger");
    values.set(entry.unitId, entry.attackDamageBps);
  }
  for (const event of events) {
    const ids2 = [event.survivorId, ...event.consumedIds];
    requireValue(event.consumedIds.length === 2 && new Set(ids2).size === 3, "upgrade identity");
    ids2.forEach(nonempty);
    let total = 0;
    for (const id2 of ids2) {
      total += values.get(id2) ?? 0;
      requireValue(Number.isSafeInteger(total), "growth overflow");
      values.delete(id2);
    }
    if (total) values.set(event.survivorId, total);
  }
  return [...values].filter(([, value]) => value !== 0).map(([unitId, attackDamageBps]) => ({ unitId, attackDamageBps })).sort(compareGrowth);
}
function validateResourceReceipts(context) {
  const __b8Timer = globalThis.__b8Start("validateResourceReceipts");
  try {
    const births = /* @__PURE__ */ new Map(), receiptIds = /* @__PURE__ */ new Set(), assetIds = /* @__PURE__ */ new Set();
    const add3 = (key3, birth) => {
      requireValue(!births.has(key3) && !assetIds.has(birth.id), "duplicate receipt birth");
      births.set(key3, birth);
      assetIds.add(birth.id);
    };
    for (const receipt of context.scheduleReceipts) {
      plainJson(receipt);
      keys(receipt, ["eventId", "round", "kind", "itemIds", "gold", "unitId", "definitionId"]);
      requireValue(!receiptIds.has(`schedule:${receipt.eventId}`), "duplicate schedule receipt");
      receiptIds.add(`schedule:${receipt.eventId}`);
      const round2 = getCatalogRoundByOrdinal(receipt.round);
      requireValue(round2.ordinal <= context.throughRoundOrdinal && getRoundSchedule(round2.ordinal).some((event) => event.id === receipt.eventId && event.kind === receipt.kind), "schedule identity");
      requireValue(Array.isArray(receipt.itemIds), "schedule items");
      if (receipt.kind === "component") {
        requireValue(receipt.itemIds.length === 1 && receipt.unitId === null && receipt.gold === 0 && typeof receipt.definitionId === "string" && ITEM_DEFINITIONS[receipt.definitionId]?.kind === "component", "schedule component");
        nonempty(receipt.itemIds[0]);
        add3(`schedule:${receipt.eventId}`, { kind: "item", id: receipt.itemIds[0], definitionId: receipt.definitionId, roundId: round2.roundId });
      } else requireValue(receipt.itemIds.length === 0 && receipt.kind !== "reward", "unsupported schedule birth");
    }
    for (const receipt of context.lootReceipts) {
      plainJson(receipt);
      keys(receipt, ["receiptId", "dropId", "payload", "grantedItemIds", "grantedUnitIds"]);
      nonempty(receipt.dropId);
      const tuple = JSON.parse(receipt.dropId);
      requireValue(Array.isArray(tuple) && tuple.length === 4, "loot drop identity");
      const [roundId, encounterId, sourceUnitId, slotOrdinal] = tuple;
      nonempty(roundId);
      nonempty(encounterId);
      nonempty(sourceUnitId);
      integer3(slotOrdinal);
      const round2 = getCatalogRoundById(roundId);
      requireValue(round2.ordinal <= context.throughRoundOrdinal && round2.encounterId === encounterId && receipt.dropId === lootDropId(roundId, encounterId, sourceUnitId, slotOrdinal) && receipt.receiptId === lootReceiptId(receipt.dropId), "loot receipt identity");
      requireValue(!receiptIds.has(`loot:${receipt.receiptId}`), "duplicate loot receipt");
      receiptIds.add(`loot:${receipt.receiptId}`);
      requireValue(Array.isArray(receipt.grantedItemIds) && Array.isArray(receipt.grantedUnitIds), "loot granted IDs");
      record2(receipt.payload);
      if (receipt.payload.kind === "gold") {
        keys(receipt.payload, ["kind", "quantity"]);
        integer3(receipt.payload.quantity, 1);
        requireValue(!receipt.grantedItemIds.length && !receipt.grantedUnitIds.length, "gold birth");
        continue;
      }
      keys(receipt.payload, ["kind", "definitionId", "quantity"]);
      const { kind, definitionId: definitionId2, quantity } = receipt.payload;
      nonempty(definitionId2);
      requireValue((kind === "unit" || kind === "item") && quantity === 1, "loot resource quantity");
      requireValue(kind === "unit" ? SHOP_CATALOG.includes(definitionId2) : ITEM_DEFINITIONS[definitionId2]?.kind === "component", "loot resource definition");
      const granted = kind === "unit" ? receipt.grantedUnitIds : receipt.grantedItemIds;
      requireValue(granted.length === 1 && (kind === "unit" ? receipt.grantedItemIds : receipt.grantedUnitIds).length === 0, "loot resource identity");
      nonempty(granted[0]);
      add3(`loot:${receipt.receiptId}`, { kind, id: granted[0], definitionId: definitionId2, roundId });
    }
    return births;
  } finally {
    globalThis.__b8End(__b8Timer);
  }
}
function validateUpgrade(event) {
  keys(event, ["type", "survivorId", "consumedIds", "definitionId", "fromStar", "toStar", "location"]);
  nonempty(event.definitionId);
  requireValue(event.type === "unitUpgraded" && (event.fromStar === 1 || event.fromStar === 2) && event.toStar === event.fromStar + 1, "upgrade stars");
  requireValue(Array.isArray(event.consumedIds) && event.consumedIds.length === 2 && (/* @__PURE__ */ new Set([event.survivorId, ...event.consumedIds])).size === 3 && compareCodePoints(event.consumedIds[0], event.consumedIds[1]) < 0, "upgrade participants");
  [event.survivorId, ...event.consumedIds].forEach(nonempty);
  record2(event.location);
  if (event.location.kind === "board") {
    keys(event.location, ["kind", "cell"]);
    keys(event.location.cell, ["col", "row"]);
    requireValue(isDeploymentCell(DEFAULT_BOARD, "player", event.location.cell), "upgrade location");
  } else {
    keys(event.location, ["kind", "slot"]);
    integer3(event.location.slot);
    requireValue(event.location.kind === "bench" && event.location.slot < 9, "upgrade location");
  }
}
function foldResourceProvenance(value, context) {
  const __b8Timer = globalThis.__b8Start("foldResourceProvenance");
  try {
    getCatalogRoundByOrdinal(context.throughRoundOrdinal);
    plainJson(value);
    keys(value, ["version", "entries"]);
    requireValue(value.version === RESOURCE_PROVENANCE_VERSION && Array.isArray(value.entries) && value.entries.length > 0, "version/opening");
    const entries = value.entries;
    const prefixLength = context.prefixLength ?? entries.length;
    integer3(prefixLength);
    requireValue(prefixLength <= entries.length, "prefix bounds");
    const births = validateResourceReceipts(context), usedBirths = /* @__PURE__ */ new Set();
    const units = /* @__PURE__ */ new Map(), items = /* @__PURE__ */ new Map();
    let growth = [], nextUnitSerial = 1, nextItemSerial = 1, lastOrdinal = 1;
    let acquisition = null;
    let lastShopGeneration = 0;
    const shopSlots = /* @__PURE__ */ new Set(), commits = /* @__PURE__ */ new Map();
    const firstLootBirth = /* @__PURE__ */ new Map();
    const starts = new Set(entries.filter((entry) => entry?.kind === "combat-growth-committed").map((entry) => entry.combatStartProvenancePrefixLength));
    const unitPrefixes = /* @__PURE__ */ new Map();
    const projection = () => ({
      units: [...units.values()].map((unit) => ({ ...unit })).sort(compareIds2),
      items: [...items.values()].map((item) => ({ ...item })).sort(compareIds2),
      persistentGrowth: growth.map((entry) => ({ ...entry })),
      nextUnitSerial,
      nextItemSerial
    });
    let result = projection();
    const finishAcquisition = () => {
      if (!acquisition) return;
      for (const star of [1, 2]) requireValue([...units.values()].filter((unit) => unit.definitionId === acquisition.definitionId && unit.starLevel === star).length < 3, "missing upgrade");
      acquisition = null;
    };
    const takeBirth = (key3, kind, id2, roundId) => {
      const birth = births.get(key3);
      requireValue(birth && birth.kind === kind && birth.id === id2 && birth.roundId === roundId && !usedBirths.has(key3), "receipt birth binding");
      usedBirths.add(key3);
      return birth.definitionId;
    };
    for (const [index, entry] of entries.entries()) {
      record2(entry);
      integer3(entry.sequence);
      requireValue(entry.sequence === index, "sequence");
      const round2 = getCatalogRoundById(entry.roundId);
      requireValue(round2.ordinal >= lastOrdinal && round2.ordinal <= context.throughRoundOrdinal, "round order/boundary");
      lastOrdinal = round2.ordinal;
      if (starts.has(index)) unitPrefixes.set(index, new Map(units));
      if (entry.kind !== "unit-upgraded") finishAcquisition();
      const common = ["kind", "sequence", "roundId"];
      if ((entry.kind === "unit-acquired" || entry.kind === "item-acquired") && entry.source?.kind === "loot" && !firstLootBirth.has(entry.roundId)) firstLootBirth.set(entry.roundId, index);
      if (entry.kind === "unit-acquired") {
        keys(entry, [...common, "unitId", "source"]);
        record2(entry.source);
        requireValue(round2.kind !== "supply", "unit birth in supply");
        requireValue(entry.unitId === `unit-${nextUnitSerial}`, "unit serial");
        integer3(nextUnitSerial + 1, 1);
        let definitionId2;
        if (entry.source.kind === "opening") {
          keys(entry.source, ["kind"]);
          requireValue(index === 0 && entry.unitId === OPENING_INITIAL_STATE.unit.id && round2.ordinal === 1, "opening");
          definitionId2 = OPENING_INITIAL_STATE.unit.definitionId;
        } else if (entry.source.kind === "shop") {
          keys(entry.source, ["kind", "generation", "slotIndex", "definitionId"]);
          requireValue(!commits.has(entry.roundId), "shop after settlement");
          integer3(entry.source.generation, 1);
          integer3(entry.source.slotIndex);
          requireValue(entry.source.slotIndex < MATCH_RULES.shopSize && entry.source.generation >= lastShopGeneration && SHOP_CATALOG.includes(entry.source.definitionId), "shop source");
          const key3 = `${entry.source.generation}:${entry.source.slotIndex}`;
          requireValue(!shopSlots.has(key3), "duplicate shop purchase");
          shopSlots.add(key3);
          lastShopGeneration = entry.source.generation;
          definitionId2 = entry.source.definitionId;
        } else {
          keys(entry.source, ["kind", "receiptId"]);
          requireValue(entry.source.kind === "loot", "unit source");
          nonempty(entry.source.receiptId);
          definitionId2 = takeBirth(`loot:${entry.source.receiptId}`, "unit", entry.unitId, entry.roundId);
        }
        requireValue(index !== 0 || entry.source.kind === "opening", "missing opening");
        units.set(entry.unitId, { id: entry.unitId, definitionId: definitionId2, starLevel: 1 });
        nextUnitSerial++;
        acquisition = { sequence: index, unitId: entry.unitId, definitionId: definitionId2, roundId: entry.roundId, survivorId: entry.unitId, star: 1 };
      } else if (entry.kind === "unit-upgraded") {
        keys(entry, [...common, "acquisitionSequence", "event"]);
        integer3(entry.acquisitionSequence);
        validateUpgrade(entry.event);
        const event = entry.event;
        requireValue(acquisition && acquisition.sequence === entry.acquisitionSequence && acquisition.sequence > 0 && acquisition.roundId === entry.roundId && acquisition.definitionId === event.definitionId && acquisition.star === event.fromStar && [event.survivorId, ...event.consumedIds].includes(acquisition.survivorId), "upgrade transaction");
        for (const id2 of [event.survivorId, ...event.consumedIds]) {
          const unit = units.get(id2);
          requireValue(unit && unit.definitionId === event.definitionId && unit.starLevel === event.fromStar, "upgrade ownership");
        }
        event.consumedIds.forEach((id2) => units.delete(id2));
        units.set(event.survivorId, { id: event.survivorId, definitionId: event.definitionId, starLevel: event.toStar });
        growth = mergeGrowthLedger(growth, [event]);
        acquisition.survivorId = event.survivorId;
        acquisition.star = event.toStar;
      } else if (entry.kind === "unit-sold") {
        keys(entry, [...common, "unitId", "context", "goldGranted"]);
        integer3(entry.goldGranted);
        const unit = units.get(entry.unitId);
        requireValue(unit && round2.kind !== "supply" && (entry.context === "preparation" || entry.context === "settlement-capacity"), "sale ownership/context");
        requireValue(entry.context !== "preparation" || !commits.has(entry.roundId), "preparation sale after settlement");
        requireValue(entry.context !== "settlement-capacity" || commits.has(entry.roundId), "sale before settlement");
        requireValue(entry.goldGranted === getUnitSellPrice({ ...unit, team: "player", location: { kind: "bench", slot: 0 } }), "sale price");
        units.delete(entry.unitId);
        growth = growth.filter((value2) => value2.unitId !== entry.unitId);
      } else if (entry.kind === "item-acquired") {
        keys(entry, [...common, "itemId", "source"]);
        record2(entry.source);
        requireValue(entry.itemId === `item-${nextItemSerial}`, "item serial");
        integer3(nextItemSerial + 1, 1);
        const source = entry.source;
        requireValue(source.kind === "schedule" || source.kind === "loot", "item source");
        keys(source, source.kind === "schedule" ? ["kind", "eventId"] : ["kind", "receiptId"]);
        nonempty(source.kind === "schedule" ? source.eventId : source.receiptId);
        const key3 = source.kind === "schedule" ? `schedule:${source.eventId}` : `loot:${source.receiptId}`;
        const definitionId2 = takeBirth(key3, "item", entry.itemId, entry.roundId);
        items.set(entry.itemId, { id: entry.itemId, definitionId: definitionId2 });
        nextItemSerial++;
      } else if (entry.kind === "item-combined") {
        keys(entry, [...common, "event"]);
        keys(entry.event, ["type", "consumedIds", "itemId", "definitionId"]);
        requireValue(round2.kind !== "supply" && !commits.has(entry.roundId), "combination phase");
        const event = entry.event;
        nonempty(event.definitionId);
        requireValue(event.type === "itemCombined" && Array.isArray(event.consumedIds) && event.consumedIds.length === 2 && compareCodePoints(event.consumedIds[0], event.consumedIds[1]) < 0, "combination inputs");
        const [a, b] = event.consumedIds.map((id2) => items.get(id2));
        const recipe = ITEM_DEFINITIONS[event.definitionId];
        requireValue(a && b && ITEM_DEFINITIONS[a.definitionId]?.kind === "component" && ITEM_DEFINITIONS[b.definitionId]?.kind === "component" && recipe?.kind === "completed" && recipe.recipe && (recipe.recipe[0] === a.definitionId && recipe.recipe[1] === b.definitionId || recipe.recipe[0] === b.definitionId && recipe.recipe[1] === a.definitionId), "combination recipe/ownership");
        requireValue(event.itemId === `item-${nextItemSerial}`, "combined item serial");
        integer3(nextItemSerial + 1, 1);
        event.consumedIds.forEach((id2) => items.delete(id2));
        items.set(event.itemId, { id: event.itemId, definitionId: event.definitionId });
        nextItemSerial++;
      } else if (entry.kind === "combat-growth-committed") {
        keys(entry, [...common, "combatId", "settlementId", "combatStartProvenancePrefixLength", "sourceDeltas"]);
        requireValue(round2.kind !== "supply" && entry.combatId === `round-${round2.ordinal}` && entry.settlementId === `round-${round2.ordinal}-settled` && !commits.has(entry.roundId), "combat settlement identity/uniqueness");
        integer3(entry.combatStartProvenancePrefixLength, 1);
        const start = entry.combatStartProvenancePrefixLength;
        requireValue(start <= index && Array.isArray(entry.sourceDeltas), "combat start prefix");
        requireValue(start <= (firstLootBirth.get(entry.roundId) ?? index), "loot before combat start");
        const suffix = entries.slice(start, index);
        requireValue(suffix.every((fact) => fact.roundId === entry.roundId && (fact.kind === "unit-upgraded" || (fact.kind === "unit-acquired" || fact.kind === "item-acquired") && fact.source.kind === "loot")), "combat resource suffix");
        requireValue(start === entries.length || entries[start]?.kind !== "unit-upgraded", "combat start transaction boundary");
        const originalUnits = unitPrefixes.get(start);
        let previousId = "";
        for (const delta of entry.sourceDeltas) {
          keys(delta, ["sourceUnitId", "attackDamageBps"]);
          nonempty(delta.sourceUnitId);
          integer3(delta.attackDamageBps, 1);
          requireValue(compareCodePoints(previousId, delta.sourceUnitId) < 0 && delta.attackDamageBps % 125 === 0 && originalUnits.get(delta.sourceUnitId)?.definitionId === "tristana", "combat growth source/step");
          previousId = delta.sourceUnitId;
        }
        const pending = mergeGrowthLedger(
          entry.sourceDeltas.map((delta) => ({ unitId: delta.sourceUnitId, attackDamageBps: delta.attackDamageBps })),
          suffix.filter((fact) => fact.kind === "unit-upgraded").map((fact) => fact.event)
        );
        const next = new Map(growth.map((value2) => [value2.unitId, value2.attackDamageBps]));
        for (const delta of pending) {
          requireValue(units.get(delta.unitId)?.definitionId === "tristana", "migrated growth owner");
          const total = (next.get(delta.unitId) ?? 0) + delta.attackDamageBps;
          integer3(total, 1);
          next.set(delta.unitId, total);
        }
        growth = [...next].map(([unitId, attackDamageBps]) => ({ unitId, attackDamageBps })).sort(compareGrowth);
        commits.set(entry.roundId, { roundId: entry.roundId, combatId: entry.combatId, settlementId: entry.settlementId });
      } else requireValue(false, "fact kind");
      requireValue(index !== 0 || entry.kind === "unit-acquired" && entry.source.kind === "opening", "missing opening");
      if (index + 1 === prefixLength) result = projection();
    }
    finishAcquisition();
    requireValue(usedBirths.size === births.size, "missing receipt birth");
    {
      requireValue(Array.isArray(context.combatSettlements) && context.combatSettlements.length === commits.size, "missing combat growth commit");
      const seen = /* @__PURE__ */ new Set();
      for (const expected of context.combatSettlements) {
        const commit = commits.get(expected.roundId);
        requireValue(!seen.has(expected.roundId) && commit && commit.combatId === expected.combatId && commit.settlementId === expected.settlementId, "combat growth receipt binding");
        seen.add(expected.roundId);
      }
    }
    return freezeContent(result);
  } finally {
    globalThis.__b8End(__b8Timer);
  }
}

// src/simulation/item-grants.ts
function planPermanentItemGrant(state, request, committedReceiptIds) {
  const fail3 = (reason) => ({ ok: false, state, reason });
  if (typeof request.receiptId !== "string" || !request.receiptId) return fail3("invalid-grant");
  if (committedReceiptIds.includes(request.receiptId)) return fail3("duplicate-grant");
  if (typeof request.definitionId !== "string" || !Object.hasOwn(ITEM_DEFINITIONS, request.definitionId)) return fail3("unknown-item-definition");
  const serial = state.nextItemSerial;
  if (!Number.isSafeInteger(serial) || serial < 1 || serial === Number.MAX_SAFE_INTEGER || state.items.some((item) => item.id === `item-${serial}`)) return fail3("invalid-item-serial");
  const itemId = `item-${serial}`;
  return { ok: true, state: {
    ...state,
    nextItemSerial: serial + 1,
    items: [...state.items, { id: itemId, definitionId: request.definitionId, location: { kind: "inventory" } }]
  }, grantedItemIds: [itemId] };
}

// src/simulation/loot-choice.ts
function orderedUnresolvedLootChoices(descriptors, eligibility, resolutions) {
  return descriptors.filter((d) => eligibility.some((e) => e.dropId === d.dropId && e.status === "revealed") && !resolutions.some((r) => r.dropId === d.dropId)).sort(compareLootChoices);
}
function makeLootPendingChoice(descriptor) {
  validateComponentCandidates(COMPONENT_POOL.map((p) => p.definitionId), descriptor.poolVersion);
  const choiceId = lootChoiceId(descriptor.dropId);
  return freezeContent({
    kind: "component",
    step: "offer",
    choiceId,
    eventId: choiceId,
    generation: 0,
    returnPhase: "settlement",
    offers: COMPONENT_POOL.map((p) => p.definitionId),
    targetId: null,
    rerollCount: 0
  });
}

// src/simulation/loot-freeze.ts
var LOOT_FREEZE_VERSION = "m8-b8-loot-freeze-v1";
var LOOT_REPLAY_DIGEST = digestContent({
  version: LOOT_FREEZE_VERSION,
  algorithm: LOOT_FREEZE_ALGORITHM,
  policy: NEUTRAL_ENCOUNTER_POLICY_VERSION,
  openingPolicy: "m8b-opening-project-v1",
  lootPolicy: LOOT_POLICY_VERSION,
  componentPool: { version: COMPONENT_POOL_VERSION, entries: COMPONENT_POOL },
  heroPools: { version: LOOT_HERO_POOL_VERSION, entries: LOOT_HERO_POOLS },
  slots: LOOT_SLOTS,
  categories: LOOT_CATEGORIES,
  schedule: ROUND_CATALOG,
  encounters: { version: NEUTRAL_ENCOUNTER_CATALOG_VERSION, entries: NEUTRAL_ENCOUNTERS }
});
function drawLootIndex(rng, n) {
  validateSeed(rng.state);
  if (!Number.isSafeInteger(rng.draws) || rng.draws < 0 || !Number.isSafeInteger(n) || n < 1 || n > 4294967296) throw new RangeError("Invalid loot draw");
  const limit = Math.floor(4294967296 / n) * n;
  let state = rng.state, draws = rng.draws;
  for (; ; ) {
    if (!Number.isSafeInteger(draws + 1)) throw new RangeError("Loot draw counter overflow");
    const next = nextRandom(state);
    state = next.state;
    draws++;
    if (next.word < limit) return { index: next.word % n, rng: { state, draws } };
  }
}
function validateOrdinal(ordinal) {
  if (!Number.isSafeInteger(ordinal) || ordinal < 0 || ordinal > ROUND_CATALOG.length) throw new RangeError("Invalid loot preparation boundary");
}
function validateLootContent() {
  validateComponentPool();
  for (const cost of [1, 2, 3, 4]) {
    const pool = LOOT_HERO_POOLS[cost], categories = LOOT_CATEGORIES[cost];
    if (new Set(pool.map((p) => p[0])).size !== pool.length || new Set(pool.map((p) => p[1])).size !== pool.length || pool.some(([api, id2], i) => !api || M5_UNIT_DEFINITIONS[id2]?.cost !== cost || i > 0 && compareCodePoints(pool[i - 1][0], api) >= 0) || categories.reduce((sum, c) => sum + c.weight, 0) !== 100 || categories.some((c, i) => !Number.isSafeInteger(c.weight) || c.weight <= 0 || i > 0 && compareCodePoints(categories[i - 1].id, c.id) >= 0)) throw new RangeError("Invalid loot pool/categories");
  }
  if (Object.keys(LOOT_SLOTS).length !== NEUTRAL_ENCOUNTERS.length) throw new RangeError("Invalid loot round set");
  for (const encounter of NEUTRAL_ENCOUNTERS) {
    const round2 = ROUND_CATALOG.find((r) => r.roundId === encounter.roundId);
    const slots = LOOT_SLOTS[encounter.roundId];
    if (!round2 || round2.kind !== "pve" || round2.encounterId !== encounter.encounterId || !slots || new Set(slots.map((s) => JSON.stringify([s.sourceSlotId, s.slotOrdinal]))).size !== slots.length || slots.some((s) => !Number.isSafeInteger(s.slotOrdinal) || s.slotOrdinal < 0 || !encounter.slots.some((u) => u.slotId === s.sourceSlotId))) throw new RangeError("Invalid loot source slots");
  }
}
validateLootContent();
function freezeLootThroughRound(seed, throughRoundOrdinal) {
  validateSeed(seed);
  validateOrdinal(throughRoundOrdinal);
  let rng = { state: (seed ^ LOOT_FREEZE_ALGORITHM.seedXor) >>> 0, draws: 0 };
  const rounds = [];
  const draw = (n) => {
    const result = drawLootIndex(rng, n);
    rng = result.rng;
    return result.index;
  };
  const component = () => COMPONENT_POOL[draw(COMPONENT_POOL.length)].definitionId;
  for (const round2 of ROUND_CATALOG) {
    if (round2.ordinal > throughRoundOrdinal) break;
    if (round2.kind !== "pve") continue;
    const encounter = NEUTRAL_ENCOUNTERS.find((e) => e.roundId === round2.roundId);
    const entries = LOOT_SLOTS[round2.roundId].map((s) => ({ ...s, sourceUnitId: JSON.stringify(["pve", round2.roundId, encounter.encounterId, s.sourceSlotId]) })).sort(compareLootFreezeSlots);
    const drops = [], choices = [];
    for (const entry of entries) {
      const identity = {
        roundId: round2.roundId,
        encounterId: encounter.encounterId,
        sourceUnitId: entry.sourceUnitId,
        slotOrdinal: entry.slotOrdinal,
        dropId: lootDropId(round2.roundId, encounter.encounterId, entry.sourceUnitId, entry.slotOrdinal)
      };
      const content = entry.content;
      if (content.kind === "component-choice") {
        choices.push({
          ...identity,
          kind: "component-choice",
          quantity: 1,
          poolVersion: COMPONENT_POOL_VERSION,
          terminalFallbackDefinitionId: component(),
          revealCondition: "source-killed"
        });
        continue;
      }
      let payload;
      if (content.kind === "fixed") payload = { ...content.payload };
      else if (content.kind === "random-component") payload = { kind: "item", definitionId: component(), quantity: 1 };
      else {
        const categories = LOOT_CATEGORIES[content.cost];
        let index = draw(100);
        const category = categories.find((c) => {
          if (index < c.weight) return true;
          index -= c.weight;
          return false;
        });
        if (category.payload.kind === "gold") payload = { ...category.payload };
        else {
          const pool = LOOT_HERO_POOLS[category.payload.cost];
          payload = { kind: "unit", definitionId: pool[draw(pool.length)][1], quantity: 1 };
        }
      }
      drops.push({ ...identity, payload, status: "planned", revealCondition: "source-killed", receiptId: null });
    }
    rounds.push({ encounterPlan: { roundId: round2.roundId, encounterId: encounter.encounterId, policyVersion: NEUTRAL_ENCOUNTER_POLICY_VERSION, drops }, choices });
  }
  return freezeContent({ version: LOOT_FREEZE_VERSION, seed, replayDigest: LOOT_REPLAY_DIGEST, throughRoundOrdinal, rng, rounds });
}
function restoreFrozenLootLedger(value, expected) {
  const __b8Timer = globalThis.__b8Start("restoreFrozenLootLedger");
  try {
    const replay = freezeLootThroughRound(expected.seed, expected.throughRoundOrdinal);
    if (canonicalContent(value) !== canonicalContent(replay)) throw new RangeError("Invalid frozen loot ledger");
    return replay;
  } finally {
    globalThis.__b8End(__b8Timer);
  }
}
function advanceFrozenLootLedger(ledger, throughRoundOrdinal) {
  restoreFrozenLootLedger(ledger, { seed: ledger.seed, throughRoundOrdinal: ledger.throughRoundOrdinal });
  validateOrdinal(throughRoundOrdinal);
  if (throughRoundOrdinal < ledger.throughRoundOrdinal) throw new RangeError("Cannot rewind loot preparation");
  if (throughRoundOrdinal === ledger.throughRoundOrdinal) return ledger;
  const replay = freezeLootThroughRound(ledger.seed, throughRoundOrdinal);
  return freezeContent({ ...replay, rounds: [...ledger.rounds, ...replay.rounds.slice(ledger.rounds.length)] });
}

// src/simulation/upgrades.ts
var compareIds3 = (a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
var copyLocation = (location) => location.kind === "board" ? { kind: "board", cell: { ...location.cell } } : { ...location };
function compareRetention(a, b) {
  const rank = (unit) => unit.location?.kind === "board" ? 0 : unit.location?.kind === "bench" ? 1 : 2;
  const rankDifference = rank(a) - rank(b);
  if (rankDifference) return rankDifference;
  if (a.location?.kind === "board" && b.location?.kind === "board") {
    return a.location.cell.row - b.location.cell.row || a.location.cell.col - b.location.cell.col || compareIds3(a, b);
  }
  if (a.location?.kind === "bench" && b.location?.kind === "bench") return a.location.slot - b.location.slot || compareIds3(a, b);
  return compareIds3(a, b);
}
function validateRoster(preparation) {
  const ids2 = /* @__PURE__ */ new Set(), positions = /* @__PURE__ */ new Set();
  for (const unit of preparation.units) {
    const location = unit.location;
    const position = location.kind === "board" ? `board:${location.cell.row}:${location.cell.col}` : `bench:${location.slot}`;
    const validLocation = location.kind === "board" ? contains(preparation.board, location.cell) && isDeploymentCell(preparation.board, unit.team, location.cell) : Number.isInteger(location.slot) && location.slot >= 0 && location.slot < preparation.benchSize;
    if (ids2.has(unit.id) || positions.has(position) || !validLocation) throw new Error("Invalid preparation roster");
    ids2.add(unit.id);
    positions.add(position);
  }
}
function planPurchase(preparation, definitionId2, candidateId) {
  if (!Object.hasOwn(UNIT_DEFINITIONS, definitionId2) || UNIT_DEFINITIONS[definitionId2].unitKind === "neutral") throw new RangeError(`Unknown unit definition: ${definitionId2}`);
  validateRoster(preparation);
  if (preparation.units.some((unit) => unit.id === candidateId)) throw new Error(`Duplicate unit ID: ${candidateId}`);
  let units = [...preparation.units, { id: candidateId, definitionId: definitionId2, team: "player", starLevel: 1, location: null }];
  const events = [];
  for (const fromStar of [1, 2]) {
    while (true) {
      const group = units.filter((unit) => unit.team === "player" && unit.definitionId === definitionId2 && unit.starLevel === fromStar).sort(compareRetention);
      if (group.length < 3) break;
      const [survivor, ...consumed] = group.slice(0, 3);
      if (survivor.location === null) throw new Error("Upgrade survivor has no location");
      const toStar = fromStar + 1;
      const consumedIds = consumed.map((unit) => unit.id).sort();
      const consumedSet = new Set(consumedIds);
      units = units.filter((unit) => !consumedSet.has(unit.id)).map((unit) => unit.id === survivor.id ? { ...unit, starLevel: toStar } : unit);
      events.push({
        type: "unitUpgraded",
        survivorId: survivor.id,
        consumedIds,
        definitionId: definitionId2,
        fromStar,
        toStar,
        location: copyLocation(survivor.location)
      });
    }
  }
  const pending = units.find((unit) => unit.location === null);
  if (pending) {
    const occupied = new Set(units.flatMap((unit) => unit.location?.kind === "bench" ? [unit.location.slot] : []));
    let slot3 = 0;
    while (slot3 < preparation.benchSize && occupied.has(slot3)) slot3++;
    if (slot3 === preparation.benchSize) return { ok: false, reason: "bench-full" };
    units = units.map((unit) => unit.id === pending.id ? { ...unit, location: { kind: "bench", slot: slot3 } } : unit);
  }
  const next = { ...preparation, units: units.map((unit) => {
    if (unit.location === null) throw new Error("Unplaced purchase candidate");
    return { ...unit, location: copyLocation(unit.location) };
  }).sort(compareIds3) };
  validateRoster(next);
  return { ok: true, preparation: next, events };
}
function transferUpgradeResources(items, binding, upgradeEvents) {
  let nextItems = [...items], anomalyBinding = binding;
  const events = [];
  for (const upgrade of upgradeEvents) {
    for (const consumedId of [...upgrade.consumedIds].sort()) {
      const consumedItems = nextItems.filter((item) => item.location.kind === "unit" && item.location.unitId === consumedId).sort((a, b) => {
        if (a.location.kind !== "unit" || b.location.kind !== "unit") throw new Error("Expected equipped item");
        return a.location.slot - b.location.slot || compareIds3(a, b);
      });
      const returnedIds = [];
      for (const item of consumedItems) {
        let slot3 = 0;
        while (slot3 < 3 && !checkEquipmentPlacement(nextItems, item, upgrade.survivorId, slot3).allowed) slot3++;
        const location = slot3 < 3 ? { kind: "unit", unitId: upgrade.survivorId, slot: slot3 } : { kind: "inventory" };
        nextItems = nextItems.map((candidate) => candidate.id === item.id ? { ...candidate, location } : candidate);
        if (slot3 < 3) {
          events.push({ type: "itemEquipped", itemId: item.id, unitId: upgrade.survivorId, slot: slot3 });
        } else returnedIds.push(item.id);
      }
      if (returnedIds.length) events.push({ type: "itemsReturned", itemIds: returnedIds.sort(), unitId: consumedId });
    }
    if (anomalyBinding && upgrade.consumedIds.includes(anomalyBinding.unitId)) {
      events.push({ type: "anomalyTransferred", fromId: anomalyBinding.unitId, toId: upgrade.survivorId });
      anomalyBinding = { ...anomalyBinding, unitId: upgrade.survivorId };
    }
  }
  return { items: nextItems.sort(compareIds3), anomalyBinding, events };
}

// src/simulation/unit-acquisition.ts
function planUnitAcquisition(input, definitionId2, source, acquisitionSequence) {
  const serial = input.nextUnitSerial;
  if (!Number.isSafeInteger(serial) || serial < 1 || !Number.isSafeInteger(serial + 1)) throw new RangeError("Invalid unit serial");
  const unitId = `unit-${serial}`, purchase = planPurchase(input.preparation, definitionId2, unitId);
  if (!purchase.ok) return purchase;
  const resources = transferUpgradeResources(input.items, input.anomalyBinding, purchase.events);
  return {
    ok: true,
    unitId,
    nextUnitSerial: serial + 1,
    preparation: purchase.preparation,
    items: resources.items,
    anomalyBinding: resources.anomalyBinding,
    upgradeEvents: purchase.events,
    events: [...purchase.events, ...resources.events],
    facts: [
      { kind: "unit-acquired", unitId, source },
      ...purchase.events.map((event) => ({ kind: "unit-upgraded", acquisitionSequence, event }))
    ]
  };
}

// src/simulation/loot-runtime.ts
var counterKey = (roundId) => JSON.stringify(["m8b-loot-project-v1", roundId, "components-granted"]);
var currentPlan = (state) => state.m8.loot.frozen.rounds.find((value) => value.encounterPlan.roundId === state.roundDefinitionId);
var withLoot = (state, loot) => ({ ...state, m8: { ...state.m8, loot } });
function prepareMatchLoot(seed, round2, previous) {
  if (previous && previous.frozen.seed !== seed) throw new RangeError("Loot seed mismatch");
  const frozen = previous ? advanceFrozenLootLedger(previous.frozen, round2) : freezeLootThroughRound(seed, round2);
  if (frozen === previous?.frozen) return previous;
  const added = frozen.rounds.slice(previous?.frozen.rounds.length ?? 0);
  return {
    frozen,
    direct: [...previous?.direct ?? [], ...added.flatMap((value) => value.encounterPlan.drops.map((drop) => ({ dropId: drop.dropId, status: "planned", receiptId: null })))],
    choiceEligibility: [...previous?.choiceEligibility ?? [], ...added.flatMap((value) => value.choices.map((choice) => ({ dropId: choice.dropId, status: "planned" })))],
    choiceResolutions: previous?.choiceResolutions ?? [],
    earnedEvidence: previous?.earnedEvidence ?? [],
    receipts: previous?.receipts ?? [],
    guaranteeCounters: previous?.guaranteeCounters ?? Object.fromEntries(ROUND_CATALOG.filter((value) => value.kind === "pve").map((value) => [counterKey(value.roundId), 0]))
  };
}
function revealMatchLoot(state, combat2) {
  const plan = currentPlan(state), events = [];
  if (!plan) return { state, events };
  if (combat2.combatId !== `round-${state.round}`) throw new RangeError("Loot combat mismatch");
  const loot = state.m8.loot, earnedEvidence = [...loot.earnedEvidence];
  const transition = (drop, sourceUnitId) => {
    if (drop.status !== "planned") return drop.status;
    const deaths = combat2.neutralReceipts?.deaths.filter((value) => value.unitId === sourceUnitId) ?? [];
    if (deaths.length > 1) throw new RangeError("Duplicate loot death");
    if (deaths.length) {
      const source = deaths[0];
      if (!Number.isSafeInteger(source.tick) || source.tick < 0 || source.tick > combat2.tick || !Number.isSafeInteger(source.eventSeq) || source.eventSeq < 0 || source.eventSeq >= (combat2.nextEventSeq ?? 0) || !combat2.units.some((unit) => unit.id === sourceUnitId && unit.unitKind === "neutral" && !unit.alive)) throw new RangeError("Invalid loot death");
      const death = { combatId: combat2.combatId, tick: source.tick, eventSeq: source.eventSeq };
      earnedEvidence.push({ dropId: drop.dropId, death });
      events.push({ type: "lootRevealed", dropId: drop.dropId, death });
      return "revealed";
    }
    if (combat2.status === "finished") {
      events.push({ type: "lootForfeited", dropId: drop.dropId });
      return "forfeited";
    }
    return "planned";
  };
  const direct = loot.direct.map((drop) => {
    const frozen = plan.encounterPlan.drops.find((value) => value.dropId === drop.dropId);
    if (!frozen || drop.status !== "planned") return drop;
    if (!frozen.sourceUnitId) throw new RangeError("Missing loot source");
    const status2 = transition(drop, frozen.sourceUnitId);
    return status2 === drop.status ? drop : { ...drop, status: status2 };
  });
  const choiceEligibility = loot.choiceEligibility.map((choice) => {
    const descriptor = plan.choices.find((value) => value.dropId === choice.dropId);
    if (!descriptor || choice.status !== "planned") return choice;
    const status2 = transition(choice, descriptor.sourceUnitId);
    return status2 === choice.status ? choice : { ...choice, status: status2 };
  });
  return { state: events.length ? withLoot(state, { ...loot, direct, choiceEligibility, earnedEvidence }) : state, events };
}
function commitReceipt(state, receipt) {
  const loot = state.m8.loot;
  if (loot.receipts.some((value) => value.receiptId === receipt.receiptId || value.dropId === receipt.dropId)) throw new RangeError("Duplicate loot receipt");
  let guaranteeCounters = loot.guaranteeCounters;
  if (receipt.payload.kind === "item" && ITEM_DEFINITIONS[receipt.payload.definitionId]?.kind === "component") {
    const key3 = counterKey(state.roundDefinitionId);
    const count = guaranteeCounters[key3] + receipt.payload.quantity;
    if (!Number.isSafeInteger(count) || count < 1) throw new RangeError("Invalid loot counter");
    guaranteeCounters = { ...guaranteeCounters, [key3]: count };
  }
  return withLoot(state, { ...loot, receipts: [...loot.receipts, receipt], guaranteeCounters });
}
function grantDirectLoot(initial, terminal) {
  let state = initial;
  const events = [], upgradeEvents = [];
  for (const drop of [...currentPlan(state)?.encounterPlan.drops ?? []].sort(compareLootFreezeSlots)) {
    const progress = state.m8.loot.direct.find((value) => value.dropId === drop.dropId);
    if (progress?.status !== "revealed" && progress?.status !== "pending-capacity") continue;
    if (state.combat?.status !== "finished") throw new RangeError("Loot grant before combat finish");
    const payload = drop.payload, receiptId = lootReceiptId(drop.dropId);
    let grantedItemIds = [], grantedUnitIds = [];
    if (payload.kind === "unit") {
      const purchase = planUnitAcquisition(state, payload.definitionId, { kind: "loot", receiptId }, state.resourceProvenance.entries.length);
      if (!purchase.ok) {
        const status2 = terminal ? "retained-terminal" : "pending-capacity";
        if (progress.status !== status2) state = withLoot(state, {
          ...state.m8.loot,
          direct: state.m8.loot.direct.map((value) => value.dropId === drop.dropId ? { dropId: value.dropId, status: status2, receiptId: null } : value)
        });
        continue;
      }
      state = {
        ...state,
        preparation: purchase.preparation,
        nextUnitSerial: purchase.nextUnitSerial,
        items: purchase.items,
        anomalyBinding: purchase.anomalyBinding,
        persistentGrowth: mergeGrowthLedger(state.persistentGrowth, purchase.upgradeEvents),
        resourceProvenance: appendResourceProvenance(state.resourceProvenance, state.roundDefinitionId, purchase.facts)
      };
      upgradeEvents.push(...purchase.upgradeEvents);
      events.push(...purchase.events);
      grantedUnitIds = [purchase.unitId];
    } else if (payload.kind === "item") {
      const grant = grantItem(state, payload.definitionId, receiptId);
      state = grant.state;
      grantedItemIds = grant.grantedItemIds;
    } else {
      const gold = state.gold + payload.quantity;
      if (!Number.isSafeInteger(gold)) throw new RangeError("Loot gold overflow");
      state = { ...state, gold };
    }
    const receipt = { receiptId, dropId: drop.dropId, payload, grantedItemIds, grantedUnitIds };
    state = commitReceipt(state, receipt);
    state = withLoot(state, { ...state.m8.loot, direct: state.m8.loot.direct.map((value) => value.dropId === drop.dropId ? { dropId: value.dropId, status: "granted", receiptId } : value) });
    events.push({ type: "lootGranted", receipt });
  }
  return { state, events, upgradeEvents };
}
function grantItem(state, definitionId2, receiptId) {
  const grant = planPermanentItemGrant(state, { definitionId: definitionId2, receiptId }, state.m8.loot.receipts.map((value) => value.receiptId));
  if (!grant.ok) throw new RangeError(`Invalid loot item grant: ${grant.reason}`);
  return { ...grant, state: { ...grant.state, resourceProvenance: appendResourceProvenance(
    state.resourceProvenance,
    state.roundDefinitionId,
    { kind: "item-acquired", itemId: grant.grantedItemIds[0], source: { kind: "loot", receiptId } }
  ) } };
}
function unresolvedLootChoices(state) {
  return orderedUnresolvedLootChoices(currentPlan(state)?.choices ?? [], state.m8.loot.choiceEligibility, state.m8.loot.choiceResolutions);
}
function hasPendingLootCapacity(state) {
  return state.m8.loot.direct.some((value) => value.status === "pending-capacity");
}
function grantLootChoice(state, descriptor, definitionId2, method) {
  const actual = currentPlan(state)?.choices.find((value) => value.dropId === descriptor.dropId);
  if (!actual || canonicalContent(actual) !== canonicalContent(descriptor) || !COMPONENT_POOL.some((value) => value.definitionId === definitionId2) || method !== "player-choice" && method !== "terminal-fallback" || method === "terminal-fallback" && definitionId2 !== actual.terminalFallbackDefinitionId) throw new RangeError("Invalid loot choice");
  if (state.m8.loot.choiceResolutions.some((value) => value.dropId === actual.dropId)) return { state, events: [] };
  if (state.combat?.status !== "finished") throw new RangeError("Loot choice before combat finish");
  if (!unresolvedLootChoices(state).some((value) => value.dropId === actual.dropId)) throw new RangeError("Unearned loot choice");
  const receiptId = lootReceiptId(actual.dropId), grant = grantItem(state, definitionId2, receiptId);
  const payload = { kind: "item", definitionId: definitionId2, quantity: 1 };
  const receipt = { receiptId, dropId: actual.dropId, payload, grantedItemIds: grant.grantedItemIds, grantedUnitIds: [] };
  state = commitReceipt(grant.state, receipt);
  state = withLoot(state, { ...state.m8.loot, choiceResolutions: [...state.m8.loot.choiceResolutions, { dropId: actual.dropId, receiptId, method }] });
  return { state, events: [{ type: "lootGranted", receipt }, { type: "lootChoiceResolved", dropId: actual.dropId, receiptId, method }] };
}

// src/simulation/effects.ts
var SOURCE_ORDER = {
  attack: -2,
  ability: -1,
  trait: 0,
  item: 1,
  augment: 2,
  anomaly: 3,
  enemyGrowth: 4
};
var STAT_NAMES = ["maxHp", "attackDamage", "armor", "magicResist", "initialMana", "abilityAmount", "abilityPower"];
var MECHANICS = /* @__PURE__ */ new Set([
  "artillery",
  "sniper",
  "watcher",
  "rageblade",
  "archangel",
  "dragonClaw",
  "gargoyle",
  "gunblade",
  "extraAttackMana",
  "titanic",
  "killStreak",
  "bulkyBuddies",
  "mageArmor",
  "glassCannon",
  "pumpingUp",
  "investment",
  "damageAmp",
  "acquisitionGold",
  "lowCostAllies"
]);
var MECHANIC_FIELDS = {
  artillery: ["everyN", "adBps", "radius"],
  sniper: ["damageBpsPerHex"],
  watcher: ["reductionBps", "healthyReductionBps", "thresholdBps"],
  rageblade: ["attackSpeedBps"],
  archangel: ["periodTicks", "abilityPower"],
  dragonClaw: ["periodTicks", "healMaxHpBps"],
  gargoyle: ["resistPerEnemy"],
  gunblade: ["selfHealBps", "allyHealBps"],
  extraAttackMana: ["amount"],
  titanic: ["adBps", "radius"],
  killStreak: ["mana"],
  bulkyBuddies: ["health", "shieldMaxHpBps", "durationTicks"],
  mageArmor: ["apBps"],
  glassCannon: ["startingHealthBps", "damageAmpBps"],
  pumpingUp: ["attackSpeedBpsPerRound"],
  investment: ["healthPerInterest"],
  damageAmp: ["bps"],
  acquisitionGold: ["amount"],
  lowCostAllies: ["count"]
};
var HOOKS = ["combatStart", "onAttack", "onCast", "onHpLoss"];
var compareAscii = (a, b) => a < b ? -1 : a > b ? 1 : 0;
function sourceRank(kind) {
  return SOURCE_ORDER[kind];
}
function compareEffectSources(a, b) {
  return compareAscii(a.ownerId, b.ownerId) || sourceRank(a.sourceKind) - sourceRank(b.sourceKind) || compareAscii(a.sourceDefinitionId, b.sourceDefinitionId) || compareAscii(a.sourceInstanceId, b.sourceInstanceId) || a.effectIndex - b.effectIndex;
}
function compareSourcedEffects(a, b) {
  return compareEffectSources(a.source, b.source);
}
function effectKey(source) {
  return JSON.stringify([source.ownerId, source.sourceKind, source.sourceDefinitionId, source.sourceInstanceId, source.effectIndex]);
}
function integer4(value, minimum = 0) {
  if (!Number.isSafeInteger(value) || value < minimum) throw new RangeError("Effect values must be safe nonnegative integers");
  return value;
}
function add(a, b) {
  return integer4(a + b);
}
function multiply(a, b) {
  return integer4(a * b);
}
function cloneAction(action) {
  integer4(action.amount);
  switch (action.kind) {
    case "grantShield":
      return { kind: action.kind, amount: action.amount, durationTicks: integer4(action.durationTicks, 1) };
    case "gainMana":
      return { kind: action.kind, amount: action.amount };
    case "dealDamage":
      if (action.damageType !== "physical" && action.damageType !== "magic") throw new RangeError("Unknown effect damage type");
      return { kind: action.kind, amount: action.amount, damageType: action.damageType };
    default:
      throw new RangeError("Unknown effect action");
  }
}
function cloneEffect(effect) {
  switch (effect.kind) {
    case "mechanic": {
      if (!MECHANICS.has(effect.mechanic)) throw new RangeError("Unknown finite mechanic");
      const fields = MECHANIC_FIELDS[effect.mechanic];
      if (fields.some((key3) => !Object.hasOwn(effect.values, key3))) throw new RangeError("Missing mechanic parameter");
      if (Object.keys(effect.values).some((key3) => !fields.includes(key3) && !["backRowOnly", "buddyIndex"].includes(key3))) throw new RangeError("Unknown mechanic parameter");
      for (const value of Object.values(effect.values)) integer4(value);
      for (const key3 of ["everyN", "periodTicks", "durationTicks"]) if (Object.hasOwn(effect.values, key3)) integer4(effect.values[key3], 1);
      for (const key3 of ["reductionBps", "healthyReductionBps", "thresholdBps", "startingHealthBps"])
        if ((effect.values[key3] ?? 0) > 1e4) throw new RangeError("Invalid bounded percentage");
      if (Object.hasOwn(effect.values, "radius") && effect.values.radius !== 1) throw new RangeError("Unsupported mechanic radius");
      return { kind: "mechanic", mechanic: effect.mechanic, values: { ...effect.values } };
    }
    case "statFlat":
      if (!STAT_NAMES.includes(effect.stat)) throw new RangeError("Unknown effect stat");
      return { kind: effect.kind, stat: effect.stat, amount: integer4(effect.amount) };
    case "statPercentBps":
      if (!STAT_NAMES.includes(effect.stat) || effect.stat === "initialMana") throw new RangeError("Unsupported percent stat");
      return { kind: effect.kind, stat: effect.stat, bps: integer4(effect.bps) };
    case "attackSpeedBps":
      return { kind: effect.kind, bps: integer4(effect.bps) };
    case "trigger": {
      if (!HOOKS.includes(effect.hook)) throw new RangeError("Unknown effect hook");
      integer4(effect.everyN, 1);
      const action = cloneAction(effect.action);
      if (effect.hook === "combatStart" && (effect.everyN !== 1 || action.kind === "dealDamage") || effect.hook === "onHpLoss" && action.kind !== "gainMana") throw new RangeError("Unsupported hook/action combination");
      return { kind: effect.kind, hook: effect.hook, everyN: effect.everyN, action };
    }
    default:
      throw new RangeError("Unknown effect primitive");
  }
}
function makeSourcedEffects(ownerId, sourceKind, sourceDefinitionId, sourceInstanceId, effects2, parentItemInstanceId) {
  return effects2.map((effect, effectIndex) => {
    const source = { ownerId, sourceKind, sourceDefinitionId, sourceInstanceId, effectIndex, ...parentItemInstanceId ? { parentItemInstanceId } : {} };
    return { key: effectKey(source), source, effect: cloneEffect(effect) };
  });
}
function resolveEffects(baseStats, baseAbility, input) {
  const sources = input.map(({ key: key3, source, effect }) => ({ key: key3, source: { ...source }, effect: cloneEffect(effect) })).sort(compareSourcedEffects);
  const seen = /* @__PURE__ */ new Set();
  const flat = { maxHp: 0, attackDamage: 0, armor: 0, magicResist: 0, initialMana: 0, abilityAmount: 0, abilityPower: 0 };
  const percent = { ...flat };
  let speed = 0;
  const triggers = [];
  for (const sourced of sources) {
    if (sourced.key !== effectKey(sourced.source) || seen.has(sourced.key)) throw new RangeError("Invalid or duplicate effect key");
    seen.add(sourced.key);
    const { effect } = sourced;
    switch (effect.kind) {
      case "mechanic":
        break;
      case "statFlat":
        flat[effect.stat] = add(flat[effect.stat], effect.amount);
        break;
      case "statPercentBps":
        percent[effect.stat] = add(percent[effect.stat], effect.bps);
        break;
      case "attackSpeedBps":
        speed = add(speed, effect.bps);
        break;
      case "trigger":
        triggers.push({
          key: sourced.key,
          source: { ...sourced.source },
          hook: effect.hook,
          everyN: effect.everyN,
          action: cloneAction(effect.action)
        });
        break;
    }
  }
  if (Object.values(percent).some((value) => value > 4e4) || speed > 2e4) throw new RangeError("Effect stacking bound exceeded");
  const stat2 = (name, base, minimum = 0) => {
    if (baseAbility.kind !== "s13" || name === "abilityAmount")
      return Math.max(minimum, Math.floor(multiply(add(integer4(base), flat[name]), add(1e4, percent[name])) / 1e4));
    const modifiers = sources.flatMap(({ effect }) => {
      if (effect.kind !== "statFlat" && effect.kind !== "statPercentBps" || effect.stat !== name) return [];
      return [{
        stat: name,
        unit: effect.kind === "statFlat" ? "flat" : "bps",
        value: { kind: "constant", amount: effect.kind === "statFlat" ? effect.amount : effect.bps },
        condition: { kind: "always" },
        damageFilter: null
      }];
    });
    return Math.max(minimum, resolveStat(name, base, modifiers, { holder: { id: "static", hp: baseStats.health, maxHp: baseStats.health } }));
  };
  const stats = {
    ...baseStats,
    health: stat2("maxHp", baseStats.health, 1),
    attack: stat2("attackDamage", baseStats.attack),
    armor: stat2("armor", baseStats.armor),
    magicResist: stat2("magicResist", baseStats.magicResist),
    initialMana: Math.min(integer4(baseStats.maxMana), add(integer4(baseStats.initialMana), flat.initialMana)),
    attackIntervalTicks: baseStats.baseAttackSpeedBps === void 0 ? Math.max(1, Math.ceil(multiply(integer4(baseStats.attackIntervalTicks, 1), 1e4) / add(1e4, speed))) : attackInterval(baseStats.baseAttackSpeedBps, speed),
    ...baseStats.baseAttackSpeedBps === void 0 ? {} : { baseAttackSpeedBps: baseStats.baseAttackSpeedBps, attackSpeedBonusBps: speed }
  };
  const ability = { ...baseAbility, amount: stat2("abilityAmount", baseAbility.amount) };
  const abilityPower = stat2("abilityPower", S13_COMBAT_RULES.abilityPowerBase);
  const mechanics = sources.flatMap((entry) => entry.effect.kind === "mechanic" ? [{
    source: {
      ownerId: entry.source.ownerId,
      sourceKind: entry.source.sourceKind,
      definitionId: entry.source.sourceDefinitionId,
      instanceId: entry.source.sourceInstanceId,
      effectIndex: entry.source.effectIndex,
      ...entry.source.parentItemInstanceId ? { parentItemInstanceId: entry.source.parentItemInstanceId } : {}
    },
    mechanic: entry.effect.mechanic,
    values: { ...entry.effect.values }
  }] : []);
  const mageArmor = mechanics.filter((m) => m.mechanic === "mageArmor").reduce((sum, m) => sum + Math.floor(abilityPower * (m.values.apBps ?? 0) / 1e4), 0);
  const resolvedStats = mageArmor ? { ...stats, armor: stats.armor + mageArmor, magicResist: stats.magicResist + mageArmor } : stats;
  return { stats: resolvedStats, ability, sources, triggers, ...baseAbility.kind === "s13" ? {
    abilityPower,
    mechanics,
    attackDamageBase: baseStats.attack + flat.attackDamage,
    attackDamagePercentBps: percent.attackDamage
  } : {} };
}
function copyTrigger(trigger2) {
  return {
    key: trigger2.key,
    source: { ...trigger2.source },
    hook: trigger2.hook,
    everyN: trigger2.everyN,
    action: cloneAction(trigger2.action)
  };
}
function initializeEffectRuntime(triggers) {
  const keys3 = triggers.map((trigger2) => trigger2.key).sort(compareAscii);
  if (new Set(keys3).size !== keys3.length) throw new RangeError("Duplicate trigger key");
  return keys3.map((key3) => ({ key: key3, count: 0 }));
}
function collectTriggers(triggers, runtime, hook, ownerId, primaryEnemyId) {
  const counts = /* @__PURE__ */ new Map();
  for (const counter of runtime) {
    if (counts.has(counter.key)) throw new RangeError("Duplicate effect runtime");
    counts.set(counter.key, integer4(counter.count));
  }
  const invocations = [];
  const matching = triggers.filter((trigger2) => trigger2.hook === hook && trigger2.source.ownerId === ownerId).sort((a, b) => compareEffectSources(a.source, b.source));
  const seen = /* @__PURE__ */ new Set();
  for (const trigger2 of matching) {
    if (seen.has(trigger2.key)) throw new RangeError("Duplicate trigger key");
    seen.add(trigger2.key);
    integer4(trigger2.everyN, 1);
    const count = add(counts.get(trigger2.key) ?? 0, 1);
    counts.set(trigger2.key, count);
    if (count % trigger2.everyN !== 0) continue;
    const targetId = trigger2.action.kind === "dealDamage" ? primaryEnemyId : ownerId;
    if (targetId === null) continue;
    invocations.push({ trigger: copyTrigger(trigger2), targetId, action: cloneAction(trigger2.action) });
  }
  return {
    runtime: [...counts].sort(([a], [b]) => compareAscii(a, b)).map(([key3, count]) => ({ key: key3, count })),
    invocations
  };
}

// src/simulation/combat-initialization.ts
function compileCombatInitialInputs(id2, stats, ability, resolved) {
  const inputs = {
    ...compileUnitInputs(stats),
    hp: Math.floor(stats.health * (resolved?.mechanics?.find((m) => m.mechanic === "glassCannon")?.values.startingHealthBps ?? 1e4) / 1e4),
    maxHp: stats.health,
    mana: stats.initialMana,
    maxMana: stats.maxMana,
    ...ability.kind === "s13" ? {
      abilityPower: resolved?.abilityPower ?? 100,
      ...resolved?.itemPrograms ? { itemPrograms: structuredClone(resolved.itemPrograms) } : {}
    } : {}
  };
  return itemPrograms(inputs).length ? { ...inputs, spellCrit: compileItemCrit({ ...inputs, id: id2, ability }) } : inputs;
}
function projectCombatStartMana(unit) {
  const batch = collectTriggers(unit.triggers ?? [], unit.effectRuntime ?? [], "combatStart", unit.id, null);
  const gain = batch.invocations.reduce((sum, invocation) => sum + (invocation.action.kind === "gainMana" ? invocation.action.amount : 0), 0);
  return { ...batch, gain, after: Math.min(unit.maxMana, unit.mana + gain), overflow: Math.max(0, unit.mana + gain - unit.maxMana) };
}

// src/simulation/m8/runtime-types.ts
var EMPTY_MECHANISMS = { initialized: false, combatId: "standalone", sampledAtTick: 0, statuses: [], periodicTasks: [], runtimes: [], unconsumedSurvivalKeys: [], activities: [] };

// src/simulation/m8/triggers.ts
var EMPTY_TRIGGER_LEDGER = { runtimes: [], processed: {}, actionCounts: {} };
var EMPTY_FACTS = { damage: [], healing: [], shieldDecay: [] };
function counterIdentity(combatId, source, id2) {
  return JSON.stringify([combatId, source.ownerId, source.sourceKind, source.definitionId, source.instanceId, source.parentItemInstanceId, id2]);
}
function listenerMatches(listener, holder, signal, units) {
  const event = signal.context, id2 = listener.subject === "actor" ? event.actorId : event.targetId;
  const subject = units.find((u) => u.id === id2);
  if (!subject) return false;
  const relation = listener.relationToHolder;
  if (relation === "self" && subject.id !== holder.id || relation === "ally" && subject.team !== holder.team || relation === "enemy" && subject.team === holder.team) return false;
  const cell = event.event === "cast-completed" && listener.subject === "actor" ? event.cast.completionCell : subject.cell;
  return listener.withinHexes === null || hexDistance(holder.cell, cell) <= listener.withinHexes;
}
function runtimeFor(combatId, d, tick) {
  return {
    ...effectIdentity(combatId, d.source, d.source.ownerId),
    startsAtTick: tick,
    expiresAtTick: null,
    stacks: 0,
    triggerCount: 0,
    counters: {},
    consumedRewards: [],
    nextEligibleTick: 0,
    consumed: false,
    stackPolicy: d.stackPolicy
  };
}
function effectQualifies(effect, signal) {
  const outcomes = signal.facts.damage;
  if (effect.kind === "damage" && effect.delivery === "equipment-proc" && outcomes.some((o) => o.context.equipmentDepth === 1)) return false;
  if (signal.context.event !== "damage-dealt" || effect.kind !== "apply-status") return true;
  const permission = effect.status.kind === "burn" || effect.status.kind === "wound" ? "apply-item-burn" : effect.status.kind === "sunder" ? "last-whisper" : null;
  return permission === null || outcomes.some((o) => o.context.permissions.includes(permission) && o.absorbed + o.hpDamage > 0);
}
function dispatchTriggers(combatId, definitions2, ledger, signal, units, select) {
  const event = signal.context;
  integer(event.eventSeq);
  integer(event.tick);
  integer(event.actionSeq);
  if (event.event === "cast-completed" && (!event.cast.completed || event.cast.source.ownerId !== event.actorId || event.cast.actionSeq !== event.actionSeq || event.cast.targetsSampledAtTick !== event.tick)) throw new RangeError("Invalid cast trigger binding");
  const sorted3 = [...definitions2].sort((a, b) => compareCodePoints(canonicalSource(a.source), canonicalSource(b.source)) || compareCodePoints(a.id, b.id));
  const next = new Map(ledger.runtimes.map((r) => [r.key, r])), processed = { ...ledger.processed }, actionCounts = { ...ledger.actionCounts };
  const invocations = [], counters = /* @__PURE__ */ new Map();
  for (const d of sorted3) for (const counter of d.counters) {
    const key3 = counterIdentity(combatId, d.source, counter.id), prior = counters.get(key3);
    if (prior && JSON.stringify(prior.counter) !== JSON.stringify(counter)) throw new RangeError("Conflicting shared counter declaration");
    if (!prior) counters.set(key3, { counter, owner: d });
  }
  const changed = /* @__PURE__ */ new Set();
  for (const [key3, { counter, owner: d }] of counters) {
    const holder = units.find((u) => u.id === d.source.ownerId);
    if (!holder?.alive || (processed[key3] ?? -1) >= event.eventSeq) continue;
    const eligible = counter.events.some((e) => e.event === event.event && listenerMatches(e.listener, holder, signal, units) && (e.qualifies === "completed-event" || signal.facts.damage.some((o) => o.absorbed + o.hpDamage > 0)));
    if (!eligible || signal.aggregation !== "event") continue;
    processed[key3] = event.eventSeq;
    const identity = runtimeFor(combatId, d, event.tick), old = next.get(identity.key) ?? identity, count = old.counters[counter.id] ?? 0;
    const value = Math.min(counter.cap ?? Number.MAX_SAFE_INTEGER, count + 1);
    integer(value);
    if (value !== count) {
      next.set(old.key, { ...old, counters: { ...old.counters, [counter.id]: value }, stacks: value });
      changed.add(key3);
    }
  }
  const readCounters = (d) => Object.fromEntries([...counters].filter(([key3, { counter }]) => key3 === counterIdentity(combatId, d.source, counter.id)).map(([, entry]) => [entry.counter.id, next.get(runtimeFor(combatId, entry.owner, event.tick).key)?.counters[entry.counter.id] ?? 0]));
  for (const d of sorted3) {
    const holder = units.find((u) => u.id === d.source.ownerId);
    if (!holder?.alive) continue;
    const values = readCounters(d), derived = d.event === "counter-updated";
    if (derived ? ![...changed].some((k) => [...counters.values()].some((c) => k === counterIdentity(combatId, d.source, c.counter.id))) : d.event !== event.event || d.aggregation !== signal.aggregation) continue;
    const context = derived ? { event: "counter-updated", eventSeq: event.eventSeq, tick: event.tick, actionSeq: event.actionSeq, actorId: holder.id, targetId: holder.id, cast: null } : event;
    const current = { ...signal, context };
    if (!listenerMatches(d.listener, holder, current, units)) continue;
    const identity = runtimeFor(combatId, d, event.tick), old = next.get(identity.key) ?? identity;
    const seen = JSON.stringify(["trigger", identity.key, d.id, context.event, signal.aggregation]);
    if ((processed[seen] ?? -1) >= event.eventSeq) continue;
    processed[seen] = event.eventSeq;
    const target = units.find((u) => u.id === context.targetId);
    if (!conditionHolds(d.condition, { holder, target, startingRows: holder.startingRows, positiveHpDamage: signal.facts.damage.some((o) => o.hpDamage > 0) })) continue;
    if (old.consumed || event.tick < old.nextEligibleTick || d.maxPerCombat !== null && old.triggerCount >= d.maxPerCombat) continue;
    const gate = d.gate, count = gate.kind === "always" ? 0 : values[gate.counterId] ?? 0;
    if (gate.kind === "every-n" && (count < gate.firstAt || (count - gate.firstAt) % gate.everyN !== 0)) continue;
    if (gate.kind === "stack-threshold-once" && (count < gate.at || old.consumedRewards.includes(gate.rewardId))) continue;
    let effectIndices = d.effects.flatMap((effect, index) => effectQualifies(effect, current) ? [index] : []);
    const perPacket = signal.aggregation === "event" && ["damage-dealt", "damage-taken", "shield-hit", "incoming-basic-hit"].includes(event.event);
    const stateStream = derived || perPacket;
    const actionKey = JSON.stringify([identity.key, d.id, event.actorId, event.actionSeq]);
    if ((actionCounts[actionKey] ?? 0) >= d.maxPerAction) {
      if (!stateStream) continue;
      effectIndices = effectIndices.filter((index) => d.effects[index].kind !== "damage");
    }
    if (d.effects.length && effectIndices.length === 0) continue;
    const actionLimited = !stateStream || effectIndices.some((index) => d.effects[index].kind === "damage");
    const targetIds = select(d, current);
    if (targetIds.length === 0) continue;
    const triggerCount = old.triggerCount + 1;
    integer(triggerCount);
    next.set(old.key, {
      ...old,
      triggerCount,
      nextEligibleTick: event.tick + d.internalCooldownTicks,
      consumed: d.maxPerCombat !== null && triggerCount >= d.maxPerCombat,
      consumedRewards: gate.kind === "stack-threshold-once" ? [...old.consumedRewards, gate.rewardId] : old.consumedRewards
    });
    if (actionLimited) actionCounts[actionKey] = (actionCounts[actionKey] ?? 0) + 1;
    invocations.push({ definition: d, signal: current, targetIds: [...targetIds], counters: values, effectIndices });
  }
  return { ledger: { runtimes: [...next.values()].sort((a, b) => compareCodePoints(a.key, b.key)), processed, actionCounts }, invocations };
}
function validateTriggerLedger(ledger, combatId, definitions2) {
  const keys3 = new Set(definitions2.map((d) => runtimeFor(combatId, d, 0).key)), seen = /* @__PURE__ */ new Set();
  for (const r of ledger.runtimes) {
    if (!keys3.has(r.key) || seen.has(r.key)) throw new RangeError("Unknown/duplicate trigger runtime");
    seen.add(r.key);
    for (const n of [r.triggerCount, r.stacks, r.nextEligibleTick, ...Object.values(r.counters)]) integer(n);
    const d = definitions2.find((d2) => runtimeFor(combatId, d2, 0).key === r.key);
    if (d.maxPerCombat !== null && r.triggerCount > d.maxPerCombat || new Set(r.consumedRewards).size !== r.consumedRewards.length) throw new RangeError("Invalid trigger consumption");
    for (const [id2, n] of Object.entries(r.counters)) {
      const c = d.counters.find((c2) => c2.id === id2);
      if (!c || c.cap !== null && n > c.cap) throw new RangeError("Invalid counter");
    }
  }
  for (const n of [...Object.values(ledger.processed), ...Object.values(ledger.actionCounts)]) integer(n);
}

// src/simulation/m8/s13-triggers.ts
function hasMechanismSubscriber(units, event) {
  return units.some((u) => u.mechanismDefinitions?.eventTriggers?.some((d) => d.event === event || d.counters.some((c) => c.events.some((e) => e.event === event))));
}
function emitMechanismSignal(ctx, context, facts = EMPTY_FACTS, aggregation = "event") {
  if (!hasMechanismSubscriber(ctx.units, context.event)) return;
  const signal = { context: { ...context, eventSeq: ctx.nextTriggerEventSeq ?? 0 }, facts, aggregation };
  ctx.nextTriggerEventSeq = (ctx.nextTriggerEventSeq ?? 0) + 1;
  const invocations = [];
  for (const holder of ctx.units) {
    const definitions2 = holder.mechanismDefinitions?.eventTriggers ?? [];
    if (!definitions2.length) continue;
    const result = dispatchTriggers(ctx.combatId ?? "standalone", definitions2, holder.triggerLedger ?? EMPTY_TRIGGER_LEDGER, signal, ctx.units.map((u) => ({ ...u, hp: ctx.virtualHp?.get(u.id) ?? u.hp, startingRows: startingRows(u.team, u.startingCell?.row ?? u.cell.row) ?? void 0 })), (d, s) => {
      return selectMechanismTargets(holder, ctx.units, d.selector, void 0, d.source, {
        board: ctx.board,
        tick: ctx.tick,
        eventActorId: s.context.actorId,
        eventTargetId: s.context.targetId,
        eventActorCell: s.context.cast?.completionCell,
        eligibility: "new-selection"
      }).map((u) => u.id);
    });
    holder.triggerLedger = result.ledger;
    for (const invocation of result.invocations) invocations.push({ holder, invocation });
  }
  invocations.sort((a, b) => compareCodePoints(canonicalSource(a.invocation.definition.source), canonicalSource(b.invocation.definition.source)));
  for (const { holder, invocation } of invocations) for (const targetId of invocation.targetIds) {
    const target = ctx.units.find((u) => u.id === targetId);
    const beforeDamage = [];
    for (const [index, effect] of invocation.definition.effects.entries()) {
      if (!invocation.effectIndices.includes(index)) continue;
      const source = { ...invocation.definition.source, effectIndex: invocation.definition.source.effectIndex + index };
      const ordinal = ctx.packets.length + 1e5;
      if ((context.event === "attack-completed" || context.event === "cast-completed") && effect.kind === "apply-status" && effect.status.activation === "immediate" && invocation.effectIndices.some((i) => i > index && invocation.definition.effects[i].kind === "damage")) {
        beforeDamage.push({ source, effect, ordinal });
        continue;
      }
      executeMechanismEffect(
        ctx,
        holder,
        source,
        target,
        effect,
        context.actionSeq,
        ctx.packets.length + 1e5,
        void 0,
        void 0,
        void 0,
        void 0,
        {
          area: invocation.targetIds.length > 1,
          triggeringCastActionSeq: context.event === "cast-completed" ? context.actionSeq : null,
          cast: signal.context.cast ?? void 0,
          facts,
          counters: invocation.counters
        }
      );
      if (effect.kind === "damage" && beforeDamage.length) ctx.packets[ctx.packets.length - 1].beforeDamage = beforeDamage.splice(0);
    }
  }
}

// src/simulation/m8/s13-targeting.ts
function targetUnit(unit, tick) {
  return {
    id: unit.id,
    team: unit.team,
    cell: unit.cell,
    hp: unit.hp,
    maxHp: unit.maxHp,
    alive: unit.alive,
    untargetable: effectiveStatuses(unit.mechanismState?.statuses ?? [], tick).some((g) => g.kind === "untargetable"),
    burnSources: (unit.mechanismState?.statuses ?? []).filter((g) => g.kind === "burn").flatMap((g) => g.contributions.filter((c) => isEffective(c, tick)).map((c) => c.source))
  };
}
function targetingEnvironment(board, units, holder, tick, patch = {}) {
  return { board, units: units.map((u) => targetUnit(u, tick)), holderId: holder.id, primaryId: holder.targetId, tick, ...patch };
}

// src/simulation/m8/shield.ts
function grantShieldState(identity, value, definition, tick, old) {
  validateIdentity(identity);
  integer(value);
  integer(tick);
  integer(definition.durationTicks, 1);
  if (old && old.key !== identity.key) throw new RangeError("Shield refresh source mismatch");
  const granted = Math.max(value, old?.remaining ?? 0), expiresAtTick = Math.max(tick + definition.durationTicks, old?.expiresAtTick ?? 0);
  return {
    ...identity,
    granted,
    remaining: granted,
    absorbed: 0,
    decayed: 0,
    expiredDiscarded: 0,
    startsAtTick: tick,
    expiresAtTick,
    endRewardConsumed: false,
    decay: definition.decay.kind === "none" ? { kind: "none" } : { kind: "linear-initial-grant", basisGranted: granted, grantedAtTick: tick, durationTicks: expiresAtTick - tick, lastDecayAtTick: tick }
  };
}
function maintainShield(layer, tick) {
  integer(tick);
  if (tick < layer.startsAtTick) throw new RangeError("Shield time moved backwards");
  if (layer.endRewardConsumed || layer.remaining === 0) return { layer, decayed: 0, reason: null };
  let next = layer, decayed = 0;
  const d = layer.decay;
  if (d.kind === "linear-initial-grant") {
    if (tick < d.lastDecayAtTick) throw new RangeError("Shield decay time moved backwards");
    const elapsed = Math.min(d.durationTicks, tick - d.grantedAtTick), previous = Math.min(d.durationTicks, d.lastDecayAtTick - d.grantedAtTick);
    const loss = integer(d.basisGranted) * integer(elapsed) / integer(d.durationTicks, 1) - integer(d.basisGranted) * integer(previous) / integer(d.durationTicks, 1);
    decayed = Math.min(layer.remaining, safeNumber(loss));
    next = { ...layer, remaining: layer.remaining - decayed, decayed: layer.decayed + decayed, decay: { ...d, lastDecayAtTick: Math.min(tick, layer.expiresAtTick) } };
  }
  if (tick >= layer.expiresAtTick) return { layer: { ...next, remaining: 0, expiredDiscarded: next.expiredDiscarded + next.remaining }, decayed, reason: "expired" };
  return { layer: next, decayed, reason: next.remaining === 0 ? "depleted" : null };
}
function recordShieldAbsorption(layer, remaining) {
  integer(remaining);
  if (remaining > layer.remaining || layer.endRewardConsumed && remaining !== layer.remaining) throw new RangeError("Invalid shield allocation");
  return { ...layer, remaining, absorbed: layer.absorbed + layer.remaining - remaining };
}
function endShield(layer, reason, definition, survived) {
  if (layer.endRewardConsumed) return { layer, emitEnd: false, effects: [] };
  const remaining = reason === "replaced" ? layer.remaining : 0;
  return {
    layer: { ...layer, remaining, expiredDiscarded: layer.expiredDiscarded + layer.remaining - remaining, endRewardConsumed: true },
    emitEnd: true,
    effects: survived && definition.onEnd.includes(reason) ? definition.endEffects : []
  };
}
function validateShield(layer, tick, combatId) {
  validateIdentity(layer, combatId);
  for (const n of [layer.granted, layer.remaining, layer.absorbed, layer.decayed, layer.expiredDiscarded, layer.startsAtTick, layer.expiresAtTick]) integer(n);
  if (typeof layer.endRewardConsumed !== "boolean" || layer.endRewardConsumed && layer.remaining > 0) throw new RangeError("Invalid shield consumption");
  if (integer(layer.remaining) + integer(layer.absorbed) + integer(layer.decayed) + integer(layer.expiredDiscarded) !== integer(layer.granted) || layer.startsAtTick > tick || layer.expiresAtTick <= layer.startsAtTick || layer.remaining > 0 && layer.expiresAtTick <= tick) throw new RangeError("Invalid shield conservation/lifetime");
  if (layer.decay.kind !== "none") {
    const d = layer.decay;
    integer(d.basisGranted);
    integer(d.grantedAtTick);
    integer(d.durationTicks, 1);
    integer(d.lastDecayAtTick);
    if (d.basisGranted !== layer.granted || d.grantedAtTick !== layer.startsAtTick || d.grantedAtTick + d.durationTicks !== layer.expiresAtTick || d.lastDecayAtTick < d.grantedAtTick || d.lastDecayAtTick > tick || d.lastDecayAtTick > layer.expiresAtTick) throw new RangeError("Invalid shield decay phase");
  }
}
function survivalSamples(before, after, positive, tick) {
  return before.map((u) => {
    const next = after.find((a) => a.id === u.id);
    if (!next || u.maxHp !== next.maxHp) throw new RangeError("Threshold sample requires unchanged maxHP");
    return { unitId: u.id, tick, hpBeforeDamage: u.hp, hpAfterDamage: next.hp, maxHpBeforeThresholdEffects: u.maxHp, survivedDamageBatch: next.hp > 0, receivedPositiveDamage: positive.has(u.id) };
  });
}
function survivalConsumptionKeys(definitions2, combatId, holderId) {
  return [...new Set(definitions2.filter((d) => d.maxPerCombat === 1).map((d) => effectIdentity(combatId, d.source, holderId).key))].sort(compareCodePoints);
}
function remainingSurvivalKeys(keys3, runtimes) {
  const consumed = new Set(runtimes.filter((r) => r.consumed).map((r) => r.key));
  return keys3.filter((key3) => !consumed.has(key3));
}
function consumeSurvivalTriggers(definitions2, runtimes, sample, combatId, initial = false) {
  const next = [...runtimes], fired = [];
  if (!sample.survivedDamageBatch || !sample.receivedPositiveDamage && !initial) return { runtimes: next, fired };
  for (const definition of [...definitions2].sort((a, b) => compareCodePoints(canonicalSource(a.source), canonicalSource(b.source)) || compareCodePoints(a.id, b.id))) {
    if (definition.event !== (initial ? "combat-start" : "post-damage-survival") || definition.source.ownerId !== sample.unitId || definition.listener.subject !== (initial ? "actor" : "target") || definition.listener.relationToHolder !== "self") continue;
    if (!conditionHolds(definition.condition, { holder: { id: sample.unitId, hp: sample.hpAfterDamage, maxHp: sample.maxHpBeforeThresholdEffects } })) continue;
    if (definition.gate.kind !== "always") throw new RangeError("Survival gates must be expressed by finite runtime limits");
    const identity = effectIdentity(combatId, definition.source, sample.unitId), index = next.findIndex((r) => r.key === identity.key), old = next[index];
    if (old?.consumed || old && sample.tick < old.nextEligibleTick || definition.maxPerCombat !== null && (old?.triggerCount ?? 0) >= definition.maxPerCombat) continue;
    const count = (old?.triggerCount ?? 0) + 1;
    const runtime = {
      ...identity,
      startsAtTick: old?.startsAtTick ?? sample.tick,
      expiresAtTick: null,
      stacks: old?.stacks ?? 0,
      counters: old?.counters ?? {},
      consumedRewards: old?.consumedRewards ?? [],
      stackPolicy: definition.stackPolicy,
      triggerCount: count,
      nextEligibleTick: sample.tick + definition.internalCooldownTicks,
      consumed: definition.maxPerCombat !== null && count >= definition.maxPerCombat
    };
    if (index >= 0) next[index] = runtime;
    else next.push(runtime);
    fired.push({ definition, sample: { ...sample } });
  }
  return { runtimes: next.sort((a, b) => compareCodePoints(a.key, b.key)), fired };
}

// src/simulation/combat-s13-state.ts
function ensureMechanisms(unit, tick = 0, combatId = "standalone") {
  if (!unit.mechanismState) unit.mechanismState = { ...EMPTY_MECHANISMS, combatId, sampledAtTick: tick };
}
var modifierIndex = /* @__PURE__ */ new WeakMap();
function statusModifiers(unit, stat2, tick = unit.mechanismState?.sampledAtTick ?? 0) {
  const groups = unit.mechanismState?.statuses;
  if (!groups?.length) return [];
  let index = modifierIndex.get(groups);
  if (!index || index.tick !== tick) {
    const values = /* @__PURE__ */ new Map();
    for (const group of groups) for (const c of group.contributions) if (c.application.modifier && isEffective(c, tick)) {
      const modifier2 = c.application.modifier, list2 = values.get(modifier2.stat) ?? [];
      list2.push(modifier2);
      values.set(modifier2.stat, list2);
    }
    index = { tick, values };
    modifierIndex.set(groups, index);
  }
  return index.values.get(stat2) ?? [];
}
function shieldProjection(state, legacyKey, definition, endedReason) {
  return {
    key: legacyKey,
    source: { ownerId: state.source.ownerId, sourceKind: state.source.sourceKind, definitionId: state.source.definitionId, instanceId: state.source.instanceId, effectIndex: state.source.effectIndex, ...state.source.parentItemInstanceId ? { parentItemInstanceId: state.source.parentItemInstanceId } : {} },
    granted: state.granted,
    remaining: state.remaining,
    absorbed: state.absorbed,
    expiresAtTick: state.expiresAtTick,
    m8State: state,
    ...definition ? { m8Grant: definition } : {},
    ...endedReason ? { endedReason } : {},
    ...state.decay.kind === "linear-initial-grant" ? { grantedAtTick: state.decay.grantedAtTick, decayDurationTicks: state.decay.durationTicks } : {}
  };
}
function frozenShield(layer, unit) {
  if (layer.m8State) return layer.m8State;
  const startsAtTick = layer.grantedAtTick ?? 0;
  const decayed = Math.max(0, layer.granted - layer.remaining - layer.absorbed);
  return {
    ...effectIdentity(unit.mechanismState?.combatId ?? "standalone", asSource(layer.source), unit.id),
    granted: layer.granted,
    remaining: layer.remaining,
    absorbed: layer.absorbed,
    decayed,
    expiredDiscarded: 0,
    startsAtTick,
    expiresAtTick: layer.expiresAtTick,
    endRewardConsumed: false,
    decay: layer.decayDurationTicks ? {
      kind: "linear-initial-grant",
      basisGranted: layer.granted,
      grantedAtTick: startsAtTick,
      durationTicks: layer.decayDurationTicks,
      lastDecayAtTick: Math.max(startsAtTick, unit.mechanismState?.sampledAtTick ?? startsAtTick)
    } : { kind: "none" }
  };
}
var EMPTY_RUNTIME = {
  attackCount: 0,
  castCount: 0,
  attackSpeedBps: 0,
  abilityPowerFlat: 0,
  rangeBonus: 0,
  nextAttackMagic: 0,
  nextAttackPhysical: 0,
  permanentAdBps: 0,
  buddyTriggered: false
};
var hpSample = (unit) => ({ id: unit.id, hp: unit.hp, maxHp: unit.maxHp });
var constantModifier = (stat2, amount3, unit = "flat") => ({ stat: stat2, unit, value: { kind: "constant", amount: amount3 }, condition: { kind: "always" }, damageFilter: null });
function spellCrit(unit) {
  if (unit.spellCrit) {
    const auth = validateSpellCrit(unit.spellCrit);
    if ([...auth.itemSources, ...auth.nonItemSources].some((s) => s.ownerId !== unit.id)) throw new RangeError("Wrong authorization holder");
    return auth;
  }
  return authorizeSpellCrit([], [], unit.baseCritChanceBps ?? (champion(unit) === "neutral" ? 0 : S13_COMBAT_RULES.attackCritBps), unit.baseCritMultiplierBps ?? S13_COMBAT_RULES.critMultiplierBps);
}
var compareText = (a, b) => a < b ? -1 : a > b ? 1 : 0;
var sourceKey = (s) => JSON.stringify([s.ownerId, s.sourceKind, s.definitionId, s.instanceId, s.effectIndex]);
function compareOrigins(a, b) {
  const kinds = ["attack", "ability", "trait", "item", "augment", "anomaly", "enemyGrowth"];
  return compareText(a.ownerId, b.ownerId) || kinds.indexOf(a.sourceKind) - kinds.indexOf(b.sourceKind) || compareText(a.definitionId, b.definitionId) || compareText(a.instanceId, b.instanceId) || a.effectIndex - b.effectIndex;
}
function origin(unit, effectIndex = 0) {
  return { ownerId: unit.id, sourceKind: "ability", definitionId: unit.ability.id, instanceId: unit.id, effectIndex };
}
function variable(unit, name, fallback = 0) {
  return unit.ability.kind === "s13" && Object.hasOwn(unit.ability.variables, name) ? unit.ability.variables[name] / 1e4 : fallback;
}
function champion(unit) {
  return unit.ability.kind === "s13" ? unit.ability.championId : "";
}
function mechanic(unit, name, key3, fallback = 0) {
  return (unit.mechanics ?? []).filter((m) => m.mechanic === name).reduce((sum, m) => sum + (m.values[key3] ?? fallback), 0);
}
function hasMechanic(unit, name) {
  return (unit.mechanics ?? []).some((m) => m.mechanic === name);
}
function active(unit, tick, kind) {
  return (unit.statuses ?? []).filter((s) => s.kind === kind && s.startsAtTick <= tick && s.expiresAtTick > tick);
}
function ap(unit, tick) {
  return resolveStat("abilityPower", unit.abilityPower ?? 100, [
    constantModifier("abilityPower", unit.runtime.abilityPowerFlat),
    ...active(unit, tick, "abilityPower").filter((s) => !s.contributionKeys).map((s) => constantModifier("abilityPower", s.amount)),
    ...statusModifiers(unit, "abilityPower", tick)
  ], { holder: hpSample(unit), startingRows: startingRows(unit.team, unit.startingCell?.row ?? unit.cell.row) ?? void 0 });
}
function ad(unit) {
  return resolveStat(
    "attackDamage",
    unit.attackDamageBase ?? unit.attackDamage,
    [constantModifier("attackDamage", unit.attackDamagePercentBps ?? 0, "bps"), constantModifier("attackDamage", unit.runtime.permanentAdBps, "bps"), ...statusModifiers(unit, "attackDamage")],
    { holder: hpSample(unit), startingRows: startingRows(unit.team, unit.startingCell?.row ?? unit.cell.row) ?? void 0 }
  );
}
function range(unit) {
  return resolveStat("range", unit.attackRange, [constantModifier("range", unit.runtime.rangeBonus, "hexes"), ...statusModifiers(unit, "range")], { holder: hpSample(unit), startingRows: startingRows(unit.team, unit.startingCell?.row ?? unit.cell.row) ?? void 0 });
}
function amount2(unit, tick, coefficients) {
  const flat = coefficients.flat ?? 0;
  if (!Number.isSafeInteger(flat)) throw new RangeError("Invalid S13 flat amount");
  return evaluateAmount(
    {
      flat,
      attackDamageBps: Math.round((coefficients.ad ?? 0) * 1e4),
      abilityPowerBps: Math.round((coefficients.ap ?? 0) * 100),
      maxHpBps: Math.round((coefficients.hp ?? 0) * 1e4),
      missingHpBps: 0,
      actualManaSpentBps: 0,
      actualDamageBps: 0,
      shieldAbsorbedBps: 0,
      hpBasis: "holder",
      sample: "application",
      cap: null
    },
    { holder: hpSample(unit), attackDamage: ad(unit), abilityPower: ap(unit, tick) }
  );
}
function interval(unit, tick) {
  if (champion(unit) === "neutral" && unit.unitKind !== "neutral") return unit.attackIntervalTicks;
  const speedBps = (unit.attackSpeedBonusBps ?? 0) + unit.runtime.attackSpeedBps + active(unit, tick, "attackSpeed").filter((s) => !s.contributionKeys).reduce((n, s) => n + s.amount, 0) + resolveStat("attackSpeed", 0, statusModifiers(unit, "attackSpeed", tick), { holder: hpSample(unit), startingRows: startingRows(unit.team, unit.startingCell?.row ?? unit.cell.row) ?? void 0 });
  const base = unit.baseAttackSpeedBps ?? Math.round(2e5 / unit.attackIntervalTicks);
  return attackInterval(base, speedBps);
}
function byDistance(from, list2, farthest = false) {
  return [...list2].sort((a, b) => (farthest ? -1 : 1) * (hexDistance(from.cell, a.cell) - hexDistance(from.cell, b.cell)) || compareText(a.id, b.id));
}
function areaEnemies(unit, units) {
  return units.filter((u) => u.alive && u.team !== unit.team);
}
function enemies3(unit, units) {
  return units.filter((u) => u.alive && u.team !== unit.team && !effectiveStatuses(u.mechanismState?.statuses ?? [], unit.mechanismState?.sampledAtTick ?? 0).some((g) => g.kind === "untargetable"));
}
function neighborsOf(unit, units, radius = 1) {
  return areaEnemies(unit, units).filter((u) => hexDistance(unit.cell, u.cell) <= radius).sort((a, b) => compareText(a.id, b.id));
}
function lowestAlly(unit, units, current = false) {
  return units.filter((u) => u.alive && u.team === unit.team).sort((a, b) => (current ? a.hp - b.hp : a.hp * b.maxHp - b.hp * a.maxHp) || hexDistance(unit.cell, a.cell) - hexDistance(unit.cell, b.cell) || compareText(a.id, b.id))[0];
}
function path(board, from, to) {
  return shortestPath(board, from, to);
}
function syncShield(unit) {
  unit.shield = unit.shieldLayers.reduce((n, s) => n + s.remaining, 0);
  unit.shieldExpiresAtTick = unit.shield > 0 ? Math.max(...unit.shieldLayers.filter((s) => s.remaining > 0).map((s) => s.expiresAtTick)) : null;
}
function grantShield(unit, source, value, expiresAtTick, tick, events, decay = false) {
  ensureMechanisms(unit, tick);
  const key3 = sourceKey(source), old = unit.shieldLayers.find((s) => s.key === key3);
  const definition = {
    kind: "grant-shield",
    amount: flatAmount(value),
    durationTicks: expiresAtTick - tick,
    decay: decay ? { kind: "linear-initial-grant" } : { kind: "none" },
    onEnd: [],
    endTiming: decay ? "next-action-planning" : "post-damage",
    endTargeting: { kind: "fixed", targetIds: [unit.id], ifMissing: "skip" },
    endEffects: []
  };
  const state = grantShieldState(effectIdentity(unit.mechanismState.combatId, asSource(source), unit.id), value, definition, tick, old ? frozenShield(old, unit) : void 0);
  const layer = shieldProjection(state, key3, definition);
  unit.shieldLayers = [...unit.shieldLayers.filter((s) => s.key !== key3), layer].sort((a, b) => a.expiresAtTick - b.expiresAtTick || compareText(a.m8State.key, b.m8State.key));
  syncShield(unit);
  events.push({ type: "shieldLayerChanged", tick, unitId: unit.id, layer, reason: "granted" });
}
function applyStatus(unit, source, kind, value, duration2, tick, events, immediate = false, suffix = "", actionSeq) {
  ensureMechanisms(unit, tick);
  const key3 = `${sourceKey(source)}:${kind}:${unit.id}:${suffix}`;
  const old = unit.statuses.find((s) => s.key === key3);
  if (kind === "channel" || kind === "redirect") {
    const identity = effectIdentity(unit.mechanismState.combatId, asSource(source), unit.id, String(actionSeq ?? unit.runtime.castCount));
    const activity = {
      ...identity,
      actionSeq: actionSeq ?? unit.runtime.castCount,
      startsAtTick: tick,
      expiresAtTick: tick + duration2,
      ...kind === "channel" ? { kind: "channel", blocks: ["move", "attack", "cast"], cancelOnControl: true } : { kind: "redirect", allyRadius: 1, shareBps: value, choose: "lowest-id", repeatMitigation: false, recursive: false },
      lifecycle: "active",
      endedAtTick: null,
      endReason: null
    };
    for (const previous of unit.statuses.filter((s) => s.activity?.kind === kind && s.activity.lifecycle === "active")) events.push({ type: "statusChanged", tick, unitId: unit.id, status: previous, reason: "replaced", activity: { ...previous.activity, lifecycle: "ended", endedAtTick: tick, endReason: "replaced" } });
    const activities = unit.mechanismState.activities.map((a) => a.kind === kind && a.lifecycle === "active" ? { ...a, lifecycle: "ended", endedAtTick: tick, endReason: "replaced" } : a);
    unit.mechanismState = { ...unit.mechanismState, activities: [...activities, activity] };
    const status3 = { key: key3, source, kind, amount: value, startsAtTick: tick, expiresAtTick: tick + duration2, activity };
    unit.statuses = [...unit.statuses.filter((s) => s.key !== key3), status3].sort((a, b) => compareText(a.key, b.key));
    events.push({ type: "statusChanged", tick, unitId: unit.id, status: status3, reason: "applied", activity });
    return;
  }
  const kinds = { stun: "stun", damageReduction: "damage-reduction", armorReduction: "sunder", resistanceFlat: value < 0 ? "stat-debuff" : "stat-buff", attackSpeed: "stat-buff", abilityPower: "stat-buff" };
  const frozenKind = kinds[kind];
  const policy = ["damageReduction", "armorReduction"].includes(kind) ? { kind: "strongest-category", category: frozenKind, retainSuppressed: true } : suffix ? { kind: "independent-instances" } : { kind: "refresh-same-instance", magnitude: "replace", phase: "preserve" };
  const modifiers = kind === "resistanceFlat" ? [constantModifier("armor", value), ...!suffix.startsWith("armor:") ? [constantModifier("magicResist", value)] : []] : kind === "attackSpeed" ? [constantModifier("attackSpeed", value, "bps")] : kind === "abilityPower" ? [constantModifier("abilityPower", value)] : [void 0];
  const legacyApplication = suffix.startsWith("armor:") ? suffix.slice(6) : suffix;
  const applicationId = !legacyApplication ? "source" : legacyApplication.startsWith("[") ? legacyApplication : JSON.stringify([...legacyApplication.split(":").map(Number), unit.id]);
  const contributionKeys = [];
  let groups = unit.mechanismState.statuses;
  for (const [index, modifier2] of modifiers.entries()) {
    const frozenSource = { ...asSource(source), effectIndex: source.effectIndex * 16 + index };
    const identity = effectIdentity(unit.mechanismState.combatId, frozenSource, unit.id, applicationId);
    const application = {
      activation: immediate ? "immediate" : "next-tick",
      kind: frozenKind,
      magnitudeBps: modifier2 ? 0 : value,
      duration: { kind: "ticks", ticks: duration2 },
      stackPolicy: policy,
      polarity: kind === "stun" || kind === "armorReduction" || value < 0 ? "harmful" : "beneficial",
      removable: kind !== "damageReduction",
      ...modifier2 ? { modifier: modifier2 } : {},
      damageFilter: kind === "damageReduction" ? { deliveries: "all", damageTypes: ["physical", "magic"], redirected: "exclude" } : null,
      onEnd: null
    };
    const result = applyStatusContribution(groups, identity, application, tick);
    if (!result.accepted) return;
    groups = result.groups;
    contributionKeys.push(identity.key);
  }
  unit.mechanismState = { ...unit.mechanismState, statuses: groups };
  const contribution = groups.flatMap((g) => g.contributions).find((c) => c.key === contributionKeys[0]);
  const status2 = { key: key3, kind, source, amount: value, startsAtTick: contribution.appliedAtTick, expiresAtTick: contribution.expiresAtTick, contributionKeys };
  unit.statuses = [...unit.statuses.filter((s) => s.key !== key3), status2].sort((a, b) => compareText(a.key, b.key));
  events.push({ type: "statusChanged", tick, unitId: unit.id, status: status2, reason: "applied" });
  void old;
}

// src/simulation/m8/periodic.ts
function effectAmount(task, effectIndex) {
  integer(effectIndex);
  const effect = task.program.effects[effectIndex];
  if (!effect || !["damage", "heal", "grant-shield"].includes(effect.kind) || !("amount" in effect) || typeof effect.amount === "number") throw new RangeError("Periodic account is not an amount effect");
  return effect.amount;
}
function clearRemainder(task, effectIndex, targetId) {
  return { ...task, remainders: task.remainders.filter((r) => r.effectIndex !== effectIndex || r.targetId !== targetId) };
}
function periodicAmount(task, effectIndex, targetId, sample) {
  const amount3 = effectAmount(task, effectIndex), old = task.remainders.find((r) => r.effectIndex === effectIndex && r.targetId === targetId);
  const exact = addFractions({ numerator: amountNumerator(amount3, sample), denominator: 10000n }, old ? fraction(old.numerator, old.denominator) : { numerator: 0n, denominator: 1n });
  const capped = amount3.cap !== null && exact.numerator > integer(amount3.cap) * exact.denominator;
  const hp2 = sample.target ?? sample.holder;
  const fullHealth = task.program.effects[effectIndex].kind === "heal" && hp2 !== void 0 && hp2.hp === hp2.maxHp;
  const requested = capped ? amount3.cap : safeNumber(exact.numerator / exact.denominator);
  const numerator = exact.numerator % exact.denominator;
  const cleared = clearRemainder(task, effectIndex, targetId);
  const remainder = { effectIndex, targetId, numerator: safeNumber(numerator), denominator: safeNumber(exact.denominator) };
  return { requested, task: { ...cleared, remainders: [...cleared.remainders, ...!capped && !fullHealth && numerator !== 0n ? [remainder] : []].sort((a, b) => a.effectIndex - b.effectIndex || compareCodePoints(a.targetId, b.targetId)) } };
}
function splitTotal(total, count) {
  const n = integer(total), c = integer(count, 1);
  return Array.from({ length: count }, (_, i) => safeNumber(n / c + (BigInt(i) < n % c ? 1n : 0n)));
}
function advancePeriodicTask(task, tick) {
  integer(tick);
  if (task.pulseLimit !== null && task.pulseOrdinal >= task.pulseLimit || task.endsAtTick !== null && (tick > task.endsAtTick || tick === task.endsAtTick && (task.finalPulse === "none" || task.nextPulseAtTick !== tick))) return { due: false, task: null };
  if (tick < task.nextPulseAtTick) return { due: false, task };
  if (tick !== task.nextPulseAtTick) throw new RangeError("Missed periodic pulse; never backfill");
  const next = { ...task, nextPulseAtTick: task.nextPulseAtTick + task.periodTicks, pulseOrdinal: task.pulseOrdinal + 1 };
  return { due: true, task: task.pulseLimit !== null && next.pulseOrdinal >= task.pulseLimit ? null : next };
}
function cleanPeriodicTasks(tasks, deadTargets, deadSources) {
  return tasks.filter((t) => !deadTargets.has(t.targetId) && !(t.onSourceDeath === "cancel" && deadSources.has(t.source.ownerId))).map((t) => ({ ...t, remainders: t.remainders.filter((r) => !deadTargets.has(r.targetId)) }));
}
function validatePeriodicTask(task, unitIds, deadIds, tick, combatId) {
  validateIdentity(task, combatId);
  integer(task.nextPulseAtTick);
  integer(task.periodTicks, 1);
  integer(task.pulseOrdinal);
  if (!unitIds.has(task.targetId) || !unitIds.has(task.source.ownerId) || deadIds.has(task.targetId) || task.onSourceDeath === "cancel" && deadIds.has(task.source.ownerId) || task.nextPulseAtTick <= tick || task.program.targetSnapshot !== "once-per-pulse") throw new RangeError("Invalid periodic lifecycle");
  if (task.endsAtTick !== null) {
    integer(task.endsAtTick, 1);
    if (task.endsAtTick <= tick) throw new RangeError("Invalid last pulse");
  }
  if (task.pulseLimit !== null) {
    integer(task.pulseLimit, 1);
    if (task.pulseOrdinal >= task.pulseLimit) throw new RangeError("Completed periodic task");
  }
  const accounts = /* @__PURE__ */ new Set();
  for (const r of task.remainders) {
    effectAmount(task, r.effectIndex);
    integer(r.numerator);
    integer(r.denominator, 1);
    const account = JSON.stringify([r.effectIndex, r.targetId]);
    if (accounts.has(account) || !unitIds.has(r.targetId) || deadIds.has(r.targetId) || r.numerator >= r.denominator) throw new RangeError("Invalid periodic remainder account");
    accounts.add(account);
  }
}

// src/simulation/m8/damage.ts
function permissionsFor(context) {
  const permissions = ["defender-titan", "damage-mana"];
  const ordinary = ["basic-attack", "ability-direct", "ability-periodic"].includes(context.delivery);
  const vamp2 = ordinary || context.delivery === "attack-extra";
  if (vamp2) permissions.push("omnivamp", "gunblade-ally-heal");
  if (!context.redirected) {
    if (ordinary) permissions.push("apply-item-burn");
    if (context.damageType === "physical" && context.delivery !== "item-burn") permissions.push("last-whisper");
    permissions.push("guardbreaker");
    if (context.delivery === "basic-attack") permissions.push("incoming-basic-hit");
  }
  return permissions;
}
function validateDamageContext(context) {
  if (!["physical", "magic", "true"].includes(context.damageType) || !["basic-attack", "ability-direct", "ability-periodic", "attack-extra", "equipment-proc", "item-burn"].includes(context.delivery) || !["basic", "requires-spell-authorization", "never"].includes(context.critEligibility)) throw new RangeError("Invalid damage category");
  for (const value of [context.actionSeq, context.rootActionSeq, context.packetOrdinal, context.equipmentDepth, context.source.effectIndex]) integer(value);
  if (context.equipmentDepth > 1 || ["equipment-proc", "item-burn"].includes(context.delivery) && context.critEligibility !== "never" || context.delivery === "attack-extra" && context.critEligibility !== "never" || context.delivery === "basic-attack" && !["basic", "never"].includes(context.critEligibility) || ["ability-direct", "ability-periodic"].includes(context.delivery) && context.critEligibility === "basic") throw new RangeError("Invalid damage eligibility");
  const expected = permissionsFor(context);
  if (context.permissions.length !== expected.length || new Set(context.permissions).size !== expected.length || expected.some((p) => !context.permissions.includes(p))) throw new RangeError("Forged proc permissions");
}
function prepareDamage(request, sample) {
  const { context, input } = request;
  validateDamageContext(context);
  if (sample.holder.id !== context.source.ownerId) throw new RangeError("Wrong damage holder sample");
  if (!sample.target || sample.target.id !== context.targetId) throw new RangeError("Missing damage target");
  integer(sample.target.hp);
  integer(sample.target.maxHp, 1);
  integer(sample.armor);
  integer(sample.magicResist);
  integer(sample.critMultiplierBps, 1e4);
  if (sample.target.hp > sample.target.maxHp) throw new RangeError("Invalid target HP");
  const raw = input.stage === "raw" ? evaluateAmount(input.amount, sample) : safeNumber(integer(input.amount));
  let value = raw, rawAfterCritical = raw, critical = sample.critical;
  if (input.stage === "after-mitigation") {
    if (context.parentPacketId !== input.inherited.parentPacketId) throw new RangeError("Mismatched inherited packet");
    integer(input.inherited.resolvedAtTick);
    critical = input.inherited.critical;
  } else {
    if (critical && context.critEligibility === "never") throw new RangeError("Ineligible critical damage");
    if (critical) value = safeNumber(BigInt(value) * integer(sample.critMultiplierBps, 1e4) / 10000n);
    rawAfterCritical = value;
    if (context.damageType !== "true") {
      const resistance = context.damageType === "physical" ? sample.armor : sample.magicResist;
      value = safeNumber(BigInt(value) * 100n / (100n + integer(resistance)));
    }
    const statSample = {
      holder: sample.holder,
      target: sample.target,
      packet: context,
      counters: sample.counters,
      enemiesTargetingHolder: sample.enemiesTargetingHolder
    };
    const amp = modifierValues("damageAmp", sample.amplifiers, statSample).bps;
    const reduction = context.damageType === "true" ? 0 : modifierValues(
      "damageReduction",
      sample.reductions,
      { ...statSample, holder: sample.target, target: sample.holder }
    ).bps;
    value = safeNumber(BigInt(value) * (10000n + integer(amp, -1e4)) * (10000n - integer(reduction)) / 100000000n);
    if (raw > 0 && context.delivery !== "item-burn") value = Math.max(1, value);
    if (context.delivery === "item-burn" && sample.burnCap !== void 0) value = Math.min(value, safeNumber(integer(sample.burnCap)));
  }
  const prevented = sample.prevention ? value : 0;
  if (sample.prevention) value = 0;
  return { raw, rawAfterCritical, prevented, mitigated: value, critical };
}
function allocateDamage(context, prepared, hp2, layers) {
  integer(hp2);
  integer(prepared.mitigated);
  let remaining = prepared.mitigated, absorbed = 0;
  const shields = layers.map((layer) => {
    integer(layer.remaining);
    const taken = Math.min(remaining, layer.remaining);
    absorbed += taken;
    remaining -= taken;
    return { ...layer, remaining: layer.remaining - taken };
  });
  const hpDamage = Math.min(hp2, remaining), overkill = remaining - hpDamage;
  return { outcome: {
    context,
    hit: true,
    raw: prepared.raw,
    prevented: prepared.prevented,
    mitigated: prepared.mitigated,
    critical: prepared.critical,
    absorbed,
    hpDamage,
    overkill,
    killingPacket: hp2 > 0 && hpDamage === hp2
  }, shields, hpAfter: hp2 - hpDamage };
}
function resolveDamage(request, sample) {
  const prepared = prepareDamage(request, sample);
  return allocateDamage(request.context, prepared, sample.target.hp, sample.shields);
}

// src/simulation/m8/heal.ts
function merge(contributions) {
  const sources = /* @__PURE__ */ new Map();
  for (const c of contributions) {
    const id2 = canonicalSource(c.source), old = sources.get(id2);
    sources.set(id2, { source: c.source, weight: addFractions(old?.weight ?? { numerator: 0n, denominator: 1n }, fraction(c.numerator, c.denominator)) });
  }
  return [...sources.entries()].sort((a, b) => compareCodePoints(a[0], b[0])).map(([, c]) => ({ source: c.source, ...savedFraction(c.weight) }));
}
function makeHealRequest(healId, targetId, kind, fromPacketId, contributions) {
  const merged = merge(contributions), sum = merged.reduce((s, c) => addFractions(s, fraction(c.numerator, c.denominator)), { numerator: 0n, denominator: 1n });
  return { healId, targetId, kind, fromPacketId, contributions: merged, requested: safeNumber(sum.numerator / sum.denominator) };
}
function apportion(total, weights, sources) {
  const sum = weights.reduce(addFractions, { numerator: 0n, denominator: 1n });
  if (sum.numerator === 0n) return weights.map(() => 0);
  const fractions = weights.map((w, index) => {
    const numerator = integer(total) * w.numerator * sum.denominator, denominator = w.denominator * sum.numerator;
    return { index, floor: numerator / denominator, numerator: numerator % denominator, denominator };
  });
  const result = fractions.map((f) => safeNumber(f.floor));
  let remaining = total - result.reduce((a, b) => a + b, 0);
  fractions.sort((a, b) => {
    const left = a.numerator * b.denominator, right = b.numerator * a.denominator;
    return (left > right ? -1 : left < right ? 1 : 0) || compareCodePoints(canonicalSource(sources[a.index]), canonicalSource(sources[b.index]));
  });
  for (const f of fractions) if (remaining-- > 0) result[f.index]++;
  return result;
}
function resolveHeal(request, target, woundBps) {
  integer(target.hp);
  integer(target.maxHp, 1);
  integer(woundBps);
  if (target.hp > target.maxHp || woundBps > 1e4) throw new RangeError("Invalid healing sample");
  const canonical = makeHealRequest(request.healId, request.targetId, request.kind, request.fromPacketId, request.contributions);
  if (canonical.requested !== request.requested) throw new RangeError("Heal requested total mismatch");
  const afterWound = safeNumber(integer(canonical.requested) * BigInt(1e4 - woundBps) / 10000n);
  const actual = target.alive && target.hp > 0 ? Math.min(afterWound, target.maxHp - target.hp) : 0;
  const sources = canonical.contributions.map((c) => c.source);
  const requestedShares = apportion(canonical.requested, canonical.contributions.map((c) => fraction(c.numerator, c.denominator)), sources);
  const allowedShares = apportion(afterWound, requestedShares.map((n) => fraction(n, 1)), sources);
  const actualShares = apportion(actual, allowedShares.map((n) => fraction(n, 1)), sources);
  return {
    ...canonical,
    afterWound,
    actual,
    overheal: afterWound - actual,
    preventedByWound: canonical.requested - afterWound,
    shares: sources.map((source, i) => ({ source, requested: requestedShares[i], afterWound: allowedShares[i], actual: actualShares[i], overheal: allowedShares[i] - actualShares[i], preventedByWound: requestedShares[i] - allowedShares[i] }))
  };
}
function selectVampAlly(holder, units) {
  return units.filter((u) => u.id !== holder.id && u.team === holder.team && u.alive && u.hp > 0).sort((a, b) => {
    const left = integer(a.hp) * integer(b.maxHp, 1), right = integer(b.hp) * integer(a.maxHp, 1);
    return (left < right ? -1 : left > right ? 1 : 0) || compareCodePoints(a.id, b.id);
  })[0];
}
function vampRequests(healId, holder, damage2, rates, units) {
  if (!holder.alive || holder.hp <= 0) return [];
  const outcomes = Array.isArray(damage2) ? damage2 : [damage2];
  const eligible = outcomes.filter((o) => o.hit && o.context.source.ownerId === holder.id && permissionsFor(o.context).includes("omnivamp"));
  const actual = safeNumber(eligible.reduce((sum, o) => sum + integer(o.absorbed) + integer(o.hpDamage), 0n));
  if (!actual) return [];
  const fromPacketId = eligible.length === 1 ? eligible[0].context.packetId : null;
  const ordered2 = [...rates].sort((a, b) => compareCodePoints(canonicalSource(a.source), canonicalSource(b.source)));
  const self = ordered2.filter((r) => r.bps > 0).map((r) => ({ source: r.source, numerator: safeNumber(integer(actual) * integer(r.bps)), denominator: 1e4 }));
  const requests = self.length ? [makeHealRequest(healId, holder.id, "omnivamp", fromPacketId, self)] : [];
  const ally = selectVampAlly(holder, units);
  const allyActual = safeNumber(eligible.filter((o) => permissionsFor(o.context).includes("gunblade-ally-heal")).reduce((sum, o) => sum + integer(o.absorbed) + integer(o.hpDamage), 0n));
  if (ally && allyActual) {
    for (const rate of ordered2) if (rate.allyBps > 0)
      requests.push(makeHealRequest(
        JSON.stringify([healId, canonicalSource(rate.source), "ally"]),
        ally.id,
        "ally-vamp",
        fromPacketId,
        [{ source: rate.source, numerator: safeNumber(integer(allyActual) * integer(rate.allyBps)), denominator: 1e4 }]
      ));
  }
  return requests;
}

// src/simulation/m8/s13-mechanisms.ts
function selectMechanismTargets(holder, units, selector2, boundTargetId, source, environment = {}) {
  const tick = environment.tick ?? holder.mechanismState?.sampledAtTick ?? 0;
  const ids2 = selectTargets(selector2, targetingEnvironment(
    environment.board ?? DEFAULT_BOARD,
    units,
    holder,
    tick,
    { source, boundTargetIds: boundTargetId ? [boundTargetId] : [], eligibility: selector2.candidates === "bound-target" ? "bound-packet" : "new-selection", ...environment }
  ));
  return ids2.map((id2) => units.find((u) => u.id === id2));
}
function endTargets(holder, ctx, targeting, area = false) {
  if (targeting.kind === "fixed") return targeting.targetIds.flatMap((id2) => ctx.units.filter((u) => u.id === id2 && u.alive && u.hp > 0));
  if (targeting.kind === "select") return selectMechanismTargets(holder, ctx.units, targeting.selector, void 0, void 0, { board: ctx.board, tick: ctx.tick, eligibility: area ? "area-hit" : "new-selection" });
  if (targeting.kind === "area-around-selected") {
    const center = selectMechanismTargets(holder, ctx.units, targeting.center, void 0, void 0, { board: ctx.board, tick: ctx.tick })[0];
    if (!center) return [];
    return ctx.units.filter((u) => u.alive && u.hp > 0 && (targeting.relation === "ally" ? u.team === holder.team : u.team !== holder.team) && hexDistance(center.cell, u.cell) <= targeting.radius).sort((a, b) => compareText(a.id, b.id));
  }
  throw new RangeError("Unsupported G07 end targeting for this batch");
}
function effectSample(holder, target, tick, frozen, absorbed) {
  const before = frozen ? { id: frozen.unitId, hp: frozen.hpAfterDamage, maxHp: frozen.maxHpBeforeThresholdEffects } : void 0;
  return { startingRows: startingRows(holder.team, holder.startingCell?.row ?? holder.cell.row) ?? void 0, holder: before?.id === holder.id ? before : hpSample(holder), target: before?.id === target.id ? before : hpSample(target), attackDamage: ad(holder), abilityPower: ap(holder, tick), ...absorbed !== void 0 ? { shieldAbsorbed: absorbed } : {} };
}
function clearMechanismTarget(ctx, unit, actionSeq) {
  const before = unit.targetId;
  if (before === null) return;
  unit.targetId = null;
  ctx.events.push({ type: "targetChanged", tick: ctx.tick, unitId: unit.id, before, after: null });
  emitMechanismSignal(ctx, { event: "target-changed", tick: ctx.tick, actionSeq, actorId: unit.id, targetId: null, cast: null });
}
function applyFrozenStatus(ctx, target, source, application, applicationId = "source", actionSeq = 0) {
  ensureMechanisms(target, ctx.tick, ctx.combatId);
  const identity = effectIdentity(target.mechanismState.combatId, source, target.id, applicationId);
  const result = applyStatusContribution(target.mechanismState.statuses, identity, application, ctx.tick);
  if (!result.accepted) return;
  target.mechanismState = { ...target.mechanismState, statuses: result.groups };
  const group = result.groups.find((g) => g.contributions.some((c) => c.key === identity.key));
  const status2 = {
    key: identity.key,
    source,
    kind: application.kind === "stun" ? "stun" : application.kind === "sunder" ? "armorReduction" : "resistanceFlat",
    amount: application.modifier?.value.kind === "constant" ? application.modifier.value.amount : application.magnitudeBps,
    startsAtTick: group.contributions.find((c) => c.key === identity.key).appliedAtTick,
    expiresAtTick: group.contributions.find((c) => c.key === identity.key).expiresAtTick ?? 1201,
    contributionKeys: [identity.key]
  };
  target.statuses = [...target.statuses.filter((s) => s.key !== status2.key), status2].sort((a, b) => compareText(a.key, b.key));
  ctx.events.push({ type: "statusChanged", tick: ctx.tick, unitId: target.id, status: status2, group, reason: "applied" });
  if (application.kind === "untargetable" && application.activation === "immediate") {
    for (const enemy of ctx.units) if (enemy.team !== target.team && enemy.targetId === target.id) {
      clearMechanismTarget(ctx, enemy, actionSeq);
    }
  }
  if (application.kind === "burn") synchronizeBurnTask(target, identity.key);
}
function synchronizeBurnTask(target, key3) {
  const group = target.mechanismState.statuses.find((g) => g.kind === "burn" && g.contributions.some((c2) => c2.key === key3));
  const c = group.contributions.find((c2) => c2.key === key3);
  const program = {
    definitionId: JSON.stringify([c.source.definitionId, c.source.effectIndex, "burn"]),
    selector: selfSelector({ candidates: "bound-target", relation: "enemy", maxTargets: 1 }),
    targetSnapshot: "once-per-pulse",
    effects: [{ kind: "damage", damageType: "true", delivery: "item-burn", critEligibility: "never", amount: flatAmount(0, { maxHpBps: c.application.magnitudeBps, hpBasis: "target", sample: "each-pulse" }) }]
  };
  const old = target.mechanismState.periodicTasks.find((t) => t.key === key3);
  const same4 = old && JSON.stringify(old.program) === JSON.stringify(program);
  const task = {
    key: key3,
    source: c.source,
    targetId: target.id,
    nextPulseAtTick: Math.max(group.nextPulseAtTick, old?.nextPulseAtTick ?? 0),
    periodTicks: 20,
    endsAtTick: c.expiresAtTick,
    pulseOrdinal: old?.pulseOrdinal ?? 0,
    pulseLimit: null,
    remainders: same4 ? old.remainders : [],
    finalPulse: "before-expiry",
    onSourceDeath: "persist-attached",
    onTargetDeath: "cancel",
    program
  };
  target.mechanismState = { ...target.mechanismState, periodicTasks: [...target.mechanismState.periodicTasks.filter((t) => t.key !== key3), task] };
}
function cancelAttachedBurns(tasks, ended) {
  return tasks.filter((task) => !ended.some((c) => c.application.kind === "burn" && task.key === c.key && task.targetId === c.targetId && canonicalSource(task.source) === canonicalSource(c.source) && task.program.definitionId === JSON.stringify([c.source.definitionId, c.source.effectIndex, "burn"])));
}
function executeDamageControlSequence(ctx, holder, source, target, effects2, seq) {
  let precedingDamage;
  for (const [ordinal, effect] of effects2.entries()) {
    const effectSource = { ...source, effectIndex: source.effectIndex + ordinal };
    if (precedingDamage && effect.kind === "apply-status" && effect.status.kind === "stun" && effect.status.activation === "next-tick") {
      (precedingDamage.afterDamageControl ??= []).push({ source: effectSource, effect, ordinal });
      continue;
    }
    executeMechanismEffect(ctx, holder, effectSource, target, effect, seq, ordinal);
    if (effect.kind === "damage") precedingDamage = ctx.packets[ctx.packets.length - 1];
  }
}
function executeMechanismEffect(ctx, holder, source, target, effect, seq, ordinal = 0, frozen, periodic2, amountOverride, absorbed, damageContext) {
  const sample = { ...effectSample(holder, target, ctx.tick, frozen, absorbed), ...damageContext?.cast ? { cast: damageContext.cast } : {}, ...damageContext?.facts?.damage.length ? { damageOutcomes: damageContext.facts.damage } : {} };
  const value = "amount" in effect && typeof effect.amount !== "number" ? amountOverride ?? evaluateAmount(effect.amount, sample) : 0;
  switch (effect.kind) {
    case "grant-mana":
      (ctx.manaRequests ??= []).push({ source, targetId: target.id, amount: effect.amount, reason: effect.reason, bypassLock: effect.bypassLock, castActionSeq: effect.reason === "cast-refund" ? seq : null });
      break;
    case "damage":
      ctx.packets.push({
        source,
        targetId: target.id,
        raw: value,
        damageType: effect.damageType,
        actionSeq: seq,
        ordinal,
        delivery: effect.delivery,
        critEligibility: effect.critEligibility,
        area: damageContext?.area ?? false,
        triggeringCastActionSeq: damageContext?.triggeringCastActionSeq ?? null,
        ...damageContext?.facts?.damage[0] ? { parentPacketId: damageContext.facts.damage[0].context.packetId, rootActionSeq: damageContext.facts.damage[0].context.rootActionSeq } : {},
        ...periodic2 ? { periodic: periodic2 } : {}
      });
      break;
    case "heal": {
      const request = makeHealRequest(JSON.stringify([ctx.combatId ?? "standalone", ctx.tick, canonicalSource(asSource(source)), target.id, seq, ordinal, "direct"]), target.id, "direct", null, [{ source, numerator: value, denominator: 1 }]);
      ctx.heals.push({ source, targetId: target.id, amount: value, request, ...periodic2 ? { periodic: periodic2 } : {} });
      break;
    }
    case "apply-status":
      applyFrozenStatus(ctx, target, source, effect.status, effect.status.stackPolicy.kind === "independent-instances" ? JSON.stringify([seq, ordinal]) : "source", seq);
      break;
    case "modify-stat": {
      const rawModifier = effect.modifier;
      const modifier2 = rawModifier.value.kind === "counter" ? { ...rawModifier, value: { kind: "constant", amount: safeNumber(integer(damageContext?.counters?.[rawModifier.value.counterId] ?? 0) * integer(rawModifier.value.perCount, Number.MIN_SAFE_INTEGER)) } } : rawModifier;
      if (modifier2.stat === "attackSpeed" && modifier2.unit === "bps" && modifier2.value.kind === "constant" && effect.duration.kind === "combat" && effect.activation === "immediate" && !damageContext?.applicationId && effect.stackPolicy.kind === "add-stacks" && effect.stackPolicy.cap === null && conditionHolds(modifier2.condition, sample)) {
        const before = target.runtime.attackSpeedBps;
        target.runtime.attackSpeedBps = safeNumber(integer(before) + integer(modifier2.value.amount));
        ctx.events.push({ type: "statChanged", tick: ctx.tick, unitId: target.id, source, stat: "attackSpeedBps", before, after: target.runtime.attackSpeedBps });
        break;
      }
      if (modifier2.stat === "abilityPower" && modifier2.unit === "flat" && modifier2.value.kind === "constant" && effect.duration.kind === "combat" && effect.activation === "immediate" && !damageContext?.applicationId && effect.stackPolicy.kind === "add-stacks" && effect.stackPolicy.cap === null && conditionHolds(modifier2.condition, sample)) {
        const before = (target.abilityPower ?? 100) + target.runtime.abilityPowerFlat;
        target.runtime.abilityPowerFlat = safeNumber(integer(target.runtime.abilityPowerFlat) + integer(modifier2.value.amount));
        ctx.events.push({ type: "statChanged", tick: ctx.tick, unitId: target.id, source, stat: "abilityPower", before, after: (target.abilityPower ?? 100) + target.runtime.abilityPowerFlat });
        break;
      }
      applyFrozenStatus(ctx, target, source, {
        kind: modifier2.value.kind === "constant" && modifier2.value.amount < 0 ? "stat-debuff" : "stat-buff",
        magnitudeBps: 0,
        duration: effect.duration,
        stackPolicy: effect.stackPolicy,
        activation: effect.activation,
        polarity: modifier2.value.kind === "constant" && modifier2.value.amount < 0 ? "harmful" : "beneficial",
        removable: modifier2.value.kind === "constant" && modifier2.value.amount < 0,
        modifier: modifier2,
        damageFilter: null,
        onEnd: null
      }, damageContext?.applicationId ?? (effect.stackPolicy.kind === "independent-instances" ? JSON.stringify([seq, ordinal]) : "source"), seq);
      break;
    }
    case "grant-shield": {
      const identity = effectIdentity(target.mechanismState.combatId, source, target.id), legacyKey = source.parentItemInstanceId === null ? sourceKey(source) : identity.key, old = target.shieldLayers.find((l) => l.key === legacyKey);
      const state = grantShieldState(identity, value, effect, ctx.tick, old ? frozenShield(old, target) : void 0);
      const layer = shieldProjection(state, legacyKey, effect);
      target.shieldLayers = [...target.shieldLayers.filter((l) => l.key !== legacyKey), layer];
      syncShield(target);
      ctx.events.push({ type: "shieldLayerChanged", tick: ctx.tick, unitId: target.id, layer, reason: "granted" });
      break;
    }
    case "change-max-hp": {
      const basis = target.maxHpBasis ?? { base: target.maxHp, flat: 0, bps: 0, bonusBps: 0 };
      const updated = { ...basis, bonusBps: basis.bonusBps + effect.bonusBps };
      const max = resolveStat("maxHp", updated.base, [constantModifier("maxHp", updated.flat), constantModifier("maxHp", updated.bps + updated.bonusBps, "bps")], { holder: hpSample(target) });
      const result = changeMaxHp(target.maxHp, target.hp, max);
      target.maxHp = max;
      target.hp = result.afterHp;
      target.maxHpBasis = updated;
      ctx.events.push({ type: "maxHpChanged", tick: ctx.tick, unitId: target.id, source, ...result });
      break;
    }
    case "cleanse": {
      const hostile = new Set(ctx.units.filter((u) => u.team !== target.team).map((u) => u.id));
      const result = cleanseStatuses(target.mechanismState.statuses, target.id, hostile, ctx.tick);
      target.mechanismState = { ...target.mechanismState, statuses: result.groups };
      const keys3 = new Set(result.ended.map((e) => e.contribution.key));
      target.statuses = target.statuses.filter((s) => !(s.contributionKeys?.some((k) => keys3.has(k)) || !s.contributionKeys && hostile.has(s.source.ownerId) && (s.kind === "stun" || s.kind === "armorReduction" || s.kind === "resistanceFlat" && s.amount < 0)));
      for (const unit of ctx.units) {
        unit.tasks = unit.tasks.filter((t) => !(t.attachedDot && t.targetId === target.id && hostile.has(t.source.ownerId)));
      }
      target.mechanismState = { ...target.mechanismState, periodicTasks: cancelAttachedBurns(target.mechanismState.periodicTasks, result.ended.map((e) => e.contribution)) };
      for (const ended of result.ended) ctx.events.push({
        type: "statusChanged",
        tick: ctx.tick,
        unitId: target.id,
        reason: "cleansed",
        group: { targetId: target.id, kind: ended.contribution.application.kind, contributions: [ended.contribution], effectiveSourceKey: null, effectiveMagnitudeBps: 0, nextPulseAtTick: null },
        status: { key: ended.contribution.key, source: ended.contribution.source, kind: "stun", amount: 0, startsAtTick: ended.contribution.appliedAtTick, expiresAtTick: ctx.tick }
      });
      clearMechanismTarget(ctx, target, seq);
      break;
    }
    default:
      throw new RangeError(`Effect ${effect.kind} belongs to a later B3 batch`);
  }
}
function initializeMechanisms(ctx) {
  const initial = [];
  for (const unit of ctx.units) {
    ensureMechanisms(unit, ctx.tick - 1, ctx.combatId);
    const state = unit.mechanismState;
    if (!state.initialized) {
      const definitions2 = unit.mechanismDefinitions ?? compileMechanismDefinitions(unit, state.combatId);
      unit.mechanismDefinitions = definitions2;
      unit.mechanismState = { ...state, initialized: true, periodicTasks: [...state.periodicTasks, ...definitions2.periodicTasks.map((t) => {
        const skipped = Math.max(0, Math.ceil((ctx.tick - t.nextPulseAtTick) / t.periodTicks));
        return { ...t, nextPulseAtTick: t.nextPulseAtTick + skipped * t.periodTicks, pulseOrdinal: t.pulseOrdinal + skipped };
      })] };
      for (const group of state.statuses) if (group.kind === "burn") for (const c of group.contributions) synchronizeBurnTask(unit, c.key);
      const sample = { unitId: unit.id, tick: ctx.tick - 1, hpBeforeDamage: unit.hp, hpAfterDamage: unit.hp, maxHpBeforeThresholdEffects: unit.maxHp, survivedDamageBatch: unit.hp > 0, receivedPositiveDamage: false };
      const keys3 = survivalConsumptionKeys(definitions2.survivalTriggers, state.combatId, unit.id);
      const eligible = consumeSurvivalTriggers(definitions2.survivalTriggers, state.runtimes, sample, state.combatId, true);
      unit.mechanismState = { ...unit.mechanismState, runtimes: eligible.runtimes, unconsumedSurvivalKeys: remainingSurvivalKeys(keys3, eligible.runtimes) };
      for (const definition of eligible.fired) initial.push({ holder: unit, definition });
    }
    unit.mechanismState = { ...unit.mechanismState, sampledAtTick: ctx.tick };
  }
  for (const { holder, definition: { definition, sample } } of initial) for (const [index, effect] of definition.effects.entries())
    executeMechanismEffect({ ...ctx, tick: sample.tick }, holder, { ...definition.source, effectIndex: definition.source.effectIndex + index }, holder, effect, 0, index, sample);
}
function maintainMechanisms(ctx, nextSeq) {
  const dead = new Set(ctx.units.filter((u) => !u.alive || u.hp <= 0).map((u) => u.id));
  const burnWinners = /* @__PURE__ */ new Map();
  for (const unit of ctx.units) for (const group of unit.mechanismState.statuses) if (group.kind === "burn" && group.nextPulseAtTick === ctx.tick)
    burnWinners.set(unit.id, summarizeGroup(group, ctx.tick, true).effectiveSourceKey);
  const executePulse = (unit, task) => {
    const advanced = advancePeriodicTask(task, ctx.tick);
    if (!advanced.due) {
      if (!advanced.task) unit.mechanismState = { ...unit.mechanismState, periodicTasks: unit.mechanismState.periodicTasks.filter((t) => t.key !== task.key) };
      return;
    }
    const burn2 = task.program.effects.some((e) => e.kind === "damage" && e.delivery === "item-burn");
    const holder = ctx.units.find((u) => u.id === task.source.ownerId);
    const payable = task.program.selector.sample !== "each-tick" && (!burn2 || burnWinners.get(unit.id) === task.key);
    let current = task;
    const seq = nextSeq(), firstPacket = ctx.packets.length;
    if (payable) {
      emitMechanismSignal(ctx, { event: "periodic", tick: ctx.tick, actionSeq: seq, actorId: holder.id, targetId: task.targetId, cast: null });
      const targets = selectMechanismTargets(holder, ctx.units, task.program.selector, task.targetId, task.source, { board: ctx.board, tick: ctx.tick });
      const samples = new Map(targets.map((t) => [t.id, effectSample(holder, t, ctx.tick)]));
      for (const target of targets) for (const [effectIndex, effect] of task.program.effects.entries()) {
        let value;
        if (effect.kind === "damage" || effect.kind === "heal" || effect.kind === "grant-shield") {
          const computed = periodicAmount(current, effectIndex, target.id, samples.get(target.id));
          current = computed.task;
          value = computed.requested;
        }
        const source = { ...task.source, effectIndex: task.source.effectIndex + effectIndex };
        executeMechanismEffect(ctx, holder, source, target, effect, seq, effectIndex, void 0, { holderId: unit.id, taskKey: task.key, effectIndex }, value);
      }
    }
    const updated = advanced.task ? { ...advanced.task, remainders: current.remainders } : null;
    unit.mechanismState = { ...unit.mechanismState, periodicTasks: [...unit.mechanismState.periodicTasks.filter((t) => t.key !== task.key), ...updated ? [updated] : []] };
    for (const packet2 of ctx.packets.slice(firstPacket).sort((a, b) => compareText(a.targetId, b.targetId) || a.ordinal - b.ordinal)) packet2.critical = rollCrit(packet2.critEligibility, spellCrit(holder), ctx.draw);
  };
  for (const unit of ctx.units) unit.mechanismState = { ...unit.mechanismState, periodicTasks: cleanPeriodicTasks(unit.mechanismState.periodicTasks, dead, dead) };
  for (const unit of ctx.units) for (const task of [...unit.mechanismState.periodicTasks].sort((a, b) => compareCodePoints(a.key, b.key)))
    if (task.finalPulse === "before-expiry" && task.endsAtTick === ctx.tick) executePulse(unit, task);
  for (const unit of ctx.units) {
    const expired = endStatuses(unit.mechanismState.statuses, ctx.tick);
    for (const status2 of unit.statuses) if (status2.contributionKeys?.some((k) => expired.ended.some((e) => e.contribution.key === k)))
      ctx.events.push({ type: "statusChanged", tick: ctx.tick, unitId: unit.id, status: status2, reason: "expired" });
    for (const ended of expired.ended) if (!unit.statuses.some((s) => s.contributionKeys?.includes(ended.contribution.key)))
      ctx.events.push({ type: "statusChanged", tick: ctx.tick, unitId: unit.id, reason: "expired", status: { key: ended.contribution.key, source: ended.contribution.source, kind: "resistanceFlat", amount: 0, startsAtTick: ended.contribution.appliedAtTick, expiresAtTick: ctx.tick }, group: { targetId: unit.id, kind: ended.contribution.application.kind, contributions: [ended.contribution], effectiveSourceKey: null, effectiveMagnitudeBps: 0, nextPulseAtTick: null } });
    unit.mechanismState = { ...unit.mechanismState, periodicTasks: cancelAttachedBurns(unit.mechanismState.periodicTasks, expired.ended.map((e) => e.contribution)), statuses: expired.groups.map((g) => summarizeGroup(g, ctx.tick)) };
    for (const ended of expired.ended) for (const [index, effect] of ended.effects.entries()) executeMechanismEffect(
      ctx,
      ctx.units.find((u) => u.id === ended.contribution.source.ownerId),
      { ...ended.contribution.source, effectIndex: ended.contribution.source.effectIndex + index + 1 },
      unit,
      effect,
      nextSeq(),
      index
    );
    unit.statuses = unit.statuses.filter((s) => !s.contributionKeys || s.contributionKeys.some((k) => unit.mechanismState.statuses.some((g) => g.contributions.some((c) => c.key === k))));
    unit.shieldLayers = unit.shieldLayers.map((layer) => {
      const maintained = maintainShield(frozenShield(layer, unit), ctx.tick);
      const next = shieldProjection(maintained.layer, layer.key, layer.m8Grant, maintained.reason ?? layer.endedReason);
      if (maintained.decayed > 0 && ctx.resolutionFacts) ctx.resolutionFacts = { ...ctx.resolutionFacts, shieldDecay: [...ctx.resolutionFacts.shieldDecay, { key: next.key, amount: maintained.decayed }] };
      if (maintained.decayed > 0) ctx.events.push({ type: "shieldLayerChanged", tick: ctx.tick, unitId: unit.id, layer: next, reason: "decayed" });
      if (maintained.reason) ctx.events.push({ type: "shieldLayerChanged", tick: ctx.tick, unitId: unit.id, layer: next, reason: maintained.reason === "expired" ? "expired" : "decayed", endReason: maintained.reason });
      return next;
    });
    syncShield(unit);
  }
  for (const unit of ctx.units) for (const task of [...unit.mechanismState.periodicTasks].sort((a, b) => compareCodePoints(a.key, b.key))) executePulse(unit, task);
  for (const unit of ctx.units) unit.mechanismState = { ...unit.mechanismState, statuses: advanceBurnClock(unit.mechanismState.statuses, unit.id, ctx.tick) };
}
function refreshMechanismAuras(ctx, applyNew = true) {
  for (const holder of ctx.units) for (const task of holder.mechanismDefinitions?.periodicTasks ?? []) {
    if (task.program.selector.sample !== "each-tick") continue;
    const targets = holder.alive && holder.hp > 0 ? selectMechanismTargets(holder, ctx.units, task.program.selector, void 0, task.source, { board: ctx.board, tick: ctx.tick }) : [];
    for (const [index, effect] of task.program.effects.entries()) {
      const source = { ...task.source, effectIndex: task.source.effectIndex + index }, sourceId = canonicalSource(source);
      for (const unit of ctx.units) {
        const removed = removeStatusContributions(unit.mechanismState.statuses, (c) => canonicalSource(c.source) === sourceId && !targets.some((t) => t.id === unit.id), holder.hp > 0 ? "expired" : "death-cleanup", ctx.tick);
        unit.mechanismState = { ...unit.mechanismState, statuses: removed.groups };
        const keys3 = new Set(removed.ended.map((e) => e.contribution.key));
        for (const status2 of unit.statuses.filter((s) => s.contributionKeys?.some((k) => keys3.has(k)))) ctx.events.push({ type: "statusChanged", tick: ctx.tick, unitId: unit.id, status: status2, reason: holder.hp > 0 ? "expired" : "death-cleanup" });
        unit.statuses = unit.statuses.filter((s) => !s.contributionKeys?.some((k) => keys3.has(k)));
      }
      for (const target of targets) if (applyNew && !target.mechanismState.statuses.some((g) => g.contributions.some((c) => canonicalSource(c.source) === sourceId)))
        executeMechanismEffect(ctx, holder, source, target, effect, 0, index);
    }
  }
}
function clearPeriodicAccount(ctx, reference, targetId) {
  const owner = ctx.units.find((u) => u.id === reference.holderId);
  owner.mechanismState = { ...owner.mechanismState, periodicTasks: owner.mechanismState.periodicTasks.map((t) => t.key === reference.taskKey ? clearRemainder(t, reference.effectIndex, targetId) : t) };
}
function executeShieldEnd(ctx, holder, legacyKey, seq, damageContext) {
  const layer = holder.shieldLayers.find((l) => l.key === legacyKey);
  if (!layer?.m8Grant) return;
  const state = frozenShield(layer, holder), reason = layer.endedReason ?? (state.expiresAtTick <= ctx.tick ? "expired" : "depleted");
  const ended = endShield(state, reason, layer.m8Grant, holder.alive && holder.hp > 0);
  const next = shieldProjection(ended.layer, layer.key, layer.m8Grant, reason);
  holder.shieldLayers = holder.shieldLayers.map((l) => l === layer ? next : l);
  if (!ended.emitEnd) return;
  emitMechanismSignal(ctx, { event: "shield-ended", tick: ctx.tick, actionSeq: seq, actorId: holder.id, targetId: holder.id, cast: null }, ctx.resolutionFacts);
  for (const target of endTargets(holder, ctx, layer.m8Grant.endTargeting, damageContext?.area)) for (const [index, effect] of ended.effects.entries()) executeMechanismEffect(
    ctx,
    holder,
    { ...state.source, effectIndex: state.source.effectIndex + index + 1 },
    target,
    effect,
    seq,
    index,
    void 0,
    void 0,
    void 0,
    state.absorbed,
    damageContext
  );
}
function settleShieldEnds(ctx, nextSeq) {
  for (const unit of ctx.units) for (const layer of [...unit.shieldLayers]) if (layer.m8Grant?.endTiming === "post-damage" && (layer.remaining === 0 || layer.expiresAtTick <= ctx.tick)) executeShieldEnd(ctx, unit, layer.key, nextSeq());
}
function settleSurvival(ctx, before, positive) {
  const frozen = survivalSamples(before, ctx.units, positive, ctx.tick), fired = [];
  for (const sample of frozen) {
    const unit = ctx.units.find((u) => u.id === sample.unitId);
    const result = consumeSurvivalTriggers(unit.mechanismDefinitions.survivalTriggers, unit.mechanismState.runtimes, sample, unit.mechanismState.combatId);
    unit.mechanismState = { ...unit.mechanismState, runtimes: result.runtimes, unconsumedSurvivalKeys: remainingSurvivalKeys(unit.mechanismState.unconsumedSurvivalKeys, result.runtimes) };
    for (const entry of result.fired) fired.push({ holder: unit, entry });
  }
  fired.sort((a, b) => compareText(canonicalSource(a.entry.definition.source), canonicalSource(b.entry.definition.source)));
  for (const { holder, entry: { definition, sample } } of fired) for (const [index, effect] of definition.effects.entries())
    executeMechanismEffect(ctx, holder, { ...definition.source, effectIndex: definition.source.effectIndex + index }, holder, effect, 0, index, sample);
}
function vampRates(unit, hp2) {
  return unit.mechanismDefinitions.vamp.map((def) => {
    const sample = { holder: { id: unit.id, hp: hp2, maxHp: unit.maxHp } };
    return { source: def.source, bps: resolveStat("omnivamp", 0, [def.modifier], sample), allyBps: conditionHolds(def.allyCondition, sample) ? def.allyBps : 0 };
  });
}
function commitMechanismHeal(ctx, entry) {
  const target = ctx.units.find((u) => u.id === entry.targetId);
  if (!target || target.hp <= 0 || !target.alive) return;
  const late = entry.lateAmount ? evaluateAmount(entry.lateAmount, { holder: hpSample(target), target: hpSample(target), attackDamage: ad(target), abilityPower: ap(target, ctx.tick) }) : entry.amount;
  const request = entry.request ?? makeHealRequest(
    JSON.stringify([ctx.combatId ?? "standalone", ctx.tick, canonicalSource(asSource(entry.source)), entry.targetId, "direct", ctx.heals.indexOf(entry)]),
    entry.targetId,
    "direct",
    null,
    [{ source: asSource(entry.source), numerator: late, denominator: 1 }]
  );
  const outcome = resolveHeal(request, target, statusMagnitude(target.mechanismState.statuses, "wound", ctx.tick));
  target.hp += outcome.actual;
  if (ctx.resolutionFacts) ctx.resolutionFacts = { ...ctx.resolutionFacts, healing: [...ctx.resolutionFacts.healing, outcome] };
  if (entry.periodic && (outcome.actual < outcome.afterWound || target.hp === target.maxHp)) clearPeriodicAccount(ctx, entry.periodic, target.id);
  ctx.events.push({ type: "heal", tick: ctx.tick, unitId: target.id, source: outcome.shares[0]?.source ?? entry.source, requested: outcome.requested, actual: outcome.actual, overheal: outcome.overheal, hp: target.hp, outcome });
}
function cleanupMechanisms(ctx, combatEnd = false) {
  const dead = new Set(ctx.units.filter((u) => u.hp <= 0 || !u.alive).map((u) => u.id));
  for (const unit of ctx.units) {
    const reason = combatEnd ? "combat-end" : "death-cleanup";
    if (combatEnd || dead.has(unit.id)) {
      for (const activity of unit.mechanismState.activities.filter((a) => a.lifecycle === "active")) {
        const status2 = unit.statuses.find((s) => s.activity?.key === activity.key);
        ctx.events.push({ type: "statusChanged", tick: ctx.tick, unitId: unit.id, status: status2, reason, activity: { ...activity, lifecycle: "ended", endedAtTick: ctx.tick, endReason: reason } });
      }
      const removed = removeStatusContributions(unit.mechanismState.statuses, () => true, reason, ctx.tick);
      for (const e of removed.ended) ctx.events.push({
        type: "statusChanged",
        tick: ctx.tick,
        unitId: unit.id,
        reason,
        status: { key: e.contribution.key, source: e.contribution.source, kind: "stun", amount: 0, startsAtTick: e.contribution.appliedAtTick, expiresAtTick: ctx.tick }
      });
      for (const layer of unit.shieldLayers) {
        const state = frozenShield(layer, unit), next = endShield(state, reason, layer.m8Grant ?? { kind: "grant-shield", amount: flatAmount(layer.granted), durationTicks: 1, decay: { kind: "none" }, onEnd: [], endTiming: "post-damage", endTargeting: { kind: "fixed", targetIds: [], ifMissing: "skip" }, endEffects: [] }, false);
        if (next.emitEnd) ctx.events.push({ type: "shieldLayerChanged", tick: ctx.tick, unitId: unit.id, layer: shieldProjection(next.layer, layer.key, layer.m8Grant, reason), reason: "expired", endReason: reason });
      }
      unit.mechanismState = { ...unit.mechanismState, statuses: [], activities: unit.mechanismState.activities.map((a) => a.lifecycle === "active" ? { ...a, lifecycle: "ended", endedAtTick: ctx.tick, endReason: reason } : a) };
    }
    unit.tasks = unit.tasks.filter((task) => !task.attachedDot || task.targetId === null || !dead.has(task.targetId));
    unit.mechanismState = { ...unit.mechanismState, periodicTasks: combatEnd ? [] : cleanPeriodicTasks(unit.mechanismState.periodicTasks, dead, dead) };
  }
  if (!combatEnd) refreshMechanismAuras(ctx, false);
}
function maintainActivities(ctx, unit, controlled) {
  unit.mechanismState = { ...unit.mechanismState, activities: unit.mechanismState.activities.map((activity) => {
    if (activity.lifecycle === "ended") return activity;
    const reason = activity.expiresAtTick <= ctx.tick ? "expired" : activity.kind === "channel" && controlled ? "control-cancelled" : null;
    if (!reason) return activity;
    const ended = { ...activity, lifecycle: "ended", endedAtTick: reason === "expired" ? activity.expiresAtTick : ctx.tick, endReason: reason };
    const status2 = unit.statuses.find((s) => s.activity?.key === activity.key);
    if (status2) ctx.events.push({ type: "statusChanged", tick: ctx.tick, unitId: unit.id, status: { ...status2, activity: ended }, reason, activity: ended });
    return ended;
  }) };
  unit.statuses = unit.statuses.filter((s) => !s.activity || unit.mechanismState.activities.some((a) => a.key === s.activity.key && a.lifecycle === "active"));
}

// src/simulation/combat-effects.ts
function stampCombatStep(state, events) {
  if (!state.strategy) return { state, events };
  const first = state.nextEventSeq ?? 0;
  return {
    state: { ...state, nextEventSeq: first + events.length },
    events: events.map((event, i) => ({ ...event, domain: "combat", combatId: state.combatId, eventSeq: first + i }))
  };
}
function invocationEvent(invocation, tick) {
  return {
    type: "effectTriggered",
    tick,
    source: { ...invocation.trigger.source },
    effectKey: invocation.trigger.key,
    action: { ...invocation.action },
    targetId: invocation.targetId
  };
}
function applyCombatStart(state) {
  if (!state.strategy || state.startEffectsApplied) return { state, events: [] };
  if (state.status === "finished") return stampCombatStep(
    { ...state, units: state.units.map((unit) => unit.ability.kind !== "s13" ? unit : { ...unit, mechanismDefinitions: compileMechanismDefinitions(unit, state.combatId), mechanismState: { ...EMPTY_MECHANISMS, initialized: true, combatId: state.combatId, sampledAtTick: 0 } }), startEffectsApplied: true },
    [{ type: "combatFinished", tick: 0, result: state.result, reason: "elimination" }]
  );
  const effects2 = [], shields = [], mana2 = [];
  const units = state.units.map((unit) => {
    const batch = projectCombatStartMana(unit);
    const { gain, after, overflow } = batch;
    if (unit.ability.kind === "s13") {
      const current = {
        ...unit,
        runtime: { ...EMPTY_RUNTIME, ...unit.runtime },
        statuses: [...unit.statuses ?? []],
        shieldLayers: [...unit.shieldLayers ?? []],
        tasks: [...unit.tasks ?? []],
        effectRuntime: batch.runtime
      };
      ensureMechanisms(current, 0, state.combatId);
      for (const invocation of batch.invocations) {
        effects2.push(invocationEvent(invocation, 0));
        const source = invocation.trigger.source;
        if (invocation.action.kind === "grantShield") grantShield(
          current,
          {
            ownerId: source.ownerId,
            sourceKind: source.sourceKind,
            definitionId: source.sourceDefinitionId,
            instanceId: source.sourceInstanceId,
            effectIndex: source.effectIndex,
            ...source.parentItemInstanceId ? { parentItemInstanceId: source.parentItemInstanceId } : {}
          },
          invocation.action.amount,
          invocation.action.durationTicks,
          0,
          shields
        );
      }
      current.mana = after;
      if (gain > 0) mana2.push({
        type: "manaChanged",
        tick: 0,
        unitId: current.id,
        before: unit.mana,
        spent: 0,
        attackGain: 0,
        damageGain: 0,
        hookGain: gain,
        overflow,
        after: current.mana
      });
      return current;
    }
    let shield2 = unit.shield, expiry = unit.shieldExpiresAtTick;
    for (const invocation of batch.invocations) {
      effects2.push(invocationEvent(invocation, 0));
      if (invocation.action.kind === "grantShield") {
        shield2 = Math.max(shield2, invocation.action.amount);
        expiry = Math.max(expiry ?? 0, invocation.action.durationTicks);
      }
    }
    if (shield2 === 0) expiry = null;
    if (shield2 !== unit.shield || expiry !== unit.shieldExpiresAtTick) shields.push({
      type: "shieldChanged",
      tick: 0,
      unitId: unit.id,
      reason: "granted",
      before: unit.shield,
      after: shield2,
      expiresAtTick: expiry
    });
    if (gain > 0) mana2.push({
      type: "manaChanged",
      tick: 0,
      unitId: unit.id,
      before: unit.mana,
      spent: 0,
      attackGain: 0,
      damageGain: 0,
      hookGain: gain,
      overflow,
      after
    });
    return { ...unit, shield: shield2, shieldExpiresAtTick: expiry, mana: after, effectRuntime: batch.runtime };
  });
  const mechanismUnits = units.filter((u) => u.ability.kind === "s13");
  if (mechanismUnits.length) {
    initializeMechanisms({ tick: 1, combatId: state.combatId, board: state.board, units: mechanismUnits, events: shields, packets: [], heals: [], draw: () => {
      throw new Error("Combat start mechanisms cannot draw RNG");
    } });
    for (const unit of mechanismUnits) unit.mechanismState = { ...unit.mechanismState, sampledAtTick: 0 };
    refreshMechanismAuras({ tick: 0, combatId: state.combatId, board: state.board, units: mechanismUnits, events: shields, packets: [], heals: [], draw: () => {
      throw new Error("Auras cannot draw RNG");
    } });
  }
  return stampCombatStep({ ...state, units, startEffectsApplied: true }, [...effects2, ...shields, ...mana2]);
}

// src/simulation/combat-damage.ts
function mitigateDamage(rawAmount, resistance) {
  if (!Number.isSafeInteger(rawAmount) || rawAmount < 0 || !Number.isSafeInteger(resistance) || resistance < 0) {
    throw new RangeError("Damage and resistance must be nonnegative safe integers");
  }
  return rawAmount === 0 ? 0 : Math.max(1, Math.floor(rawAmount * 100 / (100 + resistance)));
}
function aggregateDamagePackets(packets, units, includePackets = false) {
  const targets = new Map(units.map((unit) => [unit.id, unit]));
  const totals2 = /* @__PURE__ */ new Map();
  const sorted3 = [...packets].sort((a, b) => compareIds({ id: a.targetId }, { id: b.targetId }) || compareIds({ id: a.sourceId }, { id: b.sourceId }) || packetRank(a) - packetRank(b) || compareIds({ id: a.sourceInstanceId ?? "" }, { id: b.sourceInstanceId ?? "" }) || a.effectIndex - b.effectIndex || (a.packetOrdinal ?? 0) - (b.packetOrdinal ?? 0));
  for (const packet2 of sorted3) {
    const target = targets.get(packet2.targetId);
    if (!target || !target.alive) throw new Error(`Invalid damage target: ${packet2.targetId}`);
    const amount3 = mitigateDamage(packet2.rawAmount, packet2.damageType === "physical" ? target.armor : target.magicResist);
    const previous = totals2.get(target.id) ?? { physicalAmount: 0, magicAmount: 0, amount: 0 };
    totals2.set(target.id, {
      physicalAmount: previous.physicalAmount + (packet2.damageType === "physical" ? amount3 : 0),
      magicAmount: previous.magicAmount + (packet2.damageType === "magic" ? amount3 : 0),
      amount: previous.amount + amount3,
      ...includePackets ? { packets: [...previous.packets ?? [], { ...structuredClone(packet2), mitigated: amount3 }] } : {}
    });
  }
  return totals2;
}
function packetRank(packet2) {
  return packet2.sourceKind === "attack" ? 0 : packet2.sourceKind === "ability" ? 1 : 2 + sourceRank(packet2.sourceKind);
}

// src/simulation/m8/opening.ts
var cellKey = (c) => JSON.stringify([c.col, c.row]);
function planOpening(combatId, board, units, definitions2) {
  const initialUnits = units.map((u) => ({ id: u.id, team: u.team, cell: { ...u.cell }, hp: u.hp, maxHp: u.maxHp, alive: u.alive, untargetable: !!u.untargetable, controlled: !!u.controlled })).sort((a, b) => compareCodePoints(a.id, b.id));
  if (new Set(initialUnits.map((u) => u.id)).size !== units.length || new Set(initialUnits.filter((u) => u.alive).map((u) => cellKey(u.cell))).size !== initialUnits.filter((u) => u.alive).length) throw new RangeError("Invalid opening occupancy");
  const occupied = new Set(initialUnits.filter((u) => u.alive).map((u) => cellKey(u.cell))), reserved = /* @__PURE__ */ new Set(), owners = /* @__PURE__ */ new Set();
  const plans = [];
  for (const d of [...definitions2].sort((a, b) => compareCodePoints(a.source.ownerId, b.source.ownerId) || compareCodePoints(canonicalSource(a.source), canonicalSource(b.source)))) {
    const holder = initialUnits.find((u) => u.id === d.source.ownerId);
    if (!holder || owners.has(holder.id)) throw new RangeError("Invalid opening owner");
    owners.add(holder.id);
    const key3 = JSON.stringify([combatId, "opening", canonicalSource(d.source)]);
    const plan = { key: key3, source: d.source, kind: d.kind, from: holder.cell, to: holder.cell, aimId: null, path: [], targetIds: [], consumed: true, result: "no-target", task: null };
    if (!holder.alive || holder.controlled) {
      plans.push({ ...plan, result: "blocked" });
      continue;
    }
    const pathMembers = initialUnits.filter((u) => u.alive && u.hp > 0 && u.team !== holder.team && contains(board, u.cell));
    const enemies4 = pathMembers.filter((u) => !u.untargetable).sort((a, b) => hexDistance(holder.cell, b.cell) - hexDistance(holder.cell, a.cell) || compareCodePoints(a.id, b.id));
    if (!enemies4.length) {
      plans.push(plan);
      continue;
    }
    const free = (c) => contains(board, c) && !occupied.has(cellKey(c)) && !reserved.has(cellKey(c));
    if (d.kind === "backline-jump") {
      let chosen;
      for (const enemy of enemies4) {
        const to2 = getNeighbors(board, enemy.cell).filter(free).sort((a, b) => (holder.team === "enemy" ? b.row - a.row : a.row - b.row) || hexDistance(holder.cell, a) - hexDistance(holder.cell, b) || a.col - b.col || a.row - b.row)[0];
        if (to2) {
          chosen = { ...plan, to: to2, aimId: enemy.id, result: "moved" };
          reserved.add(cellKey(to2));
          break;
        }
      }
      plans.push(chosen ?? { ...plan, aimId: enemies4[0].id, result: "no-space" });
      continue;
    }
    const aim = enemies4[0], path2 = [];
    let reached = false;
    let at = holder.cell, direction;
    for (let step = 0; step < 4; step++) {
      const [q, r] = axial(at);
      if (sameCell(at, aim.cell)) reached = true;
      const next = reached ? direction ? offset(q + direction[0], r + direction[1]) : void 0 : getNeighbors(board, at).find((c) => hexDistance(c, aim.cell) < hexDistance(at, aim.cell));
      if (!next || !contains(board, next)) break;
      const [nq, nr] = axial(next);
      direction = [nq - q, nr - r];
      path2.push(next);
      at = next;
    }
    const last = path2.map((c, index) => free(c) ? index : -1).reduce((a, b) => Math.max(a, b), -1);
    if (last < 0) {
      plans.push({ ...plan, aimId: aim.id, result: "no-space" });
      continue;
    }
    const truncated = path2.slice(0, last + 1), to = truncated[truncated.length - 1];
    reserved.add(cellKey(to));
    const targetIds = truncated.flatMap((c) => pathMembers.filter((u) => sameCell(u.cell, c)).map((u) => u.id));
    const task = { key: JSON.stringify([key3, "damage"]), source: d.source, executeAtTick: 1, status: "pending", targetIds, effects: d.effects };
    plans.push({ ...plan, to, aimId: aim.id, path: truncated, targetIds, result: "moved", task });
  }
  return { combatId, initialUnits, plans, committed: false };
}
function commitOpening(state, units) {
  if (state.committed) return { state, units: [...units], movements: [] };
  const movements = state.plans.filter((p) => p.result === "moved").map((p) => ({ type: "movement", tick: 0, unitId: p.source.ownerId, from: p.from, to: p.to }));
  const next = units.map((u) => {
    const movement = movements.find((m) => m.unitId === u.id);
    if (movement && !sameCell(u.cell, movement.from)) throw new RangeError("Opening snapshot changed");
    return movement ? { ...u, cell: { ...movement.to } } : u;
  });
  return { state: { ...state, committed: true }, units: next, movements };
}
function advanceOpeningTasks(state, tick, units) {
  const ready = [];
  const plans = state.plans.map((p) => {
    const task = p.task;
    if (!task || task.status !== "pending" || task.executeAtTick > tick) return p;
    if (!state.committed) throw new RangeError("Uncommitted opening task");
    const owner = units.find((u) => u.id === task.source.ownerId), status2 = !owner?.alive || owner.hp <= 0 || owner.controlled ? "cancelled" : "executed";
    const next = { ...task, status: status2 };
    if (status2 === "executed") ready.push(next);
    return { ...p, task: next };
  });
  return { state: { ...state, plans }, ready };
}

// src/simulation/m8/planning.ts
function damageTypeForTarget(declared, _target, _facts) {
  return declared;
}

// src/simulation/m8/companions.ts
function freezeCompanions(combatId, members, definitions2) {
  const bindings = definitions2.map((d) => {
    const owner = members.find((m) => m.id === d.source.ownerId);
    if (!owner || owner.unitKind !== "neutral" || !owner.encounterId || !owner.monsterFamily) throw new RangeError("Missing formal neutral classification");
    if (d.maxReactions !== void 0) integer(d.maxReactions, 1);
    return {
      source: d.source,
      maxReactions: d.maxReactions ?? members.length,
      team: owner.team,
      encounterId: owner.encounterId,
      monsterFamily: owner.monsterFamily,
      effects: d.effects,
      members: members.filter((m) => m.id !== owner.id && m.unitKind === "neutral" && m.team === owner.team && m.encounterId === owner.encounterId && m.monsterFamily === owner.monsterFamily).map((m) => m.id).sort(compareCodePoints)
    };
  }).sort((a, b) => compareCodePoints(canonicalSource(a.source), canonicalSource(b.source)));
  if (new Set(bindings.map((b) => canonicalSource(b.source))).size !== bindings.length) throw new RangeError("Duplicate companion source");
  return { combatId, bindings, reactions: [] };
}
function registerDeaths(state, deaths, livingAfterCleanup) {
  const live = new Set(livingAfterCleanup), keys3 = new Set(state.reactions.map((r) => r.key)), additions = [];
  const seen = /* @__PURE__ */ new Set();
  for (const death of [...deaths].sort((a, b) => compareCodePoints(a.deadUnitId, b.deadUnitId))) {
    if (death.combatId !== state.combatId || seen.has(death.deadUnitId) || live.has(death.deadUnitId)) throw new RangeError("Invalid death batch");
    integer(death.tick);
    seen.add(death.deadUnitId);
    for (const b of state.bindings) {
      if (!live.has(b.source.ownerId) || !b.members.includes(death.deadUnitId) || b.team !== death.team || b.encounterId !== death.encounterId || b.monsterFamily !== death.monsterFamily) continue;
      const key3 = JSON.stringify([state.combatId, b.source.ownerId, canonicalSource(b.source), death.deadUnitId]);
      if (keys3.has(key3) || [...state.reactions, ...additions].filter((r) => canonicalSource(r.source) === canonicalSource(b.source)).length >= b.maxReactions) continue;
      keys3.add(key3);
      additions.push({ key: key3, source: b.source, deadUnitId: death.deadUnitId, deathEventId: death.eventId, targetId: b.source.ownerId, registeredAtTick: death.tick, executeAtTick: death.tick + 1, status: "pending", effects: b.effects });
    }
  }
  return additions.length ? { ...state, reactions: [...state.reactions, ...additions] } : state;
}
function advanceReactions(state, tick, living, combatEnded) {
  const ready = [], live = new Set(living);
  const reactions = state.reactions.map((r) => {
    if (r.status !== "pending") return r;
    if (combatEnded || !live.has(r.source.ownerId)) return { ...r, status: "cancelled" };
    if (r.executeAtTick > tick) return r;
    const next = { ...r, status: "executed" };
    ready.push(next);
    return next;
  });
  return { state: { ...state, reactions }, ready };
}

// src/simulation/combat-s13-abilities.ts
function packet(ctx, unit, target, raw, type, seq, ordinal = 0, bounce = false, area = false, triggeringCastActionSeq = seq) {
  ctx.packets.push({
    source: origin(unit),
    targetId: target.id,
    raw,
    damageType: type,
    actionSeq: seq,
    ordinal,
    delivery: "ability-direct",
    critEligibility: "requires-spell-authorization",
    area,
    triggeringCastActionSeq,
    ...bounce ? { bounce } : {}
  });
}
function addTask(unit, kind, at, targetId, value, seq, ordinal = 0, total = 1, cancellable = false) {
  unit.tasks.push({
    key: `${unit.id}:${seq}:${kind}:${ordinal}`,
    kind,
    source: origin(unit),
    executeAtTick: at,
    targetId,
    amount: value,
    ordinal,
    total,
    cancellable,
    actionSeq: seq,
    ...kind === "ireliaEnd" ? { shieldEndKey: sourceKey(origin(unit)) } : {},
    ...kind === "bleed" ? { attachedDot: true } : {}
  });
}
function replaceEndTask(unit, kind, at, value, seq) {
  unit.tasks = unit.tasks.filter((t) => t.kind !== kind);
  addTask(unit, kind, at, null, value, seq);
}
function planS13Cast(ctx, unit, target, seq) {
  const { tick, units, events } = ctx, source = origin(unit), v = (key3, fallback = 0) => variable(unit, key3, fallback);
  const mag = (key3) => amount2(unit, tick, { ap: v(key3) });
  const physical = (key3, apKey) => amount2(unit, tick, { ad: v(key3), ap: apKey ? v(apKey) : 0 });
  const duration2 = (key3, fallback = 4) => Math.round(v(key3, fallback) * 20);
  const targets = [];
  const hit = (enemy, value, type = "magic", bounce = false) => {
    packet(
      ctx,
      unit,
      enemy,
      value,
      type,
      seq,
      targets.length,
      bounce,
      ["darius", "urgot", "rell", "scar", "ezreal", "garen"].includes(champion(unit))
    );
    targets.push(enemy.id);
  };
  const shield2 = (ally, value, ticks, decay = false) => {
    grantShield(ally, source, value, tick + ticks, tick, events, decay);
    targets.push(ally.id);
  };
  switch (champion(unit)) {
    case "irelia": {
      const ticks = duration2("ShieldDuration", 3);
      shield2(unit, mag("ShieldHealth"), ticks, true);
      const layer = unit.shieldLayers.find((l) => l.key === sourceKey(source));
      unit.shieldLayers = unit.shieldLayers.map((l) => l !== layer ? l : { ...l, m8Grant: {
        ...l.m8Grant,
        onEnd: ["depleted", "expired"],
        endTargeting: { kind: "select", selector: { primary: "normal", candidates: "board", relation: "enemy", anchor: "holder", radius: 1, maxTargets: 100, excludeSelf: true, excludePrimary: false, distinct: true, order: "id", sample: "action-completion" } },
        endEffects: [{ kind: "damage", damageType: "magic", delivery: "ability-direct", critEligibility: "requires-spell-authorization", amount: flatAmount(mag("StrikeBaseDamage"), { shieldAbsorbedBps: Math.round(v("PercentShieldDamage", 0.3) * 1e4), sample: "packet" }) }]
      } });
      replaceEndTask(unit, "ireliaEnd", tick + ticks, mag("StrikeBaseDamage"), seq);
      break;
    }
    case "maddie": {
      const far = byDistance(unit, enemies3(unit, units), true)[0];
      if (!far) break;
      const shots = [0, 4, 9, 13, 18, 23];
      shots.forEach((offset2, n) => addTask(unit, "maddie", tick + offset2, far.id, physical("PercentAttackDamage", "APDamage"), seq, n, shots.length, true));
      applyStatus(unit, source, "channel", 0, 24, tick, events, true, "", seq);
      targets.push(far.id);
      break;
    }
    case "darius": {
      for (const enemy of neighborsOf(unit, units)) hit(enemy, physical("PercentAttackDamage"), "physical");
      ctx.heals.push({ source, targetId: unit.id, amount: mag("Heal") });
      const total = physical("BleedPercentAttackDamage");
      unit.tasks = unit.tasks.filter((t) => t.kind !== "bleed" || t.targetId !== target.id);
      for (let n = 0; n < 4; n++) addTask(
        unit,
        "bleed",
        tick + (n + 1) * 20,
        target.id,
        splitTotal(total, 4)[n],
        seq,
        n,
        4
      );
      break;
    }
    case "lux": {
      const ally = lowestAlly(unit, units, true);
      shield2(ally, mag("Shield"), duration2("ShieldDuration"));
      unit.runtime.nextAttackMagic = mag("Damage");
      break;
    }
    case "zyra": {
      hit(target, mag("TargetDamage"));
      applyStatus(target, source, "stun", 0, duration2("StunDuration", 1), tick, events);
      for (const enemy of byDistance(unit, enemies3(unit, units).filter((u) => u.id !== target.id)).slice(0, v("NumSmallerVines", 2))) hit(enemy, mag("AOEDamage"));
      break;
    }
    case "tristana":
      hit(target, physical("PercentAttackDamage", "APDamage"), "physical", true);
      break;
    case "urgot": {
      for (const enemy of areaEnemies(unit, units).filter((u) => hexDistance(target.cell, u.cell) <= 1)) {
        hit(enemy, physical(enemy.id === target.id ? "PrimaryDamage" : "SecondaryDamage", "APDamage"), "physical");
        applyStatus(enemy, source, "armorReduction", 2e3, duration2("Duration", 6), tick, events);
      }
      break;
    }
    case "rell": {
      shield2(unit, mag("Shield"), duration2("ShieldDuration"));
      const cells = path(ctx.board, unit.cell, target.cell);
      const hitUnits = areaEnemies(unit, units).filter((u) => cells.some((c) => c.col === u.cell.col && c.row === u.cell.row));
      const steal = v("DefensesSteal");
      for (const enemy of hitUnits) {
        hit(enemy, mag("StabDamage"));
        applyStatus(enemy, source, "resistanceFlat", -steal, 1200, tick, events, false, JSON.stringify([seq, enemy.id]));
        applyStatus(unit, source, "resistanceFlat", steal, 1200, tick, events, false, JSON.stringify([seq, enemy.id]));
      }
      break;
    }
    case "leona": {
      const ticks = duration2("Duration", 3);
      applyStatus(unit, source, "damageReduction", Math.min(1e4, Math.round(v("DR") * ap(unit, tick) * 100)), ticks, tick, events, true);
      replaceEndTask(unit, "leonaEnd", tick + ticks, mag("Damage"), seq);
      break;
    }
    case "vander": {
      const ticks = duration2("TauntDuration", 2.5);
      applyStatus(unit, source, "channel", 0, ticks, tick, events, true, "", seq);
      applyStatus(unit, source, "resistanceFlat", mag("Resists"), ticks, tick, events, true);
      unit.runtime.nextAttackPhysical = amount2(unit, tick, { ad: v("PercentAttackDamage") + v("BonusDamageADRatio") * mechanic(unit, "lowCostAllies", "count") });
      targets.push(unit.id);
      break;
    }
    case "kogmaw": {
      const speedBefore = unit.runtime.attackSpeedBps, rangeBefore = range(unit);
      unit.runtime.attackSpeedBps += Math.round(v("AttackSpeed", 0.25) * 1e4);
      if (unit.runtime.castCount % v("RangeIncreaseNumAttacks", 3) === 0) unit.runtime.rangeBonus++;
      events.push({ type: "statChanged", tick, unitId: unit.id, source, stat: "attackSpeedBps", before: speedBefore, after: unit.runtime.attackSpeedBps });
      if (rangeBefore !== range(unit)) events.push({
        type: "statChanged",
        tick,
        unitId: unit.id,
        source,
        stat: "range",
        before: rangeBefore,
        after: range(unit)
      });
      targets.push(unit.id);
      break;
    }
    case "scar": {
      for (const enemy of byDistance(unit, enemies3(unit, units)).slice(0, v("NumEnemies", 3))) {
        hit(enemy, mag("Damage"));
        applyStatus(enemy, source, "stun", 0, duration2("StunDuration", 1.5), tick, events);
      }
      ctx.heals.push({ source, targetId: unit.id, amount: mag("Heal") });
      break;
    }
    case "ezreal": {
      for (const enemy of areaEnemies(unit, units).filter((u) => hexDistance(target.cell, u.cell) <= 1)) hit(enemy, physical("PercentAttackDamage", "APDamage"), "physical");
      hit(target, physical("PercentCenterDamage"), "physical");
      break;
    }
    case "loris": {
      const ticks = duration2("Duration");
      shield2(unit, mag("Shield"), ticks);
      applyStatus(unit, source, "redirect", Math.round(v("PercentDamageRedirect", 0.5) * 1e4), ticks, tick, events, true, "", seq);
      replaceEndTask(unit, "lorisEnd", tick + ticks, mag("Damage"), seq);
      break;
    }
    case "nami": {
      let current = target;
      const seen = /* @__PURE__ */ new Set();
      for (let n = 0; n <= v("NumBounces", 3); n++) {
        hit(current, mag("Damage"));
        seen.add(current.id);
        const next = byDistance(current, enemies3(unit, units).filter((u) => !seen.has(u.id) && hexDistance(current.cell, u.cell) <= v("SearchRange", 3)))[0];
        if (!next) break;
        current = next;
      }
      break;
    }
    case "corki": {
      const total = v("BaseMissiles", 21);
      for (let n = 0; n < total; n++) {
        const mult = (n + 1) % v("SpecialMissileNum", 7) === 0 ? v("SpecialMissileMult", 7) : 1;
        addTask(
          unit,
          "corki",
          tick + n,
          target.id,
          amount2(unit, tick, { ad: v("PercentAD") * mult, flat: v("FlatDamagePerMissile") * mult }),
          seq,
          n,
          total,
          true
        );
      }
      applyStatus(unit, source, "channel", 0, total, tick, events, true, "", seq);
      targets.push(target.id);
      break;
    }
    case "garen": {
      shield2(unit, amount2(unit, tick, { ap: v("APShield"), hp: v("PercentHealthShield") }), duration2("ShieldDuration"));
      for (const enemy of areaEnemies(unit, units).filter((u) => hexDistance(target.cell, u.cell) <= 2)) hit(
        enemy,
        physical(enemy.id === target.id ? "ADRatio" : "SecondaryADRatio"),
        "physical"
      );
      break;
    }
    case "zoe": {
      hit(target, mag("Damage"));
      const seen = /* @__PURE__ */ new Set([target.id]);
      for (let n = 0; n < v("NumRepeats", 2); n++) {
        const next = byDistance(target, enemies3(unit, units).filter((u) => !seen.has(u.id) && hexDistance(target.cell, u.cell) <= v("HexLimiter", 4)), true)[0];
        if (!next) break;
        hit(next, mag("Damage"));
        seen.add(next.id);
        hit(target, mag("Damage"));
      }
      break;
    }
    case "caitlyn": {
      const total = v("TotalShots", 4), ticks = duration2("RaidDuration", 5);
      for (let n = 0; n < total; n++) addTask(
        unit,
        "caitlyn",
        tick + Math.floor(n * ticks / total),
        null,
        physical("PercentAttackDamage", "APDamage"),
        seq,
        n,
        total,
        true
      );
      applyStatus(unit, source, "channel", 0, ticks, tick, events, true, "", seq);
      targets.push(target.id);
      break;
    }
  }
  return targets;
}
function executeTask(ctx, unit, task) {
  if (task.kind === "tristanaBounce" && !task.inherited) throw new RangeError("Missing inherited Tristana receipt");
  const opponents = enemies3(unit, ctx.units), target = (task.attachedDot || task.inherited ? areaEnemies(unit, ctx.units) : opponents).find((u) => u.id === task.targetId);
  const emit = (u, value, type = "physical", ordinal = task.ordinal) => {
    ctx.packets.push({
      source: task.source,
      targetId: u.id,
      raw: value,
      damageType: type,
      actionSeq: task.actionSeq,
      ordinal,
      delivery: task.kind === "bleed" ? "ability-periodic" : "ability-direct",
      critEligibility: task.kind === "tristanaBounce" ? "never" : "requires-spell-authorization",
      area: ["caitlyn", "ireliaEnd", "leonaEnd", "lorisEnd"].includes(task.kind),
      triggeringCastActionSeq: task.actionSeq,
      ...task.kind === "tristanaBounce" ? { inherited: task.inherited } : {}
    });
  };
  switch (task.kind) {
    case "bleed":
      if (target) emit(target, task.amount);
      break;
    case "tristanaBounce":
      if (target) emit(target, task.amount);
      break;
    case "maddie": {
      const aim = target ?? byDistance(unit, opponents, true)[0];
      if (!aim) break;
      const line = path(ctx.board, unit.cell, aim.cell);
      const intercepted = line.map((c) => opponents.find((u) => u.cell.col === c.col && u.cell.row === c.row)).find(Boolean);
      if (intercepted) emit(intercepted, task.amount);
      break;
    }
    case "corki": {
      const aim = target ?? byDistance(unit, opponents)[0];
      if (!aim) break;
      const choices = [aim, ...opponents.filter((u) => u.id !== aim.id && hexDistance(u.cell, aim.cell) <= 2).sort((a, b) => a.id < b.id ? -1 : 1)];
      const hit = choices[task.ordinal % choices.length];
      emit(hit, task.amount);
      const shred = variable(unit, "FlatArmorShred", 1) * ((task.ordinal + 1) % 7 === 0 ? 7 : 1);
      applyStatus(hit, task.source, "resistanceFlat", -shred, 1200, ctx.tick, ctx.events, false, `armor:${task.actionSeq}:${task.ordinal}`);
      break;
    }
    case "caitlyn": {
      if (opponents.length === 0) break;
      const env = targetingEnvironment(ctx.board, ctx.units, unit, ctx.tick);
      const centerId = chooseRandomCenter(env, ctx.draw);
      const selected = selectAbilityTargets({ kind: "random-enemy-center", areaOrder: "id", radius: 1, rng: "combat", mapping: "word-modulo-id-sorted-count", draws: 1 }, { ...env, randomCenterId: centerId });
      const center = ctx.units.find((u) => u.id === selected.centerId);
      for (const id2 of selected.targetIds) emit(ctx.units.find((u) => u.id === id2), task.amount, "physical", task.ordinal * 100);
      emit(center, amount2(unit, ctx.tick, { ad: variable(unit, "HeadshotPercentAD") }), "physical", task.ordinal * 100 + 1);
      applyStatus(center, task.source, "resistanceFlat", -variable(unit, "ResistReduction", 20), 1200, ctx.tick, ctx.events, false, `${task.actionSeq}:${task.ordinal}`);
      break;
    }
    case "ireliaEnd":
      executeShieldEnd(ctx, unit, task.shieldEndKey ?? sourceKey(task.source), task.actionSeq, { area: true, triggeringCastActionSeq: task.actionSeq });
      break;
    case "leonaEnd":
      for (const enemy of neighborsOf(unit, ctx.units)) emit(enemy, task.amount, "magic");
      break;
    case "lorisEnd": {
      const center = byDistance(unit, opponents)[0];
      if (!center) break;
      for (const enemy of areaEnemies(unit, ctx.units).filter((u) => hexDistance(center.cell, u.cell) <= 1)) emit(enemy, task.amount, "magic");
      break;
    }
  }
}
function planS13Attack(ctx, unit, target, seq) {
  const source = { ...origin(unit), sourceKind: "attack" }, base = unit.runtime.nextAttackPhysical || ad(unit);
  ctx.packets.push({
    source,
    targetId: target.id,
    raw: base,
    damageType: "physical",
    actionSeq: seq,
    ordinal: 0,
    delivery: "basic-attack",
    critEligibility: "basic",
    area: false,
    triggeringCastActionSeq: null
  });
  if (unit.attackCone) {
    const ids2 = selectConeTargets(targetingEnvironment(ctx.board, ctx.units, unit, ctx.tick, { primaryId: target.id }));
    const raw = safeNumber(integer(base) * integer(unit.attackCone.secondaryDamageBps) / 10000n);
    for (const [index, id2] of ids2.entries()) ctx.packets.push({ source: origin(unit), targetId: id2, raw, damageType: "physical", actionSeq: seq, rootActionSeq: seq, parentPacketId: JSON.stringify([ctx.combatId ?? "standalone", ctx.tick, unit.id, seq, target.id, 0]), ordinal: 100 + index, delivery: "ability-direct", critEligibility: "never", area: true, triggeringCastActionSeq: null });
  }
  unit.runtime.nextAttackPhysical = 0;
  if (unit.runtime.nextAttackMagic > 0) {
    packet(ctx, unit, target, unit.runtime.nextAttackMagic, "magic", seq, 1, false, false, null);
    unit.runtime.nextAttackMagic = 0;
  }
  if (champion(unit) === "kogmaw") packet(ctx, unit, target, amount2(unit, ctx.tick, { ap: variable(unit, "DamageOnAttack") }), "magic", seq, 2, false, false, null);
  let ordinal = 3;
  for (const effect of [...unit.mechanics ?? []].sort((a, b) => compareOrigins(a.source, b.source))) {
    if (effect.mechanic === "artillery" && unit.runtime.attackCount % (effect.values.everyN ?? 5) === 0 || effect.mechanic === "titanic") {
      const bps = effect.values.adBps ?? (effect.mechanic === "artillery" ? 12500 : 4e3);
      for (const enemy of areaEnemies(unit, ctx.units).filter((u) => hexDistance(target.cell, u.cell) <= 1))
        ctx.packets.push({
          source: effect.source,
          targetId: enemy.id,
          raw: Math.floor(ad(unit) * bps / 1e4),
          damageType: "physical",
          actionSeq: seq,
          ordinal: ordinal++,
          delivery: "attack-extra",
          critEligibility: "never",
          area: true,
          triggeringCastActionSeq: null
        });
    }
  }
}

// src/simulation/combat-s13.ts
function key2(cell) {
  return `${cell.col}:${cell.row}`;
}
function move(state, unit, target, occupied) {
  const seen = /* @__PURE__ */ new Set([key2(unit.cell)]), queue = [{ cell: unit.cell }];
  for (let i = 0; i < queue.length; i++) for (const cell of getNeighbors(state.board, queue[i].cell)) {
    if (seen.has(key2(cell)) || occupied.has(key2(cell))) continue;
    seen.add(key2(cell));
    const first = queue[i].first ?? cell;
    if (hexDistance(cell, target.cell) <= range(unit)) return first;
    queue.push({ cell, first });
  }
  return void 0;
}
function defenses(unit, physical, tick, units) {
  const stat2 = physical ? "armor" : "magicResist";
  const modifiers = [...statusModifiers(unit, stat2, tick), ...active(unit, tick, "resistanceFlat").filter((s) => !s.contributionKeys && (physical || !s.key.includes(":armor:"))).map((s) => constantModifier(stat2, s.amount))];
  for (const m of unit.mechanics ?? []) if (m.mechanic === "gargoyle") modifiers.push({
    ...constantModifier(stat2, 0),
    value: { kind: "unit-count", perUnit: m.values.resistPerEnemy, population: "alive-enemies-targeting-holder", sample: "current", distinctBy: "unitId" }
  });
  const shred = Math.max(statusMagnitude(unit.mechanismState?.statuses ?? [], physical ? "sunder" : "shred", tick), ...physical ? active(unit, tick, "armorReduction").filter((s) => !s.contributionKeys).map((s) => s.amount) : [0]);
  modifiers.push(constantModifier(stat2, -shred, "bps"));
  return resolveStat(stat2, physical ? unit.armor : unit.magicResist, modifiers, {
    holder: hpSample(unit),
    startingRows: startingRows(unit.team, unit.startingCell?.row ?? unit.cell.row) ?? void 0,
    enemiesTargetingHolder: units.filter((u) => u.alive && u.team !== unit.team && u.targetId === unit.id).map((u) => u.id)
  });
}
function damageRequest(packet2, combatId, tick) {
  const partial = {
    source: asSource(packet2.source),
    targetId: packet2.targetId,
    damageType: packet2.damageType,
    delivery: packet2.delivery,
    actionSeq: packet2.actionSeq,
    rootActionSeq: packet2.rootActionSeq ?? packet2.actionSeq,
    parentPacketId: packet2.inherited?.parentPacketId ?? packet2.parentPacketId ?? null,
    triggeringCastActionSeq: packet2.triggeringCastActionSeq,
    packetId: JSON.stringify([combatId, tick, packet2.source.ownerId, packet2.actionSeq, packet2.targetId, packet2.ordinal]),
    packetOrdinal: packet2.ordinal,
    equipmentDepth: packet2.delivery === "equipment-proc" || packet2.delivery === "item-burn" ? 1 : 0,
    redirected: false,
    area: packet2.area,
    critEligibility: packet2.critEligibility,
    permissions: []
  };
  const context = { ...partial, permissions: permissionsFor(partial) };
  return { context, input: packet2.inherited ? { stage: "after-mitigation", amount: packet2.raw, inherited: packet2.inherited } : { stage: "raw", amount: {
    flat: packet2.raw,
    attackDamageBps: 0,
    abilityPowerBps: 0,
    maxHpBps: 0,
    missingHpBps: 0,
    actualManaSpentBps: 0,
    actualDamageBps: 0,
    shieldAbsorbedBps: 0,
    hpBasis: "holder",
    sample: "packet",
    cap: null
  } } };
}
function damageSample(packet2, target, owner, tick, units, hp2) {
  const amplifiers = owner ? [...statusModifiers(owner, "damageAmp", tick)] : [];
  if (owner) for (const m of owner.mechanics ?? []) {
    if (m.mechanic === "damageAmp") amplifiers.push(constantModifier("damageAmp", m.values.bps, "bps"));
    if (m.mechanic === "sniper") amplifiers.push(constantModifier("damageAmp", m.values.damageBpsPerHex * hexDistance(owner.cell, target.cell), "bps"));
    if (m.mechanic === "glassCannon") amplifiers.push(constantModifier("damageAmp", m.values.damageAmpBps, "bps"));
  }
  const reduction = (bps) => ({
    ...constantModifier("damageReduction", bps, "bps"),
    damageFilter: { deliveries: "all", damageTypes: ["physical", "magic"], redirected: "exclude" }
  });
  const reductions = [...statusModifiers(target, "damageReduction", tick), ...active(target, tick, "damageReduction").filter((s) => !s.contributionKeys).map((s) => reduction(s.amount)), ...(target.mechanismState?.statuses ?? []).filter((g) => g.kind === "damage-reduction").flatMap((g) => g.contributions.filter((c) => isEffective(c, tick)).map((c) => ({ ...constantModifier("damageReduction", c.application.magnitudeBps, "bps"), damageFilter: c.application.damageFilter })))];
  for (const m of target.mechanics ?? []) if (m.mechanic === "watcher") reductions.push(reduction(
    BigInt(target.hp) * 10000n > BigInt(target.maxHp) * BigInt(m.values.thresholdBps) ? m.values.healthyReductionBps : m.values.reductionBps
  ));
  return {
    holder: hpSample(owner ?? target),
    target: { ...hpSample(target), hp: hp2 },
    attackDamage: owner ? ad(owner) : 0,
    abilityPower: owner ? ap(owner, tick) : 0,
    armor: defenses(target, true, tick, units),
    magicResist: defenses(target, false, tick, units),
    amplifiers,
    reductions,
    prevention: effectiveStatuses(target.mechanismState?.statuses ?? [], tick).some((g) => g.kind === "damage-prevention"),
    ...packet2.delivery === "item-burn" && champion(target) === "neutral" ? { burnCap: 100 } : {},
    critical: packet2.critical ?? false,
    critMultiplierBps: owner ? spellCrit(owner).multiplierBps : S13_COMBAT_RULES.critMultiplierBps,
    shields: [...target.shieldLayers].sort((a, b) => a.expiresAtTick - b.expiresAtTick || compareText(frozenShield(a, target).key, frozenShield(b, target).key))
  };
}
function advanceS13Tick(state) {
  const tick = state.tick + 1, events = [];
  const units = state.units.map((unit) => {
    const copy = structuredClone({
      ...unit,
      ...unit.mechanismDefinitions ? { mechanismDefinitions: void 0 } : {},
      ...unit.mechanismState ? { mechanismState: void 0 } : {},
      ...unit.triggerLedger ? { triggerLedger: void 0 } : {}
    });
    return {
      ...copy,
      ...unit.mechanismDefinitions ? { mechanismDefinitions: unit.mechanismDefinitions } : {},
      ...unit.mechanismState ? { mechanismState: unit.mechanismState } : {},
      ...unit.triggerLedger ? { triggerLedger: unit.triggerLedger } : {},
      startingCell: unit.startingCell ?? { ...unit.cell },
      runtime: { ...EMPTY_RUNTIME, ...copy.runtime },
      statuses: copy.statuses ?? [],
      shieldLayers: copy.shieldLayers ?? [],
      tasks: copy.tasks ?? [],
      cooldownTicks: unit.alive ? Math.max(0, unit.cooldownTicks - 1) : 0,
      moveCooldownTicks: unit.alive ? Math.max(0, unit.moveCooldownTicks - 1) : 0
    };
  }).sort(compareIds);
  let rngState = state.rngState ?? 0, rngDraws = state.rngDraws ?? 0, actionSeq = state.nextActionSeq ?? 0;
  const ctx = { manaRequests: [], castReceipts: [], resolutionFacts: EMPTY_FACTS, nextTriggerEventSeq: state.nextTriggerEventSeq ?? 0, tick, combatId: state.combatId ?? "standalone", board: state.board, units, events, packets: [], heals: [], draw: () => {
    const next = nextRandom(rngState);
    rngState = next.state;
    rngDraws++;
    return next.word;
  } };
  initializeMechanisms(ctx);
  if (state.tick === 0) {
    ctx.tick = 0;
    for (const unit of units) unit.mechanismState = { ...unit.mechanismState, sampledAtTick: 0 };
    for (const unit of units) emitMechanismSignal(ctx, { event: "combat-start", tick: 0, actionSeq: 0, actorId: unit.id, targetId: unit.id, cast: null });
    ctx.tick = tick;
    for (const unit of units) unit.mechanismState = { ...unit.mechanismState, sampledAtTick: tick };
  }
  let openingState = state.openingState;
  const openingUnits = (atTick = tick) => units.map((u) => ({ ...targetUnit(u, atTick), controlled: active(u, atTick, "stun").length > 0 || effectiveStatuses(u.mechanismState.statuses, atTick).some((g) => g.kind === "stun") }));
  if (state.openingDefinitions?.length && !openingState) {
    if (state.tick !== 0) throw new RangeError("Missing consumed opening state");
    openingState = planOpening(ctx.combatId, ctx.board, openingUnits(state.tick), state.openingDefinitions);
  }
  if (openingState && !openingState.committed) {
    const committed = commitOpening(openingState, units);
    openingState = committed.state;
    for (const u of units) u.cell = committed.units.find((next) => next.id === u.id).cell;
    events.push(...committed.movements);
  }
  const companionDefinitions = units.flatMap((u) => u.companionDefinitions ?? []);
  let companionState = state.companionState ?? (companionDefinitions.length ? freezeCompanions(ctx.combatId, units.filter((u) => u.alive), companionDefinitions) : void 0);
  if (companionState) {
    const reactions = advanceReactions(companionState, tick, units.filter((u) => u.alive && u.hp > 0).map((u) => u.id), false);
    companionState = reactions.state;
    for (const reaction of reactions.ready) {
      const holder = units.find((u) => u.id === reaction.targetId);
      for (const [index, effect] of reaction.effects.entries()) {
        const source = { ...reaction.source, effectIndex: reaction.source.effectIndex + index };
        if (effect.kind === "heal") ctx.heals.push({ source, targetId: holder.id, amount: 0, lateAmount: effect.amount, reactionKey: reaction.key });
        else executeMechanismEffect(ctx, holder, source, holder, { ...effect, activation: "immediate", stackPolicy: { kind: "independent-instances" } }, actionSeq++, index, void 0, void 0, void 0, void 0, { area: false, triggeringCastActionSeq: null, applicationId: reaction.deadUnitId });
      }
    }
  }
  const startHp = new Map(units.map((u) => [u.id, u.hp])), manaBefore = new Map(units.map((u) => [u.id, u.mana]));
  const spent = /* @__PURE__ */ new Map(), attackMana = /* @__PURE__ */ new Map(), killMana = /* @__PURE__ */ new Map();
  const hookMana = /* @__PURE__ */ new Map();
  const hooks = (unit, hook, seq) => {
    const batch = collectTriggers(unit.triggers ?? [], unit.effectRuntime ?? [], hook, unit.id, unit.targetId);
    unit.effectRuntime = batch.runtime;
    batch.invocations.forEach((invocation, index) => {
      events.push(invocationEvent(invocation, tick));
      const original = invocation.trigger.source;
      const source = {
        ownerId: original.ownerId,
        sourceKind: original.sourceKind,
        definitionId: original.sourceDefinitionId,
        instanceId: original.sourceInstanceId,
        effectIndex: original.effectIndex,
        ...original.parentItemInstanceId ? { parentItemInstanceId: original.parentItemInstanceId } : {}
      };
      const target = units.find((u) => u.id === invocation.targetId);
      if (invocation.action.kind === "gainMana") hookMana.set(unit.id, (hookMana.get(unit.id) ?? 0) + invocation.action.amount);
      else if (target && invocation.action.kind === "grantShield") grantShield(target, source, invocation.action.amount, tick + invocation.action.durationTicks, tick, events);
      else if (target && invocation.action.kind === "dealDamage") ctx.packets.push({
        source,
        targetId: target.id,
        raw: invocation.action.amount,
        damageType: invocation.action.damageType,
        actionSeq: seq,
        ordinal: 1e5 + index,
        delivery: source.sourceKind === "item" ? "equipment-proc" : "attack-extra",
        critEligibility: "never",
        area: false,
        triggeringCastActionSeq: invocation.trigger.hook === "onCast" ? seq : null
      });
    });
  };
  maintainMechanisms(ctx, () => actionSeq++);
  const blocked = /* @__PURE__ */ new Set();
  for (const unit of units) {
    for (const status2 of unit.statuses.filter((s) => !s.contributionKeys && !s.activity && s.expiresAtTick <= tick)) events.push({ type: "statusChanged", tick, unitId: unit.id, status: status2, reason: "expired" });
    unit.statuses = unit.statuses.filter((s) => s.activity || s.expiresAtTick > tick);
    const controlled = active(unit, tick, "stun").length > 0 || effectiveStatuses(unit.mechanismState.statuses, tick).some((g) => g.kind === "stun");
    maintainActivities(ctx, unit, controlled);
    if (controlled) {
      blocked.add(unit.id);
      unit.tasks = unit.tasks.filter((t) => !t.cancellable);
    }
  }
  const occupied = new Set(units.filter((u) => u.alive).map((u) => key2(u.cell))), reserved = /* @__PURE__ */ new Set();
  const intents = units.map((unit) => {
    if (!unit.alive || blocked.has(unit.id) || active(unit, tick, "channel").length > 0) return void 0;
    const target = byDistance(unit, enemies3(unit, units))[0];
    if (!target || unit.moveCooldownTicks > 0 || hexDistance(unit.cell, target.cell) <= range(unit)) return void 0;
    return move(state, unit, target, occupied);
  });
  units.forEach((unit, n) => {
    const destination = intents[n];
    if (!destination || reserved.has(key2(destination))) return;
    reserved.add(key2(destination));
    events.push({ type: "movement", tick, unitId: unit.id, from: unit.cell, to: destination });
    unit.cell = destination;
    unit.moveCooldownTicks = MOVE_INTERVAL_TICKS;
  });
  refreshMechanismAuras(ctx);
  if (openingState) {
    const advanced = advanceOpeningTasks(openingState, tick, openingUnits());
    openingState = advanced.state;
    for (const task of advanced.ready) {
      const holder = units.find((u) => u.id === task.source.ownerId), seq = actionSeq++;
      for (const id2 of task.targetIds) {
        const target = units.find((u) => u.id === id2 && u.alive && u.hp > 0);
        if (!target) continue;
        executeDamageControlSequence(ctx, holder, task.source, target, task.effects, seq);
      }
    }
  }
  for (const unit of units) {
    const firstPacket = ctx.packets.length;
    const target = byDistance(unit, enemies3(unit, units))[0];
    if (unit.alive && unit.targetId !== (target?.id ?? null)) events.push({ type: "targetChanged", tick, unitId: unit.id, before: unit.targetId, after: target?.id ?? null });
    const previousTarget = unit.targetId;
    unit.targetId = unit.alive ? target?.id ?? null : null;
    if (unit.alive && previousTarget !== unit.targetId) emitMechanismSignal(ctx, { event: "target-changed", tick, actionSeq, actorId: unit.id, targetId: unit.targetId, cast: null });
    const due = unit.tasks.filter((t) => t.executeAtTick <= tick || t.shieldEndKey !== void 0 && unit.shieldLayers.find((s) => s.key === t.shieldEndKey)?.remaining === 0);
    unit.tasks = unit.tasks.filter((t) => !due.includes(t));
    for (const task of due) if ((!task.cancellable || unit.alive && !blocked.has(unit.id)) && (unit.alive || task.attachedDot || task.kind === "tristanaBounce")) executeTask(ctx, unit, task);
    const rollPlannedPackets = () => {
      const authorization = spellCrit(unit);
      const planned = ctx.packets.slice(firstPacket).sort((a, b) => a.actionSeq - b.actionSeq || compareText(a.targetId, b.targetId) || a.ordinal - b.ordinal);
      for (const packet2 of planned) packet2.critical = packet2.inherited ? packet2.inherited.critical : rollCrit(packet2.critEligibility, packet2.source.ownerId === unit.id ? authorization : spellCrit(units.find((u) => u.id === packet2.source.ownerId)), ctx.draw);
    };
    if (!unit.alive || !target || blocked.has(unit.id) || active(unit, tick, "channel").length > 0) {
      rollPlannedPackets();
      continue;
    }
    const inRange = hexDistance(unit.cell, target.cell) <= range(unit);
    const selfCast = ["irelia", "leona", "vander", "kogmaw", "lux", "loris", "scar", "caitlyn", "maddie"].includes(champion(unit));
    const pendingVanderStrike = champion(unit) === "vander" && unit.runtime.nextAttackPhysical > 0;
    if (champion(unit) !== "neutral" && unit.maxMana > 0 && !pendingVanderStrike && unit.mana >= unit.maxMana && (inRange || selfCast)) {
      const seq = actionSeq++, beforeCount = events.length;
      const cost = planManaCost({ unitId: unit.id, current: unit.mana, maximum: unit.maxMana, lockedUntilTick: unit.manaLockedUntilTick ?? 0 }, unit.mana);
      spent.set(unit.id, cost.actualManaSpent);
      unit.mana = cost.after.current;
      unit.runtime.castCount++;
      const oldInterval = interval(unit, tick);
      const targets = planS13Cast(ctx, unit, target, seq);
      const receipt = completeCast({ source: asSource(origin(unit)), actionSeq: seq, completed: true, targetIds: targets, targetsSampledAtTick: tick, actualManaSpent: 0, refundedMana: 0, completionCell: unit.cell }, cost.actualManaSpent);
      (ctx.castReceipts ??= []).push(receipt);
      events.splice(beforeCount, 0, { type: "cast", tick, sourceId: unit.id, abilityId: unit.ability.id, targetIds: targets, manaSpent: spent.get(unit.id) });
      unit.cooldownTicks = oldInterval;
      const immediate = unit.tasks.filter((t) => t.executeAtTick <= tick);
      unit.tasks = unit.tasks.filter((t) => t.executeAtTick > tick);
      for (const task of immediate) executeTask(ctx, unit, task);
      hooks(unit, "onCast", seq);
      emitMechanismSignal(ctx, { event: "cast-completed", tick, actionSeq: seq, actorId: unit.id, targetId: target.id, cast: receipt });
    } else if (inRange && unit.cooldownTicks === 0) {
      const seq = actionSeq++, neutral2 = champion(unit) === "neutral";
      unit.runtime.attackCount++;
      events.push({ type: "attack", tick, attackerId: unit.id, targetId: target.id });
      const oldInterval = interval(unit, tick);
      planS13Attack(ctx, unit, target, seq);
      unit.cooldownTicks = oldInterval;
      hooks(unit, "onAttack", seq);
      emitMechanismSignal(ctx, { event: "attack-completed", tick, actionSeq: seq, actorId: unit.id, targetId: target.id, cast: null });
      if (!neutral2) attackMana.set(unit.id, S13_COMBAT_RULES.attackMana + mechanic(unit, "extraAttackMana", "amount"));
    }
    rollPlannedPackets();
  }
  const beforeDamage = units.map((u) => ({ id: u.id, hp: u.hp, maxHp: u.maxHp }));
  const positiveDamage = /* @__PURE__ */ new Set();
  const virtualHp = new Map(units.map((u) => [u.id, u.hp])), hpLost = /* @__PURE__ */ new Map(), totals2 = /* @__PURE__ */ new Map();
  const damageByAction = /* @__PURE__ */ new Map();
  const allOutcomes = [];
  const trackAssists = hasMechanismSubscriber(units, "kill-or-assist");
  const damageContributors = { ...state.damageContributors };
  ctx.virtualHp = virtualHp;
  const killed = /* @__PURE__ */ new Map();
  const ricochetActions = /* @__PURE__ */ new Set(), aggregatedActions = /* @__PURE__ */ new Set();
  const commitOutcome = (target, result2, packet2, legacyRaw) => {
    const outcome = result2.outcome, { absorbed, hpDamage: actual, context, critical } = outcome;
    target.shieldLayers = result2.shields.map((layer) => {
      const old = target.shieldLayers.find((s) => s.key === layer.key);
      const taken = old.remaining - layer.remaining;
      const next = shieldProjection(recordShieldAbsorption(frozenShield(old, target), layer.remaining), old.key, old.m8Grant, taken > 0 && layer.remaining === 0 ? "depleted" : old.endedReason);
      if (taken > 0) {
        events.push({ type: "shieldLayerChanged", tick, unitId: target.id, layer: next, reason: "absorbed" });
        if (next.remaining === 0) events.push({ type: "shieldLayerChanged", tick, unitId: target.id, layer: next, reason: "absorbed", endReason: "depleted" });
      }
      return next;
    });
    syncShield(target);
    virtualHp.set(target.id, result2.hpAfter);
    allOutcomes.push(outcome);
    ctx.resolutionFacts = { ...ctx.resolutionFacts, damage: allOutcomes };
    hpLost.set(target.id, (hpLost.get(target.id) ?? 0) + actual);
    const total = totals2.get(target.id) ?? { physical: 0, magic: 0, true: 0, absorbed: 0, incoming: 0 };
    total[packet2.damageType] += outcome.mitigated;
    total.absorbed += absorbed;
    total.incoming += outcome.mitigated;
    totals2.set(target.id, total);
    if (absorbed + actual > 0) {
      positiveDamage.add(target.id);
      if (trackAssists) damageContributors[target.id] = [.../* @__PURE__ */ new Set([...damageContributors[target.id] ?? [], context.source.ownerId])].sort(compareText);
    }
    events.push({
      type: "packetDamage",
      tick,
      source: packet2.source,
      unitId: target.id,
      damageType: packet2.damageType,
      raw: legacyRaw,
      mitigated: outcome.mitigated,
      absorbed,
      hpDamage: actual,
      actionSeq: packet2.actionSeq,
      packetOrdinal: packet2.ordinal,
      critical,
      redirected: context.redirected
    });
    const owner = units.find((u) => u.id === packet2.source.ownerId);
    if (owner && absorbed + actual > 0 && context.permissions.includes("omnivamp")) {
      const damageKey = JSON.stringify([owner.id, packet2.actionSeq]), old = damageByAction.get(damageKey);
      damageByAction.set(damageKey, {
        owner,
        source: packet2.source,
        seq: packet2.actionSeq,
        outcomes: [...old?.outcomes ?? [], outcome],
        hpAmount: (old?.hpAmount ?? 0) + actual,
        heal: old?.heal ?? packet2.onPositiveHpDamageHeal
      });
    }
    if (outcome.killingPacket) {
      killed.set(target.id, packet2.source);
      events.push({ type: "kill", tick, unitId: target.id, source: packet2.source });
      const ricochetKey = JSON.stringify([packet2.source.ownerId, packet2.actionSeq]);
      if (owner && !context.redirected && packet2.bounce && !ricochetActions.has(ricochetKey) && outcome.overkill > 0) {
        const next = byDistance(target, enemies3(owner, units).filter((u) => u.id !== target.id && (virtualHp.get(u.id) ?? 0) > 0))[0];
        if (next) {
          ricochetActions.add(ricochetKey);
          owner.tasks.push({
            key: `${owner.id}:${packet2.actionSeq}:bounce`,
            kind: "tristanaBounce",
            source: packet2.source,
            executeAtTick: tick + 1,
            targetId: next.id,
            amount: outcome.overkill,
            ordinal: 0,
            total: 1,
            cancellable: false,
            actionSeq: packet2.actionSeq,
            inherited: { parentPacketId: context.packetId, resolvedAtTick: tick, portion: "overkill", critical }
          });
          const gain = Math.round(variable(owner, "ASKillGain", 1.25) * 100);
          owner.runtime.permanentAdBps += gain;
          events.push({ type: "growth", tick, unitId: owner.id, amountBps: gain, totalBps: owner.runtime.permanentAdBps });
        }
      }
    }
    const facts = { damage: [outcome], healing: [], shieldDecay: [] };
    const signal = { tick, actionSeq: context.rootActionSeq, actorId: context.source.ownerId, targetId: target.id, cast: null };
    if (context.permissions.includes("incoming-basic-hit") && outcome.hit) emitMechanismSignal(ctx, { ...signal, event: "incoming-basic-hit" }, facts);
    if (absorbed + actual > 0) {
      emitMechanismSignal(ctx, { ...signal, event: "damage-dealt" }, facts);
      emitMechanismSignal(ctx, { ...signal, event: "damage-taken" }, facts);
      if (absorbed > 0 && context.permissions.includes("guardbreaker")) emitMechanismSignal(ctx, { ...signal, event: "shield-hit" }, facts);
    }
  };
  ctx.packets.sort((a, b) => compareText(a.source.ownerId, b.source.ownerId) || a.actionSeq - b.actionSeq || compareText(a.targetId, b.targetId) || a.ordinal - b.ordinal);
  for (let packetIndex = 0; packetIndex < ctx.packets.length; packetIndex++) {
    let packet2 = ctx.packets[packetIndex];
    const beforeDerived = ctx.packets.length;
    const target = units.find((u) => u.id === packet2.targetId);
    if (!target || !target.alive) continue;
    const owner = units.find((u) => u.id === packet2.source.ownerId);
    if (owner) for (const prefix of packet2.beforeDamage ?? []) executeMechanismEffect(ctx, owner, prefix.source, target, prefix.effect, packet2.actionSeq, prefix.ordinal);
    const damageType = damageTypeForTarget(packet2.damageType, targetUnit(target, tick), ctx.resolutionFacts);
    if (damageType !== packet2.damageType) packet2 = { ...packet2, damageType };
    const request = damageRequest(packet2, state.combatId ?? "standalone", tick);
    const sample = damageSample(packet2, target, owner, tick, units, virtualHp.get(target.id));
    const prepared = prepareDamage(request, sample);
    if (packet2.periodic && (sample.prevention || sample.burnCap !== void 0 && prepared.mitigated >= sample.burnCap)) clearPeriodicAccount(ctx, packet2.periodic, target.id);
    const protector = units.filter((u) => u.alive && u.id !== target.id && u.team === target.team && hexDistance(u.cell, target.cell) <= 1 && active(u, tick, "redirect").length > 0).sort(compareIds)[0];
    const transfer = protector ? safeNumber(BigInt(prepared.mitigated) * BigInt(Math.max(...active(protector, tick, "redirect").map((s) => s.amount))) / 10000n) : 0;
    commitOutcome(target, allocateDamage(request.context, { ...prepared, mitigated: prepared.mitigated - transfer }, sample.target.hp, sample.shields), packet2, prepared.rawAfterCritical);
    if (protector && transfer > 0) {
      const partial = {
        ...request.context,
        targetId: protector.id,
        redirected: true,
        critEligibility: "never",
        parentPacketId: request.context.packetId,
        packetId: JSON.stringify([request.context.packetId, "redirect", protector.id])
      };
      const redirected = { context: { ...partial, permissions: permissionsFor(partial) }, input: {
        stage: "after-mitigation",
        amount: transfer,
        inherited: { parentPacketId: request.context.packetId, resolvedAtTick: tick, portion: "redirect-share", critical: prepared.critical }
      } };
      const redirectSample = damageSample(packet2, protector, owner, tick, units, virtualHp.get(protector.id));
      commitOutcome(protector, resolveDamage(redirected, redirectSample), packet2, prepared.rawAfterCritical);
    }
    if (owner && target.alive && (virtualHp.get(target.id) ?? 0) > 0) {
      for (const control of packet2.afterDamageControl ?? []) executeMechanismEffect(ctx, owner, control.source, target, control.effect, packet2.actionSeq, control.ordinal);
    }
    const rootSeq = request.context.rootActionSeq;
    if (!aggregatedActions.has(rootSeq) && !ctx.packets.slice(packetIndex + 1).some((p) => (p.rootActionSeq ?? p.actionSeq) === rootSeq)) {
      aggregatedActions.add(rootSeq);
      const owners = [...new Set(allOutcomes.filter((o) => o.context.rootActionSeq === rootSeq).map((o) => o.context.source.ownerId))].sort(compareText);
      for (const actorId of owners) {
        const damage2 = allOutcomes.filter((o) => o.context.source.ownerId === actorId && o.context.rootActionSeq === rootSeq);
        emitMechanismSignal(ctx, { event: "damage-dealt", tick, actionSeq: rootSeq, actorId, targetId: damage2[0]?.context.targetId ?? null, cast: null }, { ...ctx.resolutionFacts, damage: damage2 }, "action-damage-total");
      }
    }
    if (ctx.packets.length > beforeDerived) {
      const children = ctx.packets.splice(beforeDerived).sort((a, b) => compareText(canonicalSource(asSource(a.source)), canonicalSource(asSource(b.source))) || compareText(a.targetId, b.targetId) || a.ordinal - b.ordinal);
      for (const child of children) child.critical = rollCrit(child.critEligibility, spellCrit(units.find((u) => u.id === child.source.ownerId)), ctx.draw);
      ctx.packets.splice(packetIndex + 1, 0, ...children);
    }
  }
  ctx.virtualHp = void 0;
  for (const unit of units) {
    unit.hp = virtualHp.get(unit.id);
    const total = totals2.get(unit.id);
    if (total) events.push({
      type: "damage",
      tick,
      unitId: unit.id,
      amount: total.incoming,
      hp: unit.hp,
      physicalAmount: total.physical,
      magicAmount: total.magic,
      absorbed: total.absorbed,
      hpDamage: hpLost.get(unit.id) ?? 0,
      shield: unit.shield
    });
  }
  settleSurvival(ctx, beforeDamage, positiveDamage);
  settleShieldEnds(ctx, () => actionSeq++);
  const rates = new Map(units.map((unit) => [unit.id, vampRates(unit, unit.hp)]));
  for (const { owner, source, seq, outcomes, hpAmount, heal: positiveHeal } of damageByAction.values()) {
    if (owner.hp <= 0) continue;
    if (hpAmount > 0) for (const definition of positiveHeal ? [{ source, amount: positiveHeal }] : owner.mechanismDefinitions.positiveDamageHeals ?? []) ctx.heals.push({
      source: definition.source,
      targetId: owner.id,
      amount: evaluateAmount(definition.amount, { holder: hpSample(owner), attackDamage: ad(owner), abilityPower: ap(owner, tick) })
    });
    for (const request of vampRequests(JSON.stringify([ctx.combatId, tick, owner.id, seq, "vamp"]), owner, outcomes, rates.get(owner.id), units))
      ctx.heals.push({ source: request.contributions[0].source, targetId: request.targetId, amount: request.requested, request });
  }
  ctx.heals.sort((a, b) => compareText(canonicalSource(asSource(a.source)), canonicalSource(asSource(b.source))) || compareText(a.targetId, b.targetId) || compareText(a.request?.healId ?? "", b.request?.healId ?? ""));
  const healIds = /* @__PURE__ */ new Set();
  for (const entry of ctx.heals) {
    if (entry.request) {
      if (healIds.has(entry.request.healId)) throw new RangeError("Duplicate planned healing mutation");
      healIds.add(entry.request.healId);
    }
    commitMechanismHeal(ctx, entry);
    if (entry.reactionKey && companionState && units.find((u) => u.id === entry.targetId).hp <= 0) companionState = { ...companionState, reactions: companionState.reactions.map((r) => r.key === entry.reactionKey ? { ...r, status: "cancelled" } : r) };
  }
  if (trackAssists) {
    for (const death of allOutcomes.filter((o) => o.killingPacket)) for (const actorId of damageContributors[death.context.targetId] ?? [])
      if (units.some((u) => u.id === actorId && u.hp > 0)) emitMechanismSignal(ctx, { event: "kill-or-assist", tick, actionSeq: death.context.rootActionSeq, actorId, targetId: death.context.targetId, cast: null }, { ...ctx.resolutionFacts, damage: [death] });
  }
  for (const source of killed.values()) {
    const owner = units.find((u) => u.id === source.ownerId);
    if (owner && owner.hp > 0 && hasMechanic(owner, "killStreak")) killMana.set(owner.id, (killMana.get(owner.id) ?? 0) + mechanic(owner, "killStreak", "mana"));
  }
  for (const request of ctx.manaRequests ?? []) {
    const target = units.find((u) => u.id === request.targetId);
    if (!target?.alive || target.hp <= 0) continue;
    const mana2 = { unitId: target.id, current: target.mana, maximum: target.maxMana, lockedUntilTick: target.manaLockedUntilTick ?? 0 };
    const receipt = ctx.castReceipts?.find((c) => c.source.ownerId === target.id && c.actionSeq === request.castActionSeq);
    const result2 = request.reason === "cast-refund" ? refundCast(mana2, request, receipt, tick) : { outcome: resolveMana(mana2, request, tick) };
    if ("receipt" in result2) ctx.castReceipts = ctx.castReceipts.map((c) => c === receipt ? result2.receipt : c);
    const outcome = result2.outcome;
    target.mana = outcome.after;
    events.push({ type: "manaChanged", tick, unitId: target.id, before: outcome.before, spent: 0, attackGain: 0, damageGain: 0, hookGain: outcome.applied, overflow: outcome.overflow, after: outcome.after, outcome });
  }
  for (const unit of units) {
    if (!unit.alive || unit.hp <= 0 || champion(unit) === "neutral") continue;
    if ((hpLost.get(unit.id) ?? 0) > 0) hooks(unit, "onHpLoss", actionSeq);
    const attackGain = attackMana.get(unit.id) ?? 0, damageGain = damageMana(hpLost.get(unit.id) ?? 0), hookGain = (killMana.get(unit.id) ?? 0) + (hookMana.get(unit.id) ?? 0);
    let overflow = 0;
    for (const [reason, gain] of [["attack", attackGain], ["damage", damageGain], ["kill", hookGain]]) {
      const outcome = resolveMana(
        { unitId: unit.id, current: unit.mana, maximum: unit.maxMana, lockedUntilTick: unit.manaLockedUntilTick ?? 0 },
        { source: asSource(origin(unit)), targetId: unit.id, amount: gain, reason, bypassLock: "none", castActionSeq: null },
        tick
      );
      unit.mana = outcome.after;
      overflow += outcome.overflow;
    }
    if ((spent.get(unit.id) ?? 0) + attackGain + damageGain + hookGain > 0) events.push({
      type: "manaChanged",
      tick,
      unitId: unit.id,
      before: manaBefore.get(unit.id),
      spent: spent.get(unit.id) ?? 0,
      attackGain,
      damageGain,
      hookGain,
      overflow,
      after: unit.mana
    });
    for (const effect of unit.mechanics ?? []) if (effect.mechanic === "bulkyBuddies" && !unit.runtime.buddyTriggered) {
      const buddy = units.find((u) => u.id === effect.targetId);
      if (buddy && (startHp.get(buddy.id) ?? 0) > 0 && buddy.hp === 0) {
        unit.runtime.buddyTriggered = true;
        grantShield(unit, effect.source, Math.floor(unit.maxHp * effect.values.shieldMaxHpBps / 1e4), tick + effect.values.durationTicks, tick, events);
      }
    }
  }
  cleanupMechanisms(ctx);
  for (const unit of units) {
    if (unit.alive && unit.hp === 0) {
      unit.alive = false;
      unit.targetId = null;
      unit.cooldownTicks = 0;
      unit.moveCooldownTicks = 0;
      unit.mana = 0;
      unit.shieldLayers = [];
      unit.shield = 0;
      unit.shieldExpiresAtTick = null;
      unit.statuses = [];
      unit.tasks = unit.tasks.filter((t) => !t.cancellable && (t.attachedDot || t.kind === "tristanaBounce"));
      events.push({ type: "death", tick, unitId: unit.id });
    }
    unit.shieldLayers = unit.shieldLayers.filter((layer) => layer.remaining > 0 || unit.tasks.some((t) => t.shieldEndKey === layer.key));
  }
  if (companionState) {
    const deaths = units.filter((u) => (startHp.get(u.id) ?? 0) > 0 && !u.alive && u.unitKind === "neutral" && u.encounterId && u.monsterFamily).map((u) => ({ combatId: ctx.combatId, tick, deadUnitId: u.id, team: u.team, encounterId: u.encounterId, monsterFamily: u.monsterFamily, eventId: JSON.stringify([ctx.combatId, tick, (state.nextEventSeq ?? 0) + events.findIndex((e) => e.type === "death" && e.unitId === u.id)]) }));
    companionState = registerDeaths(companionState, deaths, units.filter((u) => u.alive).map((u) => u.id));
  }
  const eliminated = eliminationResult(units), result = eliminated ?? (tick >= state.maxTicks ? "draw" : null);
  if (result) {
    cleanupMechanisms(ctx, true);
    for (const unit of units) {
      unit.statuses = [];
      unit.shieldLayers = [];
      syncShield(unit);
      unit.tasks = [];
    }
  }
  if (result && companionState) companionState = advanceReactions(companionState, tick, [], true).state;
  if (result) events.push({ type: "combatFinished", tick, result, reason: eliminated ? "elimination" : "timeout" });
  return stampCombatStep({ ...state, ...openingState ? { openingState } : {}, ...trackAssists ? { damageContributors } : {}, nextTriggerEventSeq: ctx.nextTriggerEventSeq, ...companionState ? { companionState } : {}, units, tick, rngState, rngDraws, nextActionSeq: actionSeq, status: result ? "finished" : "running", result }, events);
}

// src/simulation/combat-tick.ts
var cellKey2 = (cell) => `${cell.col},${cell.row}`;
function nearestEnemy(unit, units) {
  return units.filter((other) => other.alive && other.team !== unit.team).sort((a, b) => hexDistance(unit.cell, a.cell) - hexDistance(unit.cell, b.cell) || compareIds(a, b))[0];
}
function nextStep(board, unit, target, occupied) {
  const visited = /* @__PURE__ */ new Set([cellKey2(unit.cell)]);
  const queue = [{ cell: unit.cell, first: void 0 }];
  for (let index = 0; index < queue.length; index++) {
    const current = queue[index];
    for (const cell of getNeighbors(board, current.cell)) {
      const key3 = cellKey2(cell);
      if (visited.has(key3) || occupied.has(key3)) continue;
      visited.add(key3);
      const first = current.first ?? cell;
      if (hexDistance(cell, target.cell) <= unit.attackRange) return first;
      queue.push({ cell, first });
    }
  }
  return void 0;
}
function advanceCombatTick(state) {
  if (state.units.some((unit) => unit.ability.kind === "s13")) return advanceS13Tick(state);
  const tick = state.tick + 1;
  const events = [];
  const units = state.units.map((unit) => ({
    ...structuredClone(unit),
    cell: { ...unit.cell },
    ability: { ...unit.ability },
    cooldownTicks: unit.alive ? Math.max(0, unit.cooldownTicks - 1) : 0,
    moveCooldownTicks: unit.alive ? Math.max(0, unit.moveCooldownTicks - 1) : 0
  })).sort(compareIds);
  for (const unit of units) {
    if (unit.shieldExpiresAtTick === null || tick < unit.shieldExpiresAtTick) continue;
    if (unit.shield > 0) events.push({ type: "shieldChanged", tick, unitId: unit.id, reason: "expired", before: unit.shield, after: 0, expiresAtTick: null });
    unit.shield = 0;
    unit.shieldExpiresAtTick = null;
  }
  const occupied = new Set(units.filter((unit) => unit.alive).map((unit) => cellKey2(unit.cell)));
  const intents = units.map((unit) => {
    if (!unit.alive) return void 0;
    const target = nearestEnemy(unit, units);
    unit.targetId = target?.id ?? null;
    if (!target || unit.moveCooldownTicks > 0 || hexDistance(unit.cell, target.cell) <= unit.attackRange) return void 0;
    return nextStep(state.board, unit, target, occupied);
  });
  const reserved = /* @__PURE__ */ new Set();
  units.forEach((unit, index) => {
    const destination = intents[index];
    if (!destination || reserved.has(cellKey2(destination))) return;
    reserved.add(cellKey2(destination));
    events.push({ type: "movement", tick, unitId: unit.id, from: { ...unit.cell }, to: { ...destination } });
    unit.cell = destination;
    unit.moveCooldownTicks = MOVE_INTERVAL_TICKS;
  });
  const actions = [];
  for (const unit of units) {
    if (!unit.alive) continue;
    const target = nearestEnemy(unit, units);
    unit.targetId = target?.id ?? null;
    const ability = planAbility(unit, target, units);
    if (ability) actions.push({ kind: "cast", unit, intent: ability });
    else if (target && unit.cooldownTicks === 0 && hexDistance(unit.cell, target.cell) <= unit.attackRange) {
      actions.push({ kind: "attack", unit, target });
    }
  }
  const packets = [];
  const attacks = /* @__PURE__ */ new Set();
  const spentMana = /* @__PURE__ */ new Map();
  const shields = [];
  const hookMana = /* @__PURE__ */ new Map();
  const invocations = [];
  for (const action of actions) {
    const unit = action.unit;
    if (action.kind === "cast") {
      events.push({
        type: "cast",
        tick,
        sourceId: unit.id,
        abilityId: unit.ability.id,
        targetIds: [...action.intent.targetIds],
        manaSpent: unit.mana
      });
      spentMana.set(unit.id, unit.mana);
      unit.mana = 0;
      packets.push(...action.intent.packets);
      if (action.intent.shield) shields.push(action.intent.shield);
    } else {
      events.push({ type: "attack", tick, attackerId: unit.id, targetId: action.target.id });
      attacks.add(unit.id);
      packets.push({
        sourceId: unit.id,
        targetId: action.target.id,
        damageType: "physical",
        rawAmount: unit.attackDamage,
        sourceKind: "attack",
        effectIndex: 0
      });
    }
    unit.cooldownTicks = unit.attackIntervalTicks;
    if (state.strategy) {
      const batch = collectTriggers(unit.triggers ?? [], unit.effectRuntime ?? [], action.kind === "cast" ? "onCast" : "onAttack", unit.id, unit.targetId);
      unit.effectRuntime = batch.runtime;
      invocations.push(...batch.invocations);
    }
  }
  for (const invocation of invocations) {
    events.push(invocationEvent(invocation, tick));
    const { action, trigger: trigger2, targetId } = invocation;
    if (action.kind === "gainMana") hookMana.set(targetId, (hookMana.get(targetId) ?? 0) + action.amount);
    else if (action.kind === "grantShield") shields.push({ unitId: targetId, amount: action.amount, durationTicks: action.durationTicks });
    else packets.push({
      sourceId: trigger2.source.ownerId,
      targetId,
      rawAmount: action.amount,
      damageType: action.damageType,
      sourceKind: trigger2.source.sourceKind,
      source: { ...trigger2.source },
      sourceInstanceId: trigger2.source.sourceInstanceId,
      effectIndex: trigger2.source.effectIndex,
      packetOrdinal: packets.length,
      triggerEligible: false
    });
  }
  for (const unit of units) {
    const grants = shields.filter((grant) => grant.unitId === unit.id);
    if (grants.length === 0) continue;
    const before = unit.shield, previousExpiry = unit.shieldExpiresAtTick;
    unit.shield = Math.max(unit.shield, ...grants.map((grant) => grant.amount));
    unit.shieldExpiresAtTick = unit.shield > 0 ? state.strategy ? Math.max(previousExpiry ?? 0, ...grants.map((grant) => tick + grant.durationTicks)) : tick + grants.at(-1).durationTicks : null;
    if (before !== unit.shield || previousExpiry !== unit.shieldExpiresAtTick) events.push({
      type: "shieldChanged",
      tick,
      unitId: unit.id,
      reason: "granted",
      before,
      after: unit.shield,
      expiresAtTick: unit.shieldExpiresAtTick
    });
  }
  const incoming = aggregateDamagePackets(packets, units, Boolean(state.strategy));
  const hpLost = /* @__PURE__ */ new Map();
  for (const unit of units) {
    const damage2 = incoming.get(unit.id);
    if (!damage2) continue;
    const absorbed = Math.min(unit.shield, damage2.amount);
    const hpDamage = Math.min(unit.hp, damage2.amount - absorbed);
    unit.shield -= absorbed;
    if (unit.shield === 0) unit.shieldExpiresAtTick = null;
    unit.hp -= hpDamage;
    hpLost.set(unit.id, hpDamage);
    events.push({ type: "damage", tick, unitId: unit.id, ...damage2, absorbed, hpDamage, hp: unit.hp, shield: unit.shield });
  }
  if (state.strategy) for (const unit of units) {
    if (!unit.alive || unit.hp === 0 || (hpLost.get(unit.id) ?? 0) === 0) continue;
    const batch = collectTriggers(unit.triggers ?? [], unit.effectRuntime ?? [], "onHpLoss", unit.id, unit.targetId);
    unit.effectRuntime = batch.runtime;
    for (const invocation of batch.invocations) {
      events.push(invocationEvent(invocation, tick));
      hookMana.set(unit.id, (hookMana.get(unit.id) ?? 0) + invocation.action.amount);
    }
  }
  for (const unit of units) {
    if (!unit.alive || unit.hp === 0) continue;
    const spent = spentMana.get(unit.id) ?? 0;
    const attackGain = attacks.has(unit.id) ? 10 : 0;
    const damageGain = Math.min(20, Math.floor((hpLost.get(unit.id) ?? 0) / 10));
    const hookGain = hookMana.get(unit.id) ?? 0;
    if (spent === 0 && attackGain === 0 && damageGain === 0 && hookGain === 0) continue;
    const before = unit.mana + spent;
    const overflow = Math.max(0, unit.mana + attackGain + damageGain + hookGain - unit.maxMana);
    unit.mana = Math.min(unit.maxMana, unit.mana + attackGain + damageGain + hookGain);
    events.push({ type: "manaChanged", tick, unitId: unit.id, before, spent, attackGain, damageGain, ...state.strategy ? { hookGain } : {}, overflow, after: unit.mana });
  }
  for (const unit of units) {
    if (!unit.alive || unit.hp > 0) continue;
    unit.alive = false;
    unit.targetId = null;
    unit.cooldownTicks = 0;
    unit.moveCooldownTicks = 0;
    unit.mana = 0;
    unit.shield = 0;
    unit.shieldExpiresAtTick = null;
    events.push({ type: "death", tick, unitId: unit.id });
  }
  const eliminated = eliminationResult(units);
  const result = eliminated ?? (tick >= state.maxTicks ? "draw" : null);
  if (result !== null) events.push({ type: "combatFinished", tick, result, reason: eliminated === null ? "timeout" : "elimination" });
  return stampCombatStep({ ...state, units, tick, status: result === null ? "running" : "finished", result }, events);
}

// src/simulation/combat.ts
function validateCombatStart(preparation) {
  const deployed = preparation.units.filter((unit) => unit.location.kind === "board");
  const player = deployed.some((unit) => unit.team === "player");
  const enemy = deployed.some((unit) => unit.team === "enemy");
  if (!player && !enemy) return "missing-both";
  if (!player) return "missing-player";
  if (!enemy) return "missing-enemy";
  return void 0;
}
function snapshotCombat(preparationState, strategy, combatId = "standalone", rngState = 42) {
  const units = preparationState.units.flatMap((unit) => {
    if (unit.location.kind !== "board") return [];
    const resolved = strategy?.units.find((entry) => entry.unitId === unit.id);
    if (strategy && !resolved) throw new Error(`Missing strategy unit: ${unit.id}`);
    const stats = resolved?.stats ?? getUnitStats(unit.definitionId, unit.starLevel);
    const ability = resolved ? structuredClone(resolved.ability) : resolveAbility(stats.abilityId, unit.starLevel);
    const neutral2 = stats.unitKind === "neutral" ? readNeutralCombatUnit(unit.id) : void 0;
    if (stats.unitKind === "neutral" && (!neutral2 || neutral2.definitionId !== unit.definitionId || neutral2.encounterId !== unit.encounterId || unit.team !== "enemy")) throw new RangeError("Invalid neutral combat identity");
    return [{
      ...neutral2?.companionDefinitions ? { companionDefinitions: structuredClone(neutral2.companionDefinitions) } : {},
      ...neutral2?.attackCone ? { attackCone: structuredClone(neutral2.attackCone) } : {},
      ...compileCombatInitialInputs(unit.id, stats, ability, resolved),
      ...unit.encounterId ? { encounterId: unit.encounterId } : {},
      id: unit.id,
      definitionId: unit.definitionId,
      team: unit.team,
      starLevel: unit.starLevel,
      cell: { ...unit.location.cell },
      attackDamage: stats.attack,
      attackRange: stats.attackRange,
      attackIntervalTicks: stats.attackIntervalTicks,
      cooldownTicks: 0,
      moveCooldownTicks: 0,
      armor: stats.armor,
      magicResist: stats.magicResist,
      shield: 0,
      shieldExpiresAtTick: null,
      ability,
      ...resolved ? { sources: structuredClone(resolved.sources), triggers: structuredClone(resolved.triggers), effectRuntime: initializeEffectRuntime(resolved.triggers) } : {},
      ...ability.kind === "s13" ? {
        attackDamageBase: resolved?.attackDamageBase ?? stats.attack,
        attackDamagePercentBps: resolved?.attackDamagePercentBps ?? 0,
        baseAttackSpeedBps: stats.baseAttackSpeedBps ?? Math.floor(2e5 / stats.attackIntervalTicks),
        attackSpeedBonusBps: stats.attackSpeedBonusBps ?? 0,
        maxHpBasis: {
          base: getUnitStats(unit.definitionId, unit.starLevel).health,
          flat: (resolved?.sources ?? []).reduce((n, e) => n + (e.effect.kind === "statFlat" && e.effect.stat === "maxHp" ? e.effect.amount : 0), 0),
          bps: (resolved?.sources ?? []).reduce((n, e) => n + (e.effect.kind === "statPercentBps" && e.effect.stat === "maxHp" ? e.effect.bps : 0), 0),
          bonusBps: 0
        },
        mechanics: structuredClone(resolved?.mechanics ?? []),
        shieldLayers: [],
        statuses: [],
        tasks: [],
        runtime: {
          attackCount: 0,
          castCount: 0,
          attackSpeedBps: 0,
          abilityPowerFlat: 0,
          rangeBonus: 0,
          nextAttackMagic: 0,
          nextAttackPhysical: 0,
          permanentAdBps: 0,
          buddyTriggered: false
        }
      } : {},
      alive: true,
      targetId: null
    }];
  }).sort(compareIds);
  const result = eliminationResult(units);
  return {
    board: { ...preparationState.board, deploymentZones: {
      player: { ...preparationState.board.deploymentZones.player },
      enemy: { ...preparationState.board.deploymentZones.enemy }
    } },
    ...strategy ? { strategy: structuredClone(strategy), combatId, nextEventSeq: 0, startEffectsApplied: false } : {},
    ...units.some((u) => u.unitKind === "neutral") ? { ...strategy ? { neutralReceipts: { deaths: [], controls: [] } } : {}, openingDefinitions: structuredClone(COMPILED_NEUTRAL_ENCOUNTERS.flatMap((e) => e.openingDefinitions).filter((d) => units.some((u) => u.id === d.source.ownerId))) } : {},
    rngState,
    rngDraws: 0,
    nextActionSeq: 0,
    units,
    tick: 0,
    maxTicks: MAX_COMBAT_TICKS,
    status: result === null ? "running" : "finished",
    result
  };
}
function createCombatWithEvents(preparation, strategy, combatId, rngState = 42) {
  return applyCombatStart(snapshotCombat(preparation, strategy, combatId, rngState));
}
function stepCombat(state) {
  if (state.status === "finished") return { state, events: [] };
  return recordNeutralReceipts(advanceCombatTick(state));
}

// src/simulation/game.ts
function validateDeployment(state, unitId, target) {
  if (!target || typeof target !== "object" || target.kind !== "board" && target.kind !== "bench" || target.kind === "board" && (!target.cell || typeof target.cell !== "object")) return "invalid-location";
  const unit = state.units.find((unit2) => unit2.id === unitId);
  if (!unit) return "unknown-unit";
  if (unit.team !== "player") return "enemy-unit";
  const valid = target.kind === "board" ? contains(state.board, target.cell) : Number.isInteger(target.slot) && target.slot >= 0 && target.slot < state.benchSize;
  if (!valid) return "invalid-location";
  if (target.kind === "board" && !isDeploymentCell(state.board, "player", target.cell)) return "outside-deployment-zone";
  const occupied = state.units.some((unit2) => unit2.id !== unitId && unit2.location.kind === target.kind && (unit2.location.kind === "board" && target.kind === "board" ? sameCell(unit2.location.cell, target.cell) : unit2.location.kind === "bench" && target.kind === "bench" && unit2.location.slot === target.slot));
  if (occupied) return "occupied";
  return void 0;
}
function deployUnit(state, unitId, target) {
  const reason = validateDeployment(state, unitId, target);
  if (reason) return { ok: false, reason, state };
  const location = target.kind === "board" ? { kind: "board", cell: { ...target.cell } } : { ...target };
  return { ok: true, state: { ...state, units: state.units.map((unit) => unit.id === unitId ? { ...unit, location } : unit) } };
}
function getPlayerDeploymentCount(state) {
  return state.units.filter((unit) => unit.team === "player" && unit.location.kind === "board").length;
}

// src/simulation/shop.ts
function generateShop(rngState, generation, level) {
  validateSeed(rngState);
  if (!Number.isSafeInteger(generation) || generation < 1) throw new RangeError("Invalid shop generation");
  const odds = getShopOdds(level), slots = [];
  for (let slot3 = 0; slot3 < MATCH_RULES.shopSize; slot3++) {
    const tierDraw = nextRandom(rngState);
    let roll = Math.floor(tierDraw.word * 100 / 4294967296), tier = 0;
    while (roll >= odds[tier]) roll -= odds[tier++];
    const unitDraw = nextRandom(tierDraw.state);
    rngState = unitDraw.state;
    const catalog = SHOP_CATALOG_BY_COST[tier + 1];
    slots.push({ status: "available", definitionId: catalog[Math.floor(unitDraw.word * catalog.length / 4294967296)] });
  }
  return { shop: { generation, slots, locked: false }, rngState };
}

// src/simulation/validate-content.ts
var STATS = ["maxHp", "attackDamage", "armor", "magicResist", "initialMana", "abilityAmount", "abilityPower"];
var integer5 = (v, min = 0) => typeof v === "number" && Number.isSafeInteger(v) && v >= min;
var fail = (s) => {
  throw new RangeError(s);
};
var keysAre = (v, keys3) => Object.keys(v).every((key3) => keys3.includes(key3));
function finiteJson(v, seen = /* @__PURE__ */ new Set()) {
  if (v === null || typeof v === "boolean" || typeof v === "string") return;
  if (typeof v === "number" && Number.isFinite(v) && Math.abs(v) <= Number.MAX_SAFE_INTEGER) return;
  if (typeof v !== "object" || v === null || !Array.isArray(v) && Object.getPrototypeOf(v) !== Object.prototype || seen.has(v)) fail("Content must be finite plain JSON");
  if (Object.getOwnPropertySymbols(v).length) fail("Symbol keys are forbidden");
  if (Array.isArray(v)) {
    for (let i = 0; i < v.length; i++) if (!Object.hasOwn(v, i)) fail("Sparse content");
  }
  seen.add(v);
  for (const x of Object.values(v)) finiteJson(x, seen);
  seen.delete(v);
}
function ids(catalog, kind) {
  for (const [id2, entry] of Object.entries(catalog)) if (!entry || entry.id !== id2 || !/^[a-z][a-z0-9-]*$/.test(id2)) fail(`Invalid ${kind} ID: ${id2}`);
}
var MECHANIC_FIELDS2 = Object.freeze({
  artillery: ["everyN", "adBps", "radius"],
  sniper: ["damageBpsPerHex"],
  watcher: ["reductionBps", "healthyReductionBps", "thresholdBps"],
  rageblade: ["attackSpeedBps"],
  damageAmp: ["bps"],
  extraAttackMana: ["amount", "backRowOnly"],
  archangel: ["periodTicks", "abilityPower"],
  dragonClaw: ["periodTicks", "healMaxHpBps"],
  gargoyle: ["resistPerEnemy"],
  gunblade: ["selfHealBps", "allyHealBps"],
  acquisitionGold: ["amount"],
  glassCannon: ["startingHealthBps", "damageAmpBps", "backRowOnly"],
  pumpingUp: ["attackSpeedBpsPerRound"],
  investment: ["healthPerInterest"],
  bulkyBuddies: ["health", "shieldMaxHpBps", "durationTicks"],
  titanic: ["adBps", "radius"],
  mageArmor: ["apBps"],
  killStreak: ["mana"]
});
function validateEffect(effect) {
  if (!effect || typeof effect !== "object") fail("Invalid effect");
  if (effect.kind === "mechanic") {
    const fields = MECHANIC_FIELDS2[effect.mechanic];
    if (!keysAre(effect, ["kind", "mechanic", "values"]) || !fields || !effect.values || !keysAre(effect.values, fields) || fields.some((key3) => key3 !== "backRowOnly" && !Object.hasOwn(effect.values, key3)) || Object.values(effect.values).some((value) => !integer5(value) || value > 1e6)) fail("Invalid mechanic");
    for (const key3 of ["periodTicks", "durationTicks", "everyN"]) if (Object.hasOwn(effect.values, key3) && !integer5(effect.values[key3], 1)) fail("Invalid mechanic interval");
    if (effect.values.backRowOnly !== void 0 && effect.values.backRowOnly !== 1) fail("Invalid row condition");
    return;
  }
  if (effect.kind === "statFlat") {
    if (!keysAre(effect, ["kind", "stat", "amount"]) || !STATS.includes(effect.stat) || !integer5(effect.amount) || effect.amount > 1e5) fail("Invalid flat stat");
    return;
  }
  if (effect.kind === "statPercentBps") {
    if (!keysAre(effect, ["kind", "stat", "bps"]) || !STATS.includes(effect.stat) || effect.stat === "initialMana" || !integer5(effect.bps) || effect.bps > 4e4) fail("Invalid percent stat");
    return;
  }
  if (effect.kind === "attackSpeedBps") {
    if (!keysAre(effect, ["kind", "bps"]) || !integer5(effect.bps) || effect.bps > 2e4) fail("Invalid attack speed");
    return;
  }
  if (effect.kind !== "trigger" || !keysAre(effect, ["kind", "hook", "everyN", "action"]) || !["combatStart", "onAttack", "onCast", "onHpLoss"].includes(effect.hook) || !integer5(effect.everyN, 1) || effect.hook === "combatStart" && effect.everyN !== 1 || !effect.action || !integer5(effect.action.amount)) fail("Invalid trigger");
  if (effect.kind !== "trigger") return;
  const a = effect.action;
  if (a.kind === "gainMana") {
    if (!keysAre(a, ["kind", "amount"])) fail("Invalid mana action");
  } else if (a.kind === "grantShield") {
    if (!keysAre(a, ["kind", "amount", "durationTicks"]) || effect.hook === "onHpLoss" || !integer5(a.durationTicks, 1) || !integer5(a.durationTicks + 1200)) fail("Invalid shield action");
  } else if (a.kind === "dealDamage") {
    if (!keysAre(a, ["kind", "amount", "damageType"]) || !["onAttack", "onCast"].includes(effect.hook) || !["physical", "magic"].includes(a.damageType)) fail("Invalid damage action");
  } else fail("Unknown action");
}
function effects(list2) {
  if (!Array.isArray(list2) || !list2.length) fail("Empty effects");
  for (const e of list2) validateEffect(e);
}
function validateStatBounds(content) {
  const allEffects = [...Object.values(content.items), ...Object.values(content.augments), ...Object.values(content.anomalies)].flatMap((entry) => entry.effects).concat(Object.values(content.traits).flatMap((trait) => trait.tiers.flatMap((tier) => [...tier.effects, ...tier.memberEffects ?? []])));
  const triggerTotal = allEffects.reduce((sum, e) => sum + (e.kind === "trigger" ? e.action.amount : 0), 0);
  if (!integer5(triggerTotal) || !Number.isSafeInteger(triggerTotal * 3 * 100 * 56)) fail("Trigger arithmetic bound exceeded");
  for (const unit of Object.values(content.units)) {
    for (const stat2 of Object.values(unit.baseStats)) if (!integer5(stat2) || !Number.isSafeInteger(stat2 * 324 * 56 * 1e5)) fail(`Combat arithmetic bound: ${unit.id}`);
    if (!integer5(unit.attackIntervalTicks, 1) || !Number.isSafeInteger(unit.attackIntervalTicks * 1e4)) fail(`Attack speed bound: ${unit.id}`);
    const ability = content.abilities[unit.abilityId];
    if (ability && !Number.isSafeInteger(Math.max(...ability.amountByStar) * 1e4 * 56)) fail(`Ability arithmetic bound: ${unit.id}`);
  }
  const maxima = { ragebladeStacks: 1200 * 3, archangelTicks: 1200 / 100, interestHp: ROUND_CATALOG.length * 5 * 8, pumpingBps: ROUND_CATALOG.length * 50 };
  if (Object.values(maxima).some((n) => !Number.isSafeInteger(n))) fail("Dynamic bounds overflow");
}
function validateContent(overrides = {}) {
  const content = {
    units: M5_UNIT_DEFINITIONS,
    abilities: ABILITY_DEFINITIONS,
    traits: TRAIT_DEFINITIONS,
    items: ITEM_DEFINITIONS,
    augments: AUGMENT_DEFINITIONS,
    anomalies: ANOMALY_DEFINITIONS,
    shopCatalog: SHOP_CATALOG_BY_COST,
    schedule: ROUND_SCHEDULE,
    ...overrides
  };
  finiteJson(content);
  for (const kind of ["units", "abilities", "traits", "items", "augments", "anomalies"]) ids(content[kind], kind);
  if (!Object.keys(overrides).length) for (const [kind, count] of Object.entries({ units: 19, traits: 5, items: 44, augments: 6, anomalies: 3 })) {
    if (Object.keys(content[kind]).length !== count) fail(`Incorrect M5 ${kind} count`);
  }
  validateUnitDefinitions(content.units, content.shopCatalog);
  validateAbilityDefinitions(content.abilities);
  const catalogIds = Object.values(content.shopCatalog).flat();
  if (catalogIds.length !== Object.keys(content.units).length || new Set(catalogIds).size !== catalogIds.length) fail("Shop and active units differ");
  for (const ids2 of Object.values(content.shopCatalog)) if (ids2.join("|") !== [...ids2].sort().join("|")) fail("Unsorted shop catalog");
  for (const u of Object.values(content.units)) {
    if (!Object.hasOwn(content.abilities, u.abilityId) && !Object.hasOwn(S13_ABILITY_DATA, u.abilityId)) fail(`Missing ability ${u.abilityId}`);
    for (const t of u.traits) if (!Object.hasOwn(content.traits, t)) fail(`Missing trait ${t}`);
  }
  for (const t of Object.values(content.traits)) {
    if (!t.name || !["team", "members"].includes(t.target) || !t.tiers.length) fail("Invalid trait");
    const members = Object.values(content.units).filter((u) => u.traits.includes(t.id)).length;
    let previous = 0;
    for (const tier of t.tiers) {
      if (!integer5(tier.threshold, previous + 1) || tier.threshold > members || tier.threshold > 9) fail("Unreachable trait");
      previous = tier.threshold;
      effects(tier.effects);
      if (tier.memberEffects) effects(tier.memberEffects);
    }
  }
  const components = Object.values(content.items).filter((x) => x.kind === "component").map((x) => x.id).sort();
  validateComponentPool(content.items);
  const recipes = /* @__PURE__ */ new Set();
  for (const item of Object.values(content.items)) {
    const approved = ITEM_DEFINITIONS[item.id];
    if (!approved || item.apiName !== approved.apiName || item.kind !== approved.kind || item.unique !== approved.unique || item.slotCost !== approved.slotCost || [...item.recipe ?? []].sort().join("|") !== [...approved.recipe ?? []].sort().join("|")) fail("Item differs from approved B1 mapping");
    if (!item.name) fail("Missing item name");
    if (item.effects.length) effects(item.effects);
    else if (!item.combatProgram) fail("Empty item effects");
    if (item.combatProgram) validateItemProgram(item.combatProgram);
    if (item.kind === "component") {
      if (item.recipe !== void 0) fail("Component recipe");
    } else if (item.kind === "completed") {
      if (!item.recipe || item.recipe.length !== 2 || item.recipe.some((id2) => !components.includes(id2))) fail("Invalid item recipe");
      const key3 = [...item.recipe].sort().join("|");
      if (recipes.has(key3)) fail("Duplicate recipe");
      recipes.add(key3);
    } else fail("Invalid item kind");
  }
  for (let a = 0; a < components.length; a++) for (let b = a; b < components.length; b++) if (!recipes.has([components[a], components[b]].sort().join("|"))) fail("Missing completed recipe");
  if (recipes.size !== 36) fail("M8 requires 36 unique recipes");
  if (Object.keys(content.augments).length < 5 || Object.keys(content.anomalies).length < 2) fail("Choice pool exhausted");
  for (const c of [...Object.values(content.augments), ...Object.values(content.anomalies)]) {
    if (!c.name || !c.description) fail("Missing choice text");
    effects(c.effects);
  }
  if (content.schedule.fixed.length !== ROUND_SCHEDULE.fixed.length) fail("Incomplete acquisition schedule");
  for (const [index, entry] of content.schedule.fixed.entries()) {
    const expected = ROUND_SCHEDULE.fixed[index];
    if (!integer5(entry.round, 1) || entry.round > FINAL_ROUND || entry.round !== expected.round || Object.keys(entry.event).length !== Object.keys(expected.event).length || Object.entries(expected.event).some(([key3, value]) => entry.event[key3] !== value)) fail("Invalid semantic schedule");
  }
  if (content.schedule.recurring.fromRound !== ROUND_SCHEDULE.recurring.fromRound || content.schedule.recurring.everyRounds !== ROUND_SCHEDULE.recurring.everyRounds || content.schedule.recurring.randomComponents !== 0 || content.schedule.fallbackDefinitionId !== ROUND_SCHEDULE.fallbackDefinitionId) fail("Invalid finite schedule boundary");
  for (let level = 1; level <= 9; level++) {
    const row = SHOP_ODDS[level];
    if (!row || row.length !== 5 || row.some((x) => !integer5(x)) || row.reduce((a, b) => a + b, 0) !== 100) fail("Invalid shop odds");
    if (level < 9 && !integer5(XP_TO_NEXT_LEVEL[level], 1)) fail("Invalid XP");
  }
  validateStatBounds(content);
}

// src/simulation/inventory.ts
var compareIds4 = (a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
function validateCombine(items, aId, bId) {
  const a = items.find((item) => item.id === aId), b = items.find((item) => item.id === bId);
  if (!a || !b) return { allowed: false, reason: "unknown-item" };
  if (aId === bId) return { allowed: false, reason: "same-item" };
  if (a.location.kind !== "inventory" || b.location.kind !== "inventory") {
    return { allowed: false, reason: "item-not-inventory" };
  }
  const aDefinition = ITEM_DEFINITIONS[a.definitionId], bDefinition = ITEM_DEFINITIONS[b.definitionId];
  if (!aDefinition || !bDefinition) throw new RangeError("Unknown item definition");
  if (aDefinition.kind !== "component" || bDefinition.kind !== "component") return { allowed: false, reason: "invalid-recipe" };
  const result = Object.values(ITEM_DEFINITIONS).find((definition) => definition.kind === "completed" && definition.recipe && (definition.recipe[0] === a.definitionId && definition.recipe[1] === b.definitionId || definition.recipe[0] === b.definitionId && definition.recipe[1] === a.definitionId));
  if (!result) return { allowed: false, reason: "invalid-recipe" };
  return {
    allowed: true,
    reason: null,
    resultDefinitionId: result.id,
    consumedItemIds: aId < bId ? [aId, bId] : [bId, aId]
  };
}
function planCombine(items, nextItemSerial, aId, bId) {
  const preview = validateCombine(items, aId, bId);
  if (!preview.allowed) return { ok: false, reason: preview.reason };
  if (!Number.isSafeInteger(nextItemSerial) || nextItemSerial < 1 || nextItemSerial === Number.MAX_SAFE_INTEGER) {
    throw new RangeError("Invalid next item serial");
  }
  const itemId = `item-${nextItemSerial}`;
  if (items.some((item) => item.id === itemId)) throw new Error(`Duplicate item ID: ${itemId}`);
  const created = { id: itemId, definitionId: preview.resultDefinitionId, location: { kind: "inventory" } };
  return {
    ok: true,
    items: [...items.filter((item) => item.id !== aId && item.id !== bId), created].sort(compareIds4),
    nextItemSerial: nextItemSerial + 1,
    events: [{ type: "itemCombined", consumedIds: preview.consumedItemIds, itemId, definitionId: preview.resultDefinitionId }]
  };
}
function validateEquip(items, preparation, itemId, unitId, slot3) {
  const item = items.find((candidate) => candidate.id === itemId);
  if (!item) return { allowed: false, reason: "unknown-item", conflictingItemIds: [] };
  const unit = preparation.units.find((candidate) => candidate.id === unitId);
  if (!unit || unit.team !== "player") return { allowed: false, reason: "unknown-unit", conflictingItemIds: [] };
  if (item.location.kind !== "inventory") return { allowed: false, reason: "item-not-inventory", conflictingItemIds: [] };
  return checkEquipmentPlacement(items, item, unitId, slot3);
}
function planEquip(items, preparation, itemId, unitId, slot3) {
  const placement = validateEquip(items, preparation, itemId, unitId, slot3);
  if (!placement.allowed) return { ok: false, reason: placement.reason };
  slot3 = placement.occupiedSlots[0];
  return {
    ok: true,
    items: items.map((candidate) => candidate.id === itemId ? { ...candidate, location: { kind: "unit", unitId, slot: slot3 } } : candidate).sort(compareIds4),
    events: [{ type: "itemEquipped", itemId, unitId, slot: slot3 }]
  };
}
function returnUnitItems(items, unitId) {
  const itemIds = items.filter((item) => item.location.kind === "unit" && item.location.unitId === unitId).map((item) => item.id).sort();
  return {
    items: items.map((item) => item.location.kind === "unit" && item.location.unitId === unitId ? { ...item, location: { kind: "inventory" } } : item).sort(compareIds4),
    events: itemIds.length ? [{ type: "itemsReturned", itemIds, unitId }] : []
  };
}

// src/simulation/item-selectors.ts
function previewCombine(state, aId, bId) {
  if (state.phase !== "preparation") return { allowed: false, reason: "wrong-phase" };
  if (isTemporaryItemId(state, aId) || isTemporaryItemId(state, bId)) return { allowed: false, reason: "temporary-item" };
  return validateCombine(state.items, aId, bId);
}
function previewEquip(state, itemId, unitId, slot3) {
  if (state.phase !== "preparation") return { allowed: false, reason: "wrong-phase", conflictingItemIds: [] };
  if (isTemporaryItemId(state, itemId)) return { allowed: false, reason: "temporary-item", conflictingItemIds: [] };
  return validateEquip(state.items, state.preparation, itemId, unitId, slot3);
}

// src/simulation/trait-snapshot.ts
var ascii = (a, b) => a < b ? -1 : a > b ? 1 : 0;
function deriveTraits(preparation, team, definitions2 = TRAIT_DEFINITIONS) {
  const boardUnits = preparation.units.filter((unit) => unit.team === team && unit.location.kind === "board").sort((a, b) => ascii(a.id, b.id));
  for (const unit of boardUnits) {
    if (!Object.hasOwn(UNIT_DEFINITIONS, unit.definitionId)) throw new RangeError(`Unknown unit definition: ${unit.definitionId}`);
    for (const traitId of UNIT_DEFINITIONS[unit.definitionId].traits) {
      if (!Object.hasOwn(definitions2, traitId)) throw new RangeError(`Unknown trait: ${traitId}`);
    }
  }
  return Object.keys(definitions2).sort(ascii).map((traitId) => {
    const definition = definitions2[traitId];
    const members = boardUnits.filter((unit) => UNIT_DEFINITIONS[unit.definitionId].traits.includes(traitId));
    const memberDefinitionIds = [...new Set(members.map((unit) => unit.definitionId))].sort(ascii);
    const count = memberDefinitionIds.length;
    const tier = definition.tiers.reduce((highest, candidate) => candidate.threshold <= count ? Math.max(highest, candidate.threshold) : highest, 0);
    const targets = definition.target === "team" ? boardUnits : members;
    return { team, traitId, count, tier, memberDefinitionIds, targetUnitIds: tier === 0 ? [] : targets.map((unit) => unit.id) };
  });
}

// src/simulation/strategy-snapshot.ts
var DEFAULT_CATALOG = {
  traits: TRAIT_DEFINITIONS,
  items: ITEM_DEFINITIONS,
  augments: AUGMENT_DEFINITIONS,
  anomalies: ANOMALY_DEFINITIONS
};
function lookup(catalog, id2) {
  if (!Object.hasOwn(catalog, id2)) throw new RangeError(`Unknown strategy definition: ${id2}`);
  return catalog[id2];
}
function buildStrategySnapshot(state, catalog = DEFAULT_CATALOG) {
  const __b8Timer = globalThis.__b8Start("buildStrategySnapshot");
  try {
    const traits = [...deriveTraits(state.preparation, "player", catalog.traits), ...deriveTraits(state.preparation, "enemy", catalog.traits)];
    const boardUnits = state.preparation.units.filter((unit) => unit.location.kind === "board").sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
    const units = boardUnits.map((unit) => {
      const sources = [];
      const itemPrograms2 = [];
      const bindItem = (definition, instanceId, parentItemInstanceId = null) => {
        if (!definition.combatProgram) return;
        validateItemProgram(definition.combatProgram);
        itemPrograms2.push({ source: { ownerId: unit.id, sourceKind: "item", definitionId: definition.id, instanceId, effectIndex: (definition.effects.length + 1) * 1024, parentItemInstanceId }, program: structuredClone(definition.combatProgram) });
      };
      for (const trait of traits) {
        if (trait.team !== unit.team || trait.tier === 0 || !trait.targetUnitIds.includes(unit.id)) continue;
        const definition = lookup(catalog.traits, trait.traitId);
        const tier = definition.tiers.find((candidate) => candidate.threshold === trait.tier);
        if (!tier) throw new RangeError(`Unknown trait tier: ${trait.traitId}/${trait.tier}`);
        sources.push(...makeSourcedEffects(unit.id, "trait", trait.traitId, `${trait.team}:${trait.tier}`, [...tier.effects, ...trait.memberDefinitionIds.includes(unit.definitionId) ? tier.memberEffects ?? [] : []]));
      }
      if (unit.team === "player") {
        for (const item of state.items) {
          if (item.location.kind !== "unit" || item.location.unitId !== unit.id) continue;
          const definition = lookup(catalog.items, item.definitionId);
          sources.push(...makeSourcedEffects(unit.id, "item", item.definitionId, item.id, definition.effects));
          bindItem(definition, item.id);
        }
        for (const child of state.temporaryEquipment.filter((item) => item.holderId === unit.id)) {
          const definition = lookup(catalog.items, child.definitionId);
          sources.push(...makeSourcedEffects(unit.id, "item", child.definitionId, child.temporaryId, definition.effects, child.parentItemInstanceId));
          bindItem(definition, child.temporaryId, child.parentItemInstanceId);
        }
        for (const augment of state.augments) {
          const definition = lookup(catalog.augments, augment.definitionId);
          sources.push(...makeSourcedEffects(unit.id, "augment", augment.definitionId, augment.choiceId, definition.effects.flatMap((effect) => {
            if (effect.kind !== "mechanic") return [effect];
            if (effect.mechanic === "pumpingUp") return [{ kind: "attackSpeedBps", bps: state.augmentProgress.pumpingRounds * effect.values.attackSpeedBpsPerRound }];
            if (effect.mechanic === "investment") return [{ kind: "statFlat", stat: "maxHp", amount: state.augmentProgress.investmentHp }];
            if (effect.values.backRowOnly && unit.location.kind === "board" && unit.location.cell.row !== state.preparation.board.deploymentZones.player.lastRow) return [];
            if (effect.mechanic === "bulkyBuddies") {
              const adjacent = boardUnits.filter((other) => other.team === unit.team && other.id !== unit.id && other.location.kind === "board" && unit.location.kind === "board" && hexDistance(other.location.cell, unit.location.cell) === 1);
              return adjacent.length === 1 ? [{ kind: "statFlat", stat: "maxHp", amount: effect.values.health }, effect] : [];
            }
            return [effect];
          })));
        }
        const binding = state.anomalyBinding;
        if (binding?.unitId === unit.id) {
          const definition = lookup(catalog.anomalies, binding.definitionId);
          sources.push(...makeSourcedEffects(unit.id, "anomaly", binding.definitionId, binding.choiceId, definition.effects));
        }
      } else {
        for (const item of readRoundEnemyProjection(state.round).items.filter((item2) => item2.unitId === unit.id)) {
          const definition = lookup(catalog.items, item.definitionId);
          sources.push(...makeSourcedEffects(unit.id, "item", item.definitionId, `enemy:${state.round}:${unit.id}:${item.slot}`, definition.effects));
          bindItem(definition, `enemy:${state.round}:${unit.id}:${item.slot}`);
        }
      }
      const growth = state.persistentGrowth.find((entry) => entry.unitId === unit.id);
      if (growth) sources.push(...makeSourcedEffects(unit.id, "ability", "tristana-ability", `persistent:${unit.id}`, [{ kind: "statPercentBps", stat: "attackDamage", bps: growth.attackDamageBps }]));
      const base = getUnitStats(unit.definitionId, unit.starLevel);
      const resolved = resolveEffects(base, resolveAbility(base.abilityId, unit.starLevel), sources);
      const mechanics = (resolved.mechanics ?? []).map((mechanic2) => {
        if (mechanic2.mechanic !== "bulkyBuddies") return mechanic2;
        const buddy = boardUnits.find((other) => other.team === unit.team && other.id !== unit.id && other.location.kind === "board" && unit.location.kind === "board" && hexDistance(other.location.cell, unit.location.cell) === 1);
        return { ...mechanic2, targetId: buddy.id };
      });
      if (unit.definitionId === "vander") mechanics.push({ source: { ownerId: unit.id, sourceKind: "ability", definitionId: "vander-ability", instanceId: unit.id, effectIndex: 0 }, mechanic: "lowCostAllies", values: { count: boardUnits.filter((other) => other.team === unit.team && UNIT_DEFINITIONS[other.definitionId].cost <= 2).length } });
      return { unitId: unit.id, ...resolved, mechanics, ...itemPrograms2.length ? { itemPrograms: itemPrograms2 } : {} };
    });
    return { traits, units };
  } finally {
    globalThis.__b8End(__b8Timer);
  }
}

// src/simulation/rewards.ts
function planReward(state, event) {
  const previous = state.scheduleReceipts.find((receipt) => receipt.eventId === event.id);
  if (previous) {
    if (previous.kind !== "reward" || previous.round !== state.round) throw new Error("Conflicting reward receipt");
    return {
      items: state.items,
      nextItemSerial: state.nextItemSerial,
      rewardRngState: state.rewardRngState,
      gold: state.gold,
      preparation: state.preparation,
      nextUnitSerial: state.nextUnitSerial,
      receipt: previous
    };
  }
  let rewardRngState = state.rewardRngState;
  let nextItemSerial = state.nextItemSerial;
  let nextUnitSerial = state.nextUnitSerial;
  let preparation = state.preparation;
  let items = state.items;
  const definitions2 = [...event.components];
  if (!Number.isSafeInteger(event.randomComponents) || event.randomComponents < 0 || !Number.isSafeInteger(event.gold) || event.gold < 0) throw new RangeError("Invalid reward");
  for (let i = 0; i < event.randomComponents; i++) {
    const draw = nextRandom(rewardRngState);
    rewardRngState = draw.state;
    definitions2.push(COMPONENT_IDS[draw.word % COMPONENT_IDS.length]);
  }
  const itemIds = [];
  for (const definitionId2 of definitions2) {
    if (ITEM_DEFINITIONS[definitionId2]?.kind !== "component") throw new RangeError(`Unknown reward component: ${definitionId2}`);
    const granted = planPermanentItemGrant({ items, nextItemSerial }, { definitionId: definitionId2, receiptId: event.id }, state.scheduleReceipts.map((receipt) => receipt.eventId));
    if (!granted.ok) throw new RangeError(`Invalid reward item grant: ${granted.reason}`);
    ({ items, nextItemSerial } = granted.state);
    itemIds.push(...granted.grantedItemIds);
  }
  let unitId = null;
  if (event.recruitIfEmpty && !preparation.units.some((unit) => unit.team === "player")) {
    unitId = `unit-${nextUnitSerial++}`;
    preparation = { ...preparation, units: [...preparation.units, {
      id: unitId,
      definitionId: ROUND_SCHEDULE.fallbackDefinitionId,
      team: "player",
      starLevel: 1,
      location: { kind: "bench", slot: 0 }
    }] };
  }
  const gold = state.gold + event.gold;
  if (![gold, nextItemSerial, nextUnitSerial].every(Number.isSafeInteger)) throw new RangeError("Reward integer overflow");
  return {
    items,
    nextItemSerial,
    rewardRngState,
    gold,
    preparation,
    nextUnitSerial,
    receipt: { eventId: event.id, round: state.round, kind: "reward", itemIds, gold: event.gold, unitId, definitionId: null }
  };
}

// src/simulation/choices.ts
function generateChoices(ids2, rngState) {
  const pool = [...ids2].sort();
  if (pool.length < 3 || new Set(pool).size !== pool.length) throw new Error("Choice pool must contain at least three unique IDs");
  for (let i = 0; i < 3; i++) {
    const draw = nextRandom(rngState);
    rngState = draw.state;
    const j = i + draw.word % (pool.length - i);
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return { offers: pool.slice(0, 3), choiceRngState: rngState };
}

// src/simulation/encounter-selectors.ts
var HERO_RULES = {
  irelia: "\u8870\u51CF\u62A4\u76FE\uFF1B\u8017\u5C3D\u6216\u5230\u671F\u540E\u8FD1\u8EAB\u9B54\u6CD5\u7206\u53D1\u3002",
  maddie: "\u5F15\u5BFC\u5C04\u51FB\u6700\u8FDC\u76EE\u6807\uFF0C\u8DEF\u5F84\u9996\u654C\u62E6\u622A\uFF1B\u63A7\u5236\u6216\u6B7B\u4EA1\u53D6\u6D88\u540E\u7EED\u5C04\u51FB\u3002",
  darius: "\u8FD1\u8EAB\u7269\u7406\u4F24\u5BB3\u3001\u81EA\u7597\u53CA\u6301\u7EED\u6D41\u8840\u3002",
  lux: "\u4FDD\u62A4\u5F53\u524D\u751F\u547D\u6700\u4F4E\u7684\u53CB\u519B\uFF0C\u5E76\u5F3A\u5316\u4E0B\u4E00\u6B21\u666E\u653B\u3002",
  zyra: "\u4E3B\u76EE\u6807\u9B54\u4F24\u4E0E\u7729\u6655\uFF0C\u53E6\u653B\u51FB\u4E24\u4E2A\u6700\u8FD1\u654C\u4EBA\u3002",
  tristana: "\u7269\u7406\u653B\u51FB\uFF1B\u51FB\u6740\u65F6\u6EA2\u51FA\u5F39\u5C04\u5E76\u79EF\u7D2F\u6C38\u4E45\u653B\u51FB\u6210\u957F\u3002",
  urgot: "\u4E3B\u76EE\u6807\u53CA\u90BB\u8FD1\u654C\u4EBA\u7269\u7406\u4F24\u5BB3\u4E0E\u51CF\u7532\u3002",
  rell: "\u81EA\u8EAB\u62A4\u76FE\u3001\u8DEF\u5F84\u9B54\u4F24\u4E0E\u53CC\u6297\u8F6C\u79FB\u3002",
  leona: "\u6682\u65F6\u51CF\u4F24\uFF0C\u968F\u540E\u8FD1\u8EAB\u7206\u53D1\u3002",
  vander: "\u5F15\u5BFC\u83B7\u5F97\u53CC\u6297\uFF0C\u5E76\u6309\u4F4E\u8D39\u53CB\u519B\u6570\u5F3A\u5316\u4E0B\u4E00\u6B21\u653B\u51FB\u3002",
  kogmaw: "\u666E\u653B\u9644\u52A0\u9B54\u4F24\uFF1B\u65BD\u6CD5\u7D2F\u8BA1\u653B\u901F\uFF0C\u5E76\u9010\u6B65\u589E\u52A0\u5C04\u7A0B\u3002",
  scar: "\u6700\u8FD1\u4E09\u4E2A\u654C\u4EBA\u9B54\u4F24\u4E0E\u7729\u6655\uFF0C\u5E76\u81EA\u7597\u3002",
  ezreal: "\u76EE\u6807\u5468\u56F4\u7269\u7406\u4F24\u5BB3\uFF0C\u4E3B\u76EE\u6807\u53E6\u53D7\u8FFD\u52A0\u4F24\u5BB3\u3002",
  loris: "\u62A4\u76FE\u4E0E\u90BB\u8FD1\u53CB\u519B\u4F24\u5BB3\u5206\u62C5\uFF0C\u6301\u7EED\u7ED3\u675F\u540E\u8303\u56F4\u7206\u53D1\u3002",
  nami: "\u9B54\u6CD5\u4F24\u5BB3\u5728\u90BB\u8FD1\u654C\u4EBA\u4E4B\u95F4\u8DF3\u8DC3\uFF0C\u4E0D\u91CD\u590D\u547D\u4E2D\u3002",
  corki: "\u5F15\u5BFC\u8F70\u51FB\u5F53\u524D\u76EE\u6807\u9644\u8FD1\uFF0C\u7269\u7406\u4F24\u5BB3\u5E76\u51CF\u7532\u3002",
  garen: "\u81EA\u8EAB\u62A4\u76FE\uFF0C\u5BF9\u4E3B\u76EE\u6807\u53CA\u5176\u5468\u56F4\u654C\u4EBA\u9020\u6210\u7269\u7406\u4F24\u5BB3\u3002",
  zoe: "\u4E3B\u76EE\u6807\u9B54\u4F24\uFF0C\u5728\u9644\u8FD1\u672A\u547D\u4E2D\u7684\u6700\u8FDC\u654C\u4EBA\u95F4\u53CD\u5F39\uFF0C\u6BCF\u6B21\u8FD4\u56DE\u4E3B\u76EE\u6807\u3002",
  caitlyn: "\u5F15\u5BFC\u591A\u8F6E\u968F\u673A\u654C\u519B\u4E2D\u5FC3\u8303\u56F4\u7269\u7406\u4F24\u5BB3\uFF0C\u4E2D\u5FC3\u53E6\u53D7\u7206\u5934\u4F24\u5BB3\u3002"
};
function neutralDescription(m) {
  switch (m.kind) {
    case "none":
      return "\u4EC5\u666E\u653B\uFF1B\u65E0\u84DD\u3001\u65E0\u4E3B\u52A8\u6280\u80FD\u3002";
    case "companion-heal":
      return `\u540C\u65CF\u540C\u4F34\u6B7B\u4EA1\u540E\uFF0C\u4E0B\u4E00tick\u56DE\u590D\u5F53\u65F6\u7F3A\u5931\u751F\u547D\u7684${m.missingHpBps / 100}%\uFF0C\u53D7\u91CD\u4F24\u5F71\u54CD\u3002`;
    case "backline-jump":
      return "\u5F00\u573A\u4E00\u6B21\u8DF3\u5411\u654C\u65B9\u540E\u6392\u90BB\u8FD1\u7A7A\u683C\uFF1B\u65E0\u7A7A\u4F4D\u5219\u4E0D\u8DF3\uFF0C\u65E0\u4F24\u5BB3\u3002";
    case "companion-speed":
      return `\u6BCF\u4E2A\u540C\u65CF\u540C\u4F34\u6B7B\u4EA1\u540E\uFF0C\u4E0B\u4E00tick\u589E\u52A0${m.attackSpeedBps / 100}%\u653B\u901F\uFF0C\u6700\u591A${m.maxReactions}\u5C42\u3002`;
    case "attack-cone":
      return `\u666E\u653B\u7A84\u9525\u5F62\u6E85\u5C04\u81F3\u591A\u4E24\u4E2A\u526F\u76EE\u6807\uFF0C\u5404\u53D7${m.secondaryDamageBps / 100}%\u653B\u51FB\u529B\u7684\u7269\u7406\u4F24\u5BB3\uFF1B\u526F\u5305\u4E0D\u66B4\u51FB\u3002`;
    case "path-charge":
      return `\u5F00\u573A\u4E00\u6B21\u6700\u591A\u56DB\u683C\u51B2\u950B\uFF1Btick1\u5BF9\u8DEF\u5F84\u76EE\u6807\u9020\u6210\u6700\u5927\u751F\u547D${m.targetMaxHpBps / 100}%\u9B54\u4F24\uFF0C\u5C01\u9876${m.damageCap}\uFF1B\u5B58\u6D3B\u4E14\u4E0D\u514D\u63A7\u8005\u4E0B\u4E00tick\u7729\u6655${m.stunTicks}tick\u3002`;
  }
}
function readEncounterPreview(state) {
  if (state.m8.round.kind === "supply") return null;
  const snapshot = buildStrategySnapshot(state);
  return freezeContent({
    // B6 has no PvP encounter ID: this read-only namespace identifies its fixed public opponent.
    encounterId: state.m8.round.encounterId ?? `pvp:${state.m8.round.roundId}`,
    units: state.m8.preparation.enemies.map((u) => {
      const resolved = snapshot.units.find((s) => s.unitId === u.id), stats = resolved.stats, d = UNIT_DEFINITIONS[u.definitionId];
      const neutral2 = NEUTRAL_DEFINITIONS[u.definitionId];
      if (d.unitKind === "neutral" ? !neutral2 || stats.monsterFamily !== neutral2.monsterFamily : !Object.hasOwn(M5_UNIT_DEFINITIONS, u.definitionId) || neutral2) throw new RangeError("Invalid preview content classification");
      const initial = compileCombatInitialInputs(u.id, stats, resolved.ability, resolved);
      if (initial.abilityPower === void 0) throw new RangeError("Missing preview ability power");
      const crit = spellCrit({ ...initial, id: u.id, ability: resolved.ability });
      const mana2 = projectCombatStartMana({ ...initial, id: u.id, triggers: resolved.triggers, effectRuntime: initializeEffectRuntime(resolved.triggers) }).after;
      if (u.location.kind !== "board") throw new RangeError("Enemy preview requires board deployment");
      return {
        unitId: u.id,
        definitionId: u.definitionId,
        name: d.name,
        starLevel: u.starLevel,
        cell: { ...u.location.cell },
        unitKind: neutral2 ? "neutral" : "champion",
        monsterFamily: neutral2?.monsterFamily ?? null,
        stats: {
          maxHp: stats.health,
          attackDamage: stats.attack,
          armor: stats.armor,
          magicResist: stats.magicResist,
          attackRange: stats.attackRange,
          attackIntervalTicks: stats.attackIntervalTicks,
          critChanceBps: crit.chanceBps,
          critMultiplierBps: crit.multiplierBps,
          abilityPower: initial.abilityPower,
          mana: mana2,
          maxMana: stats.maxMana
        },
        abilityDescription: d.unitKind === "neutral" ? neutralDescription(NEUTRAL_DEFINITIONS[u.definitionId].mechanism) : HERO_RULES[u.definitionId]
      };
    }),
    rulesNote: state.m8.round.kind === "pve" ? "\u56FA\u5B9A\u666E\u901APvE\uFF1B\u9879\u76EE\u9996\u7248\u53C2\u6570\uFF0C25%\u57FA\u7840\u666E\u653B\u66B4\u51FB\u30011.4\u500D\u4F24\u5BB3\uFF1B\u65E0\u88C5\u5907\u3001\u65E0\u7F81\u7ECA\u3001\u4E0D\u53EF\u8D2D\u4E70\u6216\u51FA\u552E\u3002\u7279\u6B8A\u5947\u9047\u6C60\u672A\u542F\u7528\u3002" : "\u56FA\u5B9APvP\u6A21\u677F\uFF1B\u516C\u5F00\u661F\u7EA7\u3001\u88C5\u5907\u4E0E\u7F81\u7ECA\u53C2\u4E0E\u5F00\u6218\u5C5E\u6027\u8BA1\u7B97\uFF0C\u4E0D\u4ECE\u4E2D\u7ACB\u906D\u9047\u6C60\u62BD\u53D6\u3002"
  });
}

// src/simulation/match.ts
var fail2 = (state, reason) => ({ ok: false, state, reason });
var accept = (state, events = []) => {
  let seq = state.nextMatchEventSeq;
  const stamped = events.map((event) => "tick" in event ? event : { ...event, domain: "match", eventSeq: seq++ });
  return { ok: true, state: { ...state, nextMatchEventSeq: seq }, events: stamped };
};
function acceptEquipment(state, events) {
  const planned = planTemporaryEquipment(state);
  return accept(planned.state, [...events, ...planned.events]);
}
function needsAnomalyRecruitment(state) {
  return state.phase === "preparation" && !state.preparation.units.some((unit) => unit.team === "player") && getRoundSchedule(state.round).some((event) => event.kind === "anomaly" && !state.scheduleReceipts.some((receipt) => receipt.eventId === event.id));
}
function affordableOffer(state, gold = state.gold) {
  return state.shop.slots.some((slot3) => slot3.status === "available" && UNIT_DEFINITIONS[slot3.definitionId].cost <= gold);
}
function enterScheduledEvents(initial, timing = "before") {
  let state = initial;
  const events = [];
  for (const event of getRoundSchedule(state.round).filter((event2) => (event2.timing ?? "before") === timing)) {
    if (state.scheduleReceipts.some((receipt) => receipt.eventId === event.id)) continue;
    if (event.kind === "reward") {
      const { receipt, ...plan } = planReward(state, event);
      state = { ...state, ...plan, scheduleReceipts: [...state.scheduleReceipts, receipt] };
      events.push({ type: "rewardGranted", receipt });
      continue;
    }
    if (event.kind === "anomaly" && !state.preparation.units.some((unit) => unit.team === "player")) continue;
    let choiceRngState = state.choiceRngState;
    let offers = [];
    if (event.kind === "augment") {
      const drawn = generateChoices(Object.keys(AUGMENT_DEFINITIONS).filter((id2) => !state.augments.some((a) => a.definitionId === id2)), choiceRngState);
      offers = drawn.offers;
      choiceRngState = drawn.choiceRngState;
    } else if (event.kind === "component") offers = [...COMPONENT_IDS];
    const pendingChoice = {
      kind: event.kind,
      step: event.kind === "anomaly" ? "target" : "offer",
      choiceId: event.id,
      eventId: event.id,
      generation: 0,
      offers,
      targetId: null,
      rerollCount: 0,
      returnPhase: timing === "after" || getRoundKind(state.round) === "supply" ? "settlement" : "preparation"
    };
    state = { ...state, choiceRngState, phase: "choice", combat: timing === "after" ? state.combat : null, pendingChoice };
    events.push({ type: "choiceOpened", choice: pendingChoice });
    return { state, events };
  }
  return { state: {
    ...state,
    phase: timing === "after" ? "settlement" : "preparation",
    combat: timing === "after" ? state.combat : null,
    pendingChoice: null
  }, events };
}
function prepareRound(seed, round2, previous) {
  const definition = getCatalogRoundByOrdinal(round2);
  return freezeContent({ round: definition, encounterPlan: null, loot: prepareMatchLoot(seed, round2, previous), preparation: {
    version: ROUND_PREPARATION_RULES.version,
    roundId: definition.roundId,
    encounterId: definition.encounterId,
    contentStatus: definition.kind === "pve" ? ROUND_PREPARATION_RULES.pveContent : "not-pve",
    enemies: createRoundEnemies(round2)
  } });
}
function createMatch(seed = DEFAULT_MATCH_SEED) {
  validateSeed(seed);
  validateContent();
  const m8 = prepareRound(seed, 1);
  const initial = {
    schemaVersion: 5,
    rulesVersion: "m5-14.24b-v1",
    contentVersion: "s13-14.24b-slice-v1",
    commandProtocolVersion: 2,
    rngAlgorithm: "lcg32-v1",
    tickMs: 50,
    m8,
    combatInputBasis: null,
    resourceProvenance: appendResourceProvenance(
      { version: RESOURCE_PROVENANCE_VERSION, entries: [] },
      m8.round.roundId,
      { kind: "unit-acquired", unitId: OPENING_INITIAL_STATE.unit.id, source: { kind: "opening" } }
    ),
    roundDefinitionId: m8.round.roundId,
    streak: { kind: null, count: 0 },
    outcome: null,
    persistentGrowth: [],
    augmentProgress: { pumpingRounds: 0, investmentHp: 0 },
    battleSeedRngState: (seed ^ 2654435769) >>> 0,
    contentDigest: CONTENT_DIGEST,
    seed,
    equipmentState: { equipment: initializeStreams(seed).equipment, rolls: [] },
    temporaryEquipment: [],
    items: [],
    nextItemSerial: 1,
    augments: [],
    anomalyBinding: null,
    pendingChoice: null,
    scheduleReceipts: [],
    choiceRngState: (seed ^ 2654435769) >>> 0,
    rewardRngState: (seed ^ 2246822507) >>> 0,
    nextMatchEventSeq: 0,
    ...generateShop(seed, 1, MATCH_RULES.initialLevel),
    round: 1,
    gold: MATCH_RULES.initialGold,
    level: MATCH_RULES.initialLevel,
    xp: OPENING_INITIAL_STATE.xp,
    playerHp: MATCH_RULES.initialHp,
    nextUnitSerial: OPENING_INITIAL_STATE.nextUnitSeq,
    preparation: { board: structuredClone(DEFAULT_BOARD), benchSize: 9, units: [
      {
        id: OPENING_INITIAL_STATE.unit.id,
        definitionId: OPENING_INITIAL_STATE.unit.definitionId,
        team: "player",
        starLevel: OPENING_INITIAL_STATE.unit.starLevel,
        location: { kind: "board", cell: { ...OPENING_INITIAL_STATE.unit.cell } }
      },
      ...m8.preparation.enemies
    ] },
    roundResults: [],
    phase: "preparation",
    combat: null
  };
  const entered = enterScheduledEvents(initial);
  return accept(entered.state, entered.events).state;
}
function getDeploymentCap(state) {
  return state.level;
}
function validateMatchDeployment(state, unitId, target) {
  if (state.phase !== "preparation") return "wrong-phase";
  const reason = validateDeployment(state.preparation, unitId, target);
  if (reason) return reason;
  const unit = state.preparation.units.find((unit2) => unit2.id === unitId);
  return target.kind === "board" && unit.location.kind === "bench" && getPlayerDeploymentCount(state.preparation) >= getDeploymentCap(state) ? "population-cap" : void 0;
}
function deployMatchUnit(state, unitId, target) {
  const reason = validateMatchDeployment(state, unitId, target);
  if (reason) return fail2(state, reason);
  const result = deployUnit(state.preparation, unitId, target);
  return result.ok ? accept({ ...state, preparation: result.state }) : fail2(state, result.reason);
}
function buyUnit(state, slotIndex, expectedGeneration) {
  if (state.phase !== "preparation") return fail2(state, "wrong-phase");
  if (!Number.isInteger(slotIndex) || slotIndex < 0 || slotIndex >= state.shop.slots.length) return fail2(state, "invalid-slot");
  if (expectedGeneration !== state.shop.generation) return fail2(state, "stale-shop");
  const offer = state.shop.slots[slotIndex];
  if (offer.status !== "available") return fail2(state, "purchased-slot");
  const cost = UNIT_DEFINITIONS[offer.definitionId].cost;
  if (state.gold < cost) return fail2(state, "insufficient-gold");
  const plan = planUnitAcquisition(
    state,
    offer.definitionId,
    { kind: "shop", generation: expectedGeneration, slotIndex, definitionId: offer.definitionId },
    state.resourceProvenance.entries.length
  );
  if (!plan.ok) return fail2(state, plan.reason);
  const purchased = {
    ...state,
    items: plan.items,
    anomalyBinding: plan.anomalyBinding,
    persistentGrowth: mergeGrowthLedger(state.persistentGrowth, plan.upgradeEvents),
    gold: state.gold - cost,
    nextUnitSerial: plan.nextUnitSerial,
    resourceProvenance: appendResourceProvenance(state.resourceProvenance, state.roundDefinitionId, plan.facts),
    preparation: plan.preparation,
    shop: { ...state.shop, slots: state.shop.slots.map((item, index) => index === slotIndex ? { status: "purchased" } : item) }
  };
  const entered = needsAnomalyRecruitment(state) ? enterScheduledEvents(purchased) : { state: purchased, events: [] };
  return acceptEquipment(entered.state, [...plan.events, ...entered.events]);
}
function sellUnit(state, unitId) {
  const capacity = state.phase === "settlement" && hasPendingLootCapacity(state) && !unresolvedLootChoices(state).length;
  if (state.phase !== "preparation" && !capacity) return fail2(state, "wrong-phase");
  const unit = state.preparation.units.find((unit2) => unit2.id === unitId);
  if (!unit) return fail2(state, "unknown-unit");
  if (unit.team !== "player") return fail2(state, "enemy-unit");
  const returned = returnUnitItems(state.items, unitId), removesBinding = state.anomalyBinding?.unitId === unitId;
  const goldGranted = getUnitSellPrice(unit);
  let sold = {
    ...state,
    items: returned.items,
    anomalyBinding: removesBinding ? null : state.anomalyBinding,
    persistentGrowth: state.persistentGrowth.filter((growth) => growth.unitId !== unitId),
    gold: state.gold + goldGranted,
    resourceProvenance: appendResourceProvenance(
      state.resourceProvenance,
      state.roundDefinitionId,
      { kind: "unit-sold", unitId, context: capacity ? "settlement-capacity" : "preparation", goldGranted }
    ),
    preparation: { ...state.preparation, units: state.preparation.units.filter((unit2) => unit2.id !== unitId) }
  };
  const events = [...returned.events, ...removesBinding ? [{ type: "anomalyRemoved", unitId }] : []];
  if (capacity) {
    const granted = grantDirectLoot(sold, false);
    sold = granted.state;
    events.push(...granted.events);
  }
  return acceptEquipment(sold, events);
}
function setShopLock(state, locked, expectedGeneration) {
  if (state.phase !== "preparation") return fail2(state, "wrong-phase");
  if (typeof locked !== "boolean") return fail2(state, "invalid-choice");
  if (expectedGeneration !== state.shop.generation) return fail2(state, "stale-shop");
  if (Boolean(state.shop.locked) === locked) return { ok: true, state, events: [] };
  return accept({ ...state, shop: { ...state.shop, locked } });
}
function rerollShop(state) {
  if (state.phase !== "preparation") return fail2(state, "wrong-phase");
  if (state.gold < MATCH_RULES.rerollCost) return fail2(state, "insufficient-gold");
  const generated = generateShop(state.rngState, state.shop.generation + 1, state.level);
  if (needsAnomalyRecruitment(state) && !affordableOffer({ ...state, ...generated }, state.gold - MATCH_RULES.rerollCost)) return fail2(state, "insufficient-gold");
  return accept({
    ...state,
    gold: state.gold - MATCH_RULES.rerollCost,
    ...generated,
    shop: { ...generated.shop, locked: Boolean(state.shop.locked) }
  });
}
function buyXp(state) {
  if (state.phase !== "preparation") return fail2(state, "wrong-phase");
  if (state.level >= MATCH_RULES.maxLevel) return fail2(state, "max-level");
  if (state.gold < MATCH_RULES.xpPurchaseCost) return fail2(state, "insufficient-gold");
  if (needsAnomalyRecruitment(state) && !affordableOffer(state, state.gold - MATCH_RULES.xpPurchaseCost)) return fail2(state, "insufficient-gold");
  const progression = grantXp(state.level, state.xp, MATCH_RULES.xpPurchaseAmount);
  return accept({ ...state, gold: state.gold - MATCH_RULES.xpPurchaseCost, level: progression.level, xp: progression.xp });
}
function matchStartFailure(state) {
  if (state.phase !== "preparation") return "wrong-phase";
  if (needsAnomalyRecruitment(state)) return "missing-player";
  if (getPlayerDeploymentCount(state.preparation) > getDeploymentCap(state)) return "population-cap";
  const reason = validateCombatStart(state.preparation);
  return reason === "missing-player" ? void 0 : reason;
}
function settleRound(state, combat2, pendingDelta = []) {
  if (state.roundResults.some((record4) => record4.round >= state.round)) throw new Error("Duplicate settlement");
  const { kind: roundKind, isFinal, roundId } = state.m8.round;
  const survivingEnemyCount = combat2?.units.filter((unit) => unit.alive && unit.team === "enemy").length ?? 0;
  const plan = planCatalogRoundEconomy({
    roundId,
    result: combat2?.result ?? null,
    gold: state.gold,
    streak: state.streak,
    level: state.level,
    xp: state.xp,
    hp: state.playerHp,
    enemySurvivors: survivingEnemyCount
  });
  const growth = new Map(state.persistentGrowth.map((entry) => [entry.unitId, entry.attackDamageBps]));
  for (const delta of pendingDelta) growth.set(delta.unitId, (growth.get(delta.unitId) ?? 0) + delta.attackDamageBps);
  const resourceProvenance = combat2 ? appendResourceProvenance(state.resourceProvenance, roundId, {
    kind: "combat-growth-committed",
    combatId: combat2.combatId,
    settlementId: `round-${state.round}-settled`,
    combatStartProvenancePrefixLength: state.combatInputBasis.provenancePrefixLength,
    sourceDeltas: combatGrowth(combat2).map(({ unitId, attackDamageBps }) => ({ sourceUnitId: unitId, attackDamageBps }))
  }) : state.resourceProvenance;
  const terminal = plan.hpAfter === 0 || isFinal;
  const outcome = terminal ? isFinal && plan.hpAfter > 0 && combat2?.result === "playerWin" ? "victory" : "defeat" : null;
  return {
    ...state,
    resourceProvenance,
    phase: terminal ? "gameOver" : "settlement",
    outcome,
    combat: combat2,
    gold: plan.goldAfter,
    playerHp: plan.hpAfter,
    streak: plan.streakAfter,
    level: plan.progression.level,
    xp: plan.progression.xp,
    persistentGrowth: [...growth].map(([unitId, attackDamageBps]) => ({ unitId, attackDamageBps })).sort((a, b) => a.unitId.localeCompare(b.unitId)),
    augmentProgress: {
      pumpingRounds: state.augmentProgress.pumpingRounds + (state.augments.some((a) => a.definitionId === "pumping-up-i") ? 1 : 0),
      investmentHp: state.augmentProgress.investmentHp + (state.augments.some((a) => a.definitionId === "investment-strategy-i") ? 8 * plan.incomeBreakdown.interest : 0)
    },
    roundResults: [...state.roundResults, {
      round: state.round,
      roundId,
      settlementId: `round-${state.round}-settled`,
      roundKind,
      result: combat2?.result ?? "supply",
      combatTicks: combat2?.tick ?? 0,
      combatEventCount: combat2?.nextEventSeq ?? 0,
      income: plan.income,
      incomeBreakdown: plan.incomeBreakdown,
      interestBasis: plan.interestBasis,
      streakBefore: state.streak,
      streakAfter: plan.streakAfter,
      goldBefore: state.gold,
      goldAfter: plan.goldAfter,
      xpRequested: plan.progression.xpRequested,
      xpAwarded: plan.progression.xpApplied,
      levelBefore: state.level,
      levelAfter: plan.progression.level,
      xpBefore: state.xp,
      xpAfter: plan.progression.xp,
      hpBefore: state.playerHp,
      hpAfter: plan.hpAfter,
      baseDamage: plan.baseDamage,
      survivingEnemyCount,
      playerDamage: plan.playerDamage,
      hpLost: plan.hpLost
    }]
  };
}
function combatGrowth(combat2) {
  return combat2.units.filter((unit) => unit.team === "player" && (unit.runtime?.permanentAdBps ?? 0) > 0).map((unit) => ({ unitId: unit.id, attackDamageBps: unit.runtime.permanentAdBps })).sort((a, b) => a.unitId < b.unitId ? -1 : a.unitId > b.unitId ? 1 : 0);
}
function enterLootChoice(state) {
  const descriptor = unresolvedLootChoices(state)[0];
  if (!descriptor) return { state, events: [] };
  const pendingChoice = makeLootPendingChoice(descriptor);
  return { state: { ...state, phase: "choice", combat: state.combat, pendingChoice }, events: [{ type: "choiceOpened", choice: pendingChoice }] };
}
function withCombat(initial, combat2) {
  const revealed = revealMatchLoot(initial, combat2), events = [...revealed.events];
  if (combat2.status === "running") return { state: { ...revealed.state, phase: "combat", combat: combat2 }, events };
  if (combat2.result === null) throw new Error("Invalid combat result");
  const before = { ...revealed.state, phase: "settlement", combat: combat2, pendingChoice: null };
  const terminal = before.m8.round.isFinal || planCatalogRoundEconomy({
    roundId: before.roundDefinitionId,
    result: combat2.result,
    gold: before.gold,
    streak: before.streak,
    level: before.level,
    xp: before.xp,
    hp: before.playerHp,
    enemySurvivors: combat2.units.filter((unit) => unit.team === "enemy" && unit.alive).length
  }).hpAfter === 0;
  const granted = grantDirectLoot(before, terminal);
  let state = granted.state;
  events.push(...granted.events);
  if (terminal) for (const descriptor of unresolvedLootChoices(state)) {
    const fallback = grantLootChoice(state, descriptor, descriptor.terminalFallbackDefinitionId, "terminal-fallback");
    state = fallback.state;
    events.push(...fallback.events);
  }
  const equipment = planTemporaryEquipment(state);
  events.push(...equipment.events);
  const settled = settleRound(equipment.state, combat2, mergeGrowthLedger(combatGrowth(combat2), granted.upgradeEvents));
  events.push({ type: "roundSettled", round: state.round });
  if (settled.phase === "gameOver") return { state: settled, events };
  const choice = enterLootChoice(settled);
  if (choice.state.phase === "choice") return { state: choice.state, events: [...events, ...choice.events] };
  const entered = enterScheduledEvents(settled, "after");
  return { state: entered.state, events: [...events, ...entered.events] };
}
function startMatchCombat(state) {
  const reason = matchStartFailure(state);
  if (reason) return fail2(state, reason);
  const draw = nextRandom(state.battleSeedRngState);
  const combatInputBasis = freezeCombatInput(state, draw.word, state.resourceProvenance.entries.length);
  const started = createCombatWithEvents(combatInputBasis.inputs.preparation, buildStrategySnapshot(combatInputBasis.inputs), `round-${state.round}`, draw.word);
  const next = withCombat({ ...state, combatInputBasis, battleSeedRngState: draw.state }, started.state);
  return accept(next.state, [...started.events, ...next.events]);
}
function stepMatch(state) {
  if (state.phase !== "combat") return { state, events: [] };
  const next = stepCombat(state.combat), settled = withCombat(state, next.state);
  const result = accept(settled.state, [...next.events, ...settled.events]);
  return { state: result.state, events: result.ok ? result.events : [] };
}
function nextRound(state, expectedRound) {
  if (state.phase !== "settlement") return fail2(state, "wrong-phase");
  if (expectedRound !== state.round) return fail2(state, "stale-round");
  if (unresolvedLootChoices(state).length || hasPendingLootCapacity(state)) return fail2(state, "unsettled-round");
  if (state.roundResults.length !== state.round || state.roundResults.at(-1)?.round !== state.round) return fail2(state, "unsettled-round");
  const definition = getNextCatalogRound(state.m8.round.roundId);
  if (!definition) return fail2(state, "wrong-phase");
  const round2 = definition.ordinal, m8 = prepareRound(state.seed, round2, state.m8.loot);
  const emptyAnomaly = getRoundSchedule(round2).some((event) => event.kind === "anomaly") && !state.preparation.units.some((unit) => unit.team === "player");
  const refresh2 = state.shop.locked && !(emptyAnomaly && !affordableOffer(state)) ? { shop: state.shop, rngState: state.rngState } : generateShop(state.rngState, state.shop.generation + 1, state.level);
  const entered = enterScheduledEvents({
    ...state,
    round: round2,
    m8,
    roundDefinitionId: definition.roundId,
    phase: "preparation",
    combat: null,
    combatInputBasis: null,
    preparation: { ...state.preparation, units: [...state.preparation.units.filter((unit) => unit.team === "player"), ...m8.preparation.enemies] },
    ...refresh2
  });
  return acceptEquipment(entered.state, entered.events);
}
function combineItems(state, aId, bId) {
  const preview = previewCombine(state, aId, bId);
  if (!preview.allowed) return fail2(state, preview.reason);
  const plan = planCombine(state.items, state.nextItemSerial, aId, bId);
  return plan.ok ? accept({
    ...state,
    items: plan.items,
    nextItemSerial: plan.nextItemSerial,
    resourceProvenance: appendResourceProvenance(state.resourceProvenance, state.roundDefinitionId, plan.events.filter((event) => event.type === "itemCombined").map((event) => ({ kind: "item-combined", event })))
  }, plan.events) : fail2(state, plan.reason);
}
function equipItem(state, itemId, unitId, slot3) {
  const preview = previewEquip(state, itemId, unitId, slot3);
  if (!preview.allowed) return fail2(state, preview.reason);
  const plan = planEquip(state.items, state.preparation, itemId, unitId, slot3);
  return plan.ok ? acceptEquipment({ ...state, items: plan.items }, plan.events) : fail2(state, plan.reason);
}
function choiceFailure(state, choiceId, generation) {
  if (state.phase !== "choice") return "wrong-phase";
  if (!state.pendingChoice || state.pendingChoice.choiceId !== choiceId || state.pendingChoice.generation !== generation) return "stale-choice";
  return void 0;
}
function selectAnomalyTarget(state, choiceId, generation, unitId) {
  const reason = choiceFailure(state, choiceId, generation);
  if (reason) return fail2(state, reason);
  const choice = state.pendingChoice;
  if (choice.kind !== "anomaly" || choice.step !== "target") return fail2(state, "invalid-choice");
  const target = state.preparation.units.find((unit) => unit.id === unitId);
  if (!target || target.team !== "player" || state.anomalyBinding !== null) return fail2(state, "invalid-target");
  const draw = generateAnomalyOffer(Object.keys(ANOMALY_DEFINITIONS), state.choiceRngState);
  return accept(
    { ...state, choiceRngState: draw.choiceRngState, pendingChoice: { ...choice, step: "offer", targetId: unitId, offers: draw.offers, generation: generation + 1 } },
    [{ type: "anomalyTargetSelected", choiceId, unitId }]
  );
}
function rerollAnomaly(state, choiceId, generation) {
  const reason = choiceFailure(state, choiceId, generation);
  if (reason) return fail2(state, reason);
  const choice = state.pendingChoice;
  if (choice.kind !== "anomaly" || choice.step !== "offer") return fail2(state, "invalid-choice");
  if (!state.preparation.units.some((unit) => unit.id === choice.targetId && unit.team === "player")) return fail2(state, "invalid-target");
  if (state.gold < 1) return fail2(state, "insufficient-gold");
  const draw = generateAnomalyOffer(Object.keys(ANOMALY_DEFINITIONS).filter((id2) => !choice.offers.includes(id2)), state.choiceRngState);
  return accept(
    {
      ...state,
      gold: state.gold - 1,
      choiceRngState: draw.choiceRngState,
      pendingChoice: { ...choice, offers: draw.offers, generation: generation + 1, rerollCount: choice.rerollCount + 1 }
    },
    [{ type: "anomalyRerolled", choiceId, generation: generation + 1, cost: 1 }]
  );
}
function generateAnomalyOffer(ids2, rngState) {
  const pool = [...ids2].sort(), draw = nextRandom(rngState);
  return { offers: [pool[Math.floor(draw.word * pool.length / 4294967296)]], choiceRngState: draw.state };
}
function selectChoice(state, choiceId, generation, definitionId2) {
  const reason = choiceFailure(state, choiceId, generation);
  if (reason) return fail2(state, reason);
  const choice = state.pendingChoice;
  if (typeof definitionId2 !== "string" || choice.step !== "offer" || !choice.offers.includes(definitionId2)) return fail2(state, "invalid-choice");
  const descriptor = unresolvedLootChoices(state)[0];
  if (descriptor && makeLootPendingChoice(descriptor).choiceId === choiceId) {
    if (choice.kind !== "component" || generation !== 0 || !state.combat || state.combat.status !== "finished") return fail2(state, "invalid-choice");
    const granted2 = grantLootChoice(state, descriptor, definitionId2, "player-choice");
    const selected2 = { ...granted2.state, phase: "settlement", combat: state.combat, pendingChoice: null };
    const next = enterLootChoice(selected2);
    const events2 = [...granted2.events, { type: "choiceSelected", choiceId, definitionId: definitionId2, unitId: null }, ...next.events];
    if (next.state.phase === "choice") return accept(next.state, events2);
    const capacity = grantDirectLoot(next.state, false);
    const entered2 = enterScheduledEvents(capacity.state, "after");
    return acceptEquipment(entered2.state, [...events2, ...capacity.events, ...entered2.events]);
  }
  if (!getRoundSchedule(state.round).some((event) => event.id === choice.eventId && event.kind === choice.kind)) return fail2(state, "invalid-choice");
  if (choice.kind === "anomaly" && !state.preparation.units.some((unit) => unit.id === choice.targetId && unit.team === "player")) return fail2(state, "invalid-target");
  const granted = choice.kind === "component" ? planPermanentItemGrant(state, { definitionId: definitionId2, receiptId: choice.eventId }, state.scheduleReceipts.map((receipt2) => receipt2.eventId)) : null;
  if (granted && !granted.ok) return fail2(state, "invalid-choice");
  const itemId = granted?.ok ? granted.grantedItemIds[0] : null;
  const acquisitionGold = choice.kind === "augment" && definitionId2 === "placebo" ? 8 : 0;
  const receipt = {
    eventId: choice.eventId,
    round: state.round,
    kind: choice.kind,
    itemIds: itemId ? [itemId] : [],
    gold: acquisitionGold,
    unitId: choice.targetId,
    definitionId: definitionId2
  };
  let selected = {
    ...state,
    pendingChoice: null,
    gold: state.gold + acquisitionGold,
    scheduleReceipts: [...state.scheduleReceipts, receipt],
    resourceProvenance: itemId ? appendResourceProvenance(state.resourceProvenance, state.roundDefinitionId, { kind: "item-acquired", itemId, source: { kind: "schedule", eventId: choice.eventId } }) : state.resourceProvenance,
    items: granted?.ok ? granted.state.items : state.items,
    nextItemSerial: granted?.ok ? granted.state.nextItemSerial : state.nextItemSerial,
    augments: choice.kind === "augment" ? [...state.augments, { definitionId: definitionId2, choiceId, acquiredRound: state.round }] : state.augments,
    anomalyBinding: choice.kind === "anomaly" ? { definitionId: definitionId2, unitId: choice.targetId, choiceId, boundRound: state.round } : state.anomalyBinding
  };
  const events = [{ type: "choiceSelected", choiceId, definitionId: definitionId2, unitId: choice.targetId }];
  if (choice.kind === "component" && getRoundKind(state.round) === "supply") {
    selected = settleRound(selected, null);
    events.push({ type: "roundSettled", round: state.round });
    return accept(selected, events);
  }
  const entered = enterScheduledEvents(selected, choice.returnPhase === "settlement" ? "after" : "before");
  return accept(entered.state, [...events, ...entered.events]);
}

// src/simulation/m8/item-restore.ts
var same = (a, b) => canonicalContent(a) === canonicalContent(b);
function declaredEffects(unit, combatId) {
  const compiled = compileMechanismDefinitions(unit, combatId), result = [];
  const collect = (source, effects2, survivalSource) => effects2.forEach((effect, i) => {
    const bound = { ...source, effectIndex: source.effectIndex + i };
    result.push({ source: bound, effect, survivalSource });
    if (effect.kind === "grant-shield") collect({ ...bound, effectIndex: bound.effectIndex + 1 }, effect.endEffects, survivalSource);
    if (effect.kind === "apply-status" && effect.status.onEnd) collect({ ...bound, effectIndex: bound.effectIndex + 1 }, effect.status.onEnd.effects, survivalSource);
  });
  for (const d of compiled.eventTriggers ?? []) collect(d.source, d.effects);
  for (const d of compiled.survivalTriggers) collect(d.source, d.effects, d.source);
  for (const p of compiled.periodicTasks) collect(p.source, p.program.effects);
  return result;
}
function statusDeclaration(effect, owner, source) {
  if (effect.kind === "apply-status") return effect.status;
  if (effect.kind !== "modify-stat") return null;
  const raw = effect.modifier, value = raw.value;
  const modifier2 = value.kind === "counter" ? { ...raw, value: { kind: "constant", amount: (owner.triggerLedger?.runtimes.find((r) => r.source.definitionId === source.definitionId && r.source.instanceId === source.instanceId && r.source.effectIndex <= source.effectIndex && source.effectIndex < r.source.effectIndex + 32)?.counters[value.counterId] ?? 0) * value.perCount } } : raw;
  return { kind: modifier2.value.kind === "constant" && modifier2.value.amount < 0 ? "stat-debuff" : "stat-buff", magnitudeBps: 0, duration: effect.duration, stackPolicy: effect.stackPolicy, activation: effect.activation, polarity: modifier2.value.kind === "constant" && modifier2.value.amount < 0 ? "harmful" : "beneficial", removable: modifier2.value.kind === "constant" && modifier2.value.amount < 0, modifier: modifier2, damageFilter: null, onEnd: null };
}
function isDeclaredStatus(source, app, units, combatId) {
  const owner = units.find((u) => u.id === source.ownerId);
  if (!owner) return false;
  return declaredEffects(owner, combatId).some((d) => canonicalSource(d.source) === canonicalSource(source) && same(statusDeclaration(d.effect, owner, d.source), app));
}
function validateItemEffectConsumption(source, at, units, combatId) {
  const owner = units.find((u) => u.id === source.ownerId);
  if (!owner) return;
  for (const d of declaredEffects(owner, combatId).filter((d2) => canonicalSource(d2.source) === canonicalSource(source) && d2.survivalSource)) {
    const key3 = effectIdentity(combatId, d.survivalSource, owner.id).key;
    const runtime = owner.mechanismState?.runtimes.find((r) => r.key === key3);
    if (!runtime?.consumed || runtime.triggerCount !== 1 || runtime.startsAtTick > at) throw new Error("Invalid Match save: missing item effect consumption");
  }
}
function validateItemRuntime(unit, combatId, tick, definitions2) {
  const state = unit.mechanismState;
  validateTriggerLedger(unit.triggerLedger ?? { runtimes: [], processed: {}, actionCounts: {} }, combatId, definitions2.eventTriggers ?? []);
  for (const r of unit.triggerLedger?.runtimes ?? []) {
    validateIdentity(r, combatId);
    integer(r.startsAtTick);
    integer(r.nextEligibleTick);
    const d = definitions2.eventTriggers.find((d2) => canonicalSource(d2.source) === canonicalSource(r.source));
    if (!d || r.targetId !== unit.id || r.startsAtTick > tick || r.expiresAtTick !== null || r.nextEligibleTick > tick + d.internalCooldownTicks || r.consumed !== (d.maxPerCombat !== null && r.triggerCount >= d.maxPerCombat) || !same(r.stackPolicy, d.stackPolicy) || r.consumedRewards.some((id2) => d.gate.kind !== "stack-threshold-once" || id2 !== d.gate.rewardId)) throw new Error("Invalid Match save: item event runtime");
  }
  const survivalKeys = new Set(definitions2.survivalTriggers.map((d) => effectIdentity(combatId, d.source, unit.id).key));
  const seen = /* @__PURE__ */ new Set();
  for (const r of state.runtimes) {
    validateIdentity(r, combatId);
    integer(r.startsAtTick);
    integer(r.nextEligibleTick);
    const d = definitions2.survivalTriggers.find((d2) => effectIdentity(combatId, d2.source, unit.id).key === r.key);
    if (!d || !survivalKeys.has(r.key) || seen.has(r.key) || r.triggerCount !== 1 || !r.consumed || r.startsAtTick > tick || r.expiresAtTick !== null || r.stacks !== 0 || !same(r.counters, {}) || r.consumedRewards.length || r.nextEligibleTick !== r.startsAtTick + d.internalCooldownTicks || !same(r.stackPolicy, d.stackPolicy)) throw new Error("Invalid Match save: item survival runtime");
    seen.add(r.key);
  }
  const expected = new Set(survivalConsumptionKeys(definitions2.survivalTriggers, combatId, unit.id));
  if (!Array.isArray(state.unconsumedSurvivalKeys)) throw new Error("Invalid Match save: incomplete survival consumption");
  for (const key3 of state.unconsumedSurvivalKeys) {
    if (!expected.has(key3) || seen.has(key3)) throw new Error("Invalid Match save: survival consumption identity");
    seen.add(key3);
  }
  if ([...expected].some((key3) => !seen.has(key3))) throw new Error("Invalid Match save: incomplete survival consumption");
  const basis = unit.maxHpBasis;
  const bonuses = unit.itemPrograms?.length ? declaredEffects(unit, combatId).filter((d) => d.effect.kind === "change-max-hp") : [];
  const uniqueBonuses = new Map(bonuses.map((d) => [canonicalSource(d.source), d]));
  const expectedBonus = [...uniqueBonuses.values()].reduce((n, d) => n + (d.effect.kind === "change-max-hp" && state.runtimes.some((r) => r.source.definitionId === d.source.definitionId && r.source.instanceId === d.source.instanceId && r.source.effectIndex <= d.source.effectIndex && d.source.effectIndex < r.source.effectIndex + 32) ? d.effect.bonusBps : 0), 0);
  if (basis.bonusBps !== expectedBonus) throw new Error("Invalid Match save: item max HP consumption");
  const maximum = resolveStat("maxHp", basis.base, [{ stat: "maxHp", unit: "flat", value: { kind: "constant", amount: basis.flat }, condition: { kind: "always" }, damageFilter: null }, { stat: "maxHp", unit: "bps", value: { kind: "constant", amount: basis.bps + basis.bonusBps }, condition: { kind: "always" }, damageFilter: null }], { holder: unit });
  if (unit.maxHp !== maximum) throw new Error("Invalid Match save: current max HP");
}
function maxHpCandidates(unit, at, combatId) {
  const basis = unit.maxHpBasis;
  let bonuses = /* @__PURE__ */ new Set([0]);
  const seen = /* @__PURE__ */ new Set();
  for (const d of declaredEffects(unit, combatId)) {
    const key3 = canonicalSource(d.source);
    if (d.effect.kind !== "change-max-hp" || seen.has(key3)) continue;
    seen.add(key3);
    if (unit.mechanismState.runtimes.some((r) => r.source.definitionId === d.source.definitionId && r.source.instanceId === d.source.instanceId && r.source.effectIndex <= d.source.effectIndex && d.source.effectIndex < r.source.effectIndex + 32 && r.startsAtTick <= at)) {
      const bonus = d.effect.bonusBps;
      bonuses = new Set([...bonuses].flatMap((n) => [n, n + bonus]));
    }
  }
  return new Set([...bonuses].map((n) => Math.floor((basis.base + basis.flat) * (1e4 + basis.bps + n) / 1e4)));
}
function sampledStatCandidates(unit, stat2, at, combatId) {
  const base = stat2 === "abilityPower" ? (unit.abilityPower ?? 100) + (unit.mechanics ?? []).filter((m) => m.mechanic === "archangel").reduce((n, m) => n + Math.floor(at / m.values.periodTicks) * m.values.abilityPower, 0) : unit.attackDamageBase;
  if (!unit.itemPrograms?.length) return /* @__PURE__ */ new Set([stat2 === "abilityPower" ? base : Math.floor(base * (1e4 + unit.attackDamagePercentBps + (unit.runtime?.permanentAdBps ?? 0)) / 1e4)]);
  let values = [{ flat: 0, bps: stat2 === "attackDamage" ? unit.attackDamagePercentBps + (unit.runtime?.permanentAdBps ?? 0) : 0 }];
  const seen = /* @__PURE__ */ new Set();
  for (const d of declaredEffects(unit, combatId)) {
    if (d.effect.kind !== "modify-stat" || d.effect.modifier.stat !== stat2) continue;
    if (unit.mechanismDefinitions?.periodicTasks.some((t) => canonicalSource(t.source) === canonicalSource(d.source))) continue;
    const key3 = canonicalSource(d.source);
    if (seen.has(key3)) continue;
    seen.add(key3);
    const m = d.effect.modifier;
    if (m.unit !== "flat" && m.unit !== "bps") throw new Error("Unsupported enabled sampled unit");
    const initial = compileMechanismDefinitions(unit, combatId).survivalTriggers.some((t) => t.event === "combat-start" && t.condition.kind === "always" && canonicalSource(t.source) === key3);
    let options;
    if (m.value.kind === "constant") options = initial && m.condition.kind === "always" ? [m.value.amount] : [0, m.value.amount];
    else if (m.value.kind === "counter") {
      const value = m.value;
      const cap = (compileMechanismDefinitions(unit, combatId).eventTriggers ?? []).flatMap((t) => t.counters).find((c) => c.id === value.counterId)?.cap;
      if (cap === void 0 || cap === null) throw new Error("Unbounded enabled AP counter");
      options = Array.from({ length: cap + 1 }, (_, i) => i * value.perCount);
    } else options = [0];
    values = values.flatMap((n) => options.map((v) => ({ ...n, [m.unit]: n[m.unit] + v })));
  }
  return new Set(values.map((v) => Math.floor((base + v.flat) * (1e4 + v.bps) / 1e4)));
}
var abilityPowerCandidates = (unit, at, combatId) => sampledStatCandidates(unit, "abilityPower", at, combatId);
var attackDamageCandidates = (unit, at, combatId) => sampledStatCandidates(unit, "attackDamage", at, combatId);

// src/simulation/neutral-restore.ts
var same2 = (a, b) => a === b || a !== void 0 && b !== void 0 && canonicalContent(a) === canonicalContent(b);
function check(value, label) {
  if (!value) throw new Error(`Invalid Match save: neutral ${label}`);
}
function validateNeutralCombat(combat2, preparation, strategy) {
  const trusted = combat2.units.flatMap((u) => {
    const n = readNeutralCombatUnit(u.id);
    return n ? [n] : [];
  });
  const openings = COMPILED_NEUTRAL_ENCOUNTERS.flatMap((e) => e.openingDefinitions).filter((d) => trusted.some((u) => u.id === d.source.ownerId));
  const companionDefs = trusted.flatMap((u) => u.companionDefinitions ?? []);
  const openingSeq = strategy.units.reduce((n, u) => n + (u.itemPrograms ?? []).flatMap((p) => p.program.periodic ?? []).filter((p) => (p.startsAtTick ?? p.periodTicks) === 1).length, 0);
  const neutralKeys = /* @__PURE__ */ new Set(), combatId = combat2.combatId, tick = combat2.tick;
  for (const u of combat2.units) {
    const expected = trusted.find((n) => n.id === u.id);
    for (const field of ["unitKind", "monsterFamily", "encounterId", "baseCritChanceBps", "baseCritMultiplierBps", "companionDefinitions", "attackCone"])
      check(same2(u[field], expected?.[field]), `authored ${field}`);
    const origin2 = preparation.units.find((p) => p.id === u.id);
    check(origin2.location.kind === "board" && (tick === 0 && u.startingCell === void 0 || same2(u.startingCell, origin2.location.cell)), "starting cell");
    if (expected) check(u.team === "enemy" && u.starLevel === 1 && u.definitionId === expected.definitionId && u.mana === 0 && u.maxMana === 0 && same2(u.spellCrit, expected.spellCrit), "identity/mana/crit");
  }
  const receipts = combat2.neutralReceipts;
  check(trusted.length ? receipts && Array.isArray(receipts.deaths) && Array.isArray(receipts.controls) : receipts === void 0, "receipts namespace");
  const eventIds = /* @__PURE__ */ new Set(), deathIds = /* @__PURE__ */ new Set(), controlIds = /* @__PURE__ */ new Set();
  const event = (seq) => {
    check(Number.isSafeInteger(seq) && seq >= 0 && seq < combat2.nextEventSeq && !eventIds.has(seq), "receipt event");
    eventIds.add(seq);
  };
  for (const d of receipts?.deaths ?? []) {
    check(trusted.some((n) => n.id === d.unitId) && !combat2.units.find((u) => u.id === d.unitId).alive && !deathIds.has(d.unitId) && Number.isSafeInteger(d.tick) && d.tick >= 1 && d.tick <= tick, "death fact");
    deathIds.add(d.unitId);
    event(d.eventSeq);
  }
  check(trusted.every((n) => combat2.units.find((u) => u.id === n.id).alive || deathIds.has(n.id)), "lost death fact");
  check(same2(combat2.openingDefinitions, trusted.length ? openings : void 0), "opening declarations");
  if (openings.length && tick > 0) {
    const initial = preparation.units.filter((u) => u.location.kind === "board").map((u) => {
      const r = strategy.units.find((r2) => r2.unitId === u.id);
      return {
        id: u.id,
        team: u.team,
        cell: u.location.kind === "board" ? u.location.cell : { col: 0, row: 0 },
        hp: Math.floor(r.stats.health * (r.mechanics?.find((m) => m.mechanic === "glassCannon")?.values.startingHealthBps ?? 1e4) / 1e4),
        maxHp: r.stats.health,
        alive: true,
        untargetable: false,
        controlled: false
      };
    });
    const planned = planOpening(combatId, combat2.board, initial, openings);
    check(same2(combat2.openingState, { ...planned, committed: true, plans: planned.plans.map((p) => ({ ...p, task: p.task ? { ...p.task, status: "executed" } : null })) }), "opening plan/consumption");
  } else check(combat2.openingState === void 0, "unexpected opening state");
  if (companionDefs.length && tick > 0) {
    const state = combat2.companionState, expected = freezeCompanions(combatId, trusted, companionDefs);
    check(state && state.combatId === combatId && same2(state.bindings, expected.bindings) && Array.isArray(state.reactions), "companion binding");
    const seen = /* @__PURE__ */ new Set();
    for (const r of state.reactions) {
      const b = expected.bindings.find((b2) => canonicalSource(b2.source) === canonicalSource(r.source));
      const owner = combat2.units.find((u) => u.id === r.targetId), dead = combat2.units.find((u) => u.id === r.deadUnitId);
      check(b && owner && dead && !dead.alive && b.members.includes(r.deadUnitId) && r.targetId === b.source.ownerId && Number.isSafeInteger(r.registeredAtTick) && r.registeredAtTick >= 1 && r.registeredAtTick <= tick && r.executeAtTick === r.registeredAtTick + 1 && same2(r.effects, b.effects) && r.key === JSON.stringify([combatId, r.targetId, canonicalSource(b.source), r.deadUnitId]) && !seen.has(r.key), "companion binding");
      const death = receipts.deaths.find((d) => d.unitId === r.deadUnitId);
      check(death && death.tick === r.registeredAtTick && r.deathEventId === JSON.stringify([combatId, death.tick, death.eventSeq]), "death event identity");
      seen.add(r.key);
      check(state.reactions.filter((x) => canonicalSource(x.source) === canonicalSource(r.source)).length <= b.maxReactions, "reaction limit");
      check(r.status === "pending" ? r.executeAtTick === tick + 1 && owner.alive && combat2.status === "running" : r.status === "executed" ? r.executeAtTick <= tick : r.status === "cancelled" && (!owner.alive || combat2.status === "finished"), "companion lifecycle");
    }
    for (const b of expected.bindings) if (combat2.units.find((u) => u.id === b.source.ownerId).alive) {
      for (const id2 of b.members) if (!combat2.units.find((u) => u.id === id2).alive)
        check(state.reactions.some((r) => r.targetId === b.source.ownerId && r.deadUnitId === id2), "lost death consumption");
    }
  } else check(combat2.companionState === void 0, "unexpected companion state");
  for (const receipt of receipts?.controls ?? []) {
    check(!controlIds.has(receipt.key), "duplicate control receipt");
    controlIds.add(receipt.key);
    event(receipt.appliedEventSeq);
    const tuple = JSON.parse(receipt.key), task = combat2.openingState?.plans.find((p) => p.source.ownerId === tuple[1])?.task;
    check(tick >= 1 && task?.status === "executed" && task.targetIds.includes(receipt.targetId) && receipt.key === effectIdentity(combatId, { ...task.source, effectIndex: 1 }, receipt.targetId, JSON.stringify([openingSeq, 1])).key, "control binding");
    const status2 = task.effects[1];
    check(status2?.kind === "apply-status" && status2.status.kind === "stun" && status2.status.duration.kind === "ticks", "control duration");
    const startsAtTick = task.executeAtTick + (status2.status.activation === "next-tick" ? 1 : 0);
    const endsAtTick = startsAtTick + status2.status.duration.ticks;
    const target = combat2.units.find((u) => u.id === receipt.targetId);
    const active2 = target.mechanismState?.statuses.some((g) => g.contributions.some((c) => c.key === receipt.key));
    if (receipt.removedAtTick === null) check(receipt.removedEventSeq === null && receipt.removedReason === null && active2 && target.alive && combat2.status === "running" && tick < endsAtTick, "lost control");
    else {
      check(Number.isSafeInteger(receipt.removedAtTick) && receipt.removedAtTick >= 1 && receipt.removedAtTick <= tick && !active2 && receipt.removedEventSeq > receipt.appliedEventSeq, "control removal time");
      event(receipt.removedEventSeq);
      const reason = receipt.removedReason;
      check(reason === "expired" ? receipt.removedAtTick === endsAtTick : reason === "death-cleanup" ? !target.alive : reason === "combat-end" ? combat2.status === "finished" && receipt.removedAtTick === tick : reason === "cleansed" && declaredEffects(target, combatId).some((d) => d.effect.kind === "cleanse" && d.survivalSource && target.mechanismState.runtimes.some((r) => r.key === effectIdentity(combatId, d.survivalSource, target.id).key && r.consumed && r.startsAtTick === receipt.removedAtTick)), "control removal reason");
    }
  }
  for (const plan of combat2.openingState?.plans ?? []) for (const id2 of plan.task?.targetIds ?? []) {
    const target = combat2.units.find((u) => u.id === id2), r = strategy.units.find((u) => u.unitId === id2);
    const immune = (r.itemPrograms ?? []).some((p) => p.program.effects?.some((e) => e.kind === "apply-status" && e.status.kind === "control-immunity"));
    if (target.alive && !immune) check(receipts.controls.some((c) => c.targetId === id2), "lost applied control receipt");
  }
  for (const u of combat2.units) for (const c of u.mechanismState?.statuses.flatMap((g) => g.contributions) ?? []) {
    if (!trusted.some((n) => n.id === c.source.ownerId)) continue;
    const owner = trusted.find((n) => n.id === c.source.ownerId);
    let app, at = 0, applicationId;
    const reaction = combat2.companionState?.reactions.find((r) => r.status === "executed" && r.targetId === u.id && canonicalSource(r.source) === canonicalSource(c.source) && effectIdentity(combatId, r.source, u.id, r.deadUnitId).key === c.key);
    const effect = reaction?.effects[0];
    if (reaction && effect?.kind === "modify-stat") {
      app = {
        kind: "stat-buff",
        magnitudeBps: 0,
        duration: effect.duration,
        stackPolicy: { kind: "independent-instances" },
        activation: "immediate",
        polarity: "beneficial",
        removable: false,
        modifier: effect.modifier,
        damageFilter: null,
        onEnd: null
      };
      at = reaction.executeAtTick;
      applicationId = reaction.deadUnitId;
    } else {
      const definition = openings.find((d) => d.source.ownerId === owner.id);
      const task = combat2.openingState?.plans.find((p) => p.source.ownerId === owner.id)?.task;
      const status2 = definition?.kind === "path-charge" ? definition.effects[1] : void 0;
      check(task?.status === "executed" && task.targetIds.includes(u.id) && status2?.kind === "apply-status" && same2(c.source, { ...definition.source, effectIndex: 1 }), "control binding");
      app = status2.status;
      at = task.executeAtTick + (app.activation === "next-tick" ? 1 : 0);
      check(controlIds.has(c.key), "missing control receipt");
      const tuple = JSON.parse(c.key), action = JSON.parse(tuple[8]);
      check(Array.isArray(action) && action.length === 2 && action[0] === openingSeq && action[1] === 1, "control action identity");
      applicationId = tuple[8];
    }
    check(same2(c.application, app) && c.appliedAtTick === at && c.expiresAtTick === (app.duration.kind === "combat" ? null : at + app.duration.ticks) && c.key === effectIdentity(combatId, c.source, u.id, applicationId).key && !c.endRewardConsumed, "status declaration");
    neutralKeys.add(c.key);
  }
  for (const r of combat2.companionState?.reactions ?? []) if (r.status === "executed" && r.effects[0]?.kind === "modify-stat" && combat2.status === "running" && combat2.units.find((u) => u.id === r.targetId).alive)
    check(neutralKeys.has(effectIdentity(combatId, r.source, r.targetId, r.deadUnitId).key), "lost companion buff");
  return neutralKeys;
}

// src/simulation/b8-restore.ts
function check2(condition, message) {
  if (!condition) throw new RangeError(`Invalid B8 Match: ${message}`);
}
var equal2 = (a, b) => canonicalContent(a) === canonicalContent(b);
function keys2(value, names) {
  check2(value !== null && typeof value === "object" && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype, "object");
  check2(equal2(Object.keys(value).sort(), [...names].sort()), "fields");
}
function integer6(value, min = 0) {
  check2(Number.isSafeInteger(value) && value >= min, "integer");
}
var sorted2 = (values) => [...values].sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
var allChoices = (state) => state.m8.loot.frozen.rounds.flatMap((round2) => round2.choices);
function validateB8Loot(state) {
  const __b8Timer = globalThis.__b8Start("validateB8Loot");
  try {
    const loot = state.m8.loot;
    keys2(loot, ["frozen", "direct", "choiceEligibility", "choiceResolutions", "earnedEvidence", "receipts", "guaranteeCounters"]);
    const frozen = restoreFrozenLootLedger(loot.frozen, { seed: state.seed, throughRoundOrdinal: state.round });
    for (const value of [loot.direct, loot.choiceEligibility, loot.choiceResolutions, loot.earnedEvidence, loot.receipts]) check2(Array.isArray(value), "ledger array");
    const direct = frozen.rounds.flatMap((round2) => round2.encounterPlan.drops), choices = allChoices(state);
    check2(equal2(loot.direct.map((entry) => entry.dropId), direct.map((entry) => entry.dropId)) && equal2(loot.choiceEligibility.map((entry) => entry.dropId), choices.map((entry) => entry.dropId)), "slot coverage/order");
    const slots = new Map([...direct, ...choices].map((slot3) => [slot3.dropId, slot3]));
    const evidence = /* @__PURE__ */ new Map(), sourceDeaths = /* @__PURE__ */ new Map(), deathSources = /* @__PURE__ */ new Map();
    for (const entry of loot.earnedEvidence) {
      keys2(entry, ["dropId", "death"]);
      keys2(entry.death, ["combatId", "tick", "eventSeq"]);
      const slot3 = slots.get(entry.dropId);
      check2(slot3 && !evidence.has(entry.dropId), "evidence identity");
      const round2 = getCatalogRoundById(slot3.roundId), result = state.roundResults[round2.ordinal - 1];
      integer6(entry.death.tick, 1);
      integer6(entry.death.eventSeq);
      check2(entry.death.combatId === `round-${round2.ordinal}`, "death combat identity");
      const combat2 = round2.ordinal === state.round ? state.combat : null;
      check2(combat2 ? entry.death.tick <= combat2.tick && entry.death.eventSeq < combat2.nextEventSeq : result && entry.death.tick <= result.combatTicks && entry.death.eventSeq < result.combatEventCount, "death history boundary");
      const source = JSON.stringify([slot3.roundId, slot3.sourceUnitId]), identity = canonicalContent(entry.death);
      check2(!sourceDeaths.has(source) || equal2(sourceDeaths.get(source), entry.death), "source death conflict");
      check2(!deathSources.has(identity) || deathSources.get(identity) === source, "duplicate death identity");
      sourceDeaths.set(source, entry.death);
      deathSources.set(identity, source);
      evidence.set(entry.dropId, entry);
    }
    validateResourceReceipts({ scheduleReceipts: state.scheduleReceipts, lootReceipts: loot.receipts, throughRoundOrdinal: state.round });
    const receipts = /* @__PURE__ */ new Map();
    let receiptRound = 0;
    for (const receipt of loot.receipts) {
      const slot3 = slots.get(receipt.dropId);
      check2(slot3, "receipt identity");
      const ordinal = getCatalogRoundById(slot3.roundId).ordinal;
      check2(ordinal >= receiptRound, "receipt order");
      receiptRound = ordinal;
      if ("payload" in slot3) check2(equal2(receipt.payload, slot3.payload), "frozen receipt payload");
      else check2(receipt.payload.kind === "item" && makeLootPendingChoice(slot3).offers.includes(receipt.payload.definitionId), "choice receipt payload");
      receipts.set(receipt.dropId, receipt);
    }
    const resolutions = /* @__PURE__ */ new Map();
    for (const resolution of loot.choiceResolutions) {
      keys2(resolution, ["dropId", "receiptId", "method"]);
      const choice = choices.find((entry) => entry.dropId === resolution.dropId), receipt = receipts.get(resolution.dropId);
      check2(choice && receipt && !resolutions.has(resolution.dropId) && resolution.receiptId === receipt.receiptId && ["player-choice", "terminal-fallback"].includes(resolution.method), "choice resolution");
      check2(resolution.method !== "terminal-fallback" || state.phase === "gameOver" && choice.roundId === state.roundDefinitionId && equal2(receipt.payload, { kind: "item", quantity: 1, definitionId: choice.terminalFallbackDefinitionId }), "terminal fallback");
      check2(!(state.phase === "gameOver" && choice.roundId === state.roundDefinitionId) || resolution.method === "terminal-fallback", "terminal choice method");
      resolutions.set(resolution.dropId, resolution);
    }
    const validateEligibility = (slot3, status2) => {
      const earned = evidence.has(slot3.dropId), current = slot3.roundId === state.roundDefinitionId;
      const finished = !current || state.combat?.status === "finished";
      check2(earned === !["planned", "forfeited"].includes(status2), "qualification evidence");
      if (current) {
        const death = state.combat?.neutralReceipts?.deaths.find((value) => value.unitId === slot3.sourceUnitId);
        check2(earned === !!death, "current death qualification");
        if (death) check2(equal2(evidence.get(slot3.dropId).death, { combatId: state.combat.combatId, tick: death.tick, eventSeq: death.eventSeq }), "current death evidence");
      }
      check2(finished ? status2 !== "planned" : status2 === (earned ? "revealed" : "planned"), "qualification lifecycle");
    };
    for (const [index, progress] of loot.direct.entries()) {
      keys2(progress, ["dropId", "status", "receiptId"]);
      const slot3 = direct[index], receipt = receipts.get(slot3.dropId);
      check2(["planned", "revealed", "pending-capacity", "retained-terminal", "forfeited", "granted"].includes(progress.status), "direct status");
      validateEligibility(slot3, progress.status);
      check2(progress.status === "granted" ? receipt && progress.receiptId === receipt.receiptId : !receipt && progress.receiptId === null, "direct receipt");
      if (slot3.roundId !== state.roundDefinitionId) check2(["granted", "forfeited"].includes(progress.status), "unresolved historical direct");
      if (state.combat?.status === "finished" && slot3.roundId === state.roundDefinitionId) {
        check2(progress.status !== "revealed", "unprocessed direct");
        if (progress.status === "pending-capacity" || progress.status === "retained-terminal") check2(slot3.payload.kind === "unit" && progress.status === "retained-terminal" === (state.phase === "gameOver"), "unit capacity status");
      }
    }
    for (const [index, eligibility] of loot.choiceEligibility.entries()) {
      keys2(eligibility, ["dropId", "status"]);
      const slot3 = choices[index], resolution = resolutions.get(slot3.dropId);
      check2(["planned", "revealed", "forfeited"].includes(eligibility.status), "choice eligibility");
      validateEligibility(slot3, eligibility.status);
      check2(!!resolution === receipts.has(slot3.dropId) && (!resolution || eligibility.status === "revealed"), "choice grant qualification");
      if (slot3.roundId !== state.roundDefinitionId || state.phase === "gameOver") check2(eligibility.status !== "revealed" || resolution, "unresolved completed choice");
      if (state.combat?.status === "running" && slot3.roundId === state.roundDefinitionId) check2(!resolution, "combat choice grant");
    }
    const counters = Object.fromEntries(Object.keys(LOOT_SLOTS).map((roundId) => [JSON.stringify([LOOT_POLICY_VERSION, roundId, "components-granted"]), 0]));
    for (const receipt of loot.receipts) if (receipt.payload.kind === "item") counters[JSON.stringify([LOOT_POLICY_VERSION, slots.get(receipt.dropId).roundId, "components-granted"])]++;
    check2(equal2(counters, loot.guaranteeCounters), "actual guarantee counters");
    const unresolved = orderedUnresolvedLootChoices(choices, loot.choiceEligibility, loot.choiceResolutions);
    if (state.combat?.status === "finished" && state.phase !== "gameOver" && unresolved.length) {
      check2(state.phase === "choice" && equal2(state.pendingChoice, makeLootPendingChoice(unresolved[0])), "first loot choice");
      return true;
    }
    return false;
  } finally {
    globalThis.__b8End(__b8Timer);
  }
}
function validateB8Resources(state) {
  const __b8Timer = globalThis.__b8Start("validateB8Resources");
  try {
    const context = {
      scheduleReceipts: state.scheduleReceipts,
      lootReceipts: state.m8.loot.receipts,
      throughRoundOrdinal: state.round,
      combatSettlements: state.roundResults.filter((result) => result.roundKind !== "supply").map((result) => ({ roundId: result.roundId, combatId: `round-${result.round}`, settlementId: result.settlementId }))
    };
    const current = foldResourceProvenance(state.resourceProvenance, context);
    check2(equal2(current, {
      units: sorted2(state.preparation.units.filter((unit) => unit.team === "player").map(({ id: id2, definitionId: definitionId2, starLevel }) => ({ id: id2, definitionId: definitionId2, starLevel }))),
      items: sorted2(state.items.map(({ id: id2, definitionId: definitionId2 }) => ({ id: id2, definitionId: definitionId2 }))),
      persistentGrowth: state.persistentGrowth,
      nextUnitSerial: state.nextUnitSerial,
      nextItemSerial: state.nextItemSerial
    }), "current resource fold");
    if (state.combat === null) {
      check2(state.combatInputBasis === null, "inactive input basis");
      return { basis: null, saleGold: 0 };
    }
    const entries = state.resourceProvenance.entries, combat2 = state.combat;
    const commits = entries.filter((entry) => entry.kind === "combat-growth-committed" && entry.combatId === combat2.combatId);
    check2(combat2.status === "finished" ? commits.length === 1 : commits.length === 0, "current growth commit count");
    const commit = commits[0];
    check2(!commit || commit.kind === "combat-growth-committed", "growth commit");
    const prefixLength = commit?.combatStartProvenancePrefixLength ?? entries.length;
    const basis = restoreCombatInput(state.combatInputBasis, {
      seed: state.seed,
      round: state.round,
      contentDigest: state.contentDigest,
      playerLevel: state.roundResults[state.round - 1]?.levelBefore ?? state.level,
      provenancePrefixLength: prefixLength,
      // A complete prefix is exactly the immutable projection validated above in
      // this call. Historical shorter prefixes still validate the entire ledger.
      resources: prefixLength === entries.length ? current : foldResourceProvenance(state.resourceProvenance, { ...context, prefixLength }),
      equipmentRolls: state.equipmentState.rolls,
      equipmentRollPrefixLength: state.equipmentState.rolls.length,
      scheduleReceipts: state.scheduleReceipts,
      roundResults: state.roundResults
    });
    check2(state.battleSeedRngState === basis.battleSeed, "battle seed cursor");
    if (combat2.status === "running") {
      check2(equal2(readCombatStrategyInputs(state), basis.inputs), "running input mutation");
      return { basis, saleGold: 0 };
    }
    const deltas = combat2.units.filter((unit) => unit.team === "player" && (unit.runtime?.permanentAdBps ?? 0) > 0).map((unit) => ({ sourceUnitId: unit.id, attackDamageBps: unit.runtime.permanentAdBps })).sort((a, b) => a.sourceUnitId < b.sourceUnitId ? -1 : 1);
    check2(commit && equal2(commit.sourceDeltas, deltas), "original combat growth deltas");
    return { basis, saleGold: replayCurrentSuffix(state, basis) };
  } finally {
    globalThis.__b8End(__b8Timer);
  }
}
function replayCurrentSuffix(state, basis) {
  const __b8Timer = globalThis.__b8Start("replayCurrentSuffix");
  try {
    const loot = state.m8.loot, entries = state.resourceProvenance.entries;
    const frozen = loot.frozen.rounds.find((round2) => round2.encounterPlan.roundId === state.roundDefinitionId);
    const direct = frozen?.encounterPlan.drops ?? [], choices = [...frozen?.choices ?? []].sort(compareLootChoices);
    const earned = new Set(loot.earnedEvidence.map((entry) => entry.dropId)), receipts = new Map(loot.receipts.map((receipt) => [receipt.dropId, receipt]));
    const actualReceiptOrder = [], expectedProgress = /* @__PURE__ */ new Map();
    let preparation = structuredClone(basis.inputs.preparation), items = structuredClone(basis.inputs.items), binding = structuredClone(basis.inputs.anomalyBinding);
    let nextUnit = basis.nextUnitSerial, nextItem = basis.nextItemSerial, cursor = basis.provenancePrefixLength, saleGold = 0;
    const take = (fact) => {
      check2(equal2(entries[cursor], { ...fact, sequence: cursor, roundId: state.roundDefinitionId }), "ordered resource transaction");
      cursor++;
    };
    const grant = (slot3, definitionId2) => {
      const payload = "payload" in slot3 ? slot3.payload : { kind: "item", definitionId: definitionId2, quantity: 1 };
      const receipt = receipts.get(slot3.dropId);
      let itemIds = [], unitIds = [];
      if (payload.kind === "unit") {
        const plan = planUnitAcquisition(
          { preparation, items, anomalyBinding: binding, nextUnitSerial: nextUnit },
          payload.definitionId,
          { kind: "loot", receiptId: lootReceiptId(slot3.dropId) },
          cursor
        );
        if (!plan.ok) return false;
        for (const fact of plan.facts) take(fact);
        preparation = plan.preparation;
        items = plan.items;
        binding = plan.anomalyBinding;
        unitIds = [plan.unitId];
        nextUnit = plan.nextUnitSerial;
      } else if (payload.kind === "item") {
        const itemId = `item-${nextItem}`;
        take({ kind: "item-acquired", itemId, source: { kind: "loot", receiptId: lootReceiptId(slot3.dropId) } });
        items = [...items, { id: itemId, definitionId: payload.definitionId, location: { kind: "inventory" } }];
        itemIds = [itemId];
        nextItem++;
      }
      check2(equal2(receipt, { receiptId: lootReceiptId(slot3.dropId), dropId: slot3.dropId, payload, grantedItemIds: itemIds, grantedUnitIds: unitIds }), "actual grant receipt");
      actualReceiptOrder.push(slot3.dropId);
      return true;
    };
    for (const slot3 of direct) expectedProgress.set(slot3.dropId, !earned.has(slot3.dropId) ? "forfeited" : grant(slot3) ? "granted" : state.phase === "gameOver" ? "retained-terminal" : "pending-capacity");
    const earnedChoices = choices.filter((choice) => earned.has(choice.dropId));
    const resolve = (choice) => {
      const resolution = loot.choiceResolutions.find((value) => value.dropId === choice.dropId), receipt = receipts.get(choice.dropId);
      check2(resolution && receipt?.payload.kind === "item", "choice transaction");
      grant(choice, receipt.payload.definitionId);
    };
    if (state.phase === "gameOver") for (const choice of earnedChoices) resolve(choice);
    const commit = entries[cursor];
    check2(commit?.kind === "combat-growth-committed", "growth transaction order");
    take({
      kind: "combat-growth-committed",
      combatId: basis.combatId,
      settlementId: `round-${state.round}-settled`,
      combatStartProvenancePrefixLength: basis.provenancePrefixLength,
      sourceDeltas: commit.sourceDeltas
    });
    let resolvedChoices = 0;
    if (state.phase !== "gameOver") for (const choice of earnedChoices) {
      if (!loot.choiceResolutions.some((value) => value.dropId === choice.dropId)) break;
      resolve(choice);
      resolvedChoices++;
    }
    while (cursor < entries.length) {
      const sale = entries[cursor];
      check2(state.phase !== "gameOver" && resolvedChoices === earnedChoices.length && [...expectedProgress.values()].includes("pending-capacity") && sale.kind === "unit-sold" && sale.context === "settlement-capacity", "capacity sale boundary");
      const unit = preparation.units.find((value) => value.id === sale.unitId);
      check2(unit?.team === "player" && sale.goldGranted === getUnitSellPrice(unit), "capacity sale identity/price");
      take({ kind: "unit-sold", unitId: sale.unitId, context: "settlement-capacity", goldGranted: sale.goldGranted });
      saleGold += sale.goldGranted;
      preparation = { ...preparation, units: preparation.units.filter((value) => value.id !== sale.unitId) };
      items = items.map((item) => item.location.kind === "unit" && item.location.unitId === sale.unitId ? { ...item, location: { kind: "inventory" } } : item);
      if (binding?.unitId === sale.unitId) binding = null;
      for (const slot3 of direct) if (expectedProgress.get(slot3.dropId) === "pending-capacity" && grant(slot3)) expectedProgress.set(slot3.dropId, "granted");
    }
    check2(equal2(sorted2(preparation.units), sorted2(state.preparation.units)) && equal2(sorted2(items), sorted2(state.items)) && equal2(binding, state.anomalyBinding) && equal2(basis.inputs.augments, state.augments), "finished resource projection");
    check2(nextUnit === state.nextUnitSerial && nextItem === state.nextItemSerial, "finished serial projection");
    check2(equal2(actualReceiptOrder, loot.receipts.filter((receipt) => direct.some((slot3) => slot3.dropId === receipt.dropId) || choices.some((slot3) => slot3.dropId === receipt.dropId)).map((receipt) => receipt.dropId)), "current grant order");
    for (const progress of loot.direct.filter((entry) => expectedProgress.has(entry.dropId))) check2(progress.status === expectedProgress.get(progress.dropId), "capacity retry projection");
    return saleGold;
  } finally {
    globalThis.__b8End(__b8Timer);
  }
}

// src/simulation/m8/restore.ts
var same3 = (a, b) => canonicalContent(a) === canonicalContent(b);
function check3(value, message) {
  if (!value) throw new Error(`Invalid Match save: ${message}`);
}
function validateMechanisms(unit, units, tick, combatId, finished, nextActionSeq, neutralStatuses = /* @__PURE__ */ new Set()) {
  const state = unit.mechanismState, definitions2 = unit.mechanismDefinitions;
  check3(state && definitions2 && state.initialized === true && state.combatId === combatId && state.sampledAtTick === tick, "mechanism initialization/namespace");
  const compiled = compileMechanismDefinitions(unit, combatId);
  check3(same3(definitions2, compiled), "uncompiled mechanism definitions");
  check3(Array.isArray(state.statuses) && Array.isArray(state.periodicTasks) && Array.isArray(state.runtimes) && Array.isArray(state.activities), "mechanism arrays");
  validateItemRuntime(unit, combatId, tick, compiled);
  const basis = unit.maxHpBasis;
  const expectedBasis = {
    base: getUnitStats(unit.definitionId, unit.starLevel).health,
    flat: (unit.sources ?? []).reduce((n, e) => n + (e.effect.kind === "statFlat" && e.effect.stat === "maxHp" ? e.effect.amount : 0), 0),
    bps: (unit.sources ?? []).reduce((n, e) => n + (e.effect.kind === "statPercentBps" && e.effect.stat === "maxHp" ? e.effect.bps : 0), 0),
    bonusBps: 0
  };
  check3(same3({ ...basis, bonusBps: 0 }, expectedBasis), "resolved maximum health basis");
  validateStatusGroups(state.statuses, tick, combatId);
  const contributions = state.statuses.flatMap((g) => g.contributions), covered = /* @__PURE__ */ new Set();
  for (const legacy of unit.statuses ?? []) {
    if (legacy.kind === "channel" || legacy.kind === "redirect") {
      check3(legacy.activity !== void 0, "missing activity projection");
      continue;
    }
    check3(Array.isArray(legacy.contributionKeys) && legacy.contributionKeys.length > 0, "missing status contribution projection");
    for (const key3 of legacy.contributionKeys) {
      const c = contributions.find((c2) => c2.key === key3);
      if (c && (neutralStatuses.has(c.key) || c.source.sourceKind === "item" && isDeclaredStatus(c.source, c.application, units, combatId))) {
        check3(!covered.has(key3) && c.targetId === unit.id && same3(c.source, asSource(legacy.source)) && legacy.key === c.key && c.appliedAtTick === legacy.startsAtTick && (c.expiresAtTick ?? 1201) === legacy.expiresAtTick, "item status source/timing projection");
        const app2 = c.application;
        const kind2 = app2.kind === "stun" ? "stun" : app2.kind === "sunder" ? "armorReduction" : "resistanceFlat";
        const amount3 = app2.modifier?.value.kind === "constant" ? app2.modifier.value.amount : app2.magnitudeBps;
        check3(legacy.kind === kind2 && legacy.amount === amount3 && legacy.contributionKeys.length === 1 && legacy.activity === void 0, "item status semantic projection");
        if (!neutralStatuses.has(c.key)) validateItemEffectConsumption(c.source, c.appliedAtTick, units, combatId);
        covered.add(key3);
        continue;
      }
      check3(c && !covered.has(key3) && c.targetId === unit.id && c.source.ownerId === legacy.source.ownerId && c.source.sourceKind === legacy.source.sourceKind && c.source.definitionId === legacy.source.definitionId && c.source.instanceId === legacy.source.instanceId && c.source.parentItemInstanceId === null && (c.source.effectIndex === legacy.source.effectIndex * 16 || c.source.effectIndex === legacy.source.effectIndex * 16 + 1) && c.appliedAtTick === legacy.startsAtTick && c.expiresAtTick === legacy.expiresAtTick, "status source/timing projection");
      const prefix = `${sourceKey(legacy.source)}:${legacy.kind}:${unit.id}:`;
      check3(legacy.key.startsWith(prefix), "status display identity");
      const suffix = legacy.key.slice(prefix.length), legacyApplication = suffix.startsWith("armor:") ? suffix.slice(6) : suffix;
      const applicationId = !legacyApplication ? "source" : legacyApplication.startsWith("[") ? legacyApplication : JSON.stringify([...legacyApplication.split(":").map(Number), unit.id]);
      check3(JSON.parse(c.key)[8] === applicationId, "status application identity");
      const app = c.application;
      const kind = legacy.kind === "stun" ? "stun" : legacy.kind === "armorReduction" ? "sunder" : legacy.kind === "damageReduction" ? "damage-reduction" : legacy.amount < 0 ? "stat-debuff" : "stat-buff";
      check3(app.kind === kind && app.onEnd === null, "uncompiled status kind/end rewards");
      if (app.modifier) check3(app.modifier.value.kind === "constant" && app.modifier.value.amount === legacy.amount && app.modifier.unit === "flat" && ["armor", "magicResist"].includes(app.modifier.stat) && app.modifier.condition.kind === "always" && app.modifier.damageFilter === null, "status modifier projection");
      else check3(app.magnitudeBps === legacy.amount, "status magnitude projection");
      covered.add(key3);
    }
  }
  check3(covered.size === contributions.length, "uncompiled status contribution");
  const ids2 = new Set(units.map((u) => u.id)), dead = new Set(units.filter((u) => !u.alive).map((u) => u.id)), taskKeys = /* @__PURE__ */ new Set();
  for (const task of state.periodicTasks) {
    validatePeriodicTask(task, ids2, dead, tick, combatId);
    const burn2 = contributions.find((c) => c.key === task.key && c.application.kind === "burn");
    if (burn2) {
      const program = { definitionId: JSON.stringify([burn2.source.definitionId, burn2.source.effectIndex, "burn"]), selector: selfSelector({ candidates: "bound-target", relation: "enemy", maxTargets: 1 }), targetSnapshot: "once-per-pulse", effects: [{ kind: "damage", damageType: "true", delivery: "item-burn", critEligibility: "never", amount: flatAmount(0, { maxHpBps: burn2.application.magnitudeBps, hpBasis: "target", sample: "each-pulse" }) }] };
      check3(!taskKeys.has(task.key) && task.targetId === unit.id && same3(task.source, burn2.source) && task.periodTicks === 20 && task.endsAtTick === burn2.expiresAtTick && task.finalPulse === "before-expiry" && task.onSourceDeath === "persist-attached" && task.onTargetDeath === "cancel" && task.pulseLimit === null && same3(task.program, program) && task.nextPulseAtTick === state.statuses.find((g) => g.contributions.some((c) => c.key === burn2.key)).nextPulseAtTick, "item burn program");
      taskKeys.add(task.key);
      continue;
    }
    const definition = compiled.periodicTasks.find((t) => t.key === task.key);
    check3(definition && !taskKeys.has(task.key) && same3({ ...task, nextPulseAtTick: definition.nextPulseAtTick, pulseOrdinal: 0, remainders: [] }, definition), "periodic program/source binding");
    check3(task.pulseOrdinal === Math.max(0, Math.floor((tick - definition.nextPulseAtTick) / task.periodTicks) + 1) && task.nextPulseAtTick === definition.nextPulseAtTick + task.pulseOrdinal * task.periodTicks, "periodic phase");
    for (const r of task.remainders) check3(ids2.has(r.targetId) && r.denominator > 0 && r.numerator > 0, "compiled periodic account");
    taskKeys.add(task.key);
  }
  check3(state.periodicTasks.filter((t) => t.onSourceDeath === "cancel").length === (!unit.alive || finished ? 0 : compiled.periodicTasks.filter((t) => t.endsAtTick === null || t.endsAtTick > tick).length), "lost periodic tasks");
  check3(contributions.filter((c) => c.application.kind === "burn").every((c) => taskKeys.has(c.key)), "lost attached burn task");
  for (const layer of unit.shieldLayers ?? []) {
    check3(layer.m8State && layer.m8Grant, "missing frozen shield record/declaration");
    const shield2 = layer.m8State, grant = layer.m8Grant;
    validateShield(shield2, tick, combatId);
    check3(shield2.targetId === unit.id && same3(shield2.source, asSource(layer.source)) && layer.key === (shield2.source.parentItemInstanceId === null ? sourceKey(layer.source) : shield2.key) && shield2.granted === layer.granted && shield2.remaining === layer.remaining && shield2.absorbed === layer.absorbed && shield2.expiresAtTick === layer.expiresAtTick && typeof shield2.endRewardConsumed === "boolean", "shield projection");
    const declared = shield2.source.sourceKind === "item" ? units.filter((u) => u.id === shield2.source.ownerId).flatMap((u) => declaredEffects(u, combatId)).find((d) => canonicalSource(d.source) === canonicalSource(shield2.source) && d.effect.kind === "grant-shield" && same3(d.effect, grant)) : void 0;
    if (declared) {
      validateItemEffectConsumption(shield2.source, shield2.startsAtTick, units, combatId);
      check3(shield2.decay.kind === grant.decay.kind && [...maxHpCandidates(unit, shield2.startsAtTick, combatId)].some((hp2) => shield2.granted === Math.floor(hp2 * grant.amount.maxHpBps / 1e4)), "item shield sampled amount");
      check3(shield2.remaining > 0 && layer.endedReason === void 0 && !shield2.endRewardConsumed && !units.some((u) => u.tasks?.some((t) => t.shieldEndKey === layer.key)), "item shield active lifecycle");
      continue;
    }
    check3(
      grant.kind === "grant-shield" && grant.durationTicks > 0 && grant.amount.sample === "application" && grant.amount.flat >= 0 && grant.amount.attackDamageBps === 0 && grant.amount.abilityPowerBps === 0 && grant.amount.maxHpBps === 0 && grant.amount.missingHpBps === 0 && grant.amount.actualManaSpentBps === 0 && grant.amount.actualDamageBps === 0 && grant.amount.shieldAbsorbedBps === 0 && grant.amount.cap === null && grant.amount.hpBasis === "holder",
      "uncompiled shield grant"
    );
    integer(grant.durationTicks, 1);
    integer(grant.amount.flat);
    const owner = units.find((u) => u.id === shield2.source.ownerId);
    if (shield2.decay.kind === "linear-initial-grant") {
      check3(owner.ability.kind === "s13" && Object.hasOwn(owner.ability.variables, "PercentShieldDamage") && grant.endTiming === "next-action-planning" && grant.decay.kind === "linear-initial-grant" && same3(grant.onEnd, ["depleted", "expired"]) && grant.endEffects.length === 1, "decaying shield end binding");
      const end = grant.endEffects[0];
      check3(end.kind === "damage" && end.damageType === "magic" && end.delivery === "ability-direct" && end.critEligibility === "requires-spell-authorization" && end.amount.shieldAbsorbedBps === owner.ability.variables.PercentShieldDamage && end.amount.sample === "packet" && end.amount.attackDamageBps === 0 && end.amount.abilityPowerBps === 0 && end.amount.maxHpBps === 0 && end.amount.missingHpBps === 0 && end.amount.actualManaSpentBps === 0 && end.amount.actualDamageBps === 0 && end.amount.cap === null && end.amount.hpBasis === "holder", "shield end amount binding");
      const apAtGrant = (owner.abilityPower ?? 100) + (owner.mechanics ?? []).filter((m) => m.mechanic === "archangel").reduce((n, m) => n + Math.floor(shield2.startsAtTick / m.values.periodTicks) * m.values.abilityPower, 0);
      check3(end.amount.flat === Math.floor(apAtGrant * owner.ability.variables.StrikeBaseDamage / 1e6) || [...abilityPowerCandidates(owner, shield2.startsAtTick, combatId)].some((ap2) => end.amount.flat === Math.floor(ap2 * (owner.ability.kind === "s13" ? owner.ability.variables.StrikeBaseDamage : 0) / 1e6)), "shield end sampled damage");
      check3(grant.endTargeting.kind === "select" && same3(grant.endTargeting.selector, { primary: "normal", candidates: "board", relation: "enemy", anchor: "holder", radius: 1, maxTargets: 100, excludeSelf: true, excludePrimary: false, distinct: true, order: "id", sample: "action-completion" }), "shield end targeting binding");
    } else check3(grant.endTiming === "post-damage" && grant.decay.kind === "none" && grant.onEnd.length === 0 && grant.endEffects.length === 0 && same3(grant.endTargeting, { kind: "fixed", targetIds: [unit.id], ifMissing: "skip" }), "ordinary shield end binding");
    const pendingEnds = units.flatMap((u) => u.tasks ?? []).filter((t) => t.shieldEndKey === layer.key && t.source.ownerId === shield2.source.ownerId);
    check3(shield2.remaining === 0 || layer.endedReason === void 0 && !shield2.endRewardConsumed, "active shield consumption/reason");
    if (shield2.remaining === 0) check3(layer.endedReason !== void 0 || shield2.granted === 0 && !shield2.endRewardConsumed, "missing shield end reason");
    if (shield2.endRewardConsumed) check3(pendingEnds.length === 0, "consumed shield has pending end task");
    else if (grant.endTiming === "next-action-planning") check3(pendingEnds.length === 1 && pendingEnds[0].executeAtTick > tick && same3(asSource(pendingEnds[0].source), shield2.source), "missing/foreign shield end task");
    else check3(pendingEnds.length === 0, "unexpected shield end task");
    if (layer.endedReason !== void 0) check3(["depleted", "expired", "replaced", "death-cleanup", "combat-end"].includes(layer.endedReason) && shield2.remaining === 0, "shield end reason");
  }
  const activityKeys = /* @__PURE__ */ new Set();
  for (const a of state.activities) {
    validateIdentity(a, combatId);
    integer(a.actionSeq);
    integer(a.startsAtTick);
    integer(a.expiresAtTick, 1);
    check3(!activityKeys.has(a.key) && a.targetId === unit.id && a.source.ownerId === unit.id && a.source.sourceKind === "ability" && a.source.definitionId === unit.ability.id && a.source.instanceId === unit.id && a.source.effectIndex === 0 && a.source.parentItemInstanceId === null && a.actionSeq < nextActionSeq && a.startsAtTick <= tick && a.expiresAtTick > a.startsAtTick, "activity identity/time");
    activityKeys.add(a.key);
    check3(a.kind === "channel" || a.kind === "redirect", "activity kind");
    if (a.kind === "channel") check3(same3(a.blocks, ["move", "attack", "cast"]) && a.cancelOnControl === true, "channel declaration");
    else check3(a.allyRadius === 1 && a.shareBps >= 0 && a.shareBps <= 1e4 && a.choose === "lowest-id" && a.repeatMitigation === false && a.recursive === false, "redirect declaration");
    if (a.lifecycle === "active") check3(unit.alive && !finished && a.expiresAtTick > tick && a.endedAtTick === null && a.endReason === null && (unit.statuses ?? []).some((s) => s.activity?.key === a.key && same3(s.activity, a) && s.startsAtTick === a.startsAtTick && s.expiresAtTick === a.expiresAtTick && s.kind === a.kind && (a.kind !== "redirect" || s.amount === a.shareBps)), "active activity projection");
    else {
      check3(a.lifecycle === "ended", "activity lifecycle");
      integer(a.endedAtTick);
      check3(a.endedAtTick <= tick && a.endedAtTick >= a.startsAtTick && ["expired", "control-cancelled", "replaced", "death-cleanup", "combat-end"].includes(a.endReason) && (a.endReason !== "expired" || a.endedAtTick === a.expiresAtTick) && (a.kind !== "redirect" || a.endReason !== "control-cancelled"), "ended activity receipt");
    }
  }
  for (const legacy of unit.statuses ?? []) if (legacy.activity) check3(state.activities.some((a) => a.key === legacy.activity.key && a.lifecycle === "active"), "foreign activity projection");
  if (!unit.alive || finished) check3(state.statuses.length === 0 && (unit.statuses ?? []).length === 0 && (unit.shieldLayers ?? []).length === 0, "mechanism cleanup");
}

// src/simulation/serialization.ts
function requireValue2(condition, message) {
  if (!condition) throw new Error(`Invalid Match save: ${message}`);
}
var inputValidation2 = createInputValidation(requireValue2);
var integer7 = inputValidation2.integer;
var id = inputValidation2.id;
var definitionId = inputValidation2.definitionId;
var list = inputValidation2.list;
var record3 = inputValidation2.record;
var checkSerial = inputValidation2.checkSerial;
function nullableString(value) {
  if (value !== null) id(value);
}
function totalExperience(level, xp) {
  grantXp(level, xp, 0);
  return xp + Object.entries(XP_TO_NEXT_LEVEL).filter(([from]) => Number(from) < level).reduce((sum, [, amount3]) => sum + amount3, 0);
}
function validPreparationExperience(before, level, xp) {
  const after = totalExperience(level, xp), cap = totalExperience(MATCH_RULES.maxLevel, 0);
  return after >= before && (after === cap || (after - before) % MATCH_RULES.xpPurchaseAmount === 0);
}
function restoreMatch(input) {
  const __b8Timer = globalThis.__b8Start("restoreMatch");
  try {
    const raw = typeof input === "string" ? JSON.parse(input) : input;
    canonicalContent(raw);
    record3(raw);
    requireValue2(raw.schemaVersion === 5 && raw.rulesVersion === "m5-14.24b-v1" && raw.contentVersion === "s13-14.24b-slice-v1" && raw.commandProtocolVersion === 2 && raw.rngAlgorithm === "lcg32-v1" && raw.tickMs === 50, "unsupported-version");
    requireValue2(raw.contentDigest === CONTENT_DIGEST, "content-digest");
    for (const name of ["seed", "rngState", "choiceRngState", "rewardRngState", "battleSeedRngState"]) validateSeed(raw[name]);
    for (const name of ["gold", "xp", "playerHp", "nextMatchEventSeq"]) integer7(raw[name]);
    integer7(raw.round, 1);
    requireValue2(raw.playerHp <= 100, "level/HP bounds");
    requireValue2(["preparation", "choice", "combat", "settlement", "gameOver"].includes(raw.phase), "phase");
    const state = raw;
    requireValue2(state.round <= FINAL_ROUND, "round bounds");
    const roundDefinition = getCatalogRoundByOrdinal(state.round);
    const enemyProjection = readRoundEnemyProjection(state.round);
    const units = validateInputAssets(state, { playerLevel: state.level, nextUnitSerial: state.nextUnitSerial, nextItemSerial: state.nextItemSerial }, enemyProjection.units, inputValidation2);
    record3(state.m8);
    record3(state.m8.round);
    record3(state.m8.preparation);
    requireValue2(canonicalContent(state.m8.round) === canonicalContent(roundDefinition), "m8 round identity");
    requireValue2(state.m8.encounterPlan === null, "independent encounter plan authority");
    requireValue2(canonicalContent(state.m8.preparation) === canonicalContent({
      version: ROUND_PREPARATION_RULES.version,
      roundId: roundDefinition.roundId,
      encounterId: roundDefinition.encounterId,
      contentStatus: roundDefinition.kind === "pve" ? ROUND_PREPARATION_RULES.pveContent : "not-pve",
      enemies: enemyProjection.units
    }), "round preparation freeze");
    requireValue2(state.level === 9 ? state.xp === 0 : state.xp < XP_TO_NEXT_LEVEL[state.level], "current XP");
    record3(raw.shop);
    requireValue2(typeof raw.shop.locked === "boolean", "shop lock");
    integer7(raw.shop.generation, 1);
    list(raw.shop.slots);
    requireValue2(raw.shop.slots.length === 5, "shop size");
    for (const slot3 of state.shop.slots) {
      record3(slot3);
      requireValue2(slot3.status === "purchased" || slot3.status === "available", "shop slot");
      if (slot3.status === "available") definitionId(slot3.definitionId, M5_UNIT_DEFINITIONS, "shop definition");
    }
    record3(raw.equipmentState);
    record3(raw.equipmentState.equipment);
    list(raw.equipmentState.rolls);
    list(raw.temporaryEquipment);
    list(raw.augments);
    requireValue2(state.augments.length <= 3, "augment count");
    const augmentIds = /* @__PURE__ */ new Set();
    for (const augment of state.augments) {
      record3(augment);
      definitionId(augment.definitionId, AUGMENT_DEFINITIONS, "augment definition");
      requireValue2(!augmentIds.has(augment.definitionId), "duplicate augment");
      augmentIds.add(augment.definitionId);
      id(augment.choiceId);
      integer7(augment.acquiredRound, 1);
      requireValue2(augment.acquiredRound <= state.round, "augment round");
    }
    if (state.anomalyBinding !== null) {
      record3(state.anomalyBinding);
      const binding = state.anomalyBinding;
      definitionId(binding.definitionId, ANOMALY_DEFINITIONS, "anomaly definition");
      id(binding.unitId);
      requireValue2(units.get(binding.unitId)?.team === "player", "anomaly binding");
      id(binding.choiceId);
      integer7(binding.boundRound, 1);
      requireValue2(binding.boundRound <= state.round, "binding round");
    }
    list(raw.roundResults);
    requireValue2(state.roundResults.length === state.round - (state.phase === "settlement" || state.phase === "gameOver" || state.pendingChoice?.returnPhase === "settlement" && getRoundKind(state.round) !== "supply" ? 0 : 1), "history length");
    list(raw.scheduleReceipts);
    const receipts = /* @__PURE__ */ new Map();
    for (const receipt of state.scheduleReceipts) {
      record3(receipt);
      id(receipt.eventId);
      integer7(receipt.round, 1);
      requireValue2(receipt.round <= state.round, "receipt future");
      requireValue2(!receipts.has(receipt.eventId), "duplicate receipt");
      receipts.set(receipt.eventId, receipt);
      const event = getRoundSchedule(receipt.round).find((event2) => event2.id === receipt.eventId);
      requireValue2(event && receipt.kind === event.kind, "receipt event");
      if (event.kind === "reward") {
        requireValue2(receipt.gold === event.gold && receipt.itemIds.length === event.components.length + event.randomComponents && receipt.definitionId === null, "reward receipt values");
        requireValue2(new Set(receipt.itemIds).size === receipt.itemIds.length, "reward duplicate items");
        requireValue2(event.recruitIfEmpty || receipt.unitId === null, "unexpected fallback recruit");
        if (receipt.unitId !== null) checkSerial(receipt.unitId, "unit", state.nextUnitSerial);
      } else if (event.kind === "component") {
        definitionId(receipt.definitionId, ITEM_DEFINITIONS, "component receipt");
        requireValue2(ITEM_DEFINITIONS[receipt.definitionId].kind === "component" && receipt.itemIds.length === 1 && receipt.gold === 0 && receipt.unitId === null, "component receipt values");
      } else requireValue2(receipt.gold === (receipt.definitionId === "placebo" ? 8 : 0) && receipt.itemIds.length === 0, "choice receipt values");
      integer7(receipt.gold);
      list(receipt.itemIds);
      for (const itemId of receipt.itemIds) checkSerial(itemId, "item", state.nextItemSerial);
      nullableString(receipt.unitId);
      nullableString(receipt.definitionId);
      if (receipt.kind === "augment") requireValue2(state.augments.some((a) => a.choiceId === receipt.eventId && a.definitionId === receipt.definitionId), "augment receipt");
      if (receipt.kind === "anomaly") definitionId(receipt.definitionId, ANOMALY_DEFINITIONS, "anomaly receipt");
    }
    for (const augment of state.augments) requireValue2(receipts.get(augment.choiceId)?.definitionId === augment.definitionId && receipts.get(augment.choiceId)?.round === augment.acquiredRound, "augment missing receipt");
    if (state.anomalyBinding) requireValue2(receipts.get(state.anomalyBinding.choiceId)?.definitionId === state.anomalyBinding.definitionId && receipts.get(state.anomalyBinding.choiceId)?.round === state.anomalyBinding.boundRound, "binding missing receipt");
    const lootChoice = validateB8Loot(state);
    if (state.phase === "choice" && !lootChoice) {
      record3(state.pendingChoice);
      const choice = state.pendingChoice;
      id(choice.choiceId);
      id(choice.eventId);
      nullableString(choice.targetId);
      requireValue2(choice.choiceId === choice.eventId, "choice event ID");
      integer7(choice.generation);
      integer7(choice.rerollCount);
      list(choice.offers);
      requireValue2(!receipts.has(choice.eventId), "choice already completed");
      const event = getRoundSchedule(state.round).find((event2) => event2.id === choice.eventId);
      requireValue2(event?.kind === choice.kind && choice.kind !== void 0, "choice scheduled");
      if (choice.step === "target") requireValue2(choice.kind === "anomaly" && choice.targetId === null && choice.offers.length === 0 && choice.generation === 0 && choice.rerollCount === 0 && state.preparation.units.some((unit) => unit.team === "player"), "target substate");
      else {
        requireValue2(choice.step === "offer" && choice.offers.length === (choice.kind === "component" ? 8 : choice.kind === "anomaly" ? 1 : 3) && new Set(choice.offers).size === choice.offers.length, "offer substate");
        const catalog = choice.kind === "augment" ? AUGMENT_DEFINITIONS : choice.kind === "component" ? ITEM_DEFINITIONS : ANOMALY_DEFINITIONS;
        for (const offer of choice.offers) definitionId(offer, catalog, "offer definition");
        if (choice.kind === "component") {
          validateComponentCandidates(choice.offers);
        }
        if (choice.kind === "component") requireValue2(choice.targetId === null && choice.rerollCount === 0 && choice.generation === 0 && choice.offers.every((def) => ITEM_DEFINITIONS[def].kind === "component"), "component offers");
        else if (choice.kind === "augment") requireValue2(choice.targetId === null && choice.rerollCount === 0 && choice.generation === 0 && choice.offers.every((def) => !augmentIds.has(def)), "augment offers");
        else requireValue2(units.get(choice.targetId)?.team === "player" && choice.generation === choice.rerollCount + 1, "locked target");
      }
    } else if (!lootChoice) requireValue2(state.pendingChoice === null, "pending outside choice");
    const receiptOrder = state.scheduleReceipts.map((receipt) => receipt.eventId);
    const expectedReceiptOrder = [];
    for (let round2 = 1; round2 <= state.round; round2++) for (const event of getRoundSchedule(round2)) if (receipts.has(event.id)) expectedReceiptOrder.push(event.id);
    requireValue2(canonicalContent(receiptOrder) === canonicalContent(expectedReceiptOrder), "receipt order");
    let stopped = false;
    for (let round2 = 1; round2 <= state.round; round2++) for (const event of getRoundSchedule(round2)) {
      if (state.pendingChoice?.eventId === event.id) stopped = true;
      if (round2 === state.round && event.kind === "anomaly" && !receipts.has(event.id) && state.phase === "preparation" && !state.preparation.units.some((unit) => unit.team === "player")) {
        requireValue2(state.shop.slots.some((slot3) => slot3.status === "available" && UNIT_DEFINITIONS[slot3.definitionId].cost <= state.gold), "anomaly recruitment affordability");
        stopped = true;
      }
      if ((event.timing ?? "before") === "after" && state.roundResults.length < round2 || state.outcome !== null && round2 === state.round && event.timing === "after") continue;
      if (!stopped) requireValue2(receipts.has(event.id), "missing schedule receipt");
      else requireValue2(!receipts.has(event.id), "receipt beyond pending choice");
    }
    list(raw.roundResults);
    const settled = state.roundResults.length === state.round;
    requireValue2(state.roundResults.length === state.round - (settled ? 0 : 1), "history length");
    let streak = { kind: null, count: 0 };
    let experienceAfter = totalExperience(OPENING_INITIAL_STATE.level, OPENING_INITIAL_STATE.xp);
    for (const [i, result] of state.roundResults.entries()) {
      record3(result);
      requireValue2(result.round === i + 1 && result.roundId === getCatalogRoundByOrdinal(i + 1).roundId && result.settlementId === `round-${i + 1}-settled` && result.roundKind === getRoundKind(i + 1), "history round/identity");
      for (const field of ["round", "combatTicks", "combatEventCount", "income", "goldBefore", "goldAfter", "xpRequested", "xpAwarded", "levelBefore", "levelAfter", "xpBefore", "xpAfter", "hpBefore", "hpAfter", "baseDamage", "survivingEnemyCount", "playerDamage", "hpLost"]) integer7(result[field]);
      requireValue2(result.hpBefore === (i === 0 ? 100 : state.roundResults[i - 1].hpAfter), "history HP chain");
      requireValue2(canonicalContent(result.streakBefore) === canonicalContent(streak), "history streak before");
      requireValue2(validPreparationExperience(experienceAfter, result.levelBefore, result.xpBefore), "history XP preparation chain");
      const expected = planCatalogRoundEconomy({
        roundId: result.roundId,
        result: result.result === "supply" ? null : result.result,
        gold: result.goldBefore,
        hp: result.hpBefore,
        level: result.levelBefore,
        xp: result.xpBefore,
        streak,
        enemySurvivors: result.survivingEnemyCount
      });
      requireValue2(result.levelAfter === expected.progression.level && result.xpAfter === expected.progression.xp && result.xpAwarded === expected.progression.xpApplied && result.xpRequested === expected.progression.xpRequested, "history XP");
      requireValue2(result.baseDamage === expected.baseDamage && result.playerDamage === expected.playerDamage && result.hpAfter === expected.hpAfter && result.hpLost === expected.hpLost, "history damage");
      requireValue2(result.income === expected.income && result.goldAfter === expected.goldAfter && result.interestBasis === expected.interestBasis && canonicalContent(result.incomeBreakdown) === canonicalContent(expected.incomeBreakdown), "history income");
      requireValue2(canonicalContent(result.streakAfter) === canonicalContent(expected.streakAfter), "history streak");
      streak = expected.streakAfter;
      experienceAfter = totalExperience(result.levelAfter, result.xpAfter);
      requireValue2(result.combatTicks <= 1200 && (result.roundKind !== "supply" || result.combatTicks === 0 && result.combatEventCount === 0), "history ticks");
    }
    requireValue2(canonicalContent(state.streak) === canonicalContent(streak), "current streak");
    requireValue2(state.roundDefinitionId === roundDefinition.roundId, "round definition");
    requireValue2(state.phase === "gameOver" ? state.outcome === (roundDefinition.isFinal && state.playerHp > 0 && state.roundResults.at(-1)?.result === "playerWin" ? "victory" : "defeat") : state.outcome === null, "outcome");
    record3(state.augmentProgress);
    integer7(state.augmentProgress.pumpingRounds);
    integer7(state.augmentProgress.investmentHp);
    const pump = state.augments.find((a) => a.definitionId === "pumping-up-i"), investment = state.augments.find((a) => a.definitionId === "investment-strategy-i");
    requireValue2(state.augmentProgress.pumpingRounds === (pump ? state.roundResults.filter((r) => r.round >= pump.acquiredRound).length : 0), "pumping progress");
    requireValue2(state.augmentProgress.investmentHp === (investment ? state.roundResults.filter((r) => r.round >= investment.acquiredRound).reduce((n, r) => n + r.incomeBreakdown.interest * 8, 0) : 0), "investment progress");
    list(state.persistentGrowth);
    const growthIds = /* @__PURE__ */ new Set();
    for (const growth of state.persistentGrowth) {
      record3(growth);
      id(growth.unitId);
      integer7(growth.attackDamageBps, 1);
      requireValue2(units.get(growth.unitId)?.definitionId === "tristana" && !growthIds.has(growth.unitId) && growth.attackDamageBps % 125 === 0, "persistent growth");
      growthIds.add(growth.unitId);
    }
    requireValue2(state.playerHp === (state.roundResults.at(-1)?.hpAfter ?? 100), "current HP");
    if (!settled) requireValue2(validPreparationExperience(experienceAfter, state.level, state.xp), "current XP preparation chain");
    validateMatchEquipment(state);
    const { basis, saleGold } = validateB8Resources(state);
    if (settled) {
      const last = state.roundResults.at(-1);
      requireValue2(state.gold === last.goldAfter + saleGold && state.level === last.levelAfter && state.xp === last.xpAfter, "current settlement totals");
    }
    requireValue2(state.phase === "gameOver" === (state.playerHp === 0 || settled && roundDefinition.isFinal), "terminal boundary");
    if (state.phase === "preparation" || state.phase === "choice" && !settled || getRoundKind(state.round) === "supply") requireValue2(state.combat === null, "inactive combat");
    else {
      record3(state.combat);
      const combat2 = state.combat;
      validateSeed(combat2.rngState);
      integer7(combat2.rngDraws);
      integer7(combat2.nextActionSeq);
      integer7(combat2.tick);
      integer7(combat2.maxTicks, 1);
      requireValue2(combat2.tick <= combat2.maxTicks && combat2.maxTicks === 1200, "combat ticks");
      requireValue2(combat2.combatId === `round-${state.round}` && combat2.startEffectsApplied === true, "combat identity/start");
      integer7(combat2.nextEventSeq);
      requireValue2(combat2.status === "running" || combat2.status === "finished", "combat status");
      requireValue2(state.phase === "combat" === (combat2.status === "running"), "combat phase");
      requireValue2(combat2.status !== "running" || combat2.tick < combat2.maxTicks, "running timeout");
      requireValue2(combat2.status === "running" ? combat2.result === null : ["playerWin", "enemyWin", "draw"].includes(combat2.result), "combat result");
      record3(combat2.strategy);
      list(combat2.strategy.units);
      list(combat2.strategy.traits);
      list(combat2.units);
      requireValue2(basis, "missing combat input");
      const expectedStrategy = buildStrategySnapshot(basis.inputs);
      const combatPreparation = basis.inputs.preparation, combatOrigins = new Map(combatPreparation.units.map((unit) => [unit.id, unit]));
      requireValue2(canonicalContent(combat2.strategy) === canonicalContent(expectedStrategy), "resolved strategy");
      requireValue2(canonicalContent(combat2.board) === canonicalContent(combatPreparation.board), "combat board");
      const expectedIds = combatPreparation.units.filter((unit) => unit.location.kind === "board").map((unit) => unit.id).sort();
      requireValue2(canonicalContent(combat2.units.map((unit) => unit.id).sort()) === canonicalContent(expectedIds), "combat roster");
      if (settled) {
        const last = state.roundResults.at(-1);
        requireValue2(last.result === combat2.result && last.combatTicks === combat2.tick && last.combatEventCount === combat2.nextEventSeq && last.survivingEnemyCount === combat2.units.filter((unit) => unit.alive && unit.team === "enemy").length, "combat settlement result");
      }
      const combatIds = new Set(combat2.units.map((unit) => unit.id));
      requireValue2(combatIds.size === combat2.units.length, "duplicate combat ID");
      const neutralStatuses = validateNeutralCombat(combat2, combatPreparation, expectedStrategy);
      const cells = /* @__PURE__ */ new Set();
      for (const unit of combat2.units) {
        record3(unit);
        requireValue2(combatOrigins.get(unit.id)?.location.kind === "board", "combat unit origin");
        const origin2 = combatOrigins.get(unit.id);
        const resolved = expectedStrategy.units.find((value) => value.unitId === unit.id);
        if (unit.ability.kind === "s13") {
          requireValue2(unit.attackDamageBase === resolved.attackDamageBase && unit.attackDamagePercentBps === resolved.attackDamagePercentBps && unit.abilityPower === resolved.abilityPower && unit.baseAttackSpeedBps === (resolved.stats.baseAttackSpeedBps ?? Math.floor(2e5 / resolved.stats.attackIntervalTicks)) && unit.attackSpeedBonusBps === (resolved.stats.attackSpeedBonusBps ?? 0), "resolved dynamic bases");
          requireValue2(canonicalContent(unit.mechanics) === canonicalContent(resolved.mechanics), "resolved mechanics");
          requireValue2(canonicalContent(unit.itemPrograms ?? []) === canonicalContent(resolved.itemPrograms ?? []), "resolved item programs");
        }
        requireValue2(unit.team === origin2.team && unit.definitionId === origin2.definitionId && unit.starLevel === origin2.starLevel, "combat unit identity");
        const { stats } = resolved;
        if (unit.ability.kind !== "s13") requireValue2(unit.maxHp === stats.health, "resolved legacy maximum health");
        for (const [field, value] of Object.entries({ attackDamage: stats.attack, armor: stats.armor, magicResist: stats.magicResist, maxMana: stats.maxMana, attackIntervalTicks: stats.attackIntervalTicks, attackRange: stats.attackRange })) requireValue2(unit[field] === value, "resolved combat stat");
        requireValue2(canonicalContent(unit.ability) === canonicalContent(resolved.ability), "resolved ability");
        requireValue2(canonicalContent(unit.sources) === canonicalContent(resolved.sources) && canonicalContent(unit.triggers) === canonicalContent(resolved.triggers), "resolved effect source/trigger");
        for (const field of ["hp", "maxHp", "attackDamage", "armor", "magicResist", "mana", "maxMana", "shield", "cooldownTicks", "moveCooldownTicks", "attackIntervalTicks", "attackRange"]) integer7(unit[field]);
        requireValue2(unit.maxHp >= 1 && unit.maxMana >= (unit.unitKind === "neutral" ? 0 : 1) && unit.attackIntervalTicks >= 1 && unit.hp <= unit.maxHp && unit.mana <= unit.maxMana, "combat stats");
        requireValue2(unit.alive === unit.hp > 0, "alive flag");
        nullableString(unit.targetId);
        if (unit.targetId) requireValue2(combatIds.has(unit.targetId) && combat2.units.find((other) => other.id === unit.targetId)?.team !== unit.team, "target reference");
        requireValue2(unit.cooldownTicks <= 1200 && unit.moveCooldownTicks <= 5, "cooldown bounds");
        requireValue2(contains(combatPreparation.board, unit.cell), "combat cell");
        if (unit.alive) {
          const key3 = `${unit.cell.col}:${unit.cell.row}`;
          requireValue2(!cells.has(key3), "combat occupancy");
          cells.add(key3);
        }
        requireValue2(unit.shield === 0 ? unit.shieldExpiresAtTick === null : Number.isSafeInteger(unit.shieldExpiresAtTick) && unit.shieldExpiresAtTick > combat2.tick, "shield expiry");
        if (!unit.alive) requireValue2(unit.targetId === null && unit.mana === 0 && unit.shield === 0 && unit.cooldownTicks === 0 && unit.moveCooldownTicks === 0, "dead fields");
        if (unit.ability.kind === "s13") validateMechanisms(unit, combat2.units, combat2.tick, combat2.combatId, combat2.status === "finished", combat2.nextActionSeq, neutralStatuses);
        record3(unit.ability);
        integer7(unit.ability.amount);
        requireValue2(["damage", "selfShield", "s13"].includes(unit.ability.kind), "ability kind");
        validateM5Runtime(unit, combat2.tick, combatIds, combat2.units, combat2.combatId, neutralStatuses);
        list(unit.sources);
        list(unit.triggers);
        list(unit.effectRuntime);
        const sourceKeys = /* @__PURE__ */ new Set();
        for (const source of unit.sources) {
          requireValue2(source.key === effectKey(source.source) && source.source.ownerId === unit.id && !sourceKeys.has(source.key), "source key");
          sourceKeys.add(source.key);
          cloneEffect(source.effect);
        }
        const triggerKeys = /* @__PURE__ */ new Set();
        for (const trigger2 of unit.triggers) {
          requireValue2(sourceKeys.has(trigger2.key) && !triggerKeys.has(trigger2.key), "trigger key");
          triggerKeys.add(trigger2.key);
          cloneEffect({ kind: "trigger", ...trigger2 });
        }
        requireValue2(unit.effectRuntime.length === triggerKeys.size, "runtime size");
        const runtimeKeys = /* @__PURE__ */ new Set();
        for (const counter of unit.effectRuntime) {
          requireValue2(triggerKeys.has(counter.key) && !runtimeKeys.has(counter.key), "runtime key");
          runtimeKeys.add(counter.key);
          integer7(counter.count);
          const trigger2 = unit.triggers.find((t) => t.key === counter.key);
          requireValue2(counter.count <= (trigger2.hook === "combatStart" ? 1 : combat2.tick), "runtime count");
        }
      }
      const eliminated = eliminationResult(combat2.units);
      requireValue2(combat2.status === "running" ? eliminated === null : eliminated === null ? combat2.tick === combat2.maxTicks && combat2.result === "draw" : combat2.result === eliminated, "combat terminal consistency");
    }
    const restored = typeof input === "string" ? state : structuredClone(state);
    freezeContent(restored.m8);
    if (restored.combatInputBasis) freezeContent(restored.combatInputBasis);
    freezeContent(restored.resourceProvenance);
    return restored;
  } finally {
    globalThis.__b8End(__b8Timer);
  }
}
function validateM5Runtime(unit, tick, combatIds, combatUnits, combatId, neutralStatuses) {
  if (unit.ability.kind !== "s13") return;
  requireValue2(!unit.itemPrograms?.length || unit.spellCrit !== void 0, "missing item critical projection");
  if (unit.spellCrit !== void 0) {
    record3(unit.spellCrit);
    list(unit.spellCrit.itemSources);
    list(unit.spellCrit.nonItemSources);
    validateSpellCrit(unit.spellCrit);
    requireValue2(canonicalContent(unit.spellCrit) === canonicalContent(compileItemCrit(unit)), "uncompiled spell critical sources");
  }
  integer7(unit.attackDamageBase);
  integer7(unit.attackDamagePercentBps);
  integer7(unit.abilityPower);
  integer7(unit.baseAttackSpeedBps, 1);
  integer7(unit.attackSpeedBonusBps);
  record3(unit.runtime);
  for (const field of ["attackCount", "castCount", "attackSpeedBps", "abilityPowerFlat", "rangeBonus", "nextAttackMagic", "nextAttackPhysical", "permanentAdBps"]) integer7(unit.runtime[field]);
  requireValue2(typeof unit.runtime.buddyTriggered === "boolean" && unit.runtime.attackCount <= tick && unit.runtime.castCount <= tick && unit.runtime.permanentAdBps % 125 === 0, "combat runtime");
  if (unit.definitionId !== "tristana") requireValue2(unit.runtime.permanentAdBps === 0, "growth owner");
  const runtime = unit.runtime, isKog = champion(unit) === "kogmaw";
  requireValue2(runtime.attackCount + runtime.castCount <= tick, "action count bound");
  const itemSpeedAt = (at) => (unit.mechanismDefinitions?.periodicTasks ?? []).reduce((n, t) => n + t.program.effects.reduce((total2, e) => total2 + (e.kind === "modify-stat" && e.modifier.stat === "attackSpeed" && e.modifier.value.kind === "constant" && e.duration.kind === "combat" && e.stackPolicy.kind === "add-stacks" ? e.modifier.value.amount * Math.max(0, Math.floor((Math.min(at, t.endsAtTick ?? at) - t.nextPulseAtTick) / t.periodTicks) + 1) : 0), 0), 0);
  const actionSpeed = runtime.attackCount * mechanic(unit, "rageblade", "attackSpeedBps") + (isKog ? runtime.castCount * Math.round(variable(unit, "AttackSpeed", 0.25) * 1e4) : 0);
  requireValue2(unit.alive || itemSpeedAt(tick) === 0 ? runtime.attackSpeedBps === itemSpeedAt(tick) + actionSpeed : Array.from({ length: tick + 1 }, (_, at) => itemSpeedAt(at) + actionSpeed).includes(runtime.attackSpeedBps), "derived attack speed");
  requireValue2(runtime.rangeBonus === (isKog ? Math.floor(runtime.castCount / variable(unit, "RangeIncreaseNumAttacks", 3)) : 0), "derived range");
  const archangels = (unit.mechanics ?? []).filter((m) => m.mechanic === "archangel");
  const maximumAp = archangels.reduce((sum, m) => sum + Math.floor(tick / m.values.periodTicks) * m.values.abilityPower, 0);
  const possibleAp = /* @__PURE__ */ new Set([0]);
  for (const source of archangels) for (let at = source.values.periodTicks; at <= tick; at += source.values.periodTicks)
    possibleAp.add(archangels.reduce((sum, m) => sum + Math.floor(at / m.values.periodTicks) * m.values.abilityPower, 0));
  requireValue2(unit.alive ? runtime.abilityPowerFlat === maximumAp : possibleAp.has(runtime.abilityPowerFlat), "derived ability power");
  requireValue2(runtime.permanentAdBps <= runtime.castCount * (champion(unit) === "tristana" ? Math.round(variable(unit, "ASKillGain", 1.25) * 100) : 0), "derived growth bound");
  if (runtime.nextAttackMagic > 0) {
    requireValue2(champion(unit) === "lux" && runtime.castCount > 0 && [...abilityPowerCandidates(unit, 0, combatId)].some((ap2) => [...possibleAp].some((value) => Math.floor((ap2 + value) * variable(unit, "Damage") / 100) === runtime.nextAttackMagic)), "derived empowered magic");
  }
  if (runtime.nextAttackPhysical > 0) {
    const coefficient = variable(unit, "PercentAttackDamage") + variable(unit, "BonusDamageADRatio") * mechanic(unit, "lowCostAllies", "count");
    requireValue2(champion(unit) === "vander" && runtime.castCount > 0 && [...attackDamageCandidates(unit, tick, combatId)].some((attack) => runtime.nextAttackPhysical === Math.floor(attack * Math.round(coefficient * 1e4) / 1e4)), "derived empowered physical");
  }
  requireValue2(!runtime.buddyTriggered || (unit.mechanics ?? []).some((m) => m.mechanic === "bulkyBuddies" && combatUnits.some((other) => other.id === m.targetId && !other.alive)), "derived buddy trigger");
  const numerator = unit.attackDamageBase * (1e4 + unit.attackDamagePercentBps + runtime.permanentAdBps);
  requireValue2(Number.isSafeInteger(numerator) && Number.isSafeInteger(unit.baseAttackSpeedBps * (1e4 + unit.attackSpeedBonusBps + runtime.attackSpeedBps)), "dynamic arithmetic bound");
  if (unit.ability.kind === "s13") {
    const largestCoefficient = Math.max(1e4, ...Object.values(unit.ability.variables));
    requireValue2(Number.isSafeInteger(largestCoefficient * (1 + Math.floor(numerator / 1e4) + unit.maxHp + unit.abilityPower + maximumAp)), "ability arithmetic bound");
  }
  const origin2 = (source, neutralStatus = false) => {
    record3(source);
    id(source.ownerId);
    id(source.definitionId);
    id(source.instanceId);
    integer7(source.effectIndex);
    requireValue2(combatIds.has(source.ownerId) && ["attack", "ability", "trait", "item", "augment", "anomaly", "enemyGrowth"].includes(source.sourceKind), "runtime source");
    const owner = combatUnits.find((value) => value.id === source.ownerId);
    if (source.sourceKind === "ability" || source.sourceKind === "attack") {
      requireValue2(source.definitionId === owner.ability.id && source.instanceId === owner.id && (source.effectIndex === 0 || neutralStatus) && source.parentItemInstanceId == null, "ability source identity");
    } else {
      requireValue2(owner.sources?.some((entry) => entry.source.ownerId === source.ownerId && entry.source.sourceKind === source.sourceKind && entry.source.sourceDefinitionId === source.definitionId && entry.source.sourceInstanceId === source.instanceId && entry.source.effectIndex === source.effectIndex && (entry.source.parentItemInstanceId ?? null) === (source.parentItemInstanceId ?? null)) || declaredEffects(owner, combatId).some((d) => canonicalSource(d.source) === canonicalSource(asSource(source))), "frozen runtime source");
    }
  };
  list(unit.shieldLayers);
  const shieldKeys = /* @__PURE__ */ new Set();
  let total = 0;
  for (const layer of unit.shieldLayers) {
    record3(layer);
    origin2(layer.source);
    integer7(layer.granted);
    integer7(layer.remaining);
    integer7(layer.absorbed);
    integer7(layer.expiresAtTick);
    requireValue2(layer.key === (layer.source.parentItemInstanceId ? layer.m8State?.key : sourceKey(layer.source)) && !shieldKeys.has(layer.key) && layer.remaining <= layer.granted && (layer.remaining === 0 || layer.expiresAtTick > tick), "shield layer");
    shieldKeys.add(layer.key);
    total += layer.remaining;
    if (layer.grantedAtTick !== void 0 || layer.decayDurationTicks !== void 0) {
      integer7(layer.grantedAtTick);
      integer7(layer.decayDurationTicks, 1);
      requireValue2(layer.grantedAtTick <= tick && layer.expiresAtTick === layer.grantedAtTick + layer.decayDurationTicks, "shield decay timing");
    }
    if (layer.decayPerTick !== void 0) integer7(layer.decayPerTick, 1);
  }
  requireValue2(total === unit.shield && unit.shieldExpiresAtTick === (total ? Math.max(...unit.shieldLayers.filter((l) => l.remaining > 0).map((l) => l.expiresAtTick)) : null), "shield aggregate");
  list(unit.statuses);
  const statusKeys = /* @__PURE__ */ new Set();
  for (const status2 of unit.statuses) {
    record3(status2);
    origin2(status2.source, neutralStatuses.has(status2.key));
    id(status2.key);
    integer7(status2.startsAtTick);
    integer7(status2.expiresAtTick);
    requireValue2(Number.isSafeInteger(status2.amount) && (status2.amount >= 0 || status2.kind === "resistanceFlat") && !statusKeys.has(status2.key) && status2.expiresAtTick > tick && status2.startsAtTick <= tick + 1, "status range");
    requireValue2(["stun", "damageReduction", "armorReduction", "resistanceFlat", "attackSpeed", "abilityPower", "channel", "redirect"].includes(status2.kind), "status kind");
    requireValue2(status2.kind !== "abilityPower" && status2.kind !== "attackSpeed", "unsupported dynamic status source");
    requireValue2(Math.abs(status2.amount) <= 1e6, "status arithmetic bound");
    if (["damageReduction", "armorReduction", "redirect"].includes(status2.kind)) requireValue2(status2.amount <= 1e4, "status bps");
    requireValue2(status2.key.startsWith(sourceKey(status2.source)) || status2.contributionKeys?.includes(status2.key) && unit.mechanismState.statuses.some((g) => g.contributions.some((c) => c.key === status2.key && canonicalSource(c.source) === canonicalSource(asSource(status2.source)))), "status key/source");
    statusKeys.add(status2.key);
  }
  list(unit.tasks);
  const taskKeys = /* @__PURE__ */ new Set();
  for (const task of unit.tasks) {
    record3(task);
    origin2(task.source);
    id(task.key);
    integer7(task.executeAtTick);
    integer7(task.amount);
    integer7(task.ordinal);
    integer7(task.total, 1);
    integer7(task.actionSeq);
    requireValue2(task.attachedDot === (task.kind === "bleed" ? true : void 0) && task.shieldEndKey === (task.kind === "ireliaEnd" ? sourceKey(task.source) : void 0), "task mechanism binding");
    const owner = combatUnits.find((value) => value.id === task.source.ownerId);
    const maximumAmp = mechanic(owner, "damageAmp", "bps") + mechanic(owner, "glassCannon", "damageAmpBps") + mechanic(owner, "sniper", "damageBpsPerHex") * (DEFAULT_BOARD.columns + DEFAULT_BOARD.rows);
    requireValue2(task.amount <= 1e8 && task.executeAtTick <= 2401 && Number.isSafeInteger(task.amount * (1e4 + maximumAmp) * 1e4), "task arithmetic bound");
    requireValue2(!taskKeys.has(task.key) && task.executeAtTick > tick && task.ordinal < task.total && typeof task.cancellable === "boolean", "task range");
    requireValue2(["maddie", "bleed", "ireliaEnd", "leonaEnd", "lorisEnd", "corki", "caitlyn", "tristanaBounce"].includes(task.kind), "task kind");
    if (task.kind === "tristanaBounce") {
      record3(task.inherited);
      id(task.inherited.parentPacketId);
      integer7(task.inherited.resolvedAtTick);
      requireValue2(task.inherited.portion === "overkill" && typeof task.inherited.critical === "boolean" && task.executeAtTick === task.inherited.resolvedAtTick + 1 && task.inherited.resolvedAtTick <= tick, "inherited bounce receipt");
      const tuple = JSON.parse(task.inherited.parentPacketId);
      list(tuple);
      requireValue2(tuple.length === 6 && tuple[0] === combatId && tuple[1] === task.inherited.resolvedAtTick && tuple[2] === task.source.ownerId && tuple[3] === task.actionSeq && typeof tuple[4] === "string" && combatIds.has(tuple[4]) && tuple[5] === 0 && JSON.stringify(tuple) === task.inherited.parentPacketId, "inherited parent packet identity");
      const parentTarget = combatUnits.find((value) => value.id === tuple[4]);
      requireValue2(champion(owner) === "tristana" && task.source.sourceKind === "ability" && task.ordinal === 0 && task.total === 1 && !task.cancellable && !parentTarget.alive && parentTarget.team !== owner.team, "inherited primary kill");
    } else requireValue2(task.inherited === void 0, "unexpected inherited receipt");
    requireValue2(task.targetId === null || combatIds.has(task.targetId), "task target");
    taskKeys.add(task.key);
  }
  list(unit.mechanics);
  for (const mechanic2 of unit.mechanics) {
    record3(mechanic2);
    origin2(mechanic2.source);
    id(mechanic2.mechanic);
    record3(mechanic2.values);
    for (const value of Object.values(mechanic2.values)) integer7(value);
    if (mechanic2.targetId !== void 0) requireValue2(combatIds.has(mechanic2.targetId), "mechanic target");
  }
}

// ../../../../tmp/b8-sniper-replay-diagnosis/repeat-profile.ts
var import_generate_m5_route = __toESM(require_generate_m5_route());
var import_strict = __toESM(require("node:assert/strict"));
var import_node_fs = __toESM(require("node:fs"));
var import_node_crypto = __toESM(require("node:crypto"));
var import_node_inspector = __toESM(require("node:inspector"));
var import_node_os = __toESM(require("node:os"));
var output = process.env.B8_DIAG_OUTPUT;
var phase = "initialization";
var round = 1;
var stack = [];
var totals = {};
var byPhase = {};
var byCaller = {};
var byRound = {};
function add2(where, key3, ms, child) {
  const m = where[key3] ??= { count: 0, inclusiveMs: 0, exclusiveMs: 0 };
  m.count++;
  m.inclusiveMs += ms;
  m.exclusiveMs += ms - child;
}
globalThis.__b8Start = (name) => {
  const entry = { name, start: performance.now(), child: 0, phase, round, parent: stack.at(-1)?.name ?? "ROOT" };
  stack.push(entry);
  return entry;
};
globalThis.__b8End = (entry) => {
  const ms = performance.now() - entry.start;
  import_strict.default.equal(stack.pop(), entry);
  if (stack.length) stack.at(-1).child += ms;
  add2(totals, entry.name, ms, entry.child);
  add2(byPhase, entry.phase + "::" + entry.name, ms, entry.child);
  add2(byCaller, entry.parent + "::" + entry.name, ms, entry.child);
  add2(byRound, entry.round + "::" + entry.phase + "::" + entry.name, ms, entry.child);
};
function timed(name, fn) {
  const t = globalThis.__b8Start(name);
  try {
    return fn();
  } finally {
    globalThis.__b8End(t);
  }
}
function inPhase(name, fn) {
  const p = phase;
  phase = name;
  try {
    return timed("phase:" + name, fn);
  } finally {
    phase = p;
  }
}
var nativeClone = globalThis.structuredClone;
globalThis.structuredClone = (...args) => timed("structuredClone", () => nativeClone(...args));
var profileApi = {};
for (const [name, value] of Object.entries(match_exports)) profileApi[name] = typeof value === "function" ? (...args) => inPhase("publicRoute", () => timed("public:" + name, () => value(...args))) : value;
var session = new import_node_inspector.default.Session();
session.connect();
var post = (name, args = {}) => new Promise((resolve, reject) => session.post(name, args, (e, result) => e ? reject(e) : resolve(result)));
async function main() {
  console.log(JSON.stringify({ event: "start", node: process.version, execPath: process.execPath, cpu: import_node_os.default.cpus()[0]?.model, cpuCount: import_node_os.default.cpus().length, argv: process.argv }));
  await post("Profiler.enable");
  await post("Profiler.setSamplingInterval", { interval: 1e3 });
  await post("Profiler.start");
  const start = performance.now();
  let restored = createMatch(42), commands = 0, ticks = 0;
  let previousRound = 0;
  const route = await (0, import_generate_m5_route.run)(profileApi, { build: "sniper", seed: 42, onStep(before, result, command) {
    round = before.round;
    if (round !== previousRound) {
      console.log(JSON.stringify({ event: "round", round, elapsedMs: performance.now() - start, provenanceEntries: before.resourceProvenance.entries.length, phase: before.phase }));
      previousRound = round;
    }
    inPhase("compareBefore", () => import_strict.default.deepEqual(restored, before));
    const frozen = inPhase("stringifyBefore", () => JSON.stringify(restored));
    inPhase("rejectedInsertions", () => {
      const failures = [buyUnit(restored, -1, restored.shop.generation), sellUnit(restored, "absent"), selectChoice(restored, "stale", -1, "absent"), nextRound(restored, -1)];
      for (const failed of failures) {
        import_strict.default.equal(failed.ok, false);
        import_strict.default.equal(failed.state, restored);
        import_strict.default.equal("events" in failed, false);
      }
    });
    inPhase("stringifyAfterRejected", () => import_strict.default.equal(JSON.stringify(restored), frozen));
    const second = inPhase("replayCommandOrTick", () => command ? (0, import_generate_m5_route.dispatch)(match_exports, restored, command) : stepMatch(restored));
    inPhase("compareSecond", () => import_strict.default.deepEqual(second, result));
    const raw = inPhase("stringifyRestoreInput", () => JSON.stringify(second.state));
    restored = inPhase("explicitRestore", () => restoreMatch(raw));
    inPhase("compareRestored", () => import_strict.default.deepEqual(restored, second.state));
    if (command) commands++;
    else ticks++;
  } });
  import_strict.default.equal(restored.phase, "gameOver");
  (0, import_strict.default)(commands > 100);
  (0, import_strict.default)(ticks > 1e3);
  const elapsedMs = performance.now() - start;
  const { profile } = await post("Profiler.stop");
  session.disconnect();
  import_node_fs.default.writeFileSync(output + "/replay.cpuprofile", JSON.stringify(profile));
  const results = { elapsedMs, commands, ticks, passed: true, summary: route.summary, serializedFinalSha256: import_node_crypto.default.createHash("sha256").update(JSON.stringify(restored)).digest("hex"), totals, byPhase, byCaller, byRound };
  import_node_fs.default.writeFileSync(output + "/segmented-results.json", JSON.stringify(results, null, 2));
  console.log(JSON.stringify({ event: "complete", elapsedMs, commands, ticks, passed: true, totals }));
}
main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
//# sourceMappingURL=profile.cjs.map
