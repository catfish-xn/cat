import * as api from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/src/simulation/match';
import {restoreMatch} from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/src/simulation/serialization';
import {run,dispatch} from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/scripts/generate-m5-route.cjs';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import inspector from 'node:inspector';
import os from 'node:os';
const output=process.env.B8_DIAG_OUTPUT!;
let phase='initialization',round=1;
const stack:any[]=[], totals:any={}, byPhase:any={}, byCaller:any={}, byRound:any={};
function add(where:any,key:string,ms:number,child:number){const m=where[key]??={count:0,inclusiveMs:0,exclusiveMs:0};m.count++;m.inclusiveMs+=ms;m.exclusiveMs+=ms-child;}
(globalThis as any).__b8Start=(name:string)=>{const entry={name,start:performance.now(),child:0,phase,round,parent:stack.at(-1)?.name??'ROOT'};stack.push(entry);return entry;};
(globalThis as any).__b8End=(entry:any)=>{const ms=performance.now()-entry.start;assert.equal(stack.pop(),entry);if(stack.length)stack.at(-1).child+=ms;add(totals,entry.name,ms,entry.child);add(byPhase,entry.phase+'::'+entry.name,ms,entry.child);add(byCaller,entry.parent+'::'+entry.name,ms,entry.child);add(byRound,entry.round+'::'+entry.phase+'::'+entry.name,ms,entry.child);};
function timed<T>(name:string,fn:()=>T):T{const t=(globalThis as any).__b8Start(name);try{return fn();}finally{(globalThis as any).__b8End(t);}}
function inPhase<T>(name:string,fn:()=>T):T{const p=phase;phase=name;try{return timed('phase:'+name,fn);}finally{phase=p;}}
const nativeClone=globalThis.structuredClone;
globalThis.structuredClone=(...args:any[])=>timed('structuredClone',()=>nativeClone(...args));
const profileApi:any={};
for(const [name,value] of Object.entries(api))profileApi[name]=typeof value==='function'?(...args:any[])=>inPhase('publicRoute',()=>timed('public:'+name,()=>(value as any)(...args))):value;
const session=new inspector.Session();session.connect();
const post=(name:string,args={})=>new Promise<any>((resolve,reject)=>session.post(name,args,(e,result)=>e?reject(e):resolve(result)));
async function main(){
 console.log(JSON.stringify({event:'start',node:process.version,execPath:process.execPath,cpu:os.cpus()[0]?.model,cpuCount:os.cpus().length,argv:process.argv}));
 await post('Profiler.enable');await post('Profiler.setSamplingInterval',{interval:1000});await post('Profiler.start');
 const start=performance.now();let restored=api.createMatch(42),commands=0,ticks=0;let previousRound=0;
 const route=await run(profileApi,{build:'sniper',seed:42,onStep(before:any,result:any,command:any){
  round=before.round;
  if(round!==previousRound){console.log(JSON.stringify({event:'round',round,elapsedMs:performance.now()-start,provenanceEntries:before.resourceProvenance.entries.length,phase:before.phase}));previousRound=round;}
  inPhase('compareBefore',()=>assert.deepEqual(restored,before));
  const frozen=inPhase('stringifyBefore',()=>JSON.stringify(restored));
  inPhase('rejectedInsertions',()=>{const failures=[api.buyUnit(restored,-1,restored.shop.generation),api.sellUnit(restored,'absent'),api.selectChoice(restored,'stale',-1,'absent'),api.nextRound(restored,-1)];for(const failed of failures){assert.equal(failed.ok,false);assert.equal(failed.state,restored);assert.equal('events' in failed,false);}});
  inPhase('stringifyAfterRejected',()=>assert.equal(JSON.stringify(restored),frozen));
  const second=inPhase('replayCommandOrTick',()=>command?dispatch(api,restored,command):api.stepMatch(restored));
  inPhase('compareSecond',()=>assert.deepEqual(second,result));
  const raw=inPhase('stringifyRestoreInput',()=>JSON.stringify(second.state));
  restored=inPhase('explicitRestore',()=>restoreMatch(raw));
  inPhase('compareRestored',()=>assert.deepEqual(restored,second.state));
  if(command)commands++;else ticks++;
 }});
 assert.equal(restored.phase,'gameOver');assert(commands>100);assert(ticks>1000);
 const elapsedMs=performance.now()-start;const {profile}=await post('Profiler.stop');session.disconnect();
 fs.writeFileSync(output+'/replay.cpuprofile',JSON.stringify(profile));
 const results={elapsedMs,commands,ticks,passed:true,summary:route.summary,serializedFinalSha256:crypto.createHash('sha256').update(JSON.stringify(restored)).digest('hex'),totals,byPhase,byCaller,byRound};
 fs.writeFileSync(output+'/segmented-results.json',JSON.stringify(results,null,2));
 console.log(JSON.stringify({event:'complete',elapsedMs,commands,ticks,passed:true,totals}));
}
main().catch(e=>{console.error(e);process.exitCode=1;});
