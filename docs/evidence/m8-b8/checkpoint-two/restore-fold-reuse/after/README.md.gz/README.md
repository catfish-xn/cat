# 最小同调用全prefix复用：同负载前后诊断

本包记录已批准、由父任务实施的唯一生产修改：validateB8Resources 内仅 provenancePrefixLength===entries.length 时使用本次已完整验证的 current；短历史prefix依旧重新fold。诊断代理没有修改任何仓库文件。

## 核实结果

同 Node v22.23.3、同原完整 sniper seed42 路线、同全部12112个 onStep 的断言。182 commands /11930 ticks，33场战斗，每一步仍核对 before完整状态、second完整{state,events}和restored完整状态；每步4非法插入命令、不变引用、无events和JSON不变断言都执行。没有预生成fixture、少tick、更改worker/timeout/skip或复用跨restore结果。

- 总时间：143476.266245 →139150.669438 ms，减少4325.596807 ms（3.01485%）。
- restoreMatch：仍12112次，88654.915715 →83798.906782 ms，减少4856.008933 ms（5.47743%）。
- foldResourceProvenance：24081 →12151次，9491.239959 →5086.845899 ms。精确减少11930次，等于所有running恢复数；39次finished的短prefix第二fold保留。
- validateB8Resources：仍12112次，14399.671505 →9940.963124 ms。
- validateResourceReceipts：36193 →24263次，3432.943660 →2368.079539 ms。精确删去11930次随重复fold产生的验证，其余完整验证保留。
- validateB8Loot：仍12112次，4986.582176 →4980.339335 ms；restoreCombatInput：仍11969次，3048.655004 →3056.446070 ms。
- 比较程序逐一断言，除预期减少fold/receipt外，所有插桩函数及测试分段调用次数完全一致。
- 最终JSON字节SHA256一致：d3a1a077f60bcd6201bcd166cb3447e546384deb39e09c1bdc0af672018617a8。两次独立运行都在每一步断言replay state/events等于同一未修改公共路线的原结果；没有保存跨两次全流状态/事件的独立逐tick哈希清单，因此不声称做了不存在的离线全流hash比较。

这是一次成对CPU诊断，证实重复工作被精确删除且测得收益符合原预计约4.7秒量级。总时间改善包含运行噪声，不能保证相同CI改善值，不能把单例profile<180秒当原Vitest/CI通过，不能用本机结果改写原CI200失败事实。B8以前的同内容同路线基线未测，因此未量化整体B8性能回退比例。

## 来源绑定

受测HEAD在前后均为f26826a50c7c9fca2e74f4158de9d31c26e1fbfa。after为HEAD+唯一生产diff及3个新回归测试（本脚本未运行这些新测试）；源代码bundle已在运行前固定。两个运行各自的src逐文件sha256前后完全一致。源差分仅src/simulation/b8-restore.ts，详见source-comparison.json及source-and-environment-before.txt。

original-B8 source tree：5f9b62228b236074efd78b50a571cc26d23858e5，与CI200远端c854的本地等价d2011ae相同；本次after未提交，不将git HEAD:src误写为修改后源tree。工作树每个源文件都由SHA256清单绑定，完整差分保存在before文件；sourcemap包含实际插桩构建输入。

原包：/tmp/b8-sniper-replay-diagnosis。after执行原重复脚本仅改变输出目录变量，不改变timing/插桩/路线或断言；旧profile.ts与repeat-profile.ts差异只是一行输出路径参数化。Node22由显式PATH指定，未用默认Node24。原before和after的CPU自报均AMD EPYC 9V74 80-Core Processor，os.cpus().length=9；父任务暂停其他重验证直到after完成。

## 实际命令

/tmp/b8-sniper-replay-diagnosis/run-repeat.sh /tmp/b8-sniper-replay-after
PATH=/tmp/b7-npm-cache/_npx/d18f28baf1132559/node_modules/node/bin:$PATH node /tmp/b8-sniper-replay-diagnosis/compare-results.cjs /tmp/b8-sniper-replay-after > /tmp/b8-sniper-replay-after/comparison.json

profile.exit=0。execution脚本副本、构建bundle/sourcemap、CPU raw profile、分轮/分段JSON、comparison.json及源核对清单均包含在本包。后续正式原test门禁、针对验证、typecheck/预算、固定新SHA全量和CI由父任务继续处理。
