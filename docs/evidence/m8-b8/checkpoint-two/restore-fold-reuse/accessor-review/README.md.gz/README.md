# B8 complete-fold reuse: focused internal preflight evidence

Date: 2026-10-10 UTC. Node actually used: v24.19.0.
Repository: /workspace/scratch/2d61d723fa5a/cat-b8-phase2.
Baseline HEAD: f26826a50c7c9fca2e74f4158de9d31c26e1fbfa.

This is a targeted internal technical preflight, not formal independent B8 audit acceptance. The reviewer did not edit repository sources, commit, run Vitest, rerun a full suite, or benchmark performance. Only evidence files were written under this /tmp directory.

## Conclusion

The original accessor rejection regression is removed by the current conservative boundary. Ordinary JSON values produce the same resource input: resource-provenance.ts:225 defaults an omitted prefix to entries.length. The first fold fully validates the ledger before returning. Historical shorter prefixes remain separately folded; a valid finished commit has start <= its entry index < entries.length (resource-provenance.ts:338), so it cannot use the full-prefix shortcut.

Current b8-restore.ts:119 defaults parsedJsonInput to false. The only repository caller is serialization.ts:188, passing typeof input === 'string'. This matches serialization.ts:55, where this same primitive string is parsed locally with JSON.parse before validation; there is no reviver or caller-controlled object reused on that branch. Object inputs preserve the original second fold. The flag is not read from candidate state.

The cached projection remains a local variable, not a cross-restore cache. resource-provenance.ts:237-238 copies projected records and :377 deep-freezes them. combat-input.ts:84-100 reads/compares this authority and :121 returns a cloned basis; no projection alias is stored in the restored state. This is unchanged by the conservative patch.

## Confirmed original regression

The object entry point does not normalize before validation: serialization.ts:55-56 directly uses the caller object, and structuredClone occurs at :248. canonicalContent in content/index.ts:33-34 reads ordinary object properties without rejecting accessors. A persistentGrowth getter can mutate entries[0].source after the first fold at b8-restore.ts:123, when the current projection comparison reads persistentGrowth at :125. Unsafe reuse at :138 then omits the original second fold.

The exact original unsafe source was reconstructed from the baseline commit and the original observed diff. Its git blob is 2decb31b8293280de47ab306b68b94372f1a1602, matching the original observed diff prefix 2decb31. Its SHA-256 is 9bfc8652a2c86abe4a214c3209c37eca82cd98cf9bcd9b3fdb235f5490b26077.

Current reviewed b8-restore.ts git blob: c109567d28b0c7339f2d3d489d8dce405abd1e77.
Current reviewed serialization.ts git blob: 5f9146e01f4e743dca325e72f9e79d5bc5011808.
Current reviewed new tests git blob: 84dca265f80a8d6b5052eafdc2cf14a7771211f4.
Full SHA-256 values and retained source snapshots are listed in manifest.json.

## Independently executed tiny reproduction

Run from any working directory while the recorded repository dependencies remain available:

    for MODE in baseline unsafe current; do MODE=$MODE node /tmp/b8-fold-accessor-review/review.mjs; done

The loader reads the retained b8-restore/serialization snapshots and strips TypeScript in memory. No repository file is rewritten. Other imports use the current repository. The accessor trigger uses its fourth read, which is the known unchanged post-fold comparison; it does not depend on Error.stack or mock the fold.

Observed actual results, preserved in actual-output.log:

- Baseline: ordinary JSON string and object controls equal the original state; getter input rejects after four reads with Invalid resource provenance: fields.
- Unsafe optimization: both positive controls still equal; getter input is accepted after six reads and returned provenance has source.extra = 1; restoring that returned state's JSON then rejects with Invalid resource provenance: fields.
- Current conservative fix: both positive controls equal; getter input rejects after four reads with the same original fields error.

## New tests reviewed, not independently rerun

tests/m8-b8-restore-fold-reuse.test.ts:11-32 covers string full-prefix one-fold behavior, repeated independent calls, state/output equality, immutable detached projection and object double-fold fallback.
:35-47 covers a string historical short prefix retaining two folds, and an object suffix corruption rejection.
:50-55 covers string basis-prefix tampering after one successful full fold.
:58-70 adds persistentGrowth and preparation accessor mutation cases using a fold spy to mark the post-validation stage; both require two calls and the original provenance fields error.

The author reports 5/5 tests passing. This reviewer verified the test logic and independently reran the tiny persistentGrowth reproduction, not that Vitest result. The current assertions cover the changed decision boundary. An additional string form of the suffix corruption negative control would be a small optional strengthening; it is not a discovered code defect because the initial full-ledger validation is unconditional.

No blocker remains within this specific optimization and original accessor issue. Full-suite status, remaining timing failures, profiling, and overall B8 correctness are outside this review and remain pending separately.
