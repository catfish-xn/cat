import { registerHooks, stripTypeScriptTypes } from 'node:module';
import { existsSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const directory = '/tmp/b8-fold-accessor-review';
const repository = '/workspace/scratch/2d61d723fa5a/cat-b8-phase2';
const mode = process.env.MODE ?? 'current';
if (!['baseline', 'unsafe', 'current'].includes(mode)) throw new Error('Unknown mode');
registerHooks({
  resolve(specifier, context, nextResolve) {
    if (specifier.startsWith('.') && context.parentURL?.startsWith('file:')) {
      const base = new URL(specifier, context.parentURL);
      for (const suffix of ['.ts', '/index.ts']) {
        const url = new URL(base.href + suffix);
        if (existsSync(fileURLToPath(url))) return nextResolve(url.href, context);
      }
    }
    return nextResolve(specifier, context);
  },
  load(url, context, nextLoad) {
    if (!url.endsWith('.ts')) return nextLoad(url, context);
    let source = readFileSync(fileURLToPath(url), 'utf8');
    if (url.endsWith('/b8-restore.ts')) source = readFileSync(`${directory}/b8-restore.${mode}.ts`, 'utf8');
    if (url.endsWith('/serialization.ts')) source = readFileSync(`${directory}/serialization.${mode === 'current' ? 'current' : 'baseline'}.ts`, 'utf8');
    return { format: 'module', source: stripTypeScriptTypes(source, { mode: 'strip' }), shortCircuit: true };
  },
});

const { createMatch, startMatchCombat } = await import(`${repository}/src/simulation/match.ts`);
const { restoreMatch } = await import(`${repository}/src/simulation/serialization.ts`);
const sourceState = startMatchCombat(createMatch(42)).state;
const saved = JSON.stringify(sourceState);
const restoredString = restoreMatch(saved);
const restoredObject = restoreMatch(JSON.parse(saved));
console.log(JSON.stringify({ mode, check: 'plain-json-controls', stringMatches: JSON.stringify(restoredString) === saved, objectMatches: JSON.stringify(restoredObject) === saved }));

const raw = JSON.parse(saved);
const growth = raw.persistentGrowth;
let reads = 0;
Object.defineProperty(raw, 'persistentGrowth', {
  enumerable: true,
  configurable: true,
  get() {
    // First three reads are the unchanged canonical/shape checks. The fourth
    // is b8-restore.ts current projection comparison after its initial fold.
    if (++reads === 4) raw.resourceProvenance.entries[0].source.extra = 1;
    return growth;
  },
});
try {
  const restored = restoreMatch(raw);
  console.log(JSON.stringify({ mode, check: 'accessor-poc', outcome: 'accepted', reads, inputExtra: raw.resourceProvenance.entries[0].source.extra, returnedExtra: restored.resourceProvenance.entries[0].source.extra }));
  try {
    restoreMatch(JSON.stringify(restored));
    console.log(JSON.stringify({ mode, check: 'returned-state-json-restore', outcome: 'accepted' }));
  } catch (error) {
    console.log(JSON.stringify({ mode, check: 'returned-state-json-restore', outcome: 'rejected', message: error.message }));
  }
} catch (error) {
  console.log(JSON.stringify({ mode, check: 'accessor-poc', outcome: 'rejected', reads, inputExtra: raw.resourceProvenance.entries[0].source.extra, message: error.message }));
}
