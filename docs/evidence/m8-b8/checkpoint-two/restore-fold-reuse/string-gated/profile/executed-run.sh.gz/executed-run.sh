#!/bin/bash
set -euo pipefail
export PATH=/tmp/b7-npm-cache/_npx/d18f28baf1132559/node_modules/node/bin:$PATH
export B8_DIAG_OUTPUT="${1:?Supply a NEW absolute /tmp output directory}"
case "$B8_DIAG_OUTPUT" in /tmp/*) ;; *) echo 'Output must be under /tmp' >&2; exit 2 ;; esac
if test -e "$B8_DIAG_OUTPUT"; then echo 'Will not overwrite existing evidence directory' >&2; exit 2; fi
mkdir -p "$B8_DIAG_OUTPUT"
cd /workspace/scratch/2d61d723fa5a/cat-b8-phase2
TOOLS=/tmp/b8-sniper-replay-diagnosis
{
 date -u --iso-8601=seconds
 printf 'Command: B8_DIAG_OUTPUT=%q node %q\n' "$B8_DIAG_OUTPUT" "$B8_DIAG_OUTPUT/profile.cjs"
 command -v node; node --version; npm --version
 git rev-parse HEAD HEAD:src
 git status --short
 git diff -- src
 find src -type f -print0 | sort -z | xargs -0 sha256sum
 sha256sum tests/m5-replay.test.ts scripts/generate-m5-route.cjs scripts/m4-evidence.cjs tests/fixtures/m5/assert-equal.cjs
} > "$B8_DIAG_OUTPUT/source-and-environment-before.txt"
node "$TOOLS/build-repeat-profile.cjs" > "$B8_DIAG_OUTPUT/build.log" 2>&1
set +e
node "$B8_DIAG_OUTPUT/profile.cjs" > "$B8_DIAG_OUTPUT/profile.log" 2>&1
STATUS=$?
set -e
echo "$STATUS" > "$B8_DIAG_OUTPUT/profile.exit"
if test "$STATUS" -eq 0; then node "$TOOLS/summarize.cjs" "$B8_DIAG_OUTPUT" > "$B8_DIAG_OUTPUT/summary.stdout"; fi
{ date -u --iso-8601=seconds; git rev-parse HEAD HEAD:src; git status --short; find src -type f -print0 | sort -z | xargs -0 sha256sum; } > "$B8_DIAG_OUTPUT/source-and-environment-after.txt"
exit "$STATUS"
