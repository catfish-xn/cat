# 保守最终入口：固定4d9e5e0同负载profile

## 对此前证据的更正

/tmp/b8-sniper-replay-after及仓库已封存的after包是未区分输入入口的初版。该版对带副作用的accessor对象存在拒绝回归，不能作为安全修复接受。旧原始文件、日志、profile和MANIFEST保持原字节；本包另存，不覆盖或将旧包重新命名成最终版。

最终代码仅在restoreMatch从string本地JSON.parse所得输入、且所需prefix等于完整entries长度时复用本次已验证current。所有object输入（包括serialize内部restore）和短历史prefix保留原双fold。没有额外缓存或改克隆。

## 固定来源

- HEAD 4d9e5e00269c0ae6d916b58ac92373de2c00b513，src tree 16568c527580d74caca79e988bb5e8a1d43a290b。
- 运行前后git status仅原有未跟踪node_modules；169个src逐文件SHA256完全相同，见source-comparison.json。
- 原基线为CI200 c854本地等价d2011ae的src 5f9b62228b236074efd78b50a571cc26d23858e5，旧profile在f26826a相同src上运行。
- 最终与baseline生产源差异仅b8-restore.ts、serialization.ts；精确SHA256及整体清单指纹在source-comparison.json。
- 显式Node v22.23.3，/tmp/b7-npm-cache/_npx/d18f28baf1132559/node_modules/node/bin/node。CPU自报AMD EPYC 9V74 80-Core Processor，os.cpus().length=9。

## 同负载结论

使用原完整sniper seed42路线；182 commands /11930 ticks、12112次onStep、33场战斗。每次before完整状态、replay完整state/events、restored完整状态的比较，以及4非法插入命令、原引用不变、无events、JSON不变断言全部执行并通过。原测试无serializeMatch调用。未修改timeout/worker/skip，未缩小路线或使用rawfixture。

基线 → 最终保守版：
- 全段143476.266245 →139333.915966ms，减少4142.350279ms（2.88713%）。
- restoreMatch保持12112次，88654.915715 →84729.438527ms。
- foldResourceProvenance：24081 →12151次，9491.239959 →5085.751043ms。
- validateB8Resources保持12112次，14399.671505 →9985.618735ms。
- validateResourceReceipts：36193 →24263次。精确减少11930次fold及嵌套receipts，等于所有running string恢复数；39次finished短prefix的第二fold保留。
- validateB8Loot保持12112次，4986.582176 →5026.706633ms；restoreCombatInput保持11969次，3048.655004 →3069.760940ms。
- compare-results.cjs通过：除预期fold/receipt减少外所有插桩函数/分段调用数完全一致，commands/ticks与最终JSON字节SHA256一致。
- 最终SHA256：d3a1a077f60bcd6201bcd166cb3447e546384deb39e09c1bdc0af672018617a8。

每次运行均逐步断言replay的完整state/events等于同一未修改公共路线的原结果；没有额外保存跨运行的每tick独立哈希清单，因此不宣称做了不存在的离线全流hash对照。这里的最终hash是实际JSON完整字节hash。

## 额外入口计数控制

主profile完成后才独立执行controls/，不计入或干扰主profile。使用公开createMatch/start/step，真实首战164ticks，六个控制全部通过：
1. running string恢复一次：1个restore、1个fold。
2. running object恢复一次：1个restore、2个fold，输入未变、返回独立。
3. 同running object恢复两次：2个restore、4个fold，两份返回state/basis独立。
4. serialize running object：1个serialize、内部1个restore、2个fold。
5. finished短prefix string：1个restore、2个fold。
6. finished短prefix object：1个restore、2个fold。

这些毫秒级控制用于入口/调用数验证，不是warmup基准；accessor负控的正式5项回归与三模式拒绝差异由父任务另行保存，本控制没有重复冒认那些测试。

## 实际命令与文件

/tmp/b8-sniper-replay-diagnosis/run-repeat.sh /tmp/b8-sniper-replay-string-gated
PATH=/tmp/b7-npm-cache/_npx/d18f28baf1132559/node_modules/node/bin:$PATH node /tmp/b8-sniper-replay-diagnosis/compare-results.cjs /tmp/b8-sniper-replay-string-gated > /tmp/b8-sniper-replay-string-gated/comparison.json

入口计数实际命令见controls/commands.sh；主profile与controls退出码均0。所有脚本、副本、bundle/sourcemap、raw CPU profile、分轮/分段计时、比较结果、源清单及日志均保留。诊断代理全程只写/tmp，没有修改仓库。

同源旧baseline与unsafe after没有重跑。此为最终源码变化需要的一次同负载对照。它证实保守string分支仍移除确定的重复工作；本次约4.142秒收益包含运行噪声，不保证CI同幅收益。profile小于180秒不等于原Vitest门禁或CI通过，不能覆盖CI200原183.481秒timeout事实；正式验证仍由父任务按固定SHA推进。
