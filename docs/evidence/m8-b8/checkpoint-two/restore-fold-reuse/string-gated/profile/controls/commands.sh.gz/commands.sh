#!/bin/bash
# Commands executed after the full final profile completed, preserving its timing.
export PATH=/tmp/b7-npm-cache/_npx/d18f28baf1132559/node_modules/node/bin:$PATH
export B8_DIAG_OUTPUT=/tmp/b8-sniper-replay-string-gated/controls
node /tmp/b8-sniper-replay-string-gated/controls/build.cjs > /tmp/b8-sniper-replay-string-gated/controls/build.log 2>&1
node /tmp/b8-sniper-replay-string-gated/controls/profile.cjs > /tmp/b8-sniper-replay-string-gated/controls/run.log 2>&1
STATUS=$?
echo $STATUS > /tmp/b8-sniper-replay-string-gated/controls/run.exit
exit $STATUS
