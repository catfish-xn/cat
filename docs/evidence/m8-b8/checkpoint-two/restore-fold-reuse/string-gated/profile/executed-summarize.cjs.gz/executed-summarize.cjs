const fs=require('node:fs');const out=process.argv[2]||'/tmp/b8-sniper-replay-diagnosis';
const r=JSON.parse(fs.readFileSync(out+'/segmented-results.json','utf8'));
const p=JSON.parse(fs.readFileSync(out+'/replay.cpuprofile','utf8'));
const nodes=new Map(p.nodes.map(n=>[n.id,n])),parents=new Map();for(const n of p.nodes)for(const child of n.children||[])parents.set(child,n.id);
const self={},inc={},families={},ancestors={};
for(let i=0;i<p.samples.length;i++){const id=p.samples[i],ms=p.timeDeltas[i]/1000,n=nodes.get(id);const name=n.callFrame.functionName||'(anonymous)';const key=name+' @'+n.callFrame.url+':'+(n.callFrame.lineNumber+1);self[key]=(self[key]||0)+ms;
const chain=[];let node=id;const visited=new Set();while(nodes.has(node)){const a=nodes.get(node),name=a.callFrame.functionName||'(anonymous)';chain.push(name);if(!visited.has(name)){inc[name]=(inc[name]||0)+ms;visited.add(name);}node=parents.get(node);}
if(chain.includes('canonicalContent')){let first=chain.findIndex(x=>x==='canonicalContent');let rest=chain.slice(first+1).filter(x=>x!=='canonicalContent'&&x!=='(anonymous)'&&x!=='equal'&&x!=='keys');const k=rest[0]||'ROOT';ancestors[k]=(ancestors[k]||0)+ms;}
}
const sort=x=>Object.entries(x).sort((a,b)=>b[1]-a[1]);
const result={elapsedMs:r.elapsedMs,commands:r.commands,ticks:r.ticks,passed:r.passed,phaseTimes:Object.fromEntries(Object.entries(r.totals).filter(([name])=>name.startsWith('phase:'))),functionTimes:r.totals,topSelfSamplesMs:sort(self).slice(0,30),topInclusiveSamplesMs:sort(inc).slice(0,30),canonicalAncestorSamplesMs:sort(ancestors)};
fs.writeFileSync(out+'/summary.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
