const assert=require('node:assert/strict'),fs=require('node:fs');
const before=JSON.parse(fs.readFileSync('/tmp/b8-sniper-replay-diagnosis/segmented-results.json','utf8'));
const after=JSON.parse(fs.readFileSync(process.argv[2]+'/segmented-results.json','utf8'));
for(const key of ['passed','commands','ticks','serializedFinalSha256'])assert.equal(after[key],before[key],key);
for(const [key,value] of Object.entries(before.totals)){
 if(key==='foldResourceProvenance'||key==='validateResourceReceipts')continue;
 assert.equal(after.totals[key]?.count,value.count,'count '+key);
}
assert.equal(after.totals.foldResourceProvenance.count,before.totals.foldResourceProvenance.count-before.ticks,'expected exact running-fold removal');
assert.equal(after.totals.validateResourceReceipts.count,before.totals.validateResourceReceipts.count-before.ticks,'expected exact nested-receipt removal');
const keys=['restoreMatch','foldResourceProvenance','validateB8Resources','validateB8Loot','restoreCombatInput'];
console.log(JSON.stringify({sameWorkloadAndFinalBytes:true,oldElapsedMs:before.elapsedMs,newElapsedMs:after.elapsedMs,elapsedDeltaMs:after.elapsedMs-before.elapsedMs,functions:Object.fromEntries(keys.map(key=>[key,{before:before.totals[key],after:after.totals[key]}]))},null,2));
