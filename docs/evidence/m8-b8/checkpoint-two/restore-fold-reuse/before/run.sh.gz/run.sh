#!/bin/bash
set -o pipefail
export PATH=/tmp/b7-npm-cache/_npx/d18f28baf1132559/node_modules/node/bin:$PATH
cd /workspace/scratch/2d61d723fa5a/cat-b8-phase2
OUT=/tmp/b8-sniper-replay-diagnosis
{
 date -u --iso-8601=seconds
 command -v node; node --version; npm --version
 git rev-parse HEAD HEAD:src d2011ae3fff2744cb56a63a8c5c7176eb4a7f7d0:src
 git status --short
 git diff d2011ae3fff2744cb56a63a8c5c7176eb4a7f7d0 HEAD -- src tests/m5-replay.test.ts scripts/generate-m5-route.cjs scripts/m4-evidence.cjs tests/fixtures/m5/assert-equal.cjs
 find src -type f -print0 | sort -z | xargs -0 sha256sum
 sha256sum tests/m5-replay.test.ts scripts/generate-m5-route.cjs scripts/m4-evidence.cjs tests/fixtures/m5/assert-equal.cjs
} > "$OUT/source-and-environment-before.txt"
node "$OUT/build-profile.cjs" > "$OUT/build.log" 2>&1 || exit $?
node "$OUT/profile.cjs" > "$OUT/profile.log" 2>&1
STATUS=$?
echo "$STATUS" > "$OUT/profile.exit"
date -u --iso-8601=seconds > "$OUT/completed-at.txt"
exit "$STATUS"
