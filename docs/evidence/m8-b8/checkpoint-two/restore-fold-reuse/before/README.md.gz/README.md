# CI200 M5 sniper replay 只读诊断（原来源链，未修复）

## 结论

CI200 sniper 执行了全部 182 commands / 11930 ticks，并输出 passed:true，但真实耗时 183.480614452 秒越过原 180 秒门禁；Vitest 正确记为 timeout。该 passed 日志不是门禁通过。当前瓶颈以 restore 为主，而不是准备公共路线；存在已测量的 B8 同一次恢复重复完整来源验证。不能仅用当前本地更快来归因 CI 环境，也没有 B8 前同内容同路线 profile 可量化完整回退比例。

Node22 独立原负载诊断总 143476.266245 ms，全部原逐 command/tick 正负断言通过。显式恢复 88703.867900 ms（61.8248%），公共原路线命令 8974.910452 ms，独立 replay 7934.851352 ms，三次 deepEqual 合 22102.171648 ms，三次 JSON.stringify 合 12927.308161 ms，拒绝命令 66.212309 ms，其余约2766.944 ms 是路线 ledger/hash、回调/记录等。此为插桩单路线诊断，不替代原 Vitest 或全量门禁，不与 CI 时间直接作机器归一化。

测试中没有调用 serializeMatch，内部 restore 成本为 0；restoreMatch 总 12112 次。每步仍比较 before、second 完整结果、restored 完整 state；4 个非法命令均保留原引用、不含 events、原状态 JSON 不变。

## B8 热点和最小修复边界

- validateB8Resources: 12112 次 / 14399.671505 ms；foldResourceProvenance: 24081 次 / 9491.239959 ms，其中递归 receipts 验证包含在内。
- 12112 次 restore 包括 143 次无 combat、11969 次有 combat；39 次 finished suffix；11930 次 running。running 时 prefixLength===entries.length，在 current 完整验证之后再用相同 value、相同 context、显式相同长度重新 fold 一次。
- validateResourceReceipts: 36193 次 / 3432.943660 ms；一次 loot 验证 + 每次 fold 都验 receipts。这是事实次数，不能把它们当独立时间后重复相加。
- 最小候选为同次 validateB8Resources 局部：仅 prefixLength===entries.length 时，第二 fold 的 resources 使用已完整验证、冻结的 current；短 prefix 的原第二 fold 保留。所有 guard、loot 验证、source fold 当前资源比较、basis 独立验证、running input 比较、finished replay 均保留。
- current 只作为 restoreCombatInput 只读 authority，不逃逸到返回 Match，不改任何克隆，且不跨恢复/跨输入缓存。restoreCombatInput 仍返回其独立冻结 basis。无 raw fixture 例外、timeout、worker、skip 或负载变更。
- 预计删除11930次 fold，改后应为12151次；嵌套 receipts 应从36193到24263。原 fold 总时间的一半约4.746s，约全测3.31%，只是量级估计，未分开计量两次 fold，不能声称精确收益或已足以稳定通过180秒。
- CPU 1ms 采样 canonicalContent 累计47598.637ms（33.17%总），其中直接 restoreMatch 祖先40036.109ms；它明显比重复 fold 更大。原 canonical/完整JSON拒绝保持；不提出未经授权的更大验证重构。
- structuredClone 总308753次/10701.068610ms，仅 explicitRestore 内12086次/747.199404ms。准备路线克隆5227.698884ms，replay克隆4725.957451ms。本次不支持以恢复克隆为主因而改克隆。

## 来源与工具链

- CI200 https://github.com/catfish-xn/cat/actions/runs/38031091668/job/114152012079
- CI远端 c8543e192589cdc52b2a2119a45d5bfd613d8bf7；父任务给出的本地等价 d2011ae3fff2744cb56a63a8c5c7176eb4a7f7d0。
- 本次受测HEAD f26826a50c7c9fca2e74f4158de9d31c26e1fbfa；生产src tree 5f9b62228b236074efd78b50a571cc26d23858e5；d2011ae:src 相同。d2011ae与当前的src、m5-replay、generate-m5-route、m4-evidence、assert-equal差异为空；前后git status仅原有未跟踪node_modules。
- 显式 Node v22.23.3 路径 /tmp/b7-npm-cache/_npx/d18f28baf1132559/node_modules/node/bin/node，npm11.9.0。CI同Node22.23.3、npm10.9.9。
- 本机CPU自报 AMD EPYC 9V74 80-Core Processor，os.cpus().length=9。未改变worker/并发或全局环境配置。
- 最终JSON SHA256 d3a1a077f60bcd6201bcd166cb3447e546384deb39e09c1bdc0af672018617a8；victory，round38，HP83，gold245，33战斗。

## 实际执行和交付

run.sh 原样保存本次实际命令。仅在 /tmp 创建脚本及esbuild bundle，没有改仓库文件。esbuild 的 onLoad 在内存内给12个函数加 try/finally 计时；global structuredClone 只转发并计时。Inspector 1ms采样。原完整 run(api,{build:'sniper',seed:42,onStep}) 使用原路线、ledger与原逐步断言，没有少tick、预生成输入或缓存恢复。公共API包装器只计时。

初次 bundle 因 lazy Vite 的可选 lightningcss 无法解析失败，原失败日志保存在 build-first-attempt.log；给第三方 package 标准 external 后正常 bundle，运行时从未调用 Vite generateRoute 路径。没有安装软件或改依赖。原始profile、bundle及sourcemap、分轮计时、日志、源文件副本和前后sha256均保留。

未执行改后测量。为父任务提供无覆盖独立对照：

/tmp/b8-sniper-replay-diagnosis/run-repeat.sh /tmp/b8-sniper-replay-after
PATH=/tmp/b7-npm-cache/_npx/d18f28baf1132559/node_modules/node/bin:$PATH node /tmp/b8-sniper-replay-diagnosis/compare-results.cjs /tmp/b8-sniper-replay-after

重复脚本仅把输出目录参数化，仍采用同样完整场景和计时方法；不会覆盖旧目录。compare-results 会要求所有原计时函数调用次数（除预期删除的 fold/receipt）一致、182 commands/11930 ticks/最终字节hash相同，并要求仅删除11930次fold和嵌套receipts。计时与调用次数改善仍需结合原Vitest门禁及后续固定新SHA全量/CI证据，不能把单个<180秒当修复闭环。
