# TG timeout diagnosis: original scenario preserved, no accepted fix

## Status and authority boundary
- Current repository retains all original 37 seed routes, 43 definitions, original opening positions, every restore/corruption assertion, the single case, default 5000 ms timeout, and workers. A later parent clarification asks whether 43-definition coverage permits removing two duplicate-definition routes; this remains read-only evaluation, not an adopted patch.
- Both owned repository files have been restored byte-for-byte to their original versions. No commit was made. `git diff -- tests/m8-b5-temporary.test.ts tests/fixtures/b8-public-equipment.ts` is empty.
- The discarded Lux-front / 35-route patch is retained in `rejected-scope-frontline-and-35.diff` and `rejected-scope-*.ts`. Its successful runs are exploratory evidence only and DO NOT establish a fix under the latest authorization. `change.diff` and `source-after.sha256` also describe that discarded candidate, not current source.
- No production files, timeout/worker settings, or other tests were modified. No full-suite rerun was made by this worker.

## Source and toolchain
- HEAD at diagnosis: 25a7fe3d5c099ae582a4e0a48717f7e323636dae (failure-budget documentation only).
- Source baseline: d2011ae3fff2744cb56a63a8c5c7176eb4a7f7d0.
- Working directory: /workspace/scratch/2d61d723fa5a/cat-b8-phase2.
- Timing evidence below uses Node v22.23.3 / npm 11.9.0:
  export PATH=/tmp/b7-npm-cache/_npx/d18f28baf1132559/node_modules/node/bin:$PATH
- Original SHA256:
  ae2a38e30f25c8d8d9a664ca99bc5371463d57eaf84ead8a3f3dfd10c784103b  tests/m8-b5-temporary.test.ts
  19086bab7b487c06dd7ef4a643cc81e4c3f573016d2ece158f656571f77e4836  tests/fixtures/b8-public-equipment.ts
- `source-before.sha256` and `restored-original.sha256` are identical.
- The first exploration inadvertently used Node v24.19.0. Those logs/states remain under `node24-first-exploration/` and are NOT official performance/acceptance evidence.

## Original-case segmented measurement
Command (after the Node22 PATH export):
  node /tmp/b8-timeout-fix/tg/build-segmented.cjs
  node --cpu-prof --cpu-prof-dir=/tmp/b8-timeout-fix/tg --cpu-prof-name=original-segmented.cpuprofile /tmp/b8-timeout-fix/tg/profile-original-segmented.cjs
Source harness: `profile-original-segmented.ts`; compiled bundle and source map retained.
Outputs: `original-segmented.log`, `.json`, `.exit`, `.cpuprofile`.
The harness retains original seed order/37 public routes, original opening positions, exact pair bindings, both serialize/restore points, three combat ticks, step equivalence, and original shield corruption rejection. This is diagnostic instrumentation using Node strict assertions, not a substitute for the original Vitest gate.

Total measured wall time: 3194.630 ms. One diagnostic sample, not proof that the recorded full-run timeout is fixed.
- Pure roll planning: 6.977 ms / 237 candidates
- Public opening preparation: 2404.453 ms / 37 routes
- Combine and advance to 2-5: 71.442 ms / 37
- Buy XP, deploy, equip: 4.203 ms / 37
- Total preparation: 2480.098 ms (77.63% of wall time)
- TG combat start: 25.019 ms / 37
- Start serialize (includes internal restore validation): 168.669 ms / 37
- Start explicit restore: 124.338 ms / 37
- Start deep equality: 13.722 ms / 37
- Three combat ticks: 47.677 ms / 111
- After-ticks serialize (includes internal restore validation): 155.985 ms / 37
- After-ticks explicit restore: 126.290 ms / 37
- Next step on restored/original state: 11.837 / 9.428 ms, 37 each
- Next-step deep equality: 13.011 ms / 37
- Shield serialize: 4.312 ms / 1
- Shield rejection restore: 2.977 ms / 1
- All serialize calls, including their internal validation: 328.967 ms
- All explicit restore/rejection calls: 253.605 ms
- All deep comparisons: 26.734 ms
- Actual restore work is not the dominant cost in this sample. This does not prove that restore has no historical regression; no comparable pre-change restoration benchmark was established here.

Coverage: 43 distinct definitions, 37 original match seeds, shield corruption case at seed-index123 / matchSeed78084107. All retained in `original-segmented.json`.
CPU sample's largest self-time node: structuredClone ~884 ms, chiefly under normal advanceS13Tick construction. advanceS13Tick itself ~381 ms plus its map callback ~270 ms. This is a diagnostic production hotspot only; no production optimization was made or authorized here.

## Reuse feasibility under the latest boundary
There is no high-value duplicate public preparation among these 37 routes: all match seeds differ and each original route is built once. The existing preparation cache key is [seed, components]; none of these selected seeds is the seed42 path warmed by preceding tests. Identical component choices do not imply identical combat RNG, ticks, death evidence, or historical state. Copying one seed's history to another would be invalid.
Pre-generated raw JSON snapshots can technically be detached and restored independently without caching restore outputs. However, migrating the current 37 public acquisition/equip/start paths outside this case would move preparation coverage that this case presently executes out of its timer. That is not permitted by the latest instruction. Do not implement snapshot migration without an explicit responsibility/acceptance decision.
Only small local work duplication is evident (for example re-serializing the same shield-start state once). That cannot plausibly recover the 413 ms full-run overage with reliable headroom, and no such change was applied.

## Earlier preserved explorations (not the final solution)
- `build-profile.cjs`, `profile.ts`, `profile-{original,lux-front,both-front}.cjs`: pure compile-time fixture-position variants, no synthetic state/provenance.
- Node22 commands: `node profile-original.cjs original`, `node profile-lux-front.cjs lux-front`, `node profile-both-front.cjs both-front`, executed with their absolute /tmp/b8-timeout-fix/tg paths; full output and exit statuses retained.
- `original.states.json`, `lux-front.states.json`, `both-front.states.json` retain all 37 original seeds' full pre-combat/start/three-tick snapshots.
- `compare.cjs`, `compare.log`, `old-new-comparison.json`: all fields compared; candidate HP/economy/RNG and complete combatInputBasis/start Combat/three-tick Combat remained identical. Candidate opening ticks/event counts and loot death tick/eventSeq differed, and that route change is now rejected.
- `isolation.ts/.cjs/.log`: discarded-candidate independent-graph and history-bypass diagnostic; same-seed cache copies had 134 objects each and zero shared objects, and caller mutation did not contaminate the next copy. Not final-scope acceptance.
- Original baseline command: `npm test -- tests/m8-b5-temporary.test.ts`; 25/25 passed in isolation, total 4.45 s. The recorded all-suite 5413 ms first failure remains authoritative for the original gate.
- Discarded candidate command: `npm test -- tests/m8-b5-temporary.test.ts --reporter=verbose`; 25/25, target case 2917 ms.
- Discarded candidate five-file command: `npm test -- tests/m8-b5-instances.test.ts tests/m8-b5-grant-upgrade.test.ts tests/m8-b5-queries.test.ts tests/m8-b5-equipment-history.test.ts tests/m8-b5-temporary.test.ts --reporter=verbose`; 70/70, target case 2974 ms.
- Discarded candidate combined command: add `tests/m8-b8-equipment-fixture.test.ts tests/m8-b4-integration.test.ts tests/m8-b4-r3b-lifecycle.test.ts` to that five-file command; 94/94. It had already finished when the scope-retraction request arrived; output retained.
- Discarded candidate `npm run typecheck`: passed. This is not claimed as validation of a current fix.

All source scripts, first explorations, raw outputs, exit statuses and rejected patches are retained. No further route exploration is planned.

## Later read-only clarification: stable seed planning alone
The parent clarified that the user did not explicitly require 37 as a fixed route count: the primary coverage contract is 43 definitions plus per-case restore and all negative assertions. `coverage-map.ts/.cjs/.json/.log/.exit` records a fresh pure-planner analysis with actual generateRoundRolls on Node22. No repository patch or benchmark was added for this question.
- Stable greedy priority (two unseen children, then ascending seed) retains exactly 35 of the original 37 seeds, changes ordering, and preserves all 43 child definitions.
- Removed seed-index3, matchSeed3668339987: deathblade + bow. Neither its old state nor after-start path has a temporary shield rejection branch.
- Removed seed-index4, matchSeed2027808452: deathblade + gloves. Neither has a temporary shield rejection branch.
- Retained deathblade: seed-index2, matchSeed1013904226, deathblade + cloak.
- Retained bow: index27 hand-of-justice, index83 sunfire-cape, index123 crownguard.
- Retained gloves: index12 steadfast-heart, index28 warmog, index36 jeweled-gauntlet, index76 archangel, index108 gargoyle, index236 deathcap.
- Unique temporary shield corruption branch remains exactly index123, matchSeed78084107, crownguard + bow.
- All retained definitions execute the same level6 public equip, start serialize/restore, three ticks, post-tick serialize/restore, and next-step equality checks. All separate fixed-number cases and mutation-matrix assertions are unchanged by planning alone.
- This preserves definition-level coverage but does not preserve the two removed pair combinations. There is no exact retained deathblade+bow or deathblade+gloves scenario; combined stat/crit/attack-speed inputs differ from retained deathblade+cloak. Do not describe the pair matrix as identical.
- The theoretical route reduction is 5.4%; a naive equal-cost projection of the first full-run 5413 ms failure is ~5120 ms. It is not sufficient evidence of repair or reliable 5-second headroom.
