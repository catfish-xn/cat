var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key2 of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key2) && key2 !== except)
        __defProp(to, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// ../../../../tmp/b8-timeout-fix/tg/coverage-map.ts
var import_strict = __toESM(require("node:assert/strict"));
var import_node_fs = require("node:fs");

// src/simulation/rng.ts
function nextRandom(state) {
  const word = Math.imul(state, 1664525) + 1013904223 >>> 0;
  return { word, state: word };
}

// src/simulation/m8/stats.ts
function integer(value, minimum = 0) {
  if (!Number.isSafeInteger(value) || value < minimum) throw new RangeError("Expected safe integer");
  return BigInt(value);
}

// src/simulation/m8/identity.ts
var compareCodePoints = (a, b) => a < b ? -1 : a > b ? 1 : 0;

// src/simulation/m8/equipment.ts
var key = (parent, round) => JSON.stringify([parent, round]);
function initializeStreams(seed) {
  integer(seed);
  if (seed > 4294967295) throw new RangeError("Invalid seed");
  return { equipment: { state: (seed ^ 608135816) >>> 0, draws: 0 }, encounter: { state: (seed ^ 3084996962) >>> 0, draws: 0 }, loot: { state: (seed ^ 3735928559) >>> 0, draws: 0 } };
}
function uniformIndex(size, draw) {
  integer(size, 1);
  if (size > 4294967296) throw new RangeError("Uniform pool too large");
  const limit = Math.floor(4294967296 / size) * size;
  for (; ; ) {
    const word = draw();
    integer(word);
    if (word > 4294967295) throw new RangeError("Invalid random word");
    if (word < limit) return word % size;
  }
}
function validatePool(pool) {
  const all = [...pool.completed, ...pool.components];
  if (pool.version !== "tg-01-v1" || pool.completed.length !== 35 || pool.components.length !== 8 || all.some((e) => !e.apiName || !e.definitionId) || new Set(all.map((e) => e.apiName)).size !== 43 || new Set(all.map((e) => e.definitionId)).size !== 43) throw new RangeError("Invalid approved TG pool");
}
function selectTemporaryPair(playerLevel, pool, draw) {
  integer(playerLevel, 1);
  validatePool(pool);
  const completed = [...pool.completed].sort((a, b) => compareCodePoints(a.apiName, b.apiName)), components = [...pool.components].sort((a, b) => compareCodePoints(a.apiName, b.apiName));
  const first = completed[uniformIndex(completed.length, draw)], secondPool = playerLevel <= 6 ? components : completed.filter((e) => e.definitionId !== first.definitionId);
  return [first.definitionId, secondPool[uniformIndex(secondPool.length, draw)].definitionId];
}
function generateRoundRolls(state, requests, pool) {
  validatePool(pool);
  validateEquipmentState(state, pool);
  const seen = /* @__PURE__ */ new Set();
  for (const r of requests) {
    integer(r.playerLevel, 1);
    if (!r.parentItemInstanceId || !r.roundId || seen.has(key(r.parentItemInstanceId, r.roundId))) throw new RangeError("Invalid round roll request");
    seen.add(key(r.parentItemInstanceId, r.roundId));
  }
  const pending = requests.filter((r) => !state.rolls.some((old) => key(old.parentItemInstanceId, old.roundId) === key(r.parentItemInstanceId, r.roundId))).sort((a, b) => compareCodePoints(a.parentItemInstanceId, b.parentItemInstanceId) || compareCodePoints(a.roundId, b.roundId));
  if (!pending.length) return state;
  if (new Set(pending.map((r) => r.roundId)).size > 1) throw new RangeError("One round per equipment generation transaction");
  let rng = { ...state.equipment };
  const draw = () => {
    const next = nextRandom(rng.state);
    rng = { state: next.state, draws: rng.draws + 1 };
    integer(rng.draws);
    return next.word;
  };
  const additions = pending.map((r) => {
    const rngDrawStart = rng.draws, children = selectTemporaryPair(r.playerLevel, pool, draw);
    return { parentItemInstanceId: r.parentItemInstanceId, roundId: r.roundId, playerLevelSnapshot: r.playerLevel, poolVersion: pool.version, children, rngDrawStart, rngDrawEnd: rng.draws };
  });
  return { equipment: rng, rolls: [...state.rolls, ...additions] };
}
function validateEquipmentState(state, pool, initialStream) {
  validatePool(pool);
  integer(state.equipment.state);
  integer(state.equipment.draws);
  if (state.equipment.state > 4294967295) throw new RangeError("Invalid equipment stream");
  const seen = /* @__PURE__ */ new Set();
  let end = 0;
  for (const r of state.rolls) {
    const id = key(r.parentItemInstanceId, r.roundId);
    integer(r.playerLevelSnapshot, 1);
    integer(r.rngDrawStart);
    integer(r.rngDrawEnd);
    const second = r.playerLevelSnapshot <= 6 ? pool.components : pool.completed;
    if (seen.has(id) || !r.parentItemInstanceId || !r.roundId || r.poolVersion !== pool.version || r.children.length !== 2 || !pool.completed.some((e) => e.definitionId === r.children[0]) || !second.some((e) => e.definitionId === r.children[1]) || r.children[0] === r.children[1] || r.rngDrawStart !== end || r.rngDrawEnd < r.rngDrawStart + 2 || r.rngDrawEnd > state.equipment.draws) throw new RangeError("Invalid equipment roll ledger");
    seen.add(id);
    end = r.rngDrawEnd;
  }
  if (end !== state.equipment.draws) throw new RangeError("Unreceipted equipment draws");
  if (initialStream) {
    integer(initialStream.state);
    if (initialStream.state > 4294967295 || initialStream.draws !== 0) throw new RangeError("Invalid initial equipment stream");
    let cursor = { ...initialStream };
    const draw = () => {
      const next = nextRandom(cursor.state);
      cursor = { state: next.state, draws: cursor.draws + 1 };
      return next.word;
    };
    const completed = [...pool.completed].sort((a, b) => compareCodePoints(a.apiName, b.apiName)), components = [...pool.components].sort((a, b) => compareCodePoints(a.apiName, b.apiName));
    for (const r of state.rolls) {
      const first = completed[uniformIndex(35, draw)], secondPool = r.playerLevelSnapshot <= 6 ? components : completed.filter((e) => e.definitionId !== first.definitionId);
      const second = secondPool[uniformIndex(secondPool.length, draw)];
      if (r.children[0] !== first.definitionId || r.children[1] !== second.definitionId || r.rngDrawEnd !== cursor.draws) throw new RangeError("Equipment roll does not match trusted initial stream");
    }
    if (cursor.state !== state.equipment.state || cursor.draws !== state.equipment.draws) throw new RangeError("Equipment stream mismatch");
  }
}
function createEquipmentPool(entries) {
  const eligible = entries.filter((e) => !e.effects.some((effect) => effect.kind === "temporary-equipment"));
  const project = (e) => ({ apiName: e.apiName, definitionId: e.definitionId });
  const pool = { version: "tg-01-v1", completed: eligible.filter((e) => e.kind === "completed").map(project), components: eligible.filter((e) => e.kind === "component").map(project) };
  validatePool(pool);
  return pool;
}

// src/simulation/content/freeze.ts
function freezeContent(value) {
  if (value !== null && typeof value === "object") {
    for (const child of Object.values(value)) freezeContent(child);
    Object.freeze(value);
  }
  return value;
}

// src/simulation/content/item-programs.ts
var always = { kind: "always" };
var refresh = { kind: "refresh-same-instance", magnitude: "replace", phase: "preserve" };
var combat = { kind: "combat" };
var duration = (ticks) => ({ kind: "ticks", ticks });
var hp = (op, thresholdBps) => ({ kind: "hp-ratio", subject: "holder", op, thresholdBps });
var rows = (rows2) => ({ kind: "starting-rows", rows: rows2 });
var filter = (deliveries = "all") => ({ deliveries, damageTypes: ["physical", "magic"], redirected: "exclude" });
var amount = (patch = {}) => ({ flat: 0, attackDamageBps: 0, abilityPowerBps: 0, maxHpBps: 0, missingHpBps: 0, actualManaSpentBps: 0, actualDamageBps: 0, shieldAbsorbedBps: 0, hpBasis: "holder", sample: "application", cap: null, ...patch });
var modifier = (stat2, n, unit = "flat", condition = always, damageFilter = null) => ({ stat: stat2, unit, value: { kind: "constant", amount: n }, condition, damageFilter });
var selector = (patch = {}) => ({ primary: "normal", candidates: "board", relation: "self", anchor: "holder", radius: null, maxTargets: 1, excludeSelf: false, excludePrimary: false, distinct: true, order: "distance-id", sample: "action-completion", ...patch });
var enemies = (patch = {}) => selector({ relation: "enemy", excludeSelf: true, ...patch });
var stat = (m, ticks = null, activation = "immediate") => ({ kind: "modify-stat", modifier: m, activation, duration: ticks === null ? combat : duration(ticks), stackPolicy: refresh });
var status = (kind, n, ticks, patch) => ({ kind: "apply-status", status: { kind, magnitudeBps: n, duration: duration(ticks), stackPolicy: ["burn", "wound", "sunder", "shred", "damage-reduction"].includes(kind) ? { kind: "strongest-category", category: kind, retainSuppressed: true } : refresh, polarity: ["burn", "wound", "sunder", "shred", "stun"].includes(kind) ? "harmful" : "beneficial", removable: ["burn", "wound", "sunder", "shred", "stun"].includes(kind), damageFilter: kind === "damage-reduction" ? filter() : null, onEnd: null, ...patch } });
var burn = (ticks) => [status("burn", 100, ticks, { activation: "immediate" }), status("wound", 3300, ticks, { activation: "immediate" })];
var shield = (bps, ticks, endEffects = []) => ({ kind: "grant-shield", amount: amount({ maxHpBps: bps }), durationTicks: ticks, decay: { kind: "none" }, onEnd: endEffects.length ? ["depleted", "expired"] : [], endTiming: "post-damage", endTargeting: { kind: "select", selector: selector() }, endEffects });
var trigger = (patch) => ({ id: "trigger", event: "attack-completed", listener: { subject: "actor", relationToHolder: "self", withinHexes: null }, aggregation: "event", counters: [], gate: { kind: "always" }, condition: always, selector: selector(), internalCooldownTicks: 0, maxPerAction: 1, maxPerCombat: null, stackPolicy: refresh, effects: [], ...patch });
var survival = (thresholdBps, effects, initial = false) => trigger({ id: "survival", event: "post-damage-survival", ...initial ? { initialAlso: true } : {}, listener: { subject: "target", relationToHolder: "self", withinHexes: null }, condition: hp("lte", thresholdBps), maxPerCombat: 1, effects });
var damage = (damageType, patch) => ({ kind: "damage", damageType, delivery: "equipment-proc", critEligibility: "never", amount: amount(patch) });
var mana = (n, reason) => ({ kind: "grant-mana", amount: n, reason, bypassLock: reason === "cast-refund" ? "this-cast-refund" : "none" });
var periodic = (periodTicks, effects, s = selector({ sample: "each-pulse" }), patch = {}) => ({ periodTicks, program: { selector: s, targetSnapshot: "once-per-pulse", effects }, ...patch });
var vamp = (bps, condition = always) => ({ modifier: modifier("omnivamp", bps, "bps", condition), allyBps: 0, allyCondition: always });

// src/simulation/content/items-components.ts
var COMPONENTS_ITEMS = [
  {
    "id": "sword",
    "name": "\u66B4\u98CE\u5927\u5251",
    "kind": "component",
    "apiName": "TFT_Item_BFSword",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "effectDescriptions": [
      "AD: 1000 Bps"
    ],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 1e3
      }
    ]
  },
  {
    "id": "vest",
    "name": "\u9501\u5B50\u7532",
    "kind": "component",
    "apiName": "TFT_Item_ChainVest",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "effectDescriptions": [
      "Armor: 20 resistance-points"
    ],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "armor",
        "amount": 20
      }
    ]
  },
  {
    "id": "belt",
    "name": "\u5DE8\u4EBA\u8170\u5E26",
    "kind": "component",
    "apiName": "TFT_Item_GiantsBelt",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "effectDescriptions": [
      "Health: 150 health-points"
    ],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      }
    ]
  },
  {
    "id": "rod",
    "name": "\u65E0\u7528\u5927\u68D2",
    "kind": "component",
    "apiName": "TFT_Item_NeedlesslyLargeRod",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "effectDescriptions": [
      "AP: 10 ability-power-points"
    ],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 10
      }
    ]
  },
  {
    "id": "cloak",
    "name": "\u8D1F\u6781\u6597\u7BF7",
    "kind": "component",
    "apiName": "TFT_Item_NegatronCloak",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "effectDescriptions": [
      "MagicResist: 20 magic-resist-points"
    ],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "magicResist",
        "amount": 20
      }
    ]
  },
  {
    "id": "bow",
    "name": "\u53CD\u66F2\u4E4B\u5F13",
    "kind": "component",
    "apiName": "TFT_Item_RecurveBow",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "effectDescriptions": [
      "AS: 1000 Bps"
    ],
    "effects": [
      {
        "kind": "attackSpeedBps",
        "bps": 1e3
      }
    ]
  },
  {
    "id": "gloves",
    "name": "\u62F3\u5957",
    "kind": "component",
    "apiName": "TFT_Item_SparringGloves",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387 +20%\u3002"],
    "effects": [],
    combatProgram: { modifiers: [modifier("critChance", 2e3, "bps")] }
  },
  {
    "id": "tear",
    "name": "\u5973\u795E\u4E4B\u6CEA",
    "kind": "component",
    "apiName": "TFT_Item_TearOfTheGoddess",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "effectDescriptions": [
      "Mana: 15 mana-points"
    ],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "initialMana",
        "amount": 15
      }
    ]
  }
];

// src/simulation/content/items-sword.ts
var SWORD_ITEMS = [
  {
    "id": "bloodthirster",
    "name": "\u996E\u8840\u5251",
    "kind": "completed",
    "apiName": "TFT_Item_Bloodthirster",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-04",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "sword",
      "cloak"
    ],
    "effectDescriptions": ["20%\u5168\u80FD\u5438\u8840\uFF1B\u53D7\u4F24\u540E\u5B58\u6D3B\u4E14\u751F\u547D\u226440%\u65F6\u6BCF\u6218\u4E00\u6B21\u83B7\u5F9725%\u6700\u5927\u751F\u547D\u62A4\u76FE\uFF0C\u6301\u7EED5\u79D2\u3002"],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 1500
      },
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 15
      },
      {
        "kind": "statFlat",
        "stat": "magicResist",
        "amount": 20
      }
    ],
    combatProgram: { vamp: [vamp(2e3)], survival: [survival(4e3, [shield(2500, 100)])] }
  },
  {
    "id": "edge-of-night",
    "name": "\u591C\u4E4B\u950B\u5203",
    "kind": "completed",
    "apiName": "TFT_Item_GuardianAngel",
    "unique": true,
    "slotCost": 1,
    "conventionIds": [
      "A-14",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "sword",
      "vest"
    ],
    "effectDescriptions": ["\u53D7\u4F24\u540E\u5B58\u6D3B\u4E14\u751F\u547D\u226460%\u65F6\u6BCF\u6218\u4E00\u6B21\u6E05\u9664\u53EF\u79FB\u9664\u7684\u654C\u65B9\u63A7\u5236\u3001\u6301\u7EED\u4F24\u5BB3\u548C\u51CF\u76CA\uFF1B1\u79D2\u65E0\u6CD5\u9009\u4E2D\u5E76\u9632\u6B62\u4F24\u5BB3\uFF0C\u7ED3\u675F\u540E\u83B7\u5F9715%\u653B\u901F\u3002"],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 1e3
      },
      {
        "kind": "statFlat",
        "stat": "armor",
        "amount": 20
      }
    ],
    combatProgram: { survival: [survival(6e3, [{ kind: "cleanse", remove: "removable-hostile-control-dot-debuff", retarget: true }, status("untargetable", 1e4, 20, { activation: "immediate", onEnd: { reasons: ["expired"], timing: "expiry-before-actions", effects: [stat(modifier("attackSpeed", 1500, "bps"))] } }), status("damage-prevention", 1e4, 20, { activation: "immediate" })])] }
  },
  {
    "id": "infinity-edge",
    "name": "\u65E0\u5C3D\u4E4B\u5203",
    "kind": "completed",
    "apiName": "TFT_Item_InfinityEdge",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-17",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "sword",
      "gloves"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387+35%\uFF1B\u6280\u80FD\u4F24\u5BB3\u53EF\u66B4\u51FB\uFF0C\u91CD\u590D\u6280\u80FD\u66B4\u51FB\u6388\u6743\u6BCF\u6B21\u52A010%\u66B4\u4F24\u3002"],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 3500
      }
    ],
    combatProgram: { modifiers: [modifier("critChance", 3500, "bps")], effects: [{ kind: "authorize-spell-crit", duplicateBonusBps: 1e3 }] }
  },
  {
    "id": "giant-slayer",
    "name": "\u5DE8\u4EBA\u6740\u624B",
    "kind": "completed",
    "apiName": "TFT_Item_MadredsBloodrazor",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01",
      "GS-01"
    ],
    "recipe": [
      "sword",
      "bow"
    ],
    "effectDescriptions": ["\u57FA\u7840\u589E\u4F245%\uFF1B\u6BCF\u5305\u76EE\u6807\u5F53\u524D\u6700\u5927\u751F\u547D\u4E25\u683C\u8D85\u8FC71750\u65F6\u53E6\u52A020%\u3002"],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 2500
      },
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 25
      },
      {
        "kind": "attackSpeedBps",
        "bps": 1e3
      }
    ],
    combatProgram: { modifiers: [modifier("damageAmp", 500, "bps"), modifier("damageAmp", 2e3, "bps", { kind: "target-max-hp", op: "gt", hp: 1750 })] }
  },
  {
    "id": "steraks-gage",
    "name": "\u65AF\u7279\u62C9\u514B\u7684\u6311\u6218\u62A4\u624B",
    "kind": "completed",
    "apiName": "TFT_Item_SteraksGage",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "sword",
      "belt"
    ],
    "effectDescriptions": ["\u5F00\u573A\u6216\u53D7\u4F24\u540E\u5B58\u6D3B\u4E14\u751F\u547D\u226460%\u65F6\u6BCF\u6218\u4E00\u6B21\u589E\u52A025%\u6700\u5927\u751F\u547D\u53CA\u7B49\u91CF\u5F53\u524D\u751F\u547D\u300135%\u653B\u51FB\u529B\uFF0C\u6301\u7EED\u672C\u6218\u3002"],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 1500
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      }
    ],
    combatProgram: { survival: [survival(6e3, [{ kind: "change-max-hp", bonusBps: 2500, currentHp: "add-max-delta", countsAsHeal: false }, stat(modifier("attackDamage", 3500, "bps"))], true)] }
  }
];

// src/simulation/content/items-bow.ts
var BOW_ITEMS = [
  {
    "id": "last-whisper",
    "name": "\u6700\u540E\u7684\u8F7B\u8BED",
    "kind": "completed",
    "apiName": "TFT_Item_LastWhisper",
    "unique": true,
    "slotCost": 1,
    "conventionIds": [
      "A-20",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "bow",
      "gloves"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387+20%\uFF1B\u6B63\u7269\u7406\u4F24\u5BB3\uFF08\u542B\u62A4\u76FE\u4F24\u5BB3\uFF09\u4E4B\u540E\u65BD\u52A030%\u524A\u75323\u79D2\uFF0C\u540C\u7C7B\u53D6\u6700\u5F3A\uFF0C\u5237\u65B0\u4E0D\u53E0\u4E58\u3002"],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 1500
      },
      {
        "kind": "attackSpeedBps",
        "bps": 2e3
      }
    ],
    combatProgram: { modifiers: [modifier("critChance", 2e3, "bps")], triggers: [trigger({ event: "damage-dealt", selector: enemies({ candidates: "event-target" }), effects: [status("sunder", 3e3, 60, { activation: "immediate" })] })] }
  },
  {
    "id": "nashors-tooth",
    "name": "\u7EB3\u4EC0\u4E4B\u7259",
    "kind": "completed",
    "apiName": "TFT_Item_Leviathan",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-21",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "belt",
      "bow"
    ],
    "effectDescriptions": ["\u5B8C\u6210\u65BD\u6CD5\u540E\u4E0B\u4E00tick\u83B7\u5F9760%\u653B\u901F5\u79D2\uFF0C\u540C\u4EF6\u5237\u65B0\u4E0D\u53E0\u52A0\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 10
      },
      {
        "kind": "attackSpeedBps",
        "bps": 1e3
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      }
    ],
    combatProgram: { triggers: [trigger({ event: "cast-completed", effects: [stat(modifier("attackSpeed", 6e3, "bps"), 100, "next-tick")] })] }
  },
  {
    "id": "red-buff",
    "evidenceStatus": "approved-provisional",
    "name": "\u7EA2\u9738\u7B26",
    "kind": "completed",
    "apiName": "TFT_Item_RapidFireCannon",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "B-07",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "bow",
      "bow"
    ],
    "effectDescriptions": ["\u57FA\u7840\u589E\u4F243%\uFF1B\u6B63\u666E\u653B\u548C\u6280\u80FD\u4F24\u5BB3\u65BD\u52A05\u79D2\u707C\u70E7\u4E0E33%\u91CD\u4F24\uFF0C\u6BCF\u79D2\u707C\u70E71%\u5F53\u524D\u6700\u5927\u751F\u547D\u3002"],
    "effects": [
      {
        "kind": "attackSpeedBps",
        "bps": 3500
      }
    ],
    combatProgram: { modifiers: [modifier("damageAmp", 300, "bps")], triggers: [trigger({ event: "damage-dealt", selector: enemies({ candidates: "event-target" }), effects: burn(100) })] }
  },
  {
    "id": "runaans-hurricane",
    "evidenceStatus": "approved-provisional",
    "name": "\u5362\u5B89\u5A1C\u7684\u98D3\u98CE",
    "kind": "completed",
    "apiName": "TFT_Item_RunaansHurricane",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "B-10",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "cloak",
      "bow"
    ],
    "effectDescriptions": ["\u6BCF\u6B21\u5B8C\u6210\u666E\u653B\u5411\u6700\u8FD1\u7684\u53E6\u4E00\u654C\u4EBA\u53D1\u5C0455%\u5F53\u524D\u653B\u51FB\u529B\u7684\u7269\u7406\u88C5\u5907\u7BAD\u77E2\uFF1B\u4E0D\u66B4\u51FB\u3001\u4E0D\u9644\u5E26\u653B\u51FB\u7279\u6548\u3002"],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 2500
      },
      {
        "kind": "attackSpeedBps",
        "bps": 1e3
      },
      {
        "kind": "statFlat",
        "stat": "magicResist",
        "amount": 20
      }
    ],
    combatProgram: { triggers: [trigger({ selector: enemies({ excludePrimary: true, maxTargets: 1 }), effects: [damage("physical", { attackDamageBps: 5500 })] })] }
  },
  {
    "id": "statikk-shiv",
    "name": "\u65AF\u5854\u7F07\u514B\u7535\u5203",
    "kind": "completed",
    "apiName": "TFT_Item_StatikkShiv",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "B-13",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "bow",
      "tear"
    ],
    "effectDescriptions": ["\u6BCF\u7B2C3\u6B21\u5B8C\u6210\u666E\u653B\uFF0C\u5BF9\u4E3B\u76EE\u6807\u53CA\u6700\u8FD1\u6700\u591A3\u4E2A\u4E0D\u540C\u654C\u4EBA\u5148\u65BD\u52A030%\u51CF\u9B54\u62975\u79D2\uFF0C\u518D\u9020\u621035\u9B54\u6CD5\u88C5\u5907\u4F24\u5BB3\uFF0C\u4E0D\u66B4\u51FB\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 15
      },
      {
        "kind": "attackSpeedBps",
        "bps": 1500
      },
      {
        "kind": "statFlat",
        "stat": "initialMana",
        "amount": 15
      }
    ],
    combatProgram: { triggers: [trigger({ counters: [{ id: "attacks", events: [{ event: "attack-completed", listener: { subject: "actor", relationToHolder: "self", withinHexes: null }, qualifies: "completed-event" }], scope: "source-instance", reset: "combat-start", cap: null }], gate: { kind: "every-n", counterId: "attacks", everyN: 3, firstAt: 3 }, selector: enemies({ primary: "first-required", anchor: "primary-target", maxTargets: 4 }), effects: [status("shred", 3e3, 100, { activation: "immediate" }), damage("magic", { flat: 35 })] })] }
  },
  {
    "id": "titans-resolve",
    "name": "\u6CF0\u5766\u7684\u575A\u51B3",
    "kind": "completed",
    "apiName": "TFT_Item_TitansResolve",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "vest",
      "bow"
    ],
    "effectDescriptions": ["\u6BCF\u6B21\u5B8C\u6210\u666E\u653B\u53CA\u6BCF\u4E2A\u6B63\u5B9E\u9645\u627F\u4F24\u5305\uFF08\u542B\u62A4\u76FE\u627F\u4F24\uFF09\u5404\u53E01\u5C42\uFF1B\u6BCF\u5C422%\u653B\u51FB\u529B\u30012\u6CD5\u5F3A\uFF0C\u4E0B\u4E00tick\u751F\u6548\uFF0C\u6301\u7EED\u672C\u573A\uFF0C\u6700\u591A25\u5C42\u3002\u6EE1\u5C42\u989D\u591620\u53CC\u6297\u6BCF\u4EF6\u53EA\u6388\u4E88\u4E00\u6B21\uFF1B\u96F6\u4F24\u5BB3\u4E0D\u53E0\u5C42\u3002"],
    "effects": [
      {
        "kind": "attackSpeedBps",
        "bps": 1e3
      },
      {
        "kind": "statFlat",
        "stat": "armor",
        "amount": 20
      }
    ],
    combatProgram: { triggers: [trigger({ id: "growth", event: "counter-updated", counters: [{ id: "stacks", events: [{ event: "attack-completed", listener: { subject: "actor", relationToHolder: "self", withinHexes: null }, qualifies: "completed-event" }, { event: "damage-taken", listener: { subject: "target", relationToHolder: "self", withinHexes: null }, qualifies: "positive-actual-damage" }], scope: "source-instance", reset: "combat-start", cap: 25 }], effects: ["attackDamage", "abilityPower"].map((s, i) => stat({ ...modifier(s, 0, i === 0 ? "bps" : "flat"), value: { kind: "counter", counterId: "stacks", perCount: i === 0 ? 200 : 2 } }, null, "next-tick")) }), trigger({ id: "cap", event: "counter-updated", counters: [{ id: "stacks", events: [{ event: "attack-completed", listener: { subject: "actor", relationToHolder: "self", withinHexes: null }, qualifies: "completed-event" }, { event: "damage-taken", listener: { subject: "target", relationToHolder: "self", withinHexes: null }, qualifies: "positive-actual-damage" }], scope: "source-instance", reset: "combat-start", cap: 25 }], gate: { kind: "stack-threshold-once", counterId: "stacks", at: 25, rewardId: "resists" }, effects: [stat(modifier("armor", 20), null, "next-tick"), stat(modifier("magicResist", 20), null, "next-tick")] })] }
  }
];

// src/simulation/content/items-rod.ts
var ROD_ITEMS = [
  {
    "id": "crownguard",
    "name": "\u5195\u536B",
    "kind": "completed",
    "apiName": "TFT_Item_Crownguard",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-08",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "vest",
      "rod"
    ],
    "effectDescriptions": ["\u5F00\u6218\u83B7\u5F9725%\u6700\u5927\u751F\u547D\u62A4\u76FE8\u79D2\uFF1B\u62A4\u76FE\u8017\u5C3D\u6216\u81EA\u7136\u5230\u671F\u540E\u83B7\u5F9725\u6CD5\u5F3A\u81F3\u6218\u6597\u7ED3\u675F\uFF0C\u6B7B\u4EA1\u6E05\u9664\u4E0D\u5956\u52B1\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 20
      },
      {
        "kind": "statFlat",
        "stat": "armor",
        "amount": 20
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 100
      }
    ],
    combatProgram: { effects: [shield(2500, 160, [stat(modifier("abilityPower", 25))])] }
  },
  {
    "id": "ionic-spark",
    "name": "\u79BB\u5B50\u706B\u82B1",
    "kind": "completed",
    "apiName": "TFT_Item_IonicSpark",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-18",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "rod",
      "cloak"
    ],
    "effectDescriptions": ["2\u683C\u5185\u5B58\u6D3B\u654C\u4EBA\u9B54\u6297\u964D\u4F4E30%\uFF1B\u8303\u56F4\u5185\u654C\u4EBA\u5B8C\u6210\u65BD\u6CD5\u65F6\u53D7\u5B9E\u9645\u6D88\u8017\u6CD5\u529B\xD7160%\u7684\u9B54\u6CD5\u88C5\u5907\u4F24\u5BB3\uFF0C\u4E0D\u66B4\u51FB\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 15
      },
      {
        "kind": "statFlat",
        "stat": "magicResist",
        "amount": 25
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 100
      }
    ],
    combatProgram: { periodic: [periodic(1, [status("shred", 3e3, 1, { activation: "immediate" })], enemies({ radius: 2, maxTargets: 100, sample: "each-tick" }))], triggers: [trigger({ event: "cast-completed", listener: { subject: "actor", relationToHolder: "enemy", withinHexes: 2 }, selector: enemies({ candidates: "event-actor" }), effects: [damage("magic", { actualManaSpentBps: 16e3 })] })] }
  },
  {
    "id": "jeweled-gauntlet",
    "name": "\u73E0\u5149\u62A4\u624B",
    "kind": "completed",
    "apiName": "TFT_Item_JeweledGauntlet",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-19",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "rod",
      "gloves"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387+35%\uFF1B\u6280\u80FD\u4F24\u5BB3\u53EF\u66B4\u51FB\uFF0C\u91CD\u590D\u6280\u80FD\u66B4\u51FB\u6388\u6743\u6BCF\u6B21\u52A010%\u66B4\u4F24\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 35
      }
    ],
    combatProgram: { modifiers: [modifier("critChance", 3500, "bps")], effects: [{ kind: "authorize-spell-crit", duplicateBonusBps: 1e3 }] }
  },
  {
    "id": "morellonomicon",
    "name": "\u83AB\u96F7\u6D1B\u79D8\u5178",
    "kind": "completed",
    "apiName": "TFT_Item_Morellonomicon",
    "unique": true,
    "slotCost": 1,
    "conventionIds": [
      "B-01",
      "B-02",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "belt",
      "rod"
    ],
    "effectDescriptions": ["\u6B63\u666E\u653B\u548C\u6280\u80FD\u4F24\u5BB3\u65BD\u52A010\u79D2\u707C\u70E7\u4E0E33%\u91CD\u4F24\uFF0C\u6BCF\u79D2\u707C\u70E71%\u5F53\u524D\u6700\u5927\u751F\u547D\uFF1B\u4E2D\u7ACB\u6BCF\u8DF3\u4E0A\u9650100\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 25
      },
      {
        "kind": "attackSpeedBps",
        "bps": 1e3
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      }
    ],
    combatProgram: { triggers: [trigger({ event: "damage-dealt", selector: enemies({ candidates: "event-target" }), effects: burn(200) })] }
  }
];

// src/simulation/content/items-tear.ts
var TEAR_ITEMS = [
  {
    "id": "adaptive-helm",
    "name": "\u81EA\u9002\u5E94\u5934\u76D4",
    "kind": "completed",
    "apiName": "TFT_Item_AdaptiveHelm",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-01",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "cloak",
      "tear"
    ],
    "effectDescriptions": ["\u5F00\u6218\u9501\u5B9A\u5DF1\u65B9\u524D\u4E24\u6392\uFF1A40\u53CC\u6297\u3001\u6BCF\u6B21\u666E\u901A\u653B\u51FB\u547D\u4E2D\u989D\u5916\u56DE1\u84DD\uFF1B\u540E\u4E24\u6392\uFF1A15\u6CD5\u5F3A\u3001\u6BCF3\u79D2\u56DE10\u84DD\u3002\u79FB\u52A8\u4E0D\u5207\u6362\u5206\u652F\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 10
      },
      {
        "kind": "statFlat",
        "stat": "magicResist",
        "amount": 20
      },
      {
        "kind": "statFlat",
        "stat": "initialMana",
        "amount": 15
      }
    ],
    combatProgram: { modifiers: [modifier("armor", 40, "flat", rows("front-two")), modifier("magicResist", 40, "flat", rows("front-two")), modifier("abilityPower", 15, "flat", rows("back-two"))], triggers: [trigger({ event: "incoming-basic-hit", listener: { subject: "target", relationToHolder: "self", withinHexes: null }, condition: rows("front-two"), effects: [mana(1, "incoming-basic-hit")] })], periodic: [periodic(60, [mana(10, "periodic")], selector({ sample: "each-pulse" }), { condition: rows("back-two") })] }
  },
  {
    "id": "blue-buff",
    "name": "\u84DD\u9738\u7B26",
    "kind": "completed",
    "apiName": "TFT_Item_BlueBuff",
    "unique": true,
    "slotCost": 1,
    "conventionIds": [
      "A-05",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "tear",
      "tear"
    ],
    "effectDescriptions": ["\u5B8C\u6210\u65BD\u6CD5\u56DE\u590D10\u6CD5\u529B\uFF0C\u53EF\u7ED5\u8FC7\u8BE5\u6B21\u65BD\u6CD5\u9501\u84DD\uFF1B\u53C2\u4E0E\u51FB\u6740\u540E\u589E\u4F245%\u6301\u7EED8\u79D2\uFF0C\u540C\u4EF6\u5237\u65B0\u4E0D\u53E0\u52A0\u3002"],
    "effects": [
      {
        "kind": "statPercentBps",
        "stat": "attackDamage",
        "bps": 1500
      },
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 15
      },
      {
        "kind": "statFlat",
        "stat": "initialMana",
        "amount": 30
      }
    ],
    combatProgram: { triggers: [trigger({ id: "refund", event: "cast-completed", effects: [mana(10, "cast-refund")] }), trigger({ id: "takedown", event: "kill-or-assist", effects: [stat(modifier("damageAmp", 500, "bps"), 160)] })] }
  },
  {
    "id": "protectors-vow",
    "name": "\u5723\u76FE\u4F7F\u7684\u8A93\u7EA6",
    "kind": "completed",
    "apiName": "TFT_Item_FrozenHeart",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-11",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "vest",
      "tear"
    ],
    "effectDescriptions": ["\u53D7\u4F24\u540E\u5B58\u6D3B\u4E14\u751F\u547D\u226440%\u65F6\u6BCF\u6218\u4E00\u6B21\u83B7\u5F9725%\u6700\u5927\u751F\u547D\u62A4\u76FE5\u79D2\u53CA20\u53CC\u6297\u81F3\u6218\u6597\u7ED3\u675F\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "armor",
        "amount": 20
      },
      {
        "kind": "statFlat",
        "stat": "initialMana",
        "amount": 30
      }
    ],
    combatProgram: { survival: [survival(4e3, [shield(2500, 100), stat(modifier("armor", 20)), stat(modifier("magicResist", 20))])] }
  },
  {
    "id": "redemption",
    "name": "\u6551\u8D4E",
    "kind": "completed",
    "apiName": "TFT_Item_Redemption",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "B-09",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "belt",
      "tear"
    ],
    "effectDescriptions": ["\u6BCF5\u79D2\u6CBB\u75971\u683C\u5185\u5B58\u6D3B\u53CB\u519B\uFF08\u5305\u62EC\u81EA\u8EAB\uFF0915%\u5DF2\u635F\u751F\u547D\uFF0C\u6BCF\u6B21\u6BCF\u76EE\u6807\u4E0A\u96501000\uFF1B\u540C\u65F6\u65BD\u52A0\u4E0B\u4E00tick\u751F\u6548\u768410%\u5E38\u89C4\u51CF\u4F245\u79D2\uFF0C\u540C\u7C7B\u4E0D\u53E0\u52A0\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "initialMana",
        "amount": 15
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      }
    ],
    combatProgram: { periodic: [periodic(100, [{ kind: "heal", amount: amount({ missingHpBps: 1500, hpBasis: "target", sample: "each-pulse", cap: 1e3 }) }, status("damage-reduction", 1e3, 100, { activation: "next-tick" })], selector({ relation: "ally", radius: 1, maxTargets: 100, sample: "each-pulse" }))] }
  },
  {
    "id": "hand-of-justice",
    "name": "\u6B63\u4E49\u4E4B\u624B",
    "kind": "completed",
    "apiName": "TFT_Item_UnstableConcoction",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "gloves",
      "tear"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387+20%\uFF1B\u57FA\u784015%\u653B\u51FB\u529B\u300115\u6CD5\u5F3A\u300112%\u5168\u80FD\u5438\u8840\uFF1B\u751F\u547D\u4E25\u683C\u9AD8\u4E8E50%\u653B\u51FB/\u6CD5\u5F3A\u7FFB\u500D\uFF0C\u4E25\u683C\u4F4E\u4E8E50%\u5438\u8840\u7FFB\u500D\uFF0C\u607050%\u4E0D\u7FFB\u500D\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "initialMana",
        "amount": 15
      }
    ],
    combatProgram: { modifiers: [modifier("critChance", 2e3, "bps"), modifier("attackDamage", 1500, "bps"), modifier("abilityPower", 15), modifier("attackDamage", 1500, "bps", hp("gt", 5e3)), modifier("abilityPower", 15, "flat", hp("gt", 5e3))], vamp: [vamp(1200), vamp(1200, hp("lt", 5e3))] }
  }
];

// src/simulation/content/items-vest.ts
var VEST_ITEMS = [
  {
    "id": "bramble-vest",
    "name": "\u68D8\u523A\u80CC\u5FC3",
    "kind": "completed",
    "apiName": "TFT_Item_BrambleVest",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "A-06",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "vest",
      "vest"
    ],
    "effectDescriptions": ["\u666E\u653B\u5305\u51CF\u4F248%\uFF1B\u6BCF\u6B21\u666E\u901A\u653B\u51FB\u547D\u4E2D\uFF08\u542B\u62A4\u76FE\uFF09\u54111\u683C\u5185\u654C\u4EBA\u53CD\u51FB100\u9B54\u6CD5\u88C5\u5907\u4F24\u5BB3\uFF0C\u6BCF\u4EF6\u51B7\u53742\u79D2\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "armor",
        "amount": 65
      },
      {
        "kind": "statPercentBps",
        "stat": "maxHp",
        "bps": 700
      }
    ],
    combatProgram: { modifiers: [modifier("damageReduction", 800, "bps", always, filter(["basic-attack"]))], triggers: [trigger({ event: "incoming-basic-hit", listener: { subject: "target", relationToHolder: "self", withinHexes: null }, internalCooldownTicks: 40, selector: enemies({ radius: 1, maxTargets: 100 }), effects: [damage("magic", { flat: 100 })] })] }
  },
  {
    "id": "steadfast-heart",
    "name": "\u575A\u5B9A\u4E4B\u5FC3",
    "kind": "completed",
    "apiName": "TFT_Item_NightHarvester",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "vest",
      "gloves"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387+20%\uFF1B\u6BCF\u53D7\u4F24\u5305\u4E4B\u524D\u68C0\u67E5\u5F53\u524D\u751F\u547D\uFF1A\u4E25\u683C\u9AD8\u4E8E50%\u51CF\u4F2415%\uFF0C\u5176\u4F598%\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "armor",
        "amount": 20
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 200
      }
    ],
    combatProgram: { modifiers: [modifier("critChance", 2e3, "bps"), modifier("damageReduction", 800, "bps", always, filter()), modifier("damageReduction", 1500, "bps", hp("gt", 5e3), filter())] }
  },
  {
    "id": "sunfire-cape",
    "name": "\u65E5\u708E\u6597\u7BF7",
    "kind": "completed",
    "apiName": "TFT_Item_RedBuff",
    "unique": true,
    "slotCost": 1,
    "conventionIds": [
      "B-02",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "vest",
      "belt"
    ],
    "effectDescriptions": ["\u6BCF2\u79D2\u9009\u62E92\u683C\u5185\u4F18\u5148\u672A\u53D7\u672C\u4EF6\u707C\u70E7\u7684\u654C\u4EBA\uFF0C\u65BD\u52A010\u79D21%\u6BCF\u79D2\u707C\u70E7\u4E0E33%\u91CD\u4F24\uFF1B\u540C\u7C7B\u53D6\u5F3A\uFF0C\u4E2D\u7ACB\u6BCF\u8DF3\u4E0A\u9650100\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "armor",
        "amount": 20
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      },
      {
        "kind": "statPercentBps",
        "stat": "maxHp",
        "bps": 800
      }
    ],
    combatProgram: { periodic: [periodic(40, burn(200), enemies({ radius: 2, order: "not-burned-by-this-instance-distance-id", sample: "each-pulse" }))] }
  }
];

// src/simulation/content/items-cloak.ts
var CLOAK_ITEMS = [
  {
    "id": "quicksilver",
    "name": "\u6C34\u94F6",
    "kind": "completed",
    "apiName": "TFT_Item_Quicksilver",
    "unique": true,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "cloak",
      "gloves"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387+20%\uFF1B\u5F00\u6218\u514D\u63A718\u79D2\uFF0C\u6BCF2\u79D2\u83B7\u5F973%\u653B\u901F\uFF0C\u51719\u6B21\uFF1B\u653B\u901F\u6301\u7EED\u672C\u6218\uFF0C18\u79D2\u672B\u6B21\u52A0\u901F\u540E\u514D\u63A7\u5230\u671F\u3002"],
    "effects": [
      {
        "kind": "attackSpeedBps",
        "bps": 3e3
      },
      {
        "kind": "statFlat",
        "stat": "magicResist",
        "amount": 20
      }
    ],
    combatProgram: { modifiers: [modifier("critChance", 2e3, "bps")], effects: [status("control-immunity", 1e4, 360, { activation: "immediate" })], periodic: [periodic(40, [{ kind: "modify-stat", modifier: modifier("attackSpeed", 300, "bps"), activation: "immediate", duration: combat, stackPolicy: { kind: "add-stacks", cap: null } }], selector({ sample: "each-pulse" }), { endsAtTick: 360, finalPulse: "before-expiry" })] }
  },
  {
    "id": "evenshroud",
    "name": "\u8584\u66AE\u6CD5\u888D",
    "kind": "completed",
    "apiName": "TFT_Item_SpectralGauntlet",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "belt",
      "cloak"
    ],
    "effectDescriptions": ["\u5F00\u6218\u83B7\u5F9725\u53CC\u629710\u79D2\uFF1B2\u683C\u5185\u654C\u4EBA\u62A4\u7532\u964D\u4F4E30%\uFF0C\u79FB\u52A8\u3001\u79BB\u5F00\u6216\u6301\u6709\u8005\u6B7B\u4EA1\u5373\u65F6\u79FB\u9664\u5149\u73AF\uFF0C\u540C\u7C7B\u53D6\u6700\u5F3A\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "magicResist",
        "amount": 20
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      }
    ],
    combatProgram: { effects: [stat(modifier("armor", 25), 200), stat(modifier("magicResist", 25), 200)], periodic: [periodic(1, [status("sunder", 3e3, 1, { activation: "immediate" })], enemies({ radius: 2, maxTargets: 100, sample: "each-tick" }))] }
  }
];

// src/simulation/content/items-belt.ts
var BELT_ITEMS = [
  {
    "id": "guardbreaker",
    "name": "\u7834\u9632\u8005",
    "kind": "completed",
    "apiName": "TFT_Item_PowerGauntlet",
    "unique": false,
    "slotCost": 1,
    "conventionIds": [
      "B-04",
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "belt",
      "gloves"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387+20%\u3001\u57FA\u7840\u589E\u4F2410%\uFF1B\u5BF9\u62A4\u76FE\u9020\u6210\u6B63\u4F24\u5BB3\u540E\u53E6\u589E\u4F2415%\u6301\u7EED3\u79D2\uFF0C\u540C\u4EF6\u5237\u65B0\u4E0D\u53E0\u52A0\uFF0C\u89E6\u53D1\u5305\u4E0D\u4EAB\u53D7\u65B0\u589E\u76CA\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "abilityPower",
        "amount": 10
      },
      {
        "kind": "attackSpeedBps",
        "bps": 2e3
      },
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      }
    ],
    combatProgram: { modifiers: [modifier("critChance", 2e3, "bps"), modifier("damageAmp", 1e3, "bps")], triggers: [trigger({ event: "shield-hit", effects: [stat(modifier("damageAmp", 1500, "bps"), 60)] })] }
  }
];

// src/simulation/content/items-gloves.ts
var GLOVES_ITEMS = [
  {
    "id": "thiefs-gloves",
    "name": "\u7A83\u8D3C\u624B\u5957",
    "kind": "completed",
    "apiName": "TFT_Item_ThiefsGloves",
    "unique": false,
    "slotCost": 3,
    "conventionIds": [
      "GLOBAL-STAT-01"
    ],
    "recipe": [
      "gloves",
      "gloves"
    ],
    "effectDescriptions": ["\u66B4\u51FB\u7387+20%\uFF1B\u672C\u4F53\u4E0E\u4E34\u65F6\u4EF6\u5360\u75283\u69FD\u3002\u6BCF\u8F6E\u9996\u6B21\u7A7F\u6234\u751F\u6210\u4E34\u65F6\u88C5\u5907\uFF1A7\u7EA7\u53CA\u4EE5\u4E0A\u4E24\u4EF6\u6210\u88C5\uFF0C\u4EE5\u4E0B\u6210\u88C5\uFF0B\u7EC4\u4EF6\uFF1B\u540C\u8F6E\u4FDD\u6301\u7EC4\u5408\uFF0C\u65B0\u8F6E\u5237\u65B0\u3002"],
    "effects": [
      {
        "kind": "statFlat",
        "stat": "maxHp",
        "amount": 150
      }
    ],
    combatProgram: { modifiers: [modifier("critChance", 2e3, "bps")], effects: [{ kind: "temporary-equipment", policyId: "TG-01", lifetime: "round" }] }
  }
];

// src/simulation/content/items.ts
var ITEM_DEFINITIONS = freezeContent({
  ...Object.fromEntries([COMPONENTS_ITEMS, SWORD_ITEMS, BOW_ITEMS, ROD_ITEMS, TEAR_ITEMS, VEST_ITEMS, CLOAK_ITEMS, BELT_ITEMS, GLOVES_ITEMS].flat().map((item) => [item.id, item])),
  ...{
    "rageblade": {
      "id": "rageblade",
      "effectDescriptions": ["\u6BCF\u6B21\u5B8C\u6210\u666E\u653B\u53E0\u52A05%\u653B\u901F\uFF0C\u6301\u7EED\u672C\u573A\uFF0C\u65E0\u4E0A\u9650\u3002"],
      "name": "\u9B3C\u7D22\u7684\u72C2\u66B4\u4E4B\u5203",
      "kind": "completed",
      "apiName": "TFT_Item_GuinsoosRageblade",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "A-15",
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "bow",
        "rod"
      ],
      "effects": [
        {
          "kind": "statFlat",
          "stat": "abilityPower",
          "amount": 10
        },
        {
          "kind": "attackSpeedBps",
          "bps": 1e3
        },
        {
          "kind": "mechanic",
          "mechanic": "rageblade",
          "values": {
            "attackSpeedBps": 500
          }
        }
      ]
    },
    "deathblade": {
      "id": "deathblade",
      "effectDescriptions": ["\u5E38\u9A7B\u589E\u4F248%\uFF0C\u4E0E\u653B\u51FB\u529B\u5C5E\u6027\u5206\u522B\u8BA1\u7B97\u3002"],
      "name": "\u6B7B\u4EA1\u4E4B\u5203",
      "kind": "completed",
      "apiName": "TFT_Item_Deathblade",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "A-09",
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "sword",
        "sword"
      ],
      "effects": [
        {
          "kind": "statPercentBps",
          "stat": "attackDamage",
          "bps": 5500
        },
        {
          "kind": "mechanic",
          "mechanic": "damageAmp",
          "values": {
            "bps": 800
          }
        }
      ]
    },
    "shojin": {
      "id": "shojin",
      "effectDescriptions": ["\u6BCF\u6B21\u5B8C\u6210\u666E\u653B\u989D\u5916\u56DE5\u6CD5\u529B\uFF0C\u4ECD\u53D7\u9501\u84DD\u4E0E\u4E0A\u9650\u9650\u5236\u3002"],
      "name": "\u6714\u6781\u4E4B\u77DB",
      "kind": "completed",
      "apiName": "TFT_Item_SpearOfShojin",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "sword",
        "tear"
      ],
      "effects": [
        {
          "kind": "statPercentBps",
          "stat": "attackDamage",
          "bps": 1500
        },
        {
          "kind": "statFlat",
          "stat": "abilityPower",
          "amount": 15
        },
        {
          "kind": "statFlat",
          "stat": "initialMana",
          "amount": 15
        },
        {
          "kind": "mechanic",
          "mechanic": "extraAttackMana",
          "values": {
            "amount": 5
          }
        }
      ]
    },
    "archangel": {
      "id": "archangel",
      "effectDescriptions": ["\u6BCF5\u79D2\u589E\u52A030\u6CD5\u5F3A\uFF0C\u6301\u7EED\u672C\u573A\uFF0C\u9996\u6B21\u4E0D\u662F\u5F00\u6218\u3002"],
      "name": "\u5927\u5929\u4F7F\u4E4B\u6756",
      "kind": "completed",
      "apiName": "TFT_Item_ArchangelsStaff",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "A-02",
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "rod",
        "tear"
      ],
      "effects": [
        {
          "kind": "statFlat",
          "stat": "abilityPower",
          "amount": 20
        },
        {
          "kind": "statFlat",
          "stat": "initialMana",
          "amount": 15
        },
        {
          "kind": "mechanic",
          "mechanic": "archangel",
          "values": {
            "periodTicks": 100,
            "abilityPower": 30
          }
        }
      ]
    },
    "deathcap": {
      "id": "deathcap",
      "effectDescriptions": ["\u5E38\u9A7B\u589E\u4F2415%\u3002"],
      "name": "\u706D\u4E16\u8005\u7684\u6B7B\u4EA1\u4E4B\u5E3D",
      "kind": "completed",
      "apiName": "TFT_Item_RabadonsDeathcap",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "B-06",
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "rod",
        "rod"
      ],
      "effects": [
        {
          "kind": "statFlat",
          "stat": "abilityPower",
          "amount": 50
        },
        {
          "kind": "mechanic",
          "mechanic": "damageAmp",
          "values": {
            "bps": 1500
          }
        }
      ]
    },
    "warmog": {
      "id": "warmog",
      "effectDescriptions": ["\u751F\u547D\u6309\uFF08\u57FA\u7840\u4E0E\u56FA\u5B9A\u751F\u547D\u4E4B\u548C\uFF09\xD7\uFF081+\u5408\u8BA1\u751F\u547D\u767E\u5206\u6BD4\uFF09\u8BA1\u7B97\u3002"],
      "name": "\u72C2\u5F92\u94E0\u7532",
      "kind": "completed",
      "apiName": "TFT_Item_WarmogsArmor",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "belt",
        "belt"
      ],
      "effects": [
        {
          "kind": "statFlat",
          "stat": "maxHp",
          "amount": 600
        },
        {
          "kind": "statPercentBps",
          "stat": "maxHp",
          "bps": 1200
        }
      ]
    },
    "dragons-claw": {
      "id": "dragons-claw",
      "effectDescriptions": ["\u6BCF2\u79D2\u6CBB\u7597\u5F53\u65F6\u6700\u5927\u751F\u547D\u76842.5%\uFF0C\u4E0D\u590D\u6D3B\u3001\u4E0D\u8F6C\u76FE\u3002"],
      "name": "\u5DE8\u9F99\u4E4B\u722A",
      "kind": "completed",
      "apiName": "TFT_Item_DragonsClaw",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "A-10",
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "cloak",
        "cloak"
      ],
      "effects": [
        {
          "kind": "statFlat",
          "stat": "magicResist",
          "amount": 75
        },
        {
          "kind": "statPercentBps",
          "stat": "maxHp",
          "bps": 900
        },
        {
          "kind": "mechanic",
          "mechanic": "dragonClaw",
          "values": {
            "periodTicks": 40,
            "healMaxHpBps": 250
          }
        }
      ]
    },
    "gargoyle": {
      "id": "gargoyle",
      "effectDescriptions": ["\u6BCF\u4E2A\u5F53\u524D\u4E3B\u76EE\u6807\u4E3A\u6301\u6709\u8005\u7684\u5B58\u6D3B\u654C\u4EBA\u589E\u52A010\u53CC\u6297\uFF0C\u76EE\u6807\u6539\u53D8\u6216\u6B7B\u4EA1\u5373\u65F6\u91CD\u7B97\u3002"],
      "name": "\u77F3\u50CF\u9B3C\u77F3\u677F\u7532",
      "kind": "completed",
      "apiName": "TFT_Item_GargoyleStoneplate",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "A-12",
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "vest",
        "cloak"
      ],
      "effects": [
        {
          "kind": "statFlat",
          "stat": "maxHp",
          "amount": 100
        },
        {
          "kind": "statFlat",
          "stat": "armor",
          "amount": 25
        },
        {
          "kind": "statFlat",
          "stat": "magicResist",
          "amount": 25
        },
        {
          "kind": "mechanic",
          "mechanic": "gargoyle",
          "values": {
            "resistPerEnemy": 10
          }
        }
      ]
    },
    "gunblade": {
      "id": "gunblade",
      "effectDescriptions": ["15%\u5168\u80FD\u5438\u8840\uFF1B\u5408\u8D44\u683C\u5B9E\u9645\u76FE\u4F24+\u751F\u547D\u4F24\u5BB3\u768425%\u6CBB\u7597\u53E6\u4E00\u540D\u751F\u547D\u6BD4\u4F8B\u6700\u4F4E\u5B58\u6D3B\u53CB\u519B\uFF0C\u540C\u503C\u6309\u7A33\u5B9AID\uFF0C\u4E0D\u6CBB\u7597\u81EA\u8EAB\u3002"],
      "name": "\u6D77\u514B\u65AF\u79D1\u6280\u67AA\u5203",
      "kind": "completed",
      "apiName": "TFT_Item_HextechGunblade",
      "unique": false,
      "slotCost": 1,
      "conventionIds": [
        "A-16",
        "GLOBAL-STAT-01"
      ],
      "recipe": [
        "sword",
        "rod"
      ],
      "effects": [
        {
          "kind": "statPercentBps",
          "stat": "attackDamage",
          "bps": 2e3
        },
        {
          "kind": "statFlat",
          "stat": "abilityPower",
          "amount": 20
        },
        {
          "kind": "mechanic",
          "mechanic": "gunblade",
          "values": {
            "selfHealBps": 1500,
            "allyHealBps": 2500
          }
        }
      ]
    }
  }
});
var COMPONENT_IDS = Object.freeze(Object.values(ITEM_DEFINITIONS).filter((item) => item.kind === "component").sort((a, b) => a.apiName < b.apiName ? -1 : 1).map((item) => item.id));

// src/simulation/content/round-catalog.ts
var ROUND_CATALOG = freezeContent([
  { roundId: "1-2", ordinal: 1, stage: 1, subround: 2, kind: "pve", isFinal: false, encounterId: "minions-a-v1", displayName: "1-2" },
  { roundId: "1-3", ordinal: 2, stage: 1, subround: 3, kind: "pve", isFinal: false, encounterId: "minions-b-v1", displayName: "1-3" },
  { roundId: "1-4", ordinal: 3, stage: 1, subround: 4, kind: "pve", isFinal: false, encounterId: "minions-c-v1", displayName: "1-4" },
  { roundId: "2-1", ordinal: 4, stage: 2, subround: 1, kind: "pvp", isFinal: false, encounterId: null, displayName: "2-1" },
  { roundId: "2-2", ordinal: 5, stage: 2, subround: 2, kind: "pvp", isFinal: false, encounterId: null, displayName: "2-2" },
  { roundId: "2-3", ordinal: 6, stage: 2, subround: 3, kind: "pvp", isFinal: false, encounterId: null, displayName: "2-3" },
  { roundId: "2-4", ordinal: 7, stage: 2, subround: 4, kind: "supply", isFinal: false, encounterId: null, displayName: "2-4" },
  { roundId: "2-5", ordinal: 8, stage: 2, subround: 5, kind: "pvp", isFinal: false, encounterId: null, displayName: "2-5" },
  { roundId: "2-6", ordinal: 9, stage: 2, subround: 6, kind: "pvp", isFinal: false, encounterId: null, displayName: "2-6" },
  { roundId: "2-7", ordinal: 10, stage: 2, subround: 7, kind: "pve", isFinal: false, encounterId: "krugs-v1", displayName: "2-7" },
  { roundId: "3-1", ordinal: 11, stage: 3, subround: 1, kind: "pvp", isFinal: false, encounterId: null, displayName: "3-1" },
  { roundId: "3-2", ordinal: 12, stage: 3, subround: 2, kind: "pvp", isFinal: false, encounterId: null, displayName: "3-2" },
  { roundId: "3-3", ordinal: 13, stage: 3, subround: 3, kind: "pvp", isFinal: false, encounterId: null, displayName: "3-3" },
  { roundId: "3-4", ordinal: 14, stage: 3, subround: 4, kind: "supply", isFinal: false, encounterId: null, displayName: "3-4" },
  { roundId: "3-5", ordinal: 15, stage: 3, subround: 5, kind: "pvp", isFinal: false, encounterId: null, displayName: "3-5" },
  { roundId: "3-6", ordinal: 16, stage: 3, subround: 6, kind: "pvp", isFinal: false, encounterId: null, displayName: "3-6" },
  { roundId: "3-7", ordinal: 17, stage: 3, subround: 7, kind: "pve", isFinal: false, encounterId: "wolves-v1", displayName: "3-7" },
  { roundId: "4-1", ordinal: 18, stage: 4, subround: 1, kind: "pvp", isFinal: false, encounterId: null, displayName: "4-1" },
  { roundId: "4-2", ordinal: 19, stage: 4, subround: 2, kind: "pvp", isFinal: false, encounterId: null, displayName: "4-2" },
  { roundId: "4-3", ordinal: 20, stage: 4, subround: 3, kind: "pvp", isFinal: false, encounterId: null, displayName: "4-3" },
  { roundId: "4-4", ordinal: 21, stage: 4, subround: 4, kind: "supply", isFinal: false, encounterId: null, displayName: "4-4" },
  { roundId: "4-5", ordinal: 22, stage: 4, subround: 5, kind: "pvp", isFinal: false, encounterId: null, displayName: "4-5" },
  { roundId: "4-6", ordinal: 23, stage: 4, subround: 6, kind: "pvp", isFinal: false, encounterId: null, displayName: "4-6" },
  { roundId: "4-7", ordinal: 24, stage: 4, subround: 7, kind: "pve", isFinal: false, encounterId: "razorbeaks-v1", displayName: "4-7" },
  { roundId: "5-1", ordinal: 25, stage: 5, subround: 1, kind: "pvp", isFinal: false, encounterId: null, displayName: "5-1" },
  { roundId: "5-2", ordinal: 26, stage: 5, subround: 2, kind: "pvp", isFinal: false, encounterId: null, displayName: "5-2" },
  { roundId: "5-3", ordinal: 27, stage: 5, subround: 3, kind: "pvp", isFinal: false, encounterId: null, displayName: "5-3" },
  { roundId: "5-4", ordinal: 28, stage: 5, subround: 4, kind: "supply", isFinal: false, encounterId: null, displayName: "5-4" },
  { roundId: "5-5", ordinal: 29, stage: 5, subround: 5, kind: "pvp", isFinal: false, encounterId: null, displayName: "5-5" },
  { roundId: "5-6", ordinal: 30, stage: 5, subround: 6, kind: "pvp", isFinal: false, encounterId: null, displayName: "5-6" },
  { roundId: "5-7", ordinal: 31, stage: 5, subround: 7, kind: "pve", isFinal: false, encounterId: "elder-dragon-v1", displayName: "5-7" },
  { roundId: "6-1", ordinal: 32, stage: 6, subround: 1, kind: "pvp", isFinal: false, encounterId: null, displayName: "6-1" },
  { roundId: "6-2", ordinal: 33, stage: 6, subround: 2, kind: "pvp", isFinal: false, encounterId: null, displayName: "6-2" },
  { roundId: "6-3", ordinal: 34, stage: 6, subround: 3, kind: "pvp", isFinal: false, encounterId: null, displayName: "6-3" },
  { roundId: "6-4", ordinal: 35, stage: 6, subround: 4, kind: "supply", isFinal: false, encounterId: null, displayName: "6-4" },
  { roundId: "6-5", ordinal: 36, stage: 6, subround: 5, kind: "pvp", isFinal: false, encounterId: null, displayName: "6-5" },
  { roundId: "6-6", ordinal: 37, stage: 6, subround: 6, kind: "pvp", isFinal: false, encounterId: null, displayName: "6-6" },
  { roundId: "6-7", ordinal: 38, stage: 6, subround: 7, kind: "pve", isFinal: true, encounterId: "rift-herald-v1", displayName: "6-7" }
]);
var ROUND_SEMANTIC_NODES = freezeContent({
  "2-1": ["augment"],
  "2-4": ["supply"],
  "3-2": ["augment"],
  "3-4": ["supply"],
  "4-2": ["augment"],
  "4-4": ["supply"],
  "4-6": ["anomaly"],
  "5-4": ["supply"],
  "6-4": ["supply"]
});

// src/simulation/round-schedule.ts
var FINAL_ROUND = ROUND_CATALOG.at(-1).ordinal;
var ROUND_PREPARATION_RULES = freezeContent({ version: "m8-b8-preparation-v1", pveContent: "ready-b8-loot" });
var fixed = ROUND_CATALOG.flatMap((round) => (ROUND_SEMANTIC_NODES[round.roundId] ?? []).map((node) => ({ round: round.ordinal, event: {
  id: `round:${round.roundId}:${node}`,
  kind: node === "supply" ? "component" : node,
  priority: node === "augment" ? 20 : node === "anomaly" ? 30 : 10,
  timing: "before"
} })));
var ROUND_SCHEDULE = freezeContent({
  fixed,
  fallbackDefinitionId: "irelia",
  finalRound: FINAL_ROUND,
  recurring: { fromRound: FINAL_ROUND + 1, everyRounds: 7, randomComponents: 0 }
});

// src/simulation/match-rules.ts
var OPENING_INITIAL_STATE = freezeContent({
  gold: 0,
  level: 1,
  xp: 0,
  hp: 100,
  unit: { definitionId: "irelia", id: "unit-1", starLevel: 1, cell: { col: 1, row: 4 } },
  nextUnitSeq: 2
});
var MATCH_RULES = Object.freeze({
  initialGold: OPENING_INITIAL_STATE.gold,
  rerollCost: 2,
  roundIncome: 5,
  shopSize: 5,
  initialLevel: OPENING_INITIAL_STATE.level,
  maxLevel: 9,
  initialHp: OPENING_INITIAL_STATE.hp,
  xpPurchaseCost: 4,
  xpPurchaseAmount: 4,
  roundXp: 2
});
var XP_TO_NEXT_LEVEL = Object.freeze({ 1: 2, 2: 2, 3: 6, 4: 10, 5: 20, 6: 36, 7: 48, 8: 76 });
var SHOP_ODDS = Object.freeze({
  1: [100, 0, 0, 0, 0],
  2: [100, 0, 0, 0, 0],
  3: [75, 25, 0, 0, 0],
  4: [55, 30, 15, 0, 0],
  5: [45, 33, 20, 2, 0],
  6: [30, 40, 25, 5, 0],
  7: [19, 30, 40, 10, 1],
  8: [18, 25, 32, 22, 3],
  9: [15, 20, 25, 30, 10]
});
for (const row of Object.values(SHOP_ODDS)) Object.freeze(row);
var SHOP_CATALOG_BY_COST = Object.freeze({
  1: Object.freeze(["darius", "irelia", "lux", "maddie", "zyra"]),
  2: Object.freeze(["leona", "rell", "tristana", "urgot", "vander"]),
  3: Object.freeze(["ezreal", "kogmaw", "loris", "nami", "scar"]),
  4: Object.freeze(["corki", "garen", "zoe"]),
  5: Object.freeze(["caitlyn"])
});
var SHOP_CATALOG = Object.freeze(Object.values(SHOP_CATALOG_BY_COST).flat());
var STAGE_PLAYER_DAMAGE = Object.freeze({ 2: 2, 3: 5, 4: 8, 5: 10, 6: 12 });
var ECONOMY_RULES = Object.freeze({
  interestDivisor: 10,
  interestCap: 5,
  victoryGold: 1,
  pveFailureDamage: 3,
  streakThresholds: Object.freeze([Object.freeze({ count: 2, gold: 1 }), Object.freeze({ count: 4, gold: 2 }), Object.freeze({ count: 6, gold: 3 })])
});
var OPENING_ECONOMY_RULES = freezeContent({
  version: "m8b-opening-project-v1",
  rounds: { "1-2": { baseGold: 2, naturalXp: 2 }, "1-3": { baseGold: 3, naturalXp: 2 }, "1-4": { baseGold: 5, naturalXp: 0 } },
  interest: 0,
  victoryGold: 0,
  streakGold: 0,
  updateStreak: false,
  pveFailureDamage: ECONOMY_RULES.pveFailureDamage
});

// src/simulation/temporary-equipment.ts
var TEMPORARY_EQUIPMENT_POOL = freezeContent(createEquipmentPool(Object.values(ITEM_DEFINITIONS).map((item) => ({
  apiName: item.apiName,
  definitionId: item.id,
  kind: item.kind,
  effects: item.combatProgram?.effects ?? []
}))));

// ../../../../tmp/b8-timeout-fix/tg/coverage-map.ts
var candidates = Array.from({ length: 512 }, (_, seed) => {
  const matchSeed = Math.imul(seed, 2654435761) >>> 0;
  const state = generateRoundRolls({ equipment: initializeStreams(matchSeed).equipment, rolls: [] }, [{ parentItemInstanceId: "item-3", roundId: "2-5", playerLevel: 6 }], TEMPORARY_EQUIPMENT_POOL);
  return { seed, matchSeed, children: state.rolls[0].children };
});
var seenOld = /* @__PURE__ */ new Set();
var original = [];
for (const c of candidates) {
  if (c.children.every((v) => seenOld.has(v))) continue;
  original.push(c);
  c.children.forEach((v) => seenOld.add(v));
  if (seenOld.size === 43) break;
}
var seenNew = /* @__PURE__ */ new Set();
var greedy = [];
while (seenNew.size < 43) {
  const score = (c) => c.children.filter((v) => !seenNew.has(v)).length;
  const selected = candidates.reduce((best, c) => score(c) > score(best) ? c : best);
  import_strict.default.ok(score(selected) > 0);
  greedy.push(selected);
  selected.children.forEach((v) => seenNew.add(v));
}
import_strict.default.equal(original.length, 37);
import_strict.default.equal(greedy.length, 35);
import_strict.default.deepEqual([...seenOld].sort(), [...seenNew].sort());
var states = JSON.parse((0, import_node_fs.readFileSync)("/tmp/b8-timeout-fix/tg/original.states.json", "utf8"));
import_strict.default.deepEqual(states.map(({ seed, matchSeed, children }) => ({ seed, matchSeed, children })), original);
var removed = original.filter((c) => !greedy.some((g) => g.seed === c.seed)).map((c) => {
  const r = states.find((s) => s.seed === c.seed);
  return { ...c, shieldCorruptionBranch: r.shield, retainedCarriers: Object.fromEntries(c.children.map((child) => [child, greedy.filter((g) => g.children.includes(child))])), distinctPairRetained: greedy.some((g) => JSON.stringify(g.children) === JSON.stringify(c.children)) };
});
var map = original.map((c, oldIndex) => ({ ...c, oldPosition: oldIndex + 1, newPosition: greedy.findIndex((g) => g.seed === c.seed) + 1 || null }));
var summary = { node: process.version, originalCount: original.length, newCount: greedy.length, coverage: [...seenNew].sort(), oldOrder: original.map((c) => c.seed), newOrder: greedy.map((c) => c.seed), removed, retainedShield: states.filter((r) => r.shield && greedy.some((g) => g.seed === r.seed)).map(({ seed, matchSeed, children }) => ({ seed, matchSeed, children })), map, greedy };
(0, import_node_fs.writeFileSync)("/tmp/b8-timeout-fix/tg/coverage-map.json", JSON.stringify(summary, null, 2));
console.log(JSON.stringify(summary));
