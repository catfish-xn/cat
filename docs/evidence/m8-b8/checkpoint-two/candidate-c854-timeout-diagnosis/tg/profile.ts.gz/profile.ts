import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { performance } from 'node:perf_hooks';
import { publicEquipmentPreparation, resolvePublicEquipmentChoices, finishPublicEquipmentBattle } from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/tests/fixtures/b8-public-equipment.ts';
import { buyXp, combineItems, deployMatchUnit, equipItem, nextRound, startMatchCombat, stepMatch } from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/src/simulation/match.ts';
import { restoreMatch, serializeMatch } from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/src/simulation/serialization.ts';
import { generateRoundRolls, initializeStreams } from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/src/simulation/m8/equipment.ts';
import { TEMPORARY_EQUIPMENT_POOL } from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/src/simulation/temporary-equipment.ts';
const accepted = (r:any) => { assert.equal(r.ok,true); return r.state; };
const variant = process.argv[2], seen = new Set<string>(), records:any[] = [];
const started=performance.now();
for(let seed=0;seed<512 && seen.size<43;seed++) {
 const matchSeed=Math.imul(seed,2654435761)>>>0;
 const planned=generateRoundRolls({equipment:initializeStreams(matchSeed).equipment,rolls:[]},[{parentItemInstanceId:'item-3',roundId:'2-5',playerLevel:6}],TEMPORARY_EQUIPMENT_POOL);
 if(planned.rolls[0].children.every(c=>seen.has(c)))continue;
 const t0=performance.now();
 let state=publicEquipmentPreparation(['gloves','gloves'],{seed:matchSeed});
 const t1=performance.now();
 assert.deepEqual(state.roundResults.map((r:any)=>r.result),['playerWin','playerWin','playerWin']);
 assert.deepEqual(state.preparation.units.filter((u:any)=>u.team==='player').map((u:any)=>[u.id,u.definitionId]),[['unit-1','irelia'],['unit-2','maddie'],['unit-3','lux']]);
 assert.deepEqual(state.items.map((i:any)=>[i.id,i.definitionId]),[['item-1','gloves'],['item-2','gloves']]);
 assert.deepEqual(restoreMatch(serializeMatch(state)),state);
 state=accepted(combineItems(state,'item-1','item-2'));
 while(state.roundDefinitionId!=='2-5') {
  state=resolvePublicEquipmentChoices(state);
  if(state.phase==='preparation')state=finishPublicEquipmentBattle(state);
  state=resolvePublicEquipmentChoices(state);
  state=accepted(nextRound(state,state.round));
 }
 state=resolvePublicEquipmentChoices(state);
 while(state.level<6)state=accepted(buyXp(state));
 assert.equal(state.level,6);
 state=accepted(deployMatchUnit(state,'unit-1',{kind:'board',cell:{col:1,row:4}}));
 state=accepted(equipItem(state,'item-3','unit-1',0));
 assert.deepEqual(state.temporaryEquipment.map((i:any)=>i.definitionId),planned.rolls[0].children);
 for(const child of state.temporaryEquipment)seen.add(child.definitionId);
 const preCombat=state,t2=performance.now();
 state=accepted(startMatchCombat(state));
 assert.deepEqual(restoreMatch(serializeMatch(state)),state);
 const shield=state.combat?.units.flatMap((unit:any)=>unit.shieldLayers??[]).find((layer:any)=>layer.source.parentItemInstanceId);
 if(shield){const corrupt=JSON.parse(serializeMatch(state));const layer=corrupt.combat.units.flatMap((unit:any)=>unit.shieldLayers).find((layer:any)=>layer.source.parentItemInstanceId);layer.key=JSON.stringify([layer.source.ownerId,layer.source.sourceKind,layer.source.definitionId,layer.source.instanceId,layer.source.effectIndex]);assert.throws(()=>restoreMatch(corrupt),/Invalid Match save: shield projection/);}
 const combatStart=state,t3=performance.now();
 for(let i=0;i<3&&state.phase==='combat';i++)state=stepMatch(state).state;
 const restored=restoreMatch(serializeMatch(state));assert.deepEqual(stepMatch(restored),stepMatch(state));
 const t4=performance.now();
 const record={seed,matchSeed,children:planned.rolls[0].children,shield:!!shield,ms:{opening:t1-t0,progressionAndOpeningRestore:t2-t1,startAndRestore:t3-t2,threeTicksRestore:t4-t3,total:t4-t0},preCombat,combatStart,afterThree:state};
 records.push(record);
 console.log(JSON.stringify({variant,seed,matchSeed,children:record.children,shield:record.shield,ms:record.ms,opening:state.roundResults.slice(0,3).map((r:any)=>({roundId:r.roundId,result:r.result,ticks:r.combatTicks,events:r.combatEventCount,hpBefore:r.hpBefore,hpAfter:r.hpAfter,goldBefore:r.goldBefore,goldAfter:r.goldAfter})),final:{hp:state.playerHp,gold:state.gold,level:state.level,xp:state.xp,nextMatchEventSeq:state.nextMatchEventSeq}}));
}
assert.equal(seen.size,43);
writeFileSync(`/tmp/b8-timeout-fix/tg/${variant}.states.json`,JSON.stringify(records));
console.log(JSON.stringify({summary:true,variant,count:records.length,definitions:[...seen].sort(),shieldSeeds:records.filter(r=>r.shield).map(r=>r.seed),ms:performance.now()-started,stageMs:Object.fromEntries(Object.keys(records[0].ms).map(k=>[k,records.reduce((sum,r)=>sum+r.ms[k],0)]))}));
