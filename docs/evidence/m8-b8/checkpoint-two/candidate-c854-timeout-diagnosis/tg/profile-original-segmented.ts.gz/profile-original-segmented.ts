import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { performance } from 'node:perf_hooks';
import { publicEquipmentPreparation, resolvePublicEquipmentChoices, finishPublicEquipmentBattle } from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/tests/fixtures/b8-public-equipment.ts';
import { buyXp, combineItems, deployMatchUnit, equipItem, nextRound, startMatchCombat, stepMatch } from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/src/simulation/match.ts';
import { restoreMatch, serializeMatch } from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/src/simulation/serialization.ts';
import { generateRoundRolls, initializeStreams } from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/src/simulation/m8/equipment.ts';
import { TEMPORARY_EQUIPMENT_POOL } from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/src/simulation/temporary-equipment.ts';
const sums:Record<string,{ms:number,calls:number}>={};
const timed=<T>(name:string,f:()=>T):T=>{const start=performance.now();try{return f();}finally{const t=sums[name]??={ms:0,calls:0};t.ms+=performance.now()-start;t.calls++;}};
(globalThis as any).__tgMeasure=timed;
const accepted=(r:any)=>{assert.equal(r.ok,true);return r.state;},seen=new Set<string>(),records:any[]=[];
const start=performance.now();
for(let seed=0;seed<512&&seen.size<43;seed++){
const matchSeed=Math.imul(seed,2654435761)>>>0;
const planned=timed('pureRollPlanning',()=>generateRoundRolls({equipment:initializeStreams(matchSeed).equipment,rolls:[]},[{parentItemInstanceId:'item-3',roundId:'2-5',playerLevel:6}],TEMPORARY_EQUIPMENT_POOL));
if(planned.rolls[0].children.every(c=>seen.has(c)))continue;
let state=timed('preparation.opening',()=>publicEquipmentPreparation(['gloves','gloves'],{seed:matchSeed}));
state=timed('preparation.combineAndAdvance',()=>{
let s=accepted(combineItems(state,'item-1','item-2'));
while(s.roundDefinitionId!=='2-5'){s=resolvePublicEquipmentChoices(s);if(s.phase==='preparation')s=finishPublicEquipmentBattle(s);s=resolvePublicEquipmentChoices(s);s=accepted(nextRound(s,s.round));}return resolvePublicEquipmentChoices(s);});
state=timed('preparation.buyXpDeployEquip',()=>{let s=state;while(s.level<6)s=accepted(buyXp(s));assert.equal(s.level,6);s=accepted(deployMatchUnit(s,'unit-1',{kind:'board',cell:{col:1,row:4}}));return accepted(equipItem(s,'item-3','unit-1',0));});
assert.deepEqual(state.temporaryEquipment.map((i:any)=>i.definitionId),planned.rolls[0].children);for(const child of state.temporaryEquipment)seen.add(child.definitionId);
state=timed('mechanism.startCombat',()=>accepted(startMatchCombat(state)));
const serialized=timed('checked.start.serialize',()=>serializeMatch(state));
const restoredStart=timed('checked.start.restore',()=>restoreMatch(serialized));
timed('checked.start.deepComparison',()=>assert.deepEqual(restoredStart,state));
const shield=state.combat?.units.flatMap((u:any)=>u.shieldLayers??[]).find((l:any)=>l.source.parentItemInstanceId);
if(shield){const corrupt=JSON.parse(timed('checked.shield.serialize',()=>serializeMatch(state)));const layer=corrupt.combat.units.flatMap((u:any)=>u.shieldLayers).find((l:any)=>l.source.parentItemInstanceId);layer.key=JSON.stringify([layer.source.ownerId,layer.source.sourceKind,layer.source.definitionId,layer.source.instanceId,layer.source.effectIndex]);timed('checked.shield.reject',()=>assert.throws(()=>restoreMatch(corrupt),/Invalid Match save: shield projection/));}
for(let i=0;i<3&&state.phase==='combat';i++)state=timed('mechanism.threeTicks',()=>stepMatch(state)).state;
const afterSerialized=timed('checked.after.serialize',()=>serializeMatch(state));
const restored=timed('checked.after.restore',()=>restoreMatch(afterSerialized));
const restoredStep=timed('checked.next.stepRestored',()=>stepMatch(restored)),originalStep=timed('checked.next.stepOriginal',()=>stepMatch(state));
timed('checked.next.deepComparison',()=>assert.deepEqual(restoredStep,originalStep));
records.push({seed,matchSeed,children:planned.rolls[0].children,shield:!!shield,openingTicks:state.roundResults.slice(0,3).map((r:any)=>r.combatTicks)});
}
assert.equal(seen.size,43);assert.equal(records.length,37);assert.deepEqual(records.filter(r=>r.shield).map(r=>r.seed),[123]);
const summary={node:process.version,routeCount:records.length,coverage:[...seen].sort(),shieldSeeds:records.filter(r=>r.shield).map(r=>r.seed),wallMs:performance.now()-start,sums,records};
writeFileSync('/tmp/b8-timeout-fix/tg/original-segmented.json',JSON.stringify(summary,null,2));console.log(JSON.stringify(summary));
