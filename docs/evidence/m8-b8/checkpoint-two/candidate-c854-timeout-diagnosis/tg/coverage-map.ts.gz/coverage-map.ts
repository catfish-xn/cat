import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { generateRoundRolls, initializeStreams } from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/src/simulation/m8/equipment.ts';
import { TEMPORARY_EQUIPMENT_POOL } from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/src/simulation/temporary-equipment.ts';
const candidates=Array.from({length:512},(_,seed)=>{const matchSeed=Math.imul(seed,2654435761)>>>0;const state=generateRoundRolls({equipment:initializeStreams(matchSeed).equipment,rolls:[]},[{parentItemInstanceId:'item-3',roundId:'2-5',playerLevel:6}],TEMPORARY_EQUIPMENT_POOL);return{seed,matchSeed,children:state.rolls[0].children};});
const seenOld=new Set<string>(),original:typeof candidates=[];
for(const c of candidates){if(c.children.every(v=>seenOld.has(v)))continue;original.push(c);c.children.forEach(v=>seenOld.add(v));if(seenOld.size===43)break;}
const seenNew=new Set<string>(),greedy:typeof candidates=[];
while(seenNew.size<43){const score=(c:typeof candidates[number])=>c.children.filter(v=>!seenNew.has(v)).length;const selected=candidates.reduce((best,c)=>score(c)>score(best)?c:best);assert.ok(score(selected)>0);greedy.push(selected);selected.children.forEach(v=>seenNew.add(v));}
assert.equal(original.length,37);assert.equal(greedy.length,35);assert.deepEqual([...seenOld].sort(),[...seenNew].sort());
const states=JSON.parse(readFileSync('/tmp/b8-timeout-fix/tg/original.states.json','utf8'));
assert.deepEqual(states.map(({seed,matchSeed,children}:any)=>({seed,matchSeed,children})),original);
const removed=original.filter(c=>!greedy.some(g=>g.seed===c.seed)).map(c=>{const r=states.find((s:any)=>s.seed===c.seed);return{...c,shieldCorruptionBranch:r.shield,retainedCarriers:Object.fromEntries(c.children.map(child=>[child,greedy.filter(g=>g.children.includes(child))])),distinctPairRetained:greedy.some(g=>JSON.stringify(g.children)===JSON.stringify(c.children))};});
const map=original.map((c,oldIndex)=>({...c,oldPosition:oldIndex+1,newPosition:greedy.findIndex(g=>g.seed===c.seed)+1||null}));
const summary={node:process.version,originalCount:original.length,newCount:greedy.length,coverage:[...seenNew].sort(),oldOrder:original.map(c=>c.seed),newOrder:greedy.map(c=>c.seed),removed,retainedShield:states.filter((r:any)=>r.shield&&greedy.some(g=>g.seed===r.seed)).map(({seed,matchSeed,children}:any)=>({seed,matchSeed,children})),map,greedy};
writeFileSync('/tmp/b8-timeout-fix/tg/coverage-map.json',JSON.stringify(summary,null,2));console.log(JSON.stringify(summary));
