const esbuild=require(process.cwd()+'/node_modules/esbuild'),fs=require('node:fs'),path=require('node:path');
esbuild.buildSync({entryPoints:['/tmp/b8-timeout-fix/tg/profile-original-segmented.ts'],outfile:'/tmp/b8-timeout-fix/tg/profile-original-segmented.cjs',bundle:true,platform:'node',format:'cjs',sourcemap:true});
