const fs=require('node:fs'),assert=require('node:assert/strict');
const load=v=>JSON.parse(fs.readFileSync(`/tmp/b8-timeout-fix/tg/${v}.states.json`,'utf8'));
const old=load('original');
const result=[];
for(const variant of ['lux-front','both-front']){
const current=load(variant);assert.equal(current.length,old.length);const changes=[];
for(let i=0;i<old.length;i++){
 const a=old[i],b=current[i];assert.equal(a.seed,b.seed);
 for(const phase of ['preCombat','combatStart','afterThree']){
  for(const field of ['playerHp','gold','level','xp','items','preparation','temporaryEquipment','equipmentState','scheduleReceipts','rngState','choiceRngState','rewardRngState','battleSeedRngState','nextMatchEventSeq','nextItemSerial','nextUnitSerial','augments','persistentGrowth','augmentProgress','streak'])assert.deepEqual(b[phase][field],a[phase][field],`${variant}/${a.seed}/${phase}/${field}`);
 }
 assert.deepEqual(b.combatStart.combatInputBasis,a.combatStart.combatInputBasis,`${variant}/${a.seed}/combatInputBasis`);
 assert.deepEqual(b.combatStart.combat,a.combatStart.combat,`${variant}/${a.seed}/combatStart.combat`);
 assert.deepEqual(b.afterThree.combat,a.afterThree.combat,`${variant}/${a.seed}/afterThree.combat`);
 const diffs=(aa,bb,path='')=>{if(JSON.stringify(aa)===JSON.stringify(bb))return[];if(aa&&bb&&typeof aa==='object'&&typeof bb==='object'){return [...new Set([...Object.keys(aa),...Object.keys(bb)])].flatMap(k=>diffs(aa[k],bb[k],path?`${path}.${k}`:k));}return[{path,old:aa,new:bb}];};
 changes.push({seed:a.seed,matchSeed:a.matchSeed,phaseDiffs:Object.fromEntries(['preCombat','combatStart','afterThree'].map(phase=>[phase,diffs(a[phase],b[phase])])),oldOpeningTicks:a.preCombat.roundResults.slice(0,3).map(r=>r.combatTicks),newOpeningTicks:b.preCombat.roundResults.slice(0,3).map(r=>r.combatTicks),oldOpeningEvents:a.preCombat.roundResults.slice(0,3).map(r=>r.combatEventCount),newOpeningEvents:b.preCombat.roundResults.slice(0,3).map(r=>r.combatEventCount)});
}
const totals=key=>changes.reduce((out,row)=>out.map((v,i)=>v+row[key][i]),[0,0,0]);
result.push({variant,count:changes.length,mechanismFieldsIdentical:true,fullCombatInputBasisIdentical:true,combatStartAndThreeTicksFullCombatIdentical:true,oldOpeningTicks:totals('oldOpeningTicks'),newOpeningTicks:totals('newOpeningTicks'),oldOpeningEvents:totals('oldOpeningEvents'),newOpeningEvents:totals('newOpeningEvents'),diffPaths:[...new Set(changes.flatMap(c=>Object.values(c.phaseDiffs).flatMap(v=>v.map(d=>d.path))))],changes});
}
fs.writeFileSync('/tmp/b8-timeout-fix/tg/old-new-comparison.json',JSON.stringify(result,null,2));
for(const {changes,...summary}of result)console.log(JSON.stringify(summary));
