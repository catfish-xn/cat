import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import inspector from 'node:inspector';
import {createServer} from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/node_modules/vite/dist/node/index.js';
const root='/workspace/scratch/2d61d723fa5a/cat-b8-phase2',out='/tmp/b8-timeout-fix/herald';
const rows=new Map();const record=(fn,args,elapsed)=>{const round=args[0]?.roundDefinitionId??'none';const key=`${round}:${fn}`;const r=rows.get(key)??{round,fn,count:0,ms:0};r.count++;r.ms+=elapsed;rows.set(key,r);};
globalThis.__heraldDiagnosticRecord=record;
const server=await createServer({root,plugins:[{name:'diagnostic-native-cjs',enforce:'pre',load(id){if(id.endsWith('/scripts/generate-m5-route.cjs'))return `import {createRequire} from 'node:module';const {run}=createRequire(${JSON.stringify(path.join(root,'package.json'))})(${JSON.stringify(path.join(root,'scripts/generate-m5-route.cjs'))});export {run};`;},transform(source,id){if(!id.endsWith('/tests/fixtures/m8-neutral-public-route.ts'))return;return source.replace("import * as api from '../../src/simulation/match';",`import * as rawApi from '../../src/simulation/match';
const api = new Proxy(rawApi, {get(target, prop) { const value=target[prop]; return typeof value !== 'function' ? value : (...args) => { const began=performance.now();try{return value(...args);}finally{globalThis.__heraldDiagnosticRecord(String(prop),args,performance.now()-began);} }; }});`);}}],server:{middlewareMode:true,ws:false},optimizeDeps:{noDiscovery:true,include:[]},appType:'custom'});
const session=new inspector.Session();session.connect();const post=(method,params={})=>new Promise((resolve,reject)=>session.post(method,params,(error,value)=>error?reject(error):resolve(value)));
try{
 const fixture=await server.ssrLoadModule('/tests/fixtures/m8-neutral-public-route.ts');rows.clear();
 await post('Profiler.enable');await post('Profiler.start');const began=performance.now();const result=fixture.publicHeraldEquipment(['ionic-spark']);const totalMs=performance.now()-began;const {profile}=await post('Profiler.stop');
 const baseline=JSON.parse(fs.readFileSync(`${out}/baseline-ionic.json`,'utf8'));assert.deepEqual(result,baseline.prepared);
 fs.writeFileSync(`${out}/preparation.cpuprofile`,JSON.stringify(profile));const report={node:process.version,totalMs,exactBaselineEqual:true,calls:[...rows.values()]};fs.writeFileSync(`${out}/preparation-profile.json`,JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
}finally{session.disconnect();await server.close();delete globalThis.__heraldDiagnosticRecord;}
