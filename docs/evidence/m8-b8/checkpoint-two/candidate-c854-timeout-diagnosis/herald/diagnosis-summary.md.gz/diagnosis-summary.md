# B7 Herald timeout diagnostic, no repository changes

- Repository HEAD at capture: 25a7fe3d5c099ae582a4e0a48717f7e323636dae.
- Original and current fixture SHA256: e73156da73c8ce83c449116bd8bc34964808135a386ba53243b2fca518cc691d.
- Toolchain: Node v22.23.3, npm 11.9.0. Exact PATH prefix is /tmp/b7-npm-cache/_npx/d18f28baf1132559/node_modules/node/bin.
- No source, test, fixture, test configuration, timeout, worker, or performance-load changes were made by this task. Other agents' B5 edits are outside this task.
- The original full-suite log /tmp/b8-checkpoint-two-final/npm-test.log ended with 131 files: 129 passed, 2 failed; 1857 tests: 1841 passed, 6 failed, 10 skipped. All six failures explicitly say Test timed out in 5000ms. Five are these B7 cases; the remaining B5 case belongs to another investigation.

## Original five-case preparation and validation split

Original helper timing, followed by a separate diagnostic executing the original case's positive round-trip, serialized equality, full successor state/events equality, and negative corruptions using node:assert/strict:

- ionic: helper 4773.95ms; validation 133.45ms; explicit restore 28.46ms; serialization 68.09ms; negative restore 10.72ms.
- even: helper 4708.69ms; validation 96.88ms; explicit restore 24.99ms; serialization 51.23ms; negative restore 9.89ms.
- dual: helper 4689.58ms; validation 98.56ms; explicit restore 27.14ms; serialization 51.01ms; negative restore 11.44ms.
- quicksilver: helper 4622.99ms; validation 341.77ms; explicit restore 89.83ms; serialization 225.79ms.
- edge-of-night: helper 4747.28ms; validation 329.71ms; explicit restore 86.63ms; serialization 217.75ms.

The validation measurements are diagnostic Node assertions, not claimed as unchanged Vitest case runtimes. serializeMatch itself calls restoreMatch, so its timing includes additional actual validation; explicit restore timing is not the total validation cost. Aura cases have four explicit positive restores and two negative restores; immunity cases have sixteen explicit positive restores. All baseline preparations have playerHp 61, gold 229, investmentHp 1024, pumpingRounds 19. All five complete round histories are exactly equal. Full original preparation, start result, and 15 successor Match states/events are stored per branch.

## Preparation hotspot

The separately instrumented original ionic helper produced a preparation exactly deep-equal to baseline-ionic.json. Total preparation 4717.64ms. Its 15 real combat starts lead to 5844 actual stepMatch calls costing 4642.09ms. Earlier informal 5444-tick count was incorrect; authoritative measured count is 5844.

CPU self-time samples: structuredClone ~2829ms (about 60%); advanceS13Tick ~469ms; garbage collection ~198ms. See raw preparation.cpuprofile and exact per-round counts in preparation-profile.json. The hotspot is the per-unit structuredClone at src/simulation/combat-s13.ts:100. Existing code ALREADY excludes mechanismDefinitions, mechanismState, and triggerLedger from the cloned object; remaining declaration fields include ability, itemPrograms, sources, triggers, mechanics, spellCrit and companion definitions. No clone optimization was implemented or experimentally patched. Sharing further fields would require a separately approved production change and aliasing/immutability/full-trajectory tests. Current evidence does not establish a restore-performance regression.

## Reuse boundary and decisions

1. Exact-prefix preparation caching can share ionic/dual through their matching rod/cloak choice prefix and even/quicksilver through their matching cloak prefix. Each consumer would need an independent copy and all existing restores. It does not reduce the first ionic or independent edge cold construction and therefore cannot by itself solve the default 5s threshold.
2. One real common component inventory is possible: choose rod at 4-4, cloak at 4-7, cloak at 5-4, belt at 5-7, gloves at 6-4; actual PvE direct drops supply sword x2 and vest x1. This covers each independently forked test's maximum required component multiset. It changes original choices, inventory and provenance, so is not an identical original-state prefix cache. The first case still executes all 15 fights and 5844 ticks. Not implemented.
3. A command-generated raw save input could preserve the five cases' explicit Herald restore/action identity/immunity/cleanup assertions if each case independently restores it within its timer. It would stop executing each original equipment acquisition branch, battles and combine/equip commands during those tests. That is an acceptance-layer change requiring a decision, not a transparent performance fix. Current baseline files contain the original helper's returned restored preparation and are NOT represented as pre-restore raw inputs.
4. The previously discussed empty-board concessions were cancelled by the narrowed instruction before any edit. No candidate concession route was executed. No target numbers, history, state, events, or assertions were modified.

## Artifacts

- capture.mjs: executes original helper and captures all five preparations, starts and 15 ticks. A diagnostic-only Vite loader imports the unchanged CJS command driver through native createRequire.
- original-fixture.ts: byte-for-byte source before investigation.
- toolchain.txt.
- baseline-capture.log; baseline-manifest.json; baseline-{ionic,even,dual,qss,edge}.json.
- measure-validation.mjs; validation-timings.log; validation-timings.json.
- profile-preparation.mjs; preparation-profile.log; preparation-profile.json; preparation.cpuprofile.
- diagnostic-node24-loader-failure.log and diagnostic-node22-loader-failure.log: preserved initial loader errors; no measurement claim relies on these failed runs.
- SHA256SUMS: hashes for the diagnostic package.

No candidate patch exists, so no candidate-vs-baseline differences or candidate test/typecheck success is claimed. The originally requested post-fix B7 tests/typecheck were superseded by the read-only diagnostic instruction and were not run by this worker.
