import fs from 'node:fs';import assert from 'node:assert/strict';
import {createServer} from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/node_modules/vite/dist/node/index.js';
const root='/workspace/scratch/2d61d723fa5a/cat-b8-phase2',out='/tmp/b8-timeout-fix/herald';
const server=await createServer({root,server:{middlewareMode:true,ws:false},optimizeDeps:{noDiscovery:true,include:[]},appType:'custom'});
const rows=[];
try {
 const api=await server.ssrLoadModule('/src/simulation/match.ts');const {restoreMatch,serializeMatch}=await server.ssrLoadModule('/src/simulation/serialization.ts');
 for(const name of ['ionic','even','dual','qss','edge']){
  const original=JSON.parse(fs.readFileSync(`${out}/baseline-${name}.json`,'utf8'));
  const timings={restoreMs:0,serializeMs:0,stepMs:0,deepEqualityMs:0,negativeRestoreMs:0,restoreCalls:0,negativeCalls:0};
  const measured=(key,fn)=>{const t=performance.now();try{return fn();}finally{timings[key]+=performance.now()-t;}};
  const save=s=>measured('serializeMs',()=>serializeMatch(s));
  const restore=s=>{timings.restoreCalls++;return measured('restoreMs',()=>restoreMatch(s));};
  const step=s=>measured('stepMs',()=>api.stepMatch(s));
  const equal=(a,b)=>measured('deepEqualityMs',()=>assert.deepEqual(a,b));
  const trip=s=>{const saved=save(s),restored=restore(saved);equal(restored,s);assert.equal(save(restored),saved);equal(step(restored),step(s));return restored;};
  const corrupt=(s,mutation)=>{const saved=save(s);equal(restore(saved),s);const bad=JSON.parse(saved);mutation(bad);timings.negativeCalls++;measured('negativeRestoreMs',()=>assert.throws(()=>restoreMatch(bad)));};
  // Clone the saved setup, then independently execute exactly the original case's
  // positive round-trips, full successor equality, and negative corruptions.
  const total=performance.now();let s=structuredClone(original.prepared);const started=api.startMatchCombat(s);assert(started.ok);s=started.state;trip(s);
  if(['ionic','even','dual'].includes(name)){
   s=step(s).state;trip(s);const c=s.combat.units.find(u=>u.id==='unit-1').mechanismState.statuses.flatMap(g=>g.contributions).find(c=>c.source.definitionId==='void-charge-project-v1');assert(c);equal(JSON.parse(JSON.parse(c.key)[8]),[original.definitions.length,1]);
   corrupt(s,x=>{const target=x.combat.units.find(u=>u.id==='unit-1');target.maxMana=0;target.mana=0;});
   corrupt(s,x=>{const target=x.combat.units.find(u=>u.id==='unit-1');const status=target.mechanismState.statuses.flatMap(g=>g.contributions).find(c=>c.source.definitionId==='void-charge-project-v1');status.source.effectIndex=2;});
  } else {
   for(let i=0;i<15;i++){s=step(s).state;trip(s);}
   if(name==='qss')equal(s.combat.neutralReceipts.controls,[]);else assert.equal(s.combat.neutralReceipts.controls.length,1);
  }
  const totalMs=performance.now()-total;const row={name,helperPreparationMs:original.fixtureMs,validationTotalMs:totalMs,...timings};rows.push(row);console.log(JSON.stringify(row));
 }
 fs.writeFileSync(`${out}/validation-timings.json`,JSON.stringify(rows,null,2));
}finally{await server.close();}
