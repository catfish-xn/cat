import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createServer} from '/workspace/scratch/2d61d723fa5a/cat-b8-phase2/node_modules/vite/dist/node/index.js';
const root='/workspace/scratch/2d61d723fa5a/cat-b8-phase2';
const destination='/tmp/b8-timeout-fix/herald';
const label=process.argv[2];
assert(['baseline','candidate'].includes(label));
const source=fs.readFileSync(path.join(root,'tests/fixtures/m8-neutral-public-route.ts'),'utf8');
const sha=crypto.createHash('sha256').update(source).digest('hex');
const server=await createServer({root,plugins:[{name:'diagnostic-native-cjs',enforce:'pre',load(id){if(id.endsWith('/scripts/generate-m5-route.cjs'))return `import { createRequire } from 'node:module'; const { run } = createRequire(${JSON.stringify(path.join(root,'package.json'))})(${JSON.stringify(path.join(root,'scripts/generate-m5-route.cjs'))}); export { run };`;}}],server:{middlewareMode:true,ws:false},optimizeDeps:{noDiscovery:true,include:[]},appType:'custom'});
const manifest={label,sourceSha256:sha,cases:[]};
try {
 const fixture=await server.ssrLoadModule('/tests/fixtures/m8-neutral-public-route.ts');
 const api=await server.ssrLoadModule('/src/simulation/match.ts');
 const serialization=await server.ssrLoadModule('/src/simulation/serialization.ts');
 for (const [name,definitions] of [['ionic',['ionic-spark']],['even',['evenshroud']],['dual',['ionic-spark','evenshroud']],['qss',['quicksilver']],['edge',['edge-of-night']]]) {
  const t=performance.now();
  const prepared=fixture.publicHeraldEquipment(definitions);
  const fixtureMs=performance.now()-t;
  assert.equal(prepared.roundDefinitionId,'6-7');assert.equal(prepared.phase,'preparation');assert(prepared.playerHp>0);
  assert.deepEqual(serialization.restoreMatch(serialization.serializeMatch(prepared)),prepared);
  const start=api.startMatchCombat(prepared);assert(start.ok);
  const ticks=[];let current=start.state;
  for(let i=0;i<15;i++) {const step=api.stepMatch(current);ticks.push(step);current=step.state;assert.deepEqual(serialization.restoreMatch(serialization.serializeMatch(current)),current);}
  const result={name,definitions,sourceSha256:sha,fixtureMs,prepared,start,ticks};
  fs.writeFileSync(path.join(destination,`${label}-${name}.json`),JSON.stringify(result));
  const row={name,definitions,fixtureMs,playerHp:prepared.playerHp,gold:prepared.gold,augmentProgress:prepared.augmentProgress,roundResults:prepared.roundResults.filter(r=>r.round>=21),target: start.state.combat.units.find(u=>u.id==='unit-1')};
  manifest.cases.push(row);
  console.log(JSON.stringify({label,name,fixtureMs,playerHp:row.playerHp,gold:row.gold,augmentProgress:row.augmentProgress,targetMaxHp:row.target.maxHp}));
 }
 fs.writeFileSync(path.join(destination,`${label}-manifest.json`),JSON.stringify(manifest,null,2));
} finally {await server.close();}
