from pathlib import Path
p=Path('/tmp/b8-tg35-opening-cpu/mirror/tests/m8-b5-temporary.test.ts')
s=p.read_text().replace('/tmp/b8-tg43-current-segmented/segmented-results.json','/tmp/b8-tg35-opening-cpu/segmented-results.json')
s="import { Session as __CpuSession } from 'node:inspector';\n"+s
old="    __tgEnabled = true;\n    const __tgCaseStart = performance.now(), __tgCpuStart = process.cpuUsage();"
new="""    const __cpuSession = new __CpuSession();
    __cpuSession.connect();
    __cpuSession.post('Profiler.enable');
    __cpuSession.post('Profiler.setSamplingInterval', { interval: 1000 });
    __cpuSession.post('Profiler.start');
    __tgEnabled = true;
    const __tgCaseStart = performance.now(), __tgCpuStart = process.cpuUsage();"""
assert s.count(old)==1
s=s.replace(old,new)
old="      __tgEnabled = false;\n      const summary ="
new="""      __tgEnabled = false;
      __cpuSession.post('Profiler.stop', (error, result) => {
        if (error) throw error;
        __tgWriteFileSync('/tmp/b8-tg35-opening-cpu/tg35.cpuprofile', JSON.stringify(result.profile));
        __cpuSession.disconnect();
      });
      const summary ="""
assert s.count(old)==1
s=s.replace(old,new)
p.write_text(s)
