from pathlib import Path
import json,collections
root=Path('/tmp/b8-tg35-opening-cpu');p=json.loads((root/'tg35.cpuprofile').read_text());nodes={n['id']:n for n in p['nodes']};parents={c:n['id'] for n in p['nodes'] for c in n.get('children',[])}
def desc(i):
 n=nodes[i]['callFrame'];return f"{n['functionName'] or '<anon>'} | {n['url']}:{n['lineNumber']+1}:{n['columnNumber']+1}"
def path(i):
 r=[]
 while i in nodes:
  r.append(i);i=parents.get(i)
 return r
selftime=collections.Counter();inclusive=collections.Counter();prep_self=collections.Counter();prep_incl=collections.Counter();ancestors={i:path(i) for i in nodes};total=0;prep_total=0
for i,dt in zip(p['samples'],p['timeDeltas']):
 total+=dt;selftime[desc(i)]+=dt
 keys={desc(j) for j in ancestors[i]}
 for k in keys:inclusive[k]+=dt
 if any(nodes[j]['callFrame']['functionName']=='equipped' for j in ancestors[i]):
  prep_total+=dt;prep_self[desc(i)]+=dt
  for k in keys:prep_incl[k]+=dt
out={'samples':len(p['samples']),'profileUs':p['endTime']-p['startTime'],'sampleUs':total,'preparationSampleUs':prep_total,'self':selftime.most_common(),'inclusive':inclusive.most_common(),'preparationSelf':prep_self.most_common(),'preparationInclusive':prep_incl.most_common()}
(root/'cpu-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print('samples',len(p['samples']),'sampleMs',total/1000,'prepMs',prep_total/1000)
for name,data in [('PREP_SELF',prep_self),('PREP_INCLUSIVE',prep_incl),('SELF',selftime)]:
 print('\n'+name)
 for k,v in data.most_common(45):print(f'{v/1000:9.3f} {v/total*100:6.2f}% {k}')
