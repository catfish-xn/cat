#!/usr/bin/env bash
set -u
export PATH=/tmp/b7-npm-cache/_npx/d18f28baf1132559/node_modules/node/bin:$PATH
ROOT=/tmp/b8-tg-private-copy
cd "$ROOT/mirror"
for version in before candidate; do
 cp "$ROOT/$version.ts" src/simulation/combat-s13.ts
 npm test -- tests/m8-b5-temporary.test.ts -t 'all 43 eligible child definitions bind through real Match snapshots and restore' > "$ROOT/$version.log" 2>&1
 echo $? > "$ROOT/$version.exit"
done
