const fs=require('node:fs'),assert=require('node:assert/strict'),ts=require(process.cwd()+'/node_modules/typescript');
const root='/tmp/b8-tg-private-copy';
const build=name=>{
 const source=fs.readFileSync(`${root}/${name}.ts`,'utf8');const start=source.indexOf('  const units: S13Unit[] = state.units.map(unit => {',source.indexOf('export function advanceS13Tick'));
 const body=source.slice(source.indexOf('{',start)+1,source.indexOf('\n  }).sort(compareIds);',start));
 const js=ts.transpileModule(`function clone(unit: any) {${body}\n}`,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;
 return new Function('structuredClone','EMPTY_RUNTIME',js+'; return clone;')(structuredClone,{attackCount:0,castCount:0,attackSpeedBps:0,abilityPowerFlat:0,rangeBonus:0,nextAttackMagic:0,nextAttackPhysical:0,permanentAdBps:0,buddyTriggered:false});
};const baseline=build('before'),candidate=build('candidate');
const plain=()=>({id:'unit-1',cell:{col:0,row:0},alive:true,cooldownTicks:3,moveCooldownTicks:2,runtime:{attackCount:1},statuses:[],shieldLayers:[],tasks:[]});
const results=[];function test(name,fn){fn();results.push({name,passed:true})}
test('plain missing optional fields and key ordering',()=>{const a=baseline(plain()),b=candidate(plain());assert.deepEqual(a,b);assert.deepEqual(Object.keys(a),Object.keys(b));});
test('same-unit aliases and cycles retained',()=>{const make=()=>{const u=plain(),shared={v:3};u.extra={a:shared,b:shared};u.extra.self=u.extra;return u};const a=baseline(make()),b=candidate(make());assert.deepEqual(a,b);assert.equal(b.extra.a,b.extra.b);assert.equal(b.extra.self,b.extra)});
test('cross-unit alias detached independently',()=>{const shared={v:1},a=plain(),b=plain();a.extra=shared;b.extra=shared;for(const clone of [baseline,candidate]){const x=clone(a),y=clone(b);assert.notEqual(x.extra,y.extra);x.extra.v=2;assert.equal(shared.v,1);assert.equal(y.extra.v,1)}});
test('startingCell original alias stays intentional',()=>{for(const clone of [baseline,candidate]){const u=plain();u.startingCell={col:1,row:2};assert.equal(clone(u).startingCell,u.startingCell)}});
test('unknown function remains DataCloneError',()=>{for(const clone of [baseline,candidate]){const u=plain();u.extra=()=>0;assert.throws(()=>clone(u),e=>e.name==='DataCloneError')}});
test('ordered changing getters same reads and output',()=>{const make=()=>{const u=plain(),trace=[];for(const key of ['mechanismDefinitions','mechanismState','triggerLedger','startingCell','cooldownTicks','moveCooldownTicks']){let count=0;Object.defineProperty(u,key,{enumerable:true,configurable:true,get(){trace.push([key,++count]);return key==='cooldownTicks'||key==='moveCooldownTicks'?count:key==='startingCell'?undefined:{key,count}}})}return {u,trace}};const x=make(),y=make();assert.deepEqual(baseline(x.u),candidate(y.u));assert.deepEqual(x.trace,y.trace)});
test('inherited setter cannot change define-own behavior',()=>{for(const clone of [baseline,candidate]){let hits=0;const u=plain();Object.defineProperty(u,'injected',{enumerable:true,get(){Object.defineProperty(Object.prototype,'startingCell',{configurable:true,set(){hits++}});return true}});try{const result=clone(u);assert.equal(hits,0);assert(Object.hasOwn(result,'startingCell'));assert.deepEqual(result.startingCell,u.cell)}finally{delete Object.prototype.startingCell}}});
console.log(JSON.stringify({scope:'Extracted private-copy map semantics only; not full command-stream equivalence',results},null,2));
