# Approved five-case raw Herald fixture implementation

Repository base HEAD: f13fd570c15cb1699c50b27e4f0a1b37b17c0985. No commit was created by this worker. Only the approved fixture/test/new-generator/new-data scope changed; no production, package, timeout, worker or performance configuration changed.

## Results

- Explicit --write succeeded in 37.73s; fresh five raw exports preceded loading serialization.ts, verified by the SSR module graph.
- The write run then independently restored all five inputs and proved full preparation/start/fifteen successor state+events equality with the old diagnostic baseline. Those old prepared objects were restored diagnostic outputs and were used only for comparison, never as new raw generation inputs.
- A separate default verification succeeded in 37.52s by rerunning the complete 33-battle driver and original five equipment branches, then reproducing all seven raw/trajectory/manifest files byte-for-byte. It needs no old baseline or /tmp input.
- Actual unchanged preparation count is 14 battles and 5,844 ticks per branch. Prior informal “15” count included a counting mistake; its initial failed assertion log is retained. The 6-7 Herald combat starts after the raw preparation boundary. No combat/tick was removed.
- Five equipment tests passed in 99/97/104/402/363ms; the unchanged empty-equipment control passed in 126ms. Six selected tests passed; only the test-name filter skipped the other 24.
- The complete original match-wiring file passed all 30 tests, no skips. Typecheck passed.
- Source binding: d9dc028fc389459bd7d2f020988faeac9c14ebe623e907dddd790f677fc319e5. Content digest: fnv1a32-utf16:314b4c1f.

## Timing boundary, not a performance claim

Old preparation was 4.62–4.77s per original live branch, plus separately measured validation around 0.10–0.34s. The approved five recovery-specific cases now parse independent raw input and execute the complete production restore and every original positive/negative assertion inside their unchanged five-second timer. Raw strings are immutable; neither parsed objects nor restored outputs are cached. Live command generation and reproducibility have a separate repeatable verifier gate. New/old totals are not evidence of improved engine performance. Existing performance gates, load and thresholds are untouched.

## Review files and evidence to archive

Repository deliverables:
- tests/fixtures/m8-neutral-public-route.ts
- tests/m8-b7-match-wiring.test.ts
- tests/fixtures/m8-herald-raw/{generate.ts,raw-import.d.ts,README.md,manifest.json,trajectory.json,five named .json inputs}
- scripts/verify-m8-herald-fixtures.cjs

Implementation evidence in this directory (temporary until parent archives it):
- toolchain.txt
- generate-write.log and verify-independent.log
- targeted-tests.log and match-wiring-tests.log
- typecheck-final.log and status.json
- comparison-evidence.json: prior diagnostic input hashes, old baseline source identity, full-state equivalence indices, unchanged HP/gold/investment
- source-files-sha256.json and tracked-diff.patch
- generate-write-initial-count-failure.log and typecheck-initial.log retained as failed attempts

Old diagnostics are at /tmp/b8-timeout-fix/herald; their raw logs and five diagnostic snapshots remain intact. Default repository verification does not depend on that directory. Full suite, final commit/SHA, bundle budget and CI belong to the parent and are not claimed by this worker.
