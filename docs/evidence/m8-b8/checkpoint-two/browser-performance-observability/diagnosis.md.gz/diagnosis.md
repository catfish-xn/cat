# CI200 input-dev / M6 performance 只读诊断

## 结论

确定的直接失败是首次 `page.evaluate` 期间 Playwright target 丢失。现有材料能排除性能脚本自身 finally 提前关页、32 分钟 GitHub job timeout 和已返回的性能 gate 断言；不能确定 target 为什么消失，不能认定 OOM、浏览器 crash 或偶发失败。原始 artifact 缺少 Chromium stderr、退出信号、page crash / browser disconnect 事件、进程树内存与 kernel/cgroup OOM 证据，也没有 evaluate 内分段检查点。不能将失败归给 B9 bounded import，该调用尚未开始。

真实负载和领域恢复工作确已因 B8 内容接线发生变化：同一脚本、同一 Chromium 的旧 CI170 已通过，而 CI200 最大 record/prefix 显著增大，原测量路径仍执行真实 restore/replay。这样支持继续调查真实计算/分配成本，不支持修改门槛或把失败归为偶发，也不足以因果认定这些成本杀死了浏览器。

## 证据身份

- 原任务：CI200 `c8543e192589cdc52b2a2119a45d5bfd613d8bf7`，job `114152012025`。
- https://github.com/catfish-xn/cat/actions/runs/38031091668/job/114152012025
- `/workspace/shared/b8-c854-ci/job-114152012025.log`。
- `/workspace/shared/b8-c854-ci/artifact-11663227295.zip`，其中 `m6-performance/manifest.json` 与单独 `m6-performance-failure.json` 对应，此外 `m5-ci-timing-input-dev-sample1/m6-performance.json` 是 wrapper 的完成记录。
- 本地 c854 commit object 不在该 clone，未 fetch。当前 HEAD `f26826a` 的 production src tree 为 `5f9b62228b236074efd78b50a571cc26d23858e5`；在本地按仓库函数计算的整个 `sourceFingerprint` 为 `5694c83015781eb7ce6e32fc2799dcbf31218aa31d1319c269de8d66e2a9a497`，与 CI200 manifest 开始/结束值完全相同。
- 同法计算 performance `scriptHash=e0838a9624a51c72048e31034ec80472f4fd915568a4491a209326e4519de142`，亦与 CI200 相同。该 hash 是仓库 canonical(value) 后 SHA256，不能和直接文件 sha256sum 混比。因此本文可用当前脚本/生产源码精确行号解释 CI200。
- 已读 AGENTS。未改仓库、timeout/worker/负载/gate/skip/production/UI，未启动本机 Chromium，未重跑 CI 或重新生成 routes。

## 失败时间线及排除项

- log:L1：job 从 `06:48:14.285Z` 开始。
- log:L453：native input 31 cases `passed:true`；L458：真实 touch-cannon `passed:true`（其原有 B9 deferral 如实保留）；L464–466：layout/storage/components 通过。
- wrapper：performance 从 `07:04:22.785Z` 至 `07:06:35.987Z`，共 133.202s；exitCode=1、signal=null、error=null。不是 wrapper 收到 kill/timeout 的表现。wrapper `scripts/ci-m5-step.cjs:L9–22` 使用 spawnSync，无 timeout 选项。
- failure manifest:L15、390、410–413：script start `07:04:23.070Z`，routeGenerationMs=85520.744956，failure endedAt=`07:06:05.867Z`，durationMs=102850.219884，Node 自身 peakRSS=2397937664。
- 所以约 85.52s 在生成五条路线，剩余约 17.33s 才包含启动 Chromium、创建/导航空页、evaluate 参数传递及函数执行。不能说 evaluate 跑了 102.85s。
- log:L468–471：`page.evaluate: Target page, context or browser has been closed`，栈为 performance:L54:34，`log:[]`。
- performance:L189 先 catch/打印错误，L190 才设置 endedAt/durationMs、写 manifest，然后 `await browser?.close(); await server?.close();`。唯一 browser.close 在此。因而 finally 是失败之后的清理，不能反过来当起因。L129 内 finally 仅关闭 IndexedDB repository / deleteDatabase，没有 page/context/browser.close。
- log:L472 于 `07:06:35.944Z` 才打印汇总，比 manifest endedAt 晚约30.08s。这个约30s属于 manifest 写完后的 browser/server 关闭阶段；脚本没有分段记录，不能进一步分配给哪一个 close。
- `.github/workflows/ci.yml:L98–140`：job timeout=32min，matrix fail-fast=false；L124–136 shell sequential commands。实际约18m22s就结束，随后正常上传 artifact（log:L473–502），不是32min deadline。也没有 cancellation 提示。
- `src/m6/limits.ts:L11–17` 的 30s completeImport/2s firstSeek 等是末尾比较的 regression gates，不是关闭浏览器的定时器；performance:L188 才 assert gates，该位置未到达。初始 evaluate 本身没有设置100s或其他计时关闭逻辑。
- failure manifest:L407–409：Chrome153、errors=[]、failure；无 measurements、lifecycle、boundedImport。L53只监听 pageerror 与 console.error，未监听 page crash/page close/context close/browser disconnect，也未采集 browser stderr。因此 errors=[]不能排除 crash/OOM，不能证明 callback 一行未执行。

## 实际可能运行到的代码范围

首次 evaluate 覆盖 performance:L54–130。错误既可能发生于参数序列化/传输、模块 import，也可能在下面任意恢复/测量/回收阶段；现有证据不能定位到其中一行。

1. L55–58 导入生产模块并取 fixtures。
2. L66 `new BattleHistory(current.runId,current.battles,current.currentBattle)`，构造会复制完整历史，且 `src/replay/history.ts:L113–117` 对当前 prefix 调 `validateBattleRecord`。
3. L71–74、109：建 complete BattleHistory，12次真实 exportFile，含完整 match structuredClone；`src/persistence/format.ts:L43–46` 为 JSON.stringify → Blob。
4. L110–112：只有超过 MAX_BATTLE_RECORDS 才 defer。CI200 当前最大 prefix 为 round-33（manifest:L394）；按原目录 `round-catalog.ts:L9–41`，它是6-2、28场完成战斗+1个当前prefix，共29<=30。因此若运行到这里，会执行完整 current validateFile，不会走 B9 skip。
5. `format.ts:L36–40、27–29` parse/restore/clone → `validateBattleCollection`；`history.ts:L72–97` 对历史逐场 inspect；L46–69 又真实 `restoreMatch(record.context)`、startMatchCombat、逐tick stepMatch、逐事件/最终hash复核。
6. L114–118：3次 PlaybackSession constructor+首次seek、12次 cachedSeek；`src/replay/playback-session.ts:L20–24、35–49` 的 constructor 再验证完整 record，seek 用真实 stepCombat 并保留 checkpoint clones。
7. L120–129：真实 stats 聚合、生成 summary/gates、IndexedDB清理。

full import-dependent pipeline L76–106 是原有 B9 defer callback，确实不执行；这不等于上述 current restore/firstSeek 都被跳过。lifecycle:L135起与独立 boundedImport:L157起在首次 evaluate 返回之后，当前 run 没到达。

传入 evaluate 的 current 包含 completed battles（L34、130），而 manifest 的 incrementalBytes 仅来自 `{match,currentBattle,battleKeys}`（L33）。不能将2190029B当作 current envelope或整个 evaluate 参数体积；后者没有落盘测量。它同时传 complete、current、largest record、full-load。跨进程序列化/重复保留/克隆的分配成本也需纳入调查，不能只看某一个文件大小。

## CI170 对照及 B8 真实负载变化

现有对照：`/workspace/shared/b8-ci170-evidence/selected-artifact-evidence/11659826390/m6-performance/manifest.json`，sha `4554f5afee219416be410ff7edbd16ffbeb7daf5`；同 scriptHash、同 Chrome153；passed=true。旧CPU AMD EPYC9V45，新9V74，均4逻辑CPU/约16.77GB总RAM，不能当同机受控性能对比。git diff确认两个版本间 performance脚本、generate-m5-route、full-load-helper、replay/persistence/m6无差异；simulation变更包含B8 restore/runtime及其输入。

- completeBytes：23817822 → 25153739（+5.61%）。
- incrementalBytes（有限口径）：1708858 → 2190029（+28.16%）。
- incrementalEvents：3022 → 3614（+19.59%）。
- 最大record：1547599 → 1982398（+28.10%），选择从round34移至round33。
- bounded complete：21042949 → 21585345（+2.58%）；新run未测其import耗时。
- route generation：54854.84 → 85520.74ms（+55.90%）；全部route ticks：60761 → 55259（−9.06%）。负载不是仅因总tick数变多。
- Node自身peakRSS：1847398400 → 2397937664（+29.80%）。这不是Chromium或全部子进程峰值，也不是可用RAM/cgroup限额，不足以认定或排除OOM。
- CI170 firstSeek max637.4ms、boundedImport max4511.8ms曾通过。CI200没有任何返回样本，不能宣称它们超预算或沿用旧通过结论。
- 原 full-load helper 仍是公开command路线（helper:L1–9），但实际装备从旧最终5件变成15件；CI200 manifest:L228–246显示round36/37为9玩家+8敌人+15装备、round38为9玩家+1敌人+15装备。L20–26仍记 `full-load-15-equipment` B8 skipped，因为脚本L41–43无条件走原defer wrapper。观察到达15件不等于原assert已恢复执行，不能自行解除skip或称原full-load gate已通过。
- `serialization.ts:L119、187–188`接入B8真实恢复；`b8-restore.ts:L29–32`重建冻结loot ledger，L119–145折叠当前/前缀provenance、restoreCombatInput，finished时还会L149–216重放当前suffix。历史record每次restore其context时都会带入新增真实规则工作。调用图可证这些成本存在；本次缺profile，不能给其耗时比例或认为它就是浏览器退出原因。

## 最小仍缺证据 / 合理下一步

当前只读资料已经穷尽关闭根因所需的关键字段；无需也不应为了“再试一次”无诊断重跑。

若得到额外诊断授权，保持相同candidate、脚本测量workload、样本、gate、timeout、worker与现有skip，做一次观测性取证即可：
- 开启 Playwright browser 启停/stderr日志（含退出code/signal），采集 page crash/close、context close、browser disconnected 事件及单调时间；不要改成别的浏览器或启动负载参数。
- 采集进程树RSS/可用内存、cgroup memory.events/限制与有权限获取的kernel OOM证据，特别要区分Node和Chromium。高RSS不自动等于OOM。
- 首次evaluate入口、imports完成、BattleHistory完成、fullCapture完成、current validateFile完成、各firstSeek前后、return前后做低开销阶段记录；时间标记放在原测量区外，不删/替换fixture、不减小样本、不增加warmup、不更改真实性验证。
- 如允许，另外记录evaluate实际序列化参数字节数和每阶段进程内存，区分传输/反序列化与真实restore/replay热点。
- 只有取到退出原因和最后完成的阶段，才决定修复属于基础设施/测量运输还是生产域恢复；生产优化另需授权，不能靠加timeout、少负载、放宽gate或skip解决。

本诊断未执行上述建议。当前建议向用户报告“首次evaluate target关闭，原因未决；真实B8负载/恢复成本增加已证实存在，但崩溃/OOM因果未证实”。

## 同run input-preview范围核对（补充）

- job114152012069为input-preview-sample1，结果success；对应artifact11663022779。
- `.github/workflows/ci.yml:L130–135`只在MODE=dev执行m6-storage/components/performance/retry/application-failures。preview不执行这个performance脚本。
- `job-114152012069.log:L433–439`出现m6-performance只是shell正文的回显，受同段if条件控制；并非实际执行证据。
- 已直接查zip目录，只有`m5-input-preview/performance.json`及input/touch-route/layout等timing，没有m6-performance/manifest或m6-performance timing。
- preview performance.json是首轮正常战斗的frame intervals与observer heap：normal-combat 212帧，after-normal-combat ledgerLength119、combatTick164；与33战历史、最大prefix/record的M6 restore/replay测量不同，无可比的evaluate payload字节字段。
- 因此同run preview success不能解释dev target关闭，也不能提供同M6负载通过对照。已有CI170才是同scriptHash/Chrome的历史对照，仍有CPU和域内容差异。
