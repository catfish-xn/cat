# CI200 首次关闭后的最小观测性补丁

状态：已获父代理解除源锁后，应用于 scripts/verify-m6-performance.cjs；本worker未提交。未运行Chromium、performance脚本、benchmark或CI。仅检查JS语法与文本/AST结构。

## 具体改动

- 新L11–24：诊断辅助字段与日志。每条事件含sequence、event、at（UTC ISO）、elapsedMs（从原started起）、stage（最后观察到的流程阶段）、cleanupStarted、details。
- 每条事件同步追加到既有output下 diagnostics.jsonl，并同步附加到report.diagnostics.events，console用固定前缀 `__M6_PERF_DIAGNOSTIC__`。第一条采用w，其余a，避免复用output时混入旧run。附加文件写失败仅记录report.diagnostics.writeErrors，不覆盖原failure或exitCode。
- report.diagnostics.schemaVersion=1，file=diagnostics.jsonl；browserProcessExit明确写明chromium.launch返回的公开Browser API不暴露浏览器进程exitCode/signal。
- process.once('exit')只记录当前Node退出，details明确processKind=node、pid、exitCode，绝不伪装Chromium退出。Node若被SIGKILL，此事件不保证发生；没有退出事件不证明未退出。
- 新L69：browser.disconnected事件，details.connected=browser.isConnected()。
- 新L71：page.crash事件，details.closed与browserConnected。
- 新L73–77：追加独立console监听器，仅收固定前缀的log；原pageerror及console.error数组规则逐字保留。
- 新L79–82起：首次evaluate请求/入口/导入、current History、fullCapture、current validateFile、各次firstSeek前后、cached seeks后、stats和内部数据库清理阶段。浏览器标记附browserPerformanceMs，主进程接收时另有elapsedMs；异步传输延迟不能当作该函数原始耗时。
- 新L171、176、197、200、230：首次evaluate返回、lifecycle前后、bounded import前后。
- 新L235：原endedAt/durationMs、资源记录完成后，标记cleanupStarted=true及script-cleanup-start，然后执行原manifest写出、browser.close、server.close和summary。因此正常finally触发的browser disconnected为cleanupStarted=true，可与测量阶段掉线区分。
- manifest写入后发生的disconnect/Node exit只会追加到diagnostics.jsonl与CI日志，不能期待已写出的manifest包含后续事件。二者均处于既有artifacts/目录，不修改工作流归档配置。

## 保持不变的合同

node --check通过。validate-structure.cjs的13项文本/AST校验通过：
- 12个measure/measured调用、计时包装函数、fullCapture helper与所有timed callbacks完全一致。
- 五条route生成、选择逻辑、payload，所有defer/skip及其保留回调不变。
- lifecycle函数、boundedImport整个evaluate（含原开始/结束计时）逐字不变。
- chromium.launch参数、page.goto不变，无launchServer、私有browser接口、轮询、trace或exposed binding。
- 原catch、report.passed、performance gates和阈值保持；原错误数组监听代码保持。
- 所有新增mark/diagnostic调用均不在measure/measured回调内；没有新增warmup、样本、负载或更改timer起止。
- git diff --check通过；应用文件与已校验candidate完全相同。

观测日志存在有限CPU/IO开销，不能承诺零扰动；不会用阶段标记替代原gate测量结果，也不能仅凭browser-disconnected事件判OOM。真正Chromium退出码/信号和系统OOM信息本补丁并未声称采集。

## 归档

- verify-m6-performance.original.cjs：原始完整字节，原repository scriptHash与CI200一致。
- ci200-first-failure.original.json：首失败原manifest副本；未改原artifact/report。
- observability.patch：准备阶段候选补丁；applied.diff：实际仓库差异，仅该脚本。
- verify-m6-performance.candidate.cjs：实际应用候选。
- structure-applied.json、validate-structure.cjs：结构对照结果及检查脚本。
- SHA256SUMS：此目录所有非checksum文件校验和。

原文件SHA256：bc2df81af33fd6bcdc2c202ce0ca0b5605c8756f5ccd9ad405f257bee4a860a2。
新文件SHA256：7e7213a5f9e49d38ea262db68e7b8131f296e3fd0ca7a696f13e46778cc0ba80。

静态检查工具链明确为 Node v24.19.0，路径 /opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node。只做node --check及AST/text比较，没有使用Node22执行此性能脚本；也不将该静态检查称为Node22或浏览器runtime通过。CI原始版本为Node22.23.3。
