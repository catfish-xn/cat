from pathlib import Path
import difflib
p=Path('/tmp/b8-browser-performance-diagnosis/observability')
a=(p/'verify-m6-performance.original.cjs').read_text();s=a

def replace(old,new):
 global s
 assert s.count(old)==1, (old,s.count(old))
 s=s.replace(old,new)

replace(' let server,browser;',''' // Diagnostics stay outside timed callbacks and preserve the original failure path.
 const diagnosticPrefix='__M6_PERF_DIAGNOSTIC__',diagnosticFile=path.join(output,'diagnostics.jsonl');
 report.diagnostics={schemaVersion:1,file:'diagnostics.jsonl',browserProcessExit:'not exposed by the public Browser API returned by chromium.launch',events:[],writeErrors:[]};
 let diagnosticStage='setup',diagnosticCleanupStarted=false;
 const diagnostic=(event,details={})=>{
  const entry={sequence:report.diagnostics.events.length,event,at:new Date().toISOString(),elapsedMs:performance.now()-started,stage:diagnosticStage,cleanupStarted:diagnosticCleanupStarted,details};
  report.diagnostics.events.push(entry);
  try{fs.writeFileSync(diagnosticFile,JSON.stringify(entry)+'\\n',{flag:entry.sequence===0?'w':'a'});}
  catch(error){report.diagnostics.writeErrors.push({sequence:entry.sequence,message:String(error)});}
  console.log(diagnosticPrefix+JSON.stringify(entry));
 };
 const diagnosticPhase=(stage,details={})=>{diagnosticStage=stage;diagnostic('stage',details);};
 process.once('exit',code=>diagnostic('process-exit',{processKind:'node',pid:process.pid,exitCode:code}));
 diagnosticPhase('setup');
 let server,browser;''')
replace("  browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||undefined,headless:true,args:['--no-sandbox']});report.browser=browser.version();const page=await browser.newPage();report.errors=[];page.on('pageerror',error=>report.errors.push(error.message));page.on('console',message=>{if(message.type()==='error')report.errors.push(message.text());});await page.goto(`${server.resolvedUrls.local[0]}__m6_perf`);", """  diagnosticPhase('browser-launch');
  browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||undefined,headless:true,args:['--no-sandbox']});report.browser=browser.version();
  browser.on('disconnected',()=>diagnostic('browser-disconnected',{connected:browser.isConnected()}));
  diagnosticPhase('page-create');const page=await browser.newPage();
  page.on('crash',()=>diagnostic('page-crash',{closed:page.isClosed(),browserConnected:browser.isConnected()}));
  report.errors=[];page.on('pageerror',error=>report.errors.push(error.message));page.on('console',message=>{if(message.type()==='error')report.errors.push(message.text());});
  page.on('console',message=>{
   const text=message.text();if(message.type()!=='log'||!text.startsWith(diagnosticPrefix))return;
   try{const {stage,...details}=JSON.parse(text.slice(diagnosticPrefix.length));diagnosticPhase(stage,details);}
   catch(error){diagnostic('invalid-browser-marker',{message:String(error)});}
  });
  diagnosticPhase('page-goto');await page.goto(`${server.resolvedUrls.local[0]}__m6_perf`);
  diagnosticPhase('measurements-requested');""")
replace('  report.measurements=await page.evaluate(async fixtures=>{','''  report.measurements=await page.evaluate(async fixtures=>{
   const mark=(stage,details={})=>console.log('__M6_PERF_DIAGNOSTIC__'+JSON.stringify({stage,browserPerformanceMs:performance.now(),...details}));
   mark('measurements-entered');''')
replace('   const limits=await import(\'/src/m6/limits.ts\');const {complete,current,record,fullLoad}=fixtures;','''   const limits=await import('/src/m6/limits.ts');const {complete,current,record,fullLoad}=fixtures;
   mark('imports-complete',{completedBattles:complete.battles.length,currentCompletedBattles:current.battles.length,currentCombatId:current.currentBattle?.combatId,recordCombatId:record.combatId});''')
replace('   const currentHistory=new BattleHistory(current.runId,current.battles,current.currentBattle);', '''   mark('current-history-start');
   const currentHistory=new BattleHistory(current.runId,current.battles,current.currentBattle);
   mark('current-history-complete');''')
replace('    if(!fullCaptureMeasured)measureFullCapture();', '''    mark('full-capture-start');
    if(!fullCaptureMeasured)measureFullCapture();
    mark('full-capture-complete');
    mark('current-validation-start');''')
replace('    else await validateFile(exportFile(current),validateBattleCollection);', '''    else await validateFile(exportFile(current),validateBattleCollection);
    mark('current-validation-complete',{deferred:current.battles.length+(current.currentBattle?1:0)>limits.MAX_BATTLE_RECORDS});''')
replace("     measure('firstSeek',()=>{playback=new PlaybackSession(record);playback.seek(record.endTick);});", """     mark('first-seek-start',{repeat});
     measure('firstSeek',()=>{playback=new PlaybackSession(record);playback.seek(record.endTick);});
     mark('first-seek-complete',{repeat});""")
replace("     playback.dispose();", """     mark('cached-seeks-complete',{repeat});
     playback.dispose();""")
replace('    let stats=emptyStats(record.runId,record.combatId),cursor=0;', '''    mark('stats-start');
    let stats=emptyStats(record.runId,record.combatId),cursor=0;''')
replace("    if(JSON.stringify(stats)!==JSON.stringify(aggregateStats(record.runId,record.combatId,record.events)))throw Error('incremental stats mismatch');", """    if(JSON.stringify(stats)!==JSON.stringify(aggregateStats(record.runId,record.combatId,record.events)))throw Error('incremental stats mismatch');
    mark('stats-complete');""")
replace("   }finally{coordinator?.dispose();repository.close();await new Promise(resolve=>{const r=indexedDB.deleteDatabase(dbName);r.onsuccess=r.onerror=r.onblocked=resolve;});}", """   }finally{mark('measurements-cleanup-start');coordinator?.dispose();repository.close();await new Promise(resolve=>{const r=indexedDB.deleteDatabase(dbName);r.onsuccess=r.onerror=r.onblocked=resolve;});mark('measurements-cleanup-complete');}""")
replace('  for(const entry of report.measurements.skipped)console.log', "  diagnosticPhase('measurements-returned');\n  for(const entry of report.measurements.skipped)console.log")
replace('  // Warm constructors/listeners/code before establishing the lifecycle baseline.', "  diagnosticPhase('lifecycle-start');\n  // Warm constructors/listeners/code before establishing the lifecycle baseline.")
replace('  // Separate genuine <=30-battle import gate, AFTER the unchanged independent', "  diagnosticPhase('lifecycle-complete');\n  // Separate genuine <=30-battle import gate, AFTER the unchanged independent")
replace('  report.boundedImport=await page.evaluate(async fixtures=>{', "  diagnosticPhase('bounded-import-start');\n  report.boundedImport=await page.evaluate(async fixtures=>{")
replace('  assertBoundedImportGate(report.boundedImport', "  diagnosticPhase('bounded-import-returned');\n  assertBoundedImportGate(report.boundedImport")
replace("report.loadAtEnd=os.loadavg();fs.writeFileSync(path.join(output,'manifest.json')", "report.loadAtEnd=os.loadavg();diagnosticCleanupStarted=true;diagnosticPhase('script-cleanup-start',{failureRecorded:Boolean(report.failure)});fs.writeFileSync(path.join(output,'manifest.json')")
(p/'verify-m6-performance.candidate.cjs').write_text(s)
(p/'observability.patch').write_text(''.join(difflib.unified_diff(a.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='a/scripts/verify-m6-performance.cjs',tofile='b/scripts/verify-m6-performance.cjs')))
