from pathlib import Path
import json,hashlib
root=Path('/tmp/b8-tg43-current-segmented'); r=json.loads((root/'segmented-results.json').read_text());old=json.loads((root/'prior-coverage-map.json').read_text());original37=json.loads(Path('/tmp/b8-timeout-fix/tg/original-segmented.json').read_text())
s=r['sums'];ms=lambda key:s[key]['ms']
groups={
 'planning512AndSelect35':ms('planning.candidates512')+ms('planning.select'),
 'publicEquippedPreparationIncludingHelperAssertions':ms('prep.equippedInclusive'),
 'serialize71IncludingRawValidation':sum(v['ms'] for k,v in s.items() if k.startswith('serialize.')),
 'explicitRestore70StringPlus1RawShield':sum(v['ms'] for k,v in s.items() if k.startswith('restore.')),
 'combatStart35AndTicks175':sum(v['ms'] for k,v in s.items() if k.startswith('combat.')),
 'outsidePreparationAssertionsExclusive':sum(v['ms'] for k,v in s.items() if k.startswith('assert.') and k not in ('assert.prepLevel','assert.shieldRejectInclusive'))+ms('assert.shieldRejectInclusive')-ms('restore.shieldRaw'),
 'shieldJsonParse':ms('shield.jsonParse')
}
groups['unclassifiedInstrumentationAndBookkeeping']=r['wallMs']-sum(groups.values())
routeMap={x['seed']:x for x in old['greedy']};originalMap={x['seed']:x for x in original37['records']}
checks={
 'routeCount35':r['routeCount']==35,
 'definitionCount43':len(r['coverage'])==43,
 'coverageMatchesPriorDefinitionPool':r['coverage']==old['coverage'],
 'orderedSeedIndicesMatchPriorGreedy':[x['seedIndex'] for x in r['routes']]==old['newOrder'],
 'allSeedAndChildPairsMatchPriorGreedy':all(x['matchSeed']==routeMap[x['seedIndex']]['matchSeed'] and x['children']==routeMap[x['seedIndex']]['children'] and x['boundChildren']==x['children'] for x in r['routes']),
 'allOpeningTickTriplesMatchOriginal37Routes':all(x['openingTicks']==originalMap[x['seedIndex']]['openingTicks'] for x in r['routes']),
 'allRoutesRound2_5':all(x['roundId']=='2-5' for x in r['routes']),
 'shieldSeed123Crownguard':[{'seedIndex':x['seedIndex'],'shield':x['shieldChild']} for x in r['routes'] if 'shieldChild' in x]==[{'seedIndex':123,'shield':'crownguard'}],
 'allOriginalAssertionsCompleted':r['allOriginalAssertionsCompleted'],
 'all35MatchSeedsUnique':len(set(x['matchSeed'] for x in r['routes']))==35,
 'noSelectedMatchSeed42':all(x['matchSeed']!=42 for x in r['routes']),
}
repo=Path('/workspace/scratch/2d61d723fa5a/cat-b8-phase2');mirror=root/'mirror'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=sorted(p.relative_to(repo) for p in (repo/'src').rglob('*') if p.is_file())+[Path(v) for v in ['tests/fixtures/b8-public-equipment.ts','tests/match-helpers.ts','vite.config.ts','package.json','package-lock.json']]
checks['allProductionAndHelperToolchainFilesUnchangedInMirror']=all(h(repo/p)==h(mirror/p) for p in paths)
beforeHashes=dict(line.split('  ',1)[::-1] for line in (root/'source-before.sha256').read_text().splitlines())
afterHashes=dict(line.split('  ',1)[::-1] for line in (root/'source-after.sha256').read_text().splitlines())
checks['all1282OriginalTrackedHashesUnchanged']=all(afterHashes.get(path)==digest for path,digest in beforeHashes.items())
assert all(checks.values()),checks
summary={'checks':checks,'wallMs':r['wallMs'],'groups':{k:{'ms':v,'percent':v/r['wallMs']*100} for k,v in groups.items()},'openingBattleCount':35*3,'openingCombatTicks':sum(sum(x['openingTicks']) for x in r['routes']),'assertionCalls':r['assertionCalls'],'canonicalOrderedSeedPairSha256':hashlib.sha256(json.dumps(old['greedy'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),'mirrorUnchangedFileCount':len(paths),'concurrentAdditionalTrackedDocFiles':[p for p in afterHashes if p not in beforeHashes],'notes':['No second effective test run. Two launcher failures occurred before Vitest could run; retained in prelaunch-* directories.','Remote commit object 3dc3dd2d634cc64e716630c9a1ff53d65953ff60 unavailable locally; no remote-tree equivalence claimed.']}
(root/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
(root/'mirror-unchanged-files.sha256').write_text(''.join(f'{h(mirror/p)}  {p}\n' for p in paths))
print(json.dumps(summary,indent=2))
