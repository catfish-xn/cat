from pathlib import Path
import re,json,hashlib
root=Path('/tmp/b8-tg43-current-segmented')
p=root/'mirror/tests/m8-b5-temporary.test.ts'
s=p.read_text()
original=s
start=s.index("  it('all 43 eligible child definitions bind through real Match snapshots and restore', () => {")
end=s.index("  it('combat restore rejects a forged temporary program parent chain'",start)
case=s[start:end]
pre=s[:start]
post=s[end:]
def once(txt,a,b):
    assert txt.count(a)==1,(a,txt.count(a))
    return txt.replace(a,b)
pre=once(pre,"let state = publicEquipmentPreparation(['gloves', 'gloves'], { seed });", "let state = __tgMeasure('prep.opening', () => publicEquipmentPreparation(['gloves', 'gloves'], { seed }));")
pre=once(pre,"state = accepted(combineItems(state, 'item-1', 'item-2'));", "state = __tgMeasure('prep.combine', () => accepted(combineItems(state, 'item-1', 'item-2')));")
# Only the first helper, not unrelated test cases, is edited.
a=pre.index('function inventoryAtRound('); b=pre.index('function inventory(level',a)
helper=pre[a:b]
helper=helper.replace('state = resolvePublicEquipmentChoices(state);', "state = __tgMeasure('prep.resolveChoices', () => resolvePublicEquipmentChoices(state));")
helper=once(helper,"state = finishPublicEquipmentBattle(state);", "state = __tgMeasure('prep.advanceBattle', () => finishPublicEquipmentBattle(state));")
helper=once(helper,"state = accepted(nextRound(state, state.round));", "state = __tgMeasure('prep.advanceNextRound', () => accepted(nextRound(state, state.round)));")
helper=once(helper,"return resolvePublicEquipmentChoices(state);", "return __tgMeasure('prep.resolveChoices', () => resolvePublicEquipmentChoices(state));")
pre=pre[:a]+helper+pre[b:]
a=pre.index('function inventory(level');b=pre.index('/** Deliberately synthetic',a)
helper=pre[a:b]
helper=once(helper,'state = accepted(buyXp(state));', "state = __tgMeasure('prep.buyXp', () => accepted(buyXp(state)));")
helper=once(helper,'expect(state.level).toBe(level);', "__tgMeasure('assert.prepLevel', () => expect(state.level).toBe(level));")
helper=once(helper,"return accepted(deployMatchUnit(state, 'unit-1', { kind: 'board', cell: { col: 1, row: 4 } }));", "return __tgMeasure('prep.deploy', () => accepted(deployMatchUnit(state, 'unit-1', { kind: 'board', cell: { col: 1, row: 4 } })));")
# Keep inventory evaluated before the equip-only timer to avoid nested helper timing pollution.
helper=once(helper,"function equipped(level = 3, seed = 42): MatchState { return accepted(equipItem(inventory(level, seed), 'item-3', 'unit-1', 0)); }", "function equipped(level = 3, seed = 42): MatchState { const state = inventory(level, seed); return __tgMeasure('prep.equip', () => accepted(equipItem(state, 'item-3', 'unit-1', 0))); }")
pre=pre[:a]+helper+pre[b:]
case=once(case,'    const candidates = Array.from({ length: 512 }, (_, seed) => {', "    const candidates = __tgMeasure('planning.candidates512', () => Array.from({ length: 512 }, (_, seed) => {")
case=once(case,'      return { matchSeed, children: planned.rolls[0].children };\n    });', '      return { matchSeed, children: planned.rolls[0].children };\n    }));')
case=once(case,'const selected = candidates.reduce((best, candidate) => additions(candidate) > additions(best) ? candidate : best);', "const selected = __tgMeasure('planning.select', () => candidates.reduce((best, candidate) => additions(candidate) > additions(best) ? candidate : best));")
case=once(case,'      expect(additions(selected)).toBeGreaterThan(0);', "      __tgMeasure('assert.selection', () => expect(additions(selected)).toBeGreaterThan(0));")
case=once(case,'      const { matchSeed, children } = selected;', "      const { matchSeed, children } = selected;\n      __tgRoute = { matchSeed, seedIndex: candidates.indexOf(selected), children: [...children], sums: {} };\n      __tgRoutes.push(__tgRoute);\n      const __tgRouteStart = performance.now();")
case=once(case,'      let state = equipped(6, matchSeed);', "      let state = __tgMeasure('prep.equippedInclusive', () => equipped(6, matchSeed));\n      __tgRoute.openingTicks = state.roundResults.slice(0, 3).map(result => result.combatTicks);\n      __tgRoute.roundId = state.roundDefinitionId;\n      __tgRoute.boundChildren = pair(state);")
case=once(case,'      expect(pair(state)).toEqual(children);', "      __tgMeasure('assert.boundPair', () => expect(pair(state)).toEqual(children));")
case=once(case,'      state = accepted(startMatchCombat(state));', "      state = __tgMeasure('combat.start', () => accepted(startMatchCombat(state)));")
case=once(case,'      expect(restoreMatch(serializeMatch(state))).toEqual(state);', "      const __tgStartSave = __tgMeasure('serialize.start', () => serializeMatch(state));\n      const __tgStartRestored = __tgMeasure('restore.startString', () => restoreMatch(__tgStartSave));\n      __tgMeasure('assert.startEquality', () => expect(__tgStartRestored).toEqual(state));")
case=once(case,'        const corrupt = JSON.parse(serializeMatch(state));', "        const __tgShieldSave = __tgMeasure('serialize.shield', () => serializeMatch(state));\n        const corrupt = __tgMeasure('shield.jsonParse', () => JSON.parse(__tgShieldSave));")
case=once(case,"        expect(() => restoreMatch(corrupt)).toThrow('Invalid Match save: shield projection');", "        __tgMeasure('assert.shieldRejectInclusive', () => expect(() => __tgMeasure('restore.shieldRaw', () => restoreMatch(corrupt))).toThrow('Invalid Match save: shield projection'));")
case=once(case,'        shieldChildren.push(shield.source.definitionId);', '        shieldChildren.push(shield.source.definitionId);\n        __tgRoute.shieldChild = shield.source.definitionId;')
case=once(case,"      for (let i = 0; i < 3 && state.phase === 'combat'; i++) state = stepMatch(state).state;", "      for (let i = 0; i < 3 && state.phase === 'combat'; i++) state = __tgMeasure('combat.threeTicks', () => stepMatch(state)).state;")
case=once(case,'      const restored = restoreMatch(serializeMatch(state));', "      const __tgAfterSave = __tgMeasure('serialize.afterTicks', () => serializeMatch(state));\n      const restored = __tgMeasure('restore.afterTicksString', () => restoreMatch(__tgAfterSave));")
case=once(case,'      expect(stepMatch(restored)).toEqual(stepMatch(state));', "      const __tgRestoredNext = __tgMeasure('combat.stepRestored', () => stepMatch(restored));\n      const __tgOriginalNext = __tgMeasure('combat.stepOriginal', () => stepMatch(state));\n      __tgMeasure('assert.nextStepEquality', () => expect(__tgRestoredNext).toEqual(__tgOriginalNext));\n      __tgRoute.wallMs = performance.now() - __tgRouteStart;\n      __tgRoute = undefined;")
final_assertions="""    expect(seen.size).toBe(43);
    expect([...seen].sort()).toEqual([...TEMPORARY_EQUIPMENT_POOL.completed, ...TEMPORARY_EQUIPMENT_POOL.components].map(item => item.definitionId).sort());
    expect(publicRoutes).toBe(35); // One completed child per level-six roll is the lower bound.
    expect(shieldChildren).toEqual(['crownguard']); // Keep the corruption branch non-vacuous.
"""
case=once(case,final_assertions,"    __tgMeasure('assert.finalCoverage', () => {\n"+final_assertions+"    });\n    __tgCoverage = [...seen].sort();\n    __tgAllAssertionsCompleted = true;\n")
case=once(case,"restore', () => {\n", "restore', () => {\n    __tgEnabled = true;\n    const __tgCaseStart = performance.now(), __tgCpuStart = process.cpuUsage();\n    try {\n")
assert case.endswith('  });\n')
case=case[:-len('  });\n')]+"""    } finally {
      const wallMs = performance.now() - __tgCaseStart;
      const cpuMicros = process.cpuUsage(__tgCpuStart);
      __tgEnabled = false;
      const summary = { node: process.version, wallMs, cpuMicros, assertionCalls: expect.getState().assertionCalls,
        allOriginalAssertionsCompleted: __tgAllAssertionsCompleted, routeCount: __tgRoutes.length,
        coverage: __tgCoverage, sums: __tgSums, routes: __tgRoutes,
        notes: ['Instrumented diagnostic only. Default 5000ms timeout unchanged.',
          'serializeMatch includes full restoreMatch(raw state) validation; no raw TG/Herald exception.',
          'prep.equippedInclusive and assert.shieldRejectInclusive are nested totals; do not add them to their children.'] };
      __tgWriteFileSync('/tmp/b8-tg43-current-segmented/segmented-results.json', JSON.stringify(summary, null, 2));
      console.log('TG43_SEGMENTED_RESULT ' + JSON.stringify(summary));
    }
  });
"""
insert="""import { writeFileSync as __tgWriteFileSync } from 'node:fs';
import { performance } from 'node:perf_hooks';
type __TgMeasure = { ms: number; calls: number };
let __tgEnabled = false;
let __tgRoute: any;
let __tgCoverage: string[] = [];
let __tgAllAssertionsCompleted = false;
const __tgSums: Record<string, __TgMeasure> = {};
const __tgRoutes: any[] = [];
function __tgMeasure<T>(name: string, action: () => T): T {
  if (!__tgEnabled) return action();
  const start = performance.now();
  try { return action(); }
  finally {
    const ms = performance.now() - start;
    const total = __tgSums[name] ??= { ms: 0, calls: 0 }; total.ms += ms; total.calls++;
    if (__tgRoute) { const routeTotal = __tgRoute.sums[name] ??= { ms: 0, calls: 0 }; routeTotal.ms += ms; routeTotal.calls++; }
  }
}
"""
s=insert+pre+case+post
p.write_text(s)
(root/'instrumented-test.ts').write_text(s)
summary={'originalDirectExpectCount':original.count('expect('),'instrumentedDirectExpectCount':s.count('expect('),'untouchedSuffix':s.endswith(post),'originalTestSha256':hashlib.sha256(original.encode()).hexdigest(),'instrumentedTestSha256':hashlib.sha256(s.encode()).hexdigest()}
assert summary['originalDirectExpectCount']==summary['instrumentedDirectExpectCount']
(root/'instrumentation-check.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
