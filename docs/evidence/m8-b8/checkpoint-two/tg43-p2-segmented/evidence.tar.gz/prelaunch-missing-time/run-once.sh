#!/usr/bin/env bash
set -uo pipefail
ROOT=/tmp/b8-tg43-current-segmented
export PATH=/tmp/b7-npm-cache/_npx/d18f28baf1132559/node_modules/node/bin:$PATH
cd "$ROOT/mirror"
{
  printf 'Diagnostic source mirror only; no timeout or worker override.\n'
  printf 'Command: npm test -- tests/m8-b5-temporary.test.ts -t "all 43 eligible child definitions bind through real Match snapshots and restore"\n'
  printf 'Node: '; node --version
  printf 'npm: '; npm --version
  node -e 'const os=require("node:os"); console.log(JSON.stringify({cpu:os.cpus().map(c=>({model:c.model,speed:c.speed})),logicalCpus:os.cpus().length,availableParallelism:os.availableParallelism(),totalMemory:os.totalmem(),freeMemory:os.freemem(),loadavg:os.loadavg(),platform:os.platform(),release:os.release(),versions:process.versions,env:Object.fromEntries(["CI","NODE_OPTIONS","VITEST_MAX_WORKERS","VITEST_MIN_WORKERS","GITHUB_ACTIONS"].map(k=>[k,process.env[k]??null])),vitest:require("vitest/package.json").version,vite:require("vite/package.json").version},null,2))'
  sha256sum vite.config.ts package.json package-lock.json tests/fixtures/b8-public-equipment.ts tests/match-helpers.ts src/simulation/serialization.ts
  printf 'Start timestamp: '; date -u +%FT%T.%NZ
} > "$ROOT/environment-and-command.txt" 2>&1
/usr/bin/time -v npm test -- tests/m8-b5-temporary.test.ts -t "all 43 eligible child definitions bind through real Match snapshots and restore" > "$ROOT/single-run.log" 2> "$ROOT/single-run.stderr.log"
exit_code=$?
printf '%s\n' "$exit_code" > "$ROOT/single-run.exit"
printf 'End timestamp: ' >> "$ROOT/environment-and-command.txt"; date -u +%FT%T.%NZ >> "$ROOT/environment-and-command.txt"
exit 0
